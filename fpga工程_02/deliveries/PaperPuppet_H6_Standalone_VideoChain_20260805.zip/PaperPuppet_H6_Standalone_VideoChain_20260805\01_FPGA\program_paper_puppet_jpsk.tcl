set script_dir [file dirname [file normalize [info script]]]
set bitstream [file normalize [file join $script_dir "ov5640_hdmi_1080p.runs" "imple_1" "ov5640_hdmi_1080p.jpsk"]]

if {![file exists $bitstream]} {
    puts stderr "Missing bitstream: $bitstream"
    exit 2
}

puts "Programming EQ6HL130 with $bitstream"
catch {send_rawpsk_usb2cable2jtag2fpga $bitstream EQ6HL130} result
puts $result
if {[string first "JTAG down FPGA successful" $result] < 0} {
    exit 1
}
exit 0
