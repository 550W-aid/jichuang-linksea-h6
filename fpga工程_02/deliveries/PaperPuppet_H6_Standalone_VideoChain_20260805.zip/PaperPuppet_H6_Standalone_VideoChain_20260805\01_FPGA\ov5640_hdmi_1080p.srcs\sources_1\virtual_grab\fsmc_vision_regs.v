`timescale 1ns / 1ps

module fsmc_vision_regs #(
    parameter integer HEARTBEAT_DIV = 5_000_000,
    parameter         WRITE_ENABLE  = 1'b1
) (
    input  wire        sys_clk,
    input  wire        rst_n,
    input  wire [7:0]  fsmc_addr,
    inout  wire [15:0] fsmc_data,
    input  wire        fsmc_cs_n,
    input  wire        fsmc_rd_n,
    input  wire        fsmc_wr_n,
    output wire        fsmc_int,

    input  wire        snapshot_commit_i,
    input  wire [15:0] snapshot_status_i,
    input  wire [31:0] snapshot_capture_ms_i,
    input  wire [15:0] snapshot_laser_x_i,
    input  wire [15:0] snapshot_laser_y_i,
    input  wire [15:0] snapshot_target_x_i,
    input  wire [15:0] snapshot_target_y_i,
    input  wire [15:0] snapshot_error_x_i,
    input  wire [15:0] snapshot_error_y_i,
    input  wire [15:0] snapshot_target_w_i,
    input  wire [15:0] snapshot_target_h_i,
    input  wire [15:0] snapshot_quality_i,
    input  wire [15:0] snapshot_roi_left_i,
    input  wire [15:0] snapshot_roi_right_i,
    input  wire [15:0] snapshot_roi_top_i,
    input  wire [15:0] snapshot_roi_bottom_i,
    input  wire [15:0] snapshot_laser_pixels_i,
    input  wire [31:0] snapshot_target_score_i,
    input  wire [15:0] snapshot_frame_id_i,
    input  wire        frame_timeout_fault_i
);

localparam integer SNAPSHOT_WIDTH = 320;

reg  [2:0]  write_strobe_sync_r;
reg         write_mailbox_valid_r;
reg  [7:0]  write_mailbox_addr_r;
reg  [15:0] write_mailbox_data_r;

reg  [31:0] heartbeat_div_count_r;
reg  [15:0] heartbeat_binary_r;

reg  [4:0]  fault_status_r;
reg  [15:0] write_overrun_count_r;
reg  [15:0] snapshot_overrun_count_r;
reg  [15:0] protocol_fault_count_r;
reg         frame_timeout_fault_d_r;

reg  [15:0] sequence_r;
reg  [15:0] last_ack_r;
reg         snapshot_outstanding_r;
reg         pending_valid_r;
reg  [SNAPSHOT_WIDTH-1:0] published_snapshot_r;
reg  [SNAPSHOT_WIDTH-1:0] pending_snapshot_r;

reg  [15:0] read_data_r;

wire [SNAPSHOT_WIDTH-1:0] assembled_snapshot_w;
wire        write_selected_edge_w;
wire        write_overrun_event_w;
wire        write_event_w;
wire        write_control_w;
wire        write_ack_w;
wire        write_illegal_w;
wire        control_clear_snapshot_w;
wire        control_clear_fatal_w;
wire        control_clear_all_w;
wire        control_valid_w;
wire        ack_accept_w;
wire        ack_duplicate_w;
wire        ack_invalid_w;
wire        protocol_fault_event_w;
wire        snapshot_overrun_event_w;
wire        frame_timeout_event_w;
wire [15:0] heartbeat_gray_w;
wire [15:0] write_overrun_count_gray_w;
wire [15:0] snapshot_overrun_count_gray_w;
wire [15:0] protocol_fault_count_gray_w;

function [15:0] saturating_increment;
    input [15:0] value;
    begin
        saturating_increment = (value == 16'hffff) ? 16'hffff
                                                   : value + 16'd1;
    end
endfunction

assign assembled_snapshot_w = {
    snapshot_frame_id_i,
    snapshot_target_score_i[31:16],
    snapshot_target_score_i[15:0],
    snapshot_laser_pixels_i,
    snapshot_roi_bottom_i,
    snapshot_roi_top_i,
    snapshot_roi_right_i,
    snapshot_roi_left_i,
    snapshot_quality_i,
    snapshot_target_h_i,
    snapshot_target_w_i,
    snapshot_error_y_i,
    snapshot_error_x_i,
    snapshot_target_y_i,
    snapshot_target_x_i,
    snapshot_laser_y_i,
    snapshot_laser_x_i,
    snapshot_capture_ms_i[31:16],
    snapshot_capture_ms_i[15:0],
    snapshot_status_i
};

// WR_N is synchronized as data, never used as a fabric clock. The falling edge
// reaches this detector on the third 50 MHz sample, inside the FSMC 40-60 ns
// address/data capture window.
assign write_selected_edge_w = WRITE_ENABLE &&
                               write_strobe_sync_r[2] &&
                               !write_strobe_sync_r[1] &&
                               !fsmc_cs_n && fsmc_rd_n;
assign write_overrun_event_w = write_selected_edge_w &&
                                write_mailbox_valid_r;

// The edge is detected on the third sys_clk sample, 40-60 ns after WR_N falls
// for a 50 MHz sys_clk. Address remains stable for the firmware write interval;
// data is sampled while FSMC still drives its 95.24 ns data phase.
always @(posedge sys_clk or negedge rst_n) begin
    if (!rst_n) begin
        write_strobe_sync_r <= 3'b111;
        write_mailbox_valid_r <= 1'b0;
        write_mailbox_addr_r <= 8'd0;
        write_mailbox_data_r <= 16'd0;
    end else begin
        write_strobe_sync_r <= {write_strobe_sync_r[1:0], fsmc_wr_n};

        if (write_mailbox_valid_r)
            write_mailbox_valid_r <= 1'b0;

        if (write_selected_edge_w && !write_mailbox_valid_r) begin
            write_mailbox_addr_r  <= fsmc_addr;
            write_mailbox_data_r  <= fsmc_data;
            write_mailbox_valid_r <= 1'b1;
        end
    end
end

assign write_event_w   = write_mailbox_valid_r;
assign write_control_w = write_event_w && (write_mailbox_addr_r == 8'd30);
assign write_ack_w     = write_event_w && (write_mailbox_addr_r == 8'd31);
assign write_illegal_w = write_event_w && !write_control_w && !write_ack_w;

assign control_clear_snapshot_w = write_control_w &&
                                  (write_mailbox_data_r == 16'ha501);
assign control_clear_fatal_w    = write_control_w &&
                                  (write_mailbox_data_r == 16'ha502);
assign control_clear_all_w      = write_control_w &&
                                  (write_mailbox_data_r == 16'ha503);
assign control_valid_w = control_clear_snapshot_w ||
                         control_clear_fatal_w ||
                         control_clear_all_w;

assign ack_accept_w = write_ack_w && snapshot_outstanding_r &&
                      (write_mailbox_data_r == sequence_r);
assign ack_duplicate_w = write_ack_w && !snapshot_outstanding_r &&
                         (write_mailbox_data_r == last_ack_r);
assign ack_invalid_w = write_ack_w && !ack_accept_w && !ack_duplicate_w;
assign protocol_fault_event_w = write_illegal_w || ack_invalid_w ||
                                (write_control_w && !control_valid_w);
assign snapshot_overrun_event_w = snapshot_commit_i && pending_valid_r;
assign frame_timeout_event_w = frame_timeout_fault_i &&
                               !frame_timeout_fault_d_r;

always @(posedge sys_clk or negedge rst_n) begin
    if (!rst_n) begin
        heartbeat_div_count_r <= 32'd0;
        heartbeat_binary_r    <= 16'd0;
    end else if (HEARTBEAT_DIV <= 1) begin
        heartbeat_div_count_r <= 32'd0;
        heartbeat_binary_r    <= heartbeat_binary_r + 16'd1;
    end else if (heartbeat_div_count_r == HEARTBEAT_DIV - 1) begin
        heartbeat_div_count_r <= 32'd0;
        heartbeat_binary_r    <= heartbeat_binary_r + 16'd1;
    end else begin
        heartbeat_div_count_r <= heartbeat_div_count_r + 32'd1;
    end
end

assign heartbeat_gray_w = heartbeat_binary_r ^ (heartbeat_binary_r >> 1);
assign write_overrun_count_gray_w = write_overrun_count_r ^
                                    (write_overrun_count_r >> 1);
assign snapshot_overrun_count_gray_w = snapshot_overrun_count_r ^
                                       (snapshot_overrun_count_r >> 1);
assign protocol_fault_count_gray_w = protocol_fault_count_r ^
                                     (protocol_fault_count_r >> 1);

always @(posedge sys_clk or negedge rst_n) begin
    if (!rst_n) begin
        fault_status_r            <= 5'd0;
        write_overrun_count_r     <= 16'd0;
        snapshot_overrun_count_r  <= 16'd0;
        protocol_fault_count_r    <= 16'd0;
        frame_timeout_fault_d_r   <= 1'b0;
    end else begin
        frame_timeout_fault_d_r <= frame_timeout_fault_i;

        if (control_clear_snapshot_w || control_clear_all_w) begin
            fault_status_r[0]           <= 1'b0;
            snapshot_overrun_count_r    <= 16'd0;
        end

        if (control_clear_fatal_w || control_clear_all_w) begin
            fault_status_r[4:1]       <= 4'b0000;
            write_overrun_count_r    <= 16'd0;
            protocol_fault_count_r   <= 16'd0;
        end

        if (snapshot_overrun_event_w) begin
            fault_status_r[0]          <= 1'b1;
            snapshot_overrun_count_r   <=
                saturating_increment(snapshot_overrun_count_r);
        end

        if (protocol_fault_event_w) begin
            fault_status_r[1]        <= 1'b1;
            protocol_fault_count_r   <=
                saturating_increment(protocol_fault_count_r);
        end

        if (write_overrun_event_w) begin
            fault_status_r[2]       <= 1'b1;
            write_overrun_count_r   <=
                saturating_increment(write_overrun_count_r);
        end

        if (frame_timeout_event_w)
            fault_status_r[3] <= 1'b1;

        if (write_illegal_w)
            fault_status_r[4] <= 1'b1;
    end
end

always @(posedge sys_clk or negedge rst_n) begin
    if (!rst_n) begin
        sequence_r             <= 16'd0;
        last_ack_r             <= 16'd0;
        snapshot_outstanding_r <= 1'b0;
        pending_valid_r        <= 1'b0;
        published_snapshot_r   <= {SNAPSHOT_WIDTH{1'b0}};
        pending_snapshot_r     <= {SNAPSHOT_WIDTH{1'b0}};
    end else if (ack_accept_w) begin
        last_ack_r             <= sequence_r;
        snapshot_outstanding_r <= 1'b0;
        if (snapshot_commit_i) begin
            pending_snapshot_r <= assembled_snapshot_w;
            pending_valid_r    <= 1'b1;
        end
    end else if (snapshot_outstanding_r) begin
        if (snapshot_commit_i) begin
            pending_snapshot_r <= assembled_snapshot_w;
            pending_valid_r    <= 1'b1;
        end
    end else if (snapshot_commit_i) begin
        published_snapshot_r   <= assembled_snapshot_w;
        sequence_r             <= sequence_r + 16'd1;
        snapshot_outstanding_r <= 1'b1;
        pending_valid_r        <= 1'b0;
    end else if (pending_valid_r) begin
        published_snapshot_r   <= pending_snapshot_r;
        sequence_r             <= sequence_r + 16'd1;
        snapshot_outstanding_r <= 1'b1;
        pending_valid_r        <= 1'b0;
    end
end

always @* begin
    if (fsmc_addr > 8'd31) begin
        read_data_r = 16'hdead;
    end else begin
        case (fsmc_addr)
            8'd0:  read_data_r = 16'h5647;
            8'd1:  read_data_r = 16'h0001;
            8'd2:  read_data_r = published_snapshot_r[15:0];
            8'd3:  read_data_r = sequence_r;
            8'd4:  read_data_r = published_snapshot_r[31:16];
            8'd5:  read_data_r = published_snapshot_r[47:32];
            8'd6:  read_data_r = published_snapshot_r[63:48];
            8'd7:  read_data_r = published_snapshot_r[79:64];
            8'd8:  read_data_r = published_snapshot_r[95:80];
            8'd9:  read_data_r = published_snapshot_r[111:96];
            8'd10: read_data_r = published_snapshot_r[127:112];
            8'd11: read_data_r = published_snapshot_r[143:128];
            8'd12: read_data_r = published_snapshot_r[159:144];
            8'd13: read_data_r = published_snapshot_r[175:160];
            8'd14: read_data_r = published_snapshot_r[191:176];
            8'd15: read_data_r = heartbeat_gray_w;
            8'd16: read_data_r = published_snapshot_r[207:192];
            8'd17: read_data_r = published_snapshot_r[223:208];
            8'd18: read_data_r = published_snapshot_r[239:224];
            8'd19: read_data_r = published_snapshot_r[255:240];
            8'd20: read_data_r = published_snapshot_r[271:256];
            8'd21: read_data_r = published_snapshot_r[287:272];
            8'd22: read_data_r = published_snapshot_r[303:288];
            8'd23: read_data_r = published_snapshot_r[319:304];
            8'd24: read_data_r = {11'd0, fault_status_r};
            8'd25: read_data_r = write_overrun_count_gray_w;
            8'd26: read_data_r = snapshot_overrun_count_gray_w;
            8'd27: read_data_r = protocol_fault_count_gray_w;
            8'd28: read_data_r = 16'h0000;
            8'd29: read_data_r = 16'h0000;
            8'd30: read_data_r = 16'h0000;
            8'd31: read_data_r = last_ack_r;
            default: read_data_r = 16'hdead;
        endcase
    end
end

assign fsmc_data = (rst_n && !fsmc_cs_n && !fsmc_rd_n && fsmc_wr_n)
                 ? read_data_r
                 : 16'hzzzz;
assign fsmc_int = rst_n &&
                  (snapshot_outstanding_r || (|fault_status_r[4:1]));

endmodule
