`timescale 1ns / 1ps

module virtual_grab_detect_top #(
    parameter IMAGE_WIDTH  = 1920,
    parameter IMAGE_HEIGHT = 1080,
    parameter X_WIDTH      = 12,
    parameter Y_WIDTH      = 12,
    parameter CALIB_RED_ROI_MIN_X = 0,
    parameter CALIB_RED_ROI_MAX_X = IMAGE_WIDTH - 1,
    parameter CALIB_RED_ROI_MIN_Y = 0,
    parameter CALIB_RED_ROI_MAX_Y = IMAGE_HEIGHT - 1
) (
    input  wire                 clk,
    input  wire                 rst,
    input  wire                 sof,
    input  wire                 eof,
    input  wire                 pixel_valid,
    input  wire [X_WIDTH-1:0]   pixel_x,
    input  wire [Y_WIDTH-1:0]   pixel_y,
    input  wire [7:0]           pixel_r,
    input  wire [7:0]           pixel_g,
    input  wire [7:0]           pixel_b,
    input  wire                 scene_roi_valid,
    input  wire [X_WIDTH-1:0]   scene_roi_min_x,
    input  wire [X_WIDTH-1:0]   scene_roi_max_x,
    input  wire [Y_WIDTH-1:0]   scene_roi_min_y,
    input  wire [Y_WIDTH-1:0]   scene_roi_max_y,
    output wire [X_WIDTH-1:0]   origin_x,
    output wire [Y_WIDTH-1:0]   origin_y,
    output wire                 green_valid,
    output wire [X_WIDTH-1:0]   green_x,
    output wire [Y_WIDTH-1:0]   green_y,
    output wire                 red_valid,
    output wire [X_WIDTH-1:0]   red_x,
    output wire [Y_WIDTH-1:0]   red_y,
    output wire [X_WIDTH-1:0]   red_min_x,
    output wire [X_WIDTH-1:0]   red_max_x,
    output wire [Y_WIDTH-1:0]   red_min_y,
    output wire [Y_WIDTH-1:0]   red_max_y,
    output wire                 blue_valid,
    output wire [X_WIDTH-1:0]   blue_x,
    output wire [Y_WIDTH-1:0]   blue_y,
    output wire [X_WIDTH-1:0]   blue_min_x,
    output wire [X_WIDTH-1:0]   blue_max_x,
    output wire [Y_WIDTH-1:0]   blue_min_y,
    output wire [Y_WIDTH-1:0]   blue_max_y,
    output wire                 light_valid,
    output wire [X_WIDTH-1:0]   light_x,
    output wire [Y_WIDTH-1:0]   light_y,
    output wire [X_WIDTH-1:0]   light_min_x,
    output wire [X_WIDTH-1:0]   light_max_x,
    output wire [Y_WIDTH-1:0]   light_min_y,
    output wire [Y_WIDTH-1:0]   light_max_y,
    output wire [23:0]          light_pixel_count,
    output wire [23:0]          white_pixel_count,
    output wire [23:0]          green_pixel_count,
    output wire [23:0]          red_pixel_count,
    output wire [23:0]          blue_pixel_count,
    output wire [23:0]          committed_pixel_count,
    output wire [23:0]          live_pixel_count,
    output wire [23:0]          loose_red_pixel_count,
    output wire [7:0]           max_pixel_r,
    output wire [7:0]           max_pixel_g,
    output wire [7:0]           max_pixel_b,
    output wire [7:0]           last_pixel_r,
    output wire [7:0]           last_pixel_g,
    output wire [7:0]           last_pixel_b
);

    wire is_red;
    wire is_green;
    wire is_blue;
    wire is_white;
    wire is_calib_red_core;
    wire is_in_scene_roi;
    wire is_white_in_scene_roi;
    wire is_green_in_scene_roi;
    wire is_blue_in_scene_roi;
    wire is_red_in_calib_roi;
    wire [8:0] calib_diff_rg;
    wire [8:0] calib_diff_rb;
    wire [X_WIDTH:0] green_red_left_candidate_w;
    wire [X_WIDTH:0] green_red_right_candidate_w;
    wire [X_WIDTH:0] green_red_roi_min_x_w;
    wire [X_WIDTH:0] green_red_roi_max_x_w;
    wire [X_WIDTH:0] red_green_left_margin_w;
    wire [X_WIDTH:0] blue_scene_min_x_w;
    wire [X_WIDTH:0] blue_scene_max_x_w;
    wire [Y_WIDTH:0] blue_scene_min_y_w;
    wire [Y_WIDTH:0] blue_scene_max_y_w;
    localparam [X_WIDTH-1:0] CALIB_RED_ROI_MIN_X_W = CALIB_RED_ROI_MIN_X;
    localparam [X_WIDTH-1:0] CALIB_RED_ROI_MAX_X_W = CALIB_RED_ROI_MAX_X;
    localparam [Y_WIDTH-1:0] CALIB_RED_ROI_MIN_Y_W = CALIB_RED_ROI_MIN_Y;
    localparam [Y_WIDTH-1:0] CALIB_RED_ROI_MAX_Y_W = CALIB_RED_ROI_MAX_Y;
    localparam [X_WIDTH:0] RED_GREEN_NEAR_LEFT_MARGIN_W = 13'd320;
    localparam [X_WIDTH:0] RED_GREEN_WIDE_LEFT_MARGIN_W = 13'd620;
    localparam [X_WIDTH:0] RED_GREEN_WIDE_ANCHOR_X_W = 13'd650;
    localparam [X_WIDTH:0] RED_GREEN_RIGHT_MARGIN_W = 13'd220;
    localparam [X_WIDTH:0] BLUE_SCENE_MARGIN_W = 13'd32;
    localparam [Y_WIDTH:0] BLUE_SCENE_MARGIN_H = 13'd32;

    rgb_color_classifier u_classifier (
        .pixel_r(pixel_r),
        .pixel_g(pixel_g),
        .pixel_b(pixel_b),
        .is_red(is_red),
        .is_green(is_green),
        .is_blue(is_blue),
        .is_white(is_white)
    );

    wire white_valid;
    wire [X_WIDTH-1:0] white_center_x;
    wire [Y_WIDTH-1:0] white_center_y;
    wire [23:0] white_count;
    wire [X_WIDTH-1:0] white_min_x;
    wire [X_WIDTH-1:0] white_max_x;
    wire [Y_WIDTH-1:0] white_min_y;
    wire [Y_WIDTH-1:0] white_max_y;
    wire [23:0] green_count;
    wire [23:0] red_selector_count;
    wire [X_WIDTH-1:0] unused_green_min_x;
    wire [X_WIDTH-1:0] unused_green_max_x;
    wire [Y_WIDTH-1:0] unused_green_min_y;
    wire [Y_WIDTH-1:0] unused_green_max_y;
    wire [X_WIDTH:0] origin_x_sum;
    wire [Y_WIDTH:0] origin_y_sum;
    wire loose_red_candidate;
    wire selector_red_candidate;
    wire blue_hand_candidate;
    wire blue_light_candidate;
    wire blue_light_seed_candidate;
    wire blue_light_strong_seed_candidate;
    wire blue_light_hot_candidate;
    wire blue_light_in_roi;
    wire blue_light_ycc_s_ready;
    wire blue_light_ycc_valid;
    wire [23:0] blue_light_ycc_data;
    wire blue_light_ycc_keep;
    wire blue_light_ycc_sof;
    wire blue_light_ycc_eol;
    wire blue_light_ycc_eof;
    wire [7:0] blue_light_luma;
    wire [7:0] blue_light_cb;
    wire [7:0] blue_light_cr;
    wire [23:0] next_pixel_count;
    wire [23:0] next_loose_red_count;
    wire [23:0] next_red_roi_count;
    wire [7:0] next_max_r;
    wire [7:0] next_max_g;
    wire [7:0] next_max_b;
    reg [23:0] pixel_count_acc;
    reg [23:0] pixel_count_committed_reg;
    reg [23:0] loose_red_count_acc;
    reg [23:0] loose_red_count_committed_reg;
    reg [23:0] red_roi_count_acc;
    reg [23:0] red_roi_count_committed_reg;
    reg [7:0] max_r_acc;
    reg [7:0] max_g_acc;
    reg [7:0] max_b_acc;
    reg [7:0] max_r_committed_reg;
    reg [7:0] max_g_committed_reg;
    reg [7:0] max_b_committed_reg;
    reg [7:0] last_r_acc;
    reg [7:0] last_g_acc;
    reg [7:0] last_b_acc;
    reg [7:0] last_r_committed_reg;
    reg [7:0] last_g_committed_reg;
    reg [7:0] last_b_committed_reg;
    reg [X_WIDTH-1:0] blue_light_x_d0_reg;
    reg [X_WIDTH-1:0] blue_light_x_d1_reg;
    reg [Y_WIDTH-1:0] blue_light_y_d0_reg;
    reg [Y_WIDTH-1:0] blue_light_y_d1_reg;
    reg blue_light_sof_d0_reg;
    reg blue_light_sof_d1_reg;
    reg blue_light_eof_d0_reg;
    reg blue_light_eof_d1_reg;

    assign origin_x_sum = {1'b0, white_min_x} + {1'b0, white_max_x};
    assign origin_y_sum = {1'b0, white_min_y} + {1'b0, white_max_y};
    assign origin_x = white_valid ? origin_x_sum[X_WIDTH:1] : (IMAGE_WIDTH / 2);
    assign origin_y = white_valid ? origin_y_sum[Y_WIDTH:1] : (IMAGE_HEIGHT / 2);
    assign white_pixel_count = white_count;
    assign green_pixel_count = green_count;
    assign red_pixel_count = red_roi_count_committed_reg;
    assign committed_pixel_count = pixel_count_committed_reg;
    assign live_pixel_count = pixel_count_acc;
    assign loose_red_pixel_count = loose_red_count_committed_reg;
    assign max_pixel_r = max_r_committed_reg;
    assign max_pixel_g = max_g_committed_reg;
    assign max_pixel_b = max_b_committed_reg;
    assign last_pixel_r = last_r_committed_reg;
    assign last_pixel_g = last_g_committed_reg;
    assign last_pixel_b = last_b_committed_reg;
    assign calib_diff_rg = (pixel_r >= pixel_g) ?
                           ({1'b0, pixel_r} - {1'b0, pixel_g}) :
                           ({1'b0, pixel_g} - {1'b0, pixel_r});
    assign calib_diff_rb = (pixel_r >= pixel_b) ?
                           ({1'b0, pixel_r} - {1'b0, pixel_b}) :
                           ({1'b0, pixel_b} - {1'b0, pixel_r});
    assign is_calib_red_core =
        is_red &&
        (pixel_r >= 8'd110) &&
        (pixel_g <= 8'd85) &&
        (pixel_b <= 8'd90) &&
        (calib_diff_rg >= 9'd55) &&
        (calib_diff_rb >= 9'd55);
    assign is_in_scene_roi =
        scene_roi_valid &&
        (pixel_x >= scene_roi_min_x) &&
        (pixel_x <= scene_roi_max_x) &&
        (pixel_y >= scene_roi_min_y) &&
        (pixel_y <= scene_roi_max_y);
    assign is_white_in_scene_roi = is_white && is_in_scene_roi;
    assign is_green_in_scene_roi = is_green && is_in_scene_roi;
    assign blue_scene_min_x_w = {1'b0, scene_roi_min_x} + BLUE_SCENE_MARGIN_W;
    assign blue_scene_max_x_w =
        ({1'b0, scene_roi_max_x} > BLUE_SCENE_MARGIN_W) ?
        ({1'b0, scene_roi_max_x} - BLUE_SCENE_MARGIN_W) :
        {(X_WIDTH+1){1'b0}};
    assign blue_scene_min_y_w = {1'b0, scene_roi_min_y} + BLUE_SCENE_MARGIN_H;
    assign blue_scene_max_y_w =
        ({1'b0, scene_roi_max_y} > BLUE_SCENE_MARGIN_H) ?
        ({1'b0, scene_roi_max_y} - BLUE_SCENE_MARGIN_H) :
        {(Y_WIDTH+1){1'b0}};
    assign is_blue_in_scene_roi =
        scene_roi_valid &&
        ({1'b0, pixel_x} >= blue_scene_min_x_w) &&
        ({1'b0, pixel_x} <= blue_scene_max_x_w) &&
        ({1'b0, pixel_y} >= blue_scene_min_y_w) &&
        ({1'b0, pixel_y} <= blue_scene_max_y_w) &&
        (pixel_b >= 8'd150) &&
        (pixel_r <= 8'd130) &&
        (pixel_g <= 8'd160) &&
        ({1'b0, pixel_b} >= ({1'b0, pixel_r} + 9'd32)) &&
        ({1'b0, pixel_b} >= ({1'b0, pixel_g} + 9'd10));
    assign blue_hand_candidate = pixel_valid && is_blue_in_scene_roi;

    assign blue_light_luma = blue_light_ycc_data[23:16];
    assign blue_light_cb = blue_light_ycc_data[15:8];
    assign blue_light_cr = blue_light_ycc_data[7:0];
    assign blue_light_in_roi =
        scene_roi_valid &&
        ({1'b0, blue_light_x_d1_reg} >= blue_scene_min_x_w) &&
        ({1'b0, blue_light_x_d1_reg} <= blue_scene_max_x_w) &&
        ({1'b0, blue_light_y_d1_reg} >= blue_scene_min_y_w) &&
        ({1'b0, blue_light_y_d1_reg} <= blue_scene_max_y_w);
    assign blue_light_seed_candidate =
        blue_light_ycc_valid &&
        blue_light_in_roi &&
        (blue_light_luma >= 8'd80) &&
        (blue_light_cb >= 8'd145) &&
        (blue_light_cr <= 8'd145);
    assign blue_light_strong_seed_candidate =
        blue_light_ycc_valid &&
        blue_light_in_roi &&
        (blue_light_luma >= 8'd60) &&
        (blue_light_cb >= 8'd158) &&
        (blue_light_cr <= 8'd145);
    assign blue_light_hot_candidate =
        blue_light_ycc_valid &&
        blue_light_in_roi &&
        (blue_light_luma >= 8'd220) &&
        (blue_light_cb >= 8'd112) &&
        (blue_light_cb <= 8'd160) &&
        (blue_light_cr >= 8'd112) &&
        (blue_light_cr <= 8'd150);
    assign blue_light_candidate =
        blue_light_seed_candidate || blue_light_hot_candidate;

    rgb888_to_ycbcr444_stream_std #(
        .MAX_LANES(1)
    ) u_blue_light_rgb_to_ycbcr (
        .clk(clk),
        .rst_n(~rst),
        .s_valid(pixel_valid),
        .s_ready(blue_light_ycc_s_ready),
        .s_data({pixel_r, pixel_g, pixel_b}),
        .s_keep(1'b1),
        .s_sof(sof),
        .s_eol(1'b0),
        .s_eof(eof),
        .m_valid(blue_light_ycc_valid),
        .m_ready(1'b1),
        .m_data(blue_light_ycc_data),
        .m_keep(blue_light_ycc_keep),
        .m_sof(blue_light_ycc_sof),
        .m_eol(blue_light_ycc_eol),
        .m_eof(blue_light_ycc_eof)
    );

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            blue_light_x_d0_reg <= {X_WIDTH{1'b0}};
            blue_light_x_d1_reg <= {X_WIDTH{1'b0}};
            blue_light_y_d0_reg <= {Y_WIDTH{1'b0}};
            blue_light_y_d1_reg <= {Y_WIDTH{1'b0}};
            blue_light_sof_d0_reg <= 1'b0;
            blue_light_sof_d1_reg <= 1'b0;
            blue_light_eof_d0_reg <= 1'b0;
            blue_light_eof_d1_reg <= 1'b0;
        end else begin
            blue_light_x_d0_reg <= pixel_x;
            blue_light_x_d1_reg <= blue_light_x_d0_reg;
            blue_light_y_d0_reg <= pixel_y;
            blue_light_y_d1_reg <= blue_light_y_d0_reg;
            blue_light_sof_d0_reg <= sof;
            blue_light_sof_d1_reg <= blue_light_sof_d0_reg;
            blue_light_eof_d0_reg <= eof;
            blue_light_eof_d1_reg <= blue_light_eof_d0_reg;
        end
    end

    wire unused_blue_light_ycc_sidebands =
        blue_light_ycc_s_ready ^ blue_light_ycc_keep ^
        blue_light_ycc_sof ^ blue_light_ycc_eol ^ blue_light_ycc_eof;
    assign red_green_left_margin_w =
        ({1'b0, green_x} >= RED_GREEN_WIDE_ANCHOR_X_W) ?
        RED_GREEN_WIDE_LEFT_MARGIN_W :
        RED_GREEN_NEAR_LEFT_MARGIN_W;
    assign green_red_left_candidate_w =
        ({1'b0, green_x} > red_green_left_margin_w) ?
        ({1'b0, green_x} - red_green_left_margin_w) :
        {(X_WIDTH+1){1'b0}};
    assign green_red_right_candidate_w = {1'b0, green_x} + RED_GREEN_RIGHT_MARGIN_W;
    assign green_red_roi_min_x_w =
        green_valid ?
        ((green_red_left_candidate_w > {1'b0, CALIB_RED_ROI_MIN_X_W}) ?
         green_red_left_candidate_w :
         {1'b0, CALIB_RED_ROI_MIN_X_W}) :
        {1'b0, CALIB_RED_ROI_MIN_X_W};
    assign green_red_roi_max_x_w =
        green_valid ?
        ((green_red_right_candidate_w < {1'b0, CALIB_RED_ROI_MAX_X_W}) ?
         green_red_right_candidate_w :
         {1'b0, CALIB_RED_ROI_MAX_X_W}) :
        {1'b0, CALIB_RED_ROI_MAX_X_W};
    assign is_red_in_calib_roi =
        loose_red_candidate &&
        is_in_scene_roi &&
        ({1'b0, pixel_x} >= green_red_roi_min_x_w) &&
        ({1'b0, pixel_x} <= green_red_roi_max_x_w) &&
        (pixel_y >= CALIB_RED_ROI_MIN_Y_W) &&
        (pixel_y <= CALIB_RED_ROI_MAX_Y_W);

    assign loose_red_candidate =
        pixel_valid &&
        (pixel_r >= 8'd65) &&
        (pixel_g <= 8'd170) &&
        (pixel_b <= 8'd170) &&
        ({1'b0, pixel_r} >= ({1'b0, pixel_g} + 9'd30)) &&
        ({1'b0, pixel_r} >= ({1'b0, pixel_b} + 9'd25));
    assign selector_red_candidate =
        pixel_valid &&
        (pixel_r >= 8'd80) &&
        (pixel_g <= 8'd145) &&
        (pixel_b <= 8'd150) &&
        ({1'b0, pixel_r} >= ({1'b0, pixel_g} + 9'd35)) &&
        ({1'b0, pixel_r} >= ({1'b0, pixel_b} + 9'd30)) &&
        is_in_scene_roi &&
        ({1'b0, pixel_x} >= green_red_roi_min_x_w) &&
        ({1'b0, pixel_x} <= green_red_roi_max_x_w) &&
        (pixel_y >= CALIB_RED_ROI_MIN_Y_W) &&
        (pixel_y <= CALIB_RED_ROI_MAX_Y_W);
    assign next_pixel_count = pixel_count_acc + {{23{1'b0}}, pixel_valid};
    assign next_loose_red_count = loose_red_count_acc + {{23{1'b0}}, loose_red_candidate};
    assign next_red_roi_count = red_roi_count_acc + {{23{1'b0}}, is_red_in_calib_roi};
    assign next_max_r = !pixel_valid ? max_r_acc :
                        (pixel_count_acc == 24'd0) ? pixel_r :
                        ((pixel_r > max_r_acc) ? pixel_r : max_r_acc);
    assign next_max_g = !pixel_valid ? max_g_acc :
                        (pixel_count_acc == 24'd0) ? pixel_g :
                        ((pixel_g > max_g_acc) ? pixel_g : max_g_acc);
    assign next_max_b = !pixel_valid ? max_b_acc :
                        (pixel_count_acc == 24'd0) ? pixel_b :
                        ((pixel_b > max_b_acc) ? pixel_b : max_b_acc);

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            pixel_count_acc <= 24'd0;
            pixel_count_committed_reg <= 24'd0;
            loose_red_count_acc <= 24'd0;
            loose_red_count_committed_reg <= 24'd0;
            red_roi_count_acc <= 24'd0;
            red_roi_count_committed_reg <= 24'd0;
            max_r_acc <= 8'd0;
            max_g_acc <= 8'd0;
            max_b_acc <= 8'd0;
            max_r_committed_reg <= 8'd0;
            max_g_committed_reg <= 8'd0;
            max_b_committed_reg <= 8'd0;
            last_r_acc <= 8'd0;
            last_g_acc <= 8'd0;
            last_b_acc <= 8'd0;
            last_r_committed_reg <= 8'd0;
            last_g_committed_reg <= 8'd0;
            last_b_committed_reg <= 8'd0;
        end else begin
            if (sof) begin
                pixel_count_acc <= 24'd0;
                loose_red_count_acc <= 24'd0;
                red_roi_count_acc <= 24'd0;
                max_r_acc <= 8'd0;
                max_g_acc <= 8'd0;
                max_b_acc <= 8'd0;
                last_r_acc <= 8'd0;
                last_g_acc <= 8'd0;
                last_b_acc <= 8'd0;
            end else if (pixel_valid) begin
                pixel_count_acc <= next_pixel_count;
                loose_red_count_acc <= next_loose_red_count;
                red_roi_count_acc <= next_red_roi_count;
                max_r_acc <= next_max_r;
                max_g_acc <= next_max_g;
                max_b_acc <= next_max_b;
                last_r_acc <= pixel_r;
                last_g_acc <= pixel_g;
                last_b_acc <= pixel_b;
            end

            if (eof) begin
                pixel_count_committed_reg <= next_pixel_count;
                loose_red_count_committed_reg <= next_loose_red_count;
                red_roi_count_committed_reg <= next_red_roi_count;
                max_r_committed_reg <= next_max_r;
                max_g_committed_reg <= next_max_g;
                max_b_committed_reg <= next_max_b;
                last_r_committed_reg <= pixel_valid ? pixel_r : last_r_acc;
                last_g_committed_reg <= pixel_valid ? pixel_g : last_g_acc;
                last_b_committed_reg <= pixel_valid ? pixel_b : last_b_acc;
            end
        end
    end

    blob_stats #(
        .X_WIDTH(X_WIDTH),
        .Y_WIDTH(Y_WIDTH)
    ) u_white_stats (
        .clk(clk),
        .rst(rst),
        .sof(sof),
        .eof(eof),
        .pixel_valid(pixel_valid),
        .pixel_match(is_white_in_scene_roi),
        .pixel_x(pixel_x),
        .pixel_y(pixel_y),
        .blob_valid(white_valid),
        .center_x(white_center_x),
        .center_y(white_center_y),
        .pixel_count(white_count),
        .min_x(white_min_x),
        .max_x(white_max_x),
        .min_y(white_min_y),
        .max_y(white_max_y)
    );

    blob_stats u_green_stats (
        .clk(clk),
        .rst(rst),
        .sof(sof),
        .eof(eof),
        .pixel_valid(pixel_valid),
        .pixel_match(is_green_in_scene_roi),
        .pixel_x(pixel_x),
        .pixel_y(pixel_y),
        .blob_valid(green_valid),
        .center_x(green_x),
        .center_y(green_y),
        .pixel_count(green_count),
        .min_x(unused_green_min_x),
        .max_x(unused_green_max_x),
        .min_y(unused_green_min_y),
        .max_y(unused_green_max_y)
    );

    red_circle_run_selector #(
        .X_WIDTH(X_WIDTH),
        .Y_WIDTH(Y_WIDTH),
        .COUNT_W(24),
        .MIN_RUN(13'd3),
        .MAX_RUN(13'd190),
        .MIN_ROWS(12),
        .MIN_PIXELS(24'd500),
        .MIN_WIDTH(13'd20),
        .MAX_WIDTH(13'd220),
        .MIN_HEIGHT(13'd20),
        .MAX_HEIGHT(13'd150)
    ) u_red_stats (
        .clk(clk),
        .rst(rst),
        .sof(sof),
        .eof(eof),
        .pixel_valid(pixel_valid),
        .pixel_match(selector_red_candidate),
        .pixel_x(pixel_x),
        .pixel_y(pixel_y),
        .green_valid(green_valid),
        .green_x(green_x),
        .blob_valid(red_valid),
        .center_x(red_x),
        .center_y(red_y),
        .pixel_count(red_selector_count),
        .min_x(red_min_x),
        .max_x(red_max_x),
        .min_y(red_min_y),
        .max_y(red_max_y)
    );

    blue_hand_run_selector #(
        .X_WIDTH(X_WIDTH),
        .Y_WIDTH(Y_WIDTH),
        .COUNT_W(24),
        .MIN_RUN(13'd12),
        .MAX_RUN(13'd280),
        .MAX_GAP(13'd0),
        .TRACK_HALF_WIDTH(13'd80),
        .TRACK_HALF_HEIGHT(13'd64)
    ) u_blue_stats (
        .clk(clk),
        .rst(rst),
        .sof(sof),
        .eof(eof),
        .pixel_valid(pixel_valid),
        .pixel_match(blue_hand_candidate),
        .pixel_x(pixel_x),
        .pixel_y(pixel_y),
        .roi_min_x(blue_scene_min_x_w[X_WIDTH-1:0]),
        .roi_max_x(blue_scene_max_x_w[X_WIDTH-1:0]),
        .roi_min_y(blue_scene_min_y_w[Y_WIDTH-1:0]),
        .roi_max_y(blue_scene_max_y_w[Y_WIDTH-1:0]),
        .blob_valid(blue_valid),
        .center_x(blue_x),
        .center_y(blue_y),
        .pixel_count(blue_pixel_count),
        .min_x(blue_min_x),
        .max_x(blue_max_x),
        .min_y(blue_min_y),
        .max_y(blue_max_y)
    );

    blue_light_spot_selector #(
        .X_WIDTH(X_WIDTH),
        .Y_WIDTH(Y_WIDTH),
        .COUNT_W(24),
        .MIN_RUN(13'd6),
        .MAX_RUN(13'd96),
        .MIN_SEED_PIXELS(13'd2),
        .MIN_PEAK_Y(8'd220),
        .MIN_PEAK_COUNT(13'd2),
        .TRACK_HALF_WIDTH(13'd24),
        .TRACK_HALF_HEIGHT(13'd24)
    ) u_blue_light_stats (
        .clk(clk),
        .rst(rst),
        .sof(blue_light_sof_d1_reg),
        .eof(blue_light_eof_d1_reg),
        .pixel_valid(blue_light_ycc_valid),
        .pixel_match(blue_light_candidate),
        .pixel_seed(blue_light_strong_seed_candidate),
        .pixel_luma(blue_light_luma),
        .pixel_x(blue_light_x_d1_reg),
        .pixel_y(blue_light_y_d1_reg),
        .roi_min_x(blue_scene_min_x_w[X_WIDTH-1:0]),
        .roi_max_x(blue_scene_max_x_w[X_WIDTH-1:0]),
        .roi_min_y(blue_scene_min_y_w[Y_WIDTH-1:0]),
        .roi_max_y(blue_scene_max_y_w[Y_WIDTH-1:0]),
        .blob_valid(light_valid),
        .center_x(light_x),
        .center_y(light_y),
        .pixel_count(light_pixel_count),
        .min_x(light_min_x),
        .max_x(light_max_x),
        .min_y(light_min_y),
        .max_y(light_max_y)
    );

endmodule
