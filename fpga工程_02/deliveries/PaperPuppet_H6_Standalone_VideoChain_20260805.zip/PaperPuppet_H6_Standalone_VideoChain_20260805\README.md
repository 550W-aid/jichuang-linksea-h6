# PaperPuppet H6 Standalone Video Chain

This is an independent H6/eLinx board candidate based on the team's stable OV5640, SDRAM, and HDMI project. It is intentionally not merged into the total project.

The candidate defaults to camera pass-through. `KEY2` toggles a frame-latched saturated-color detector and a procedural Sun Wukong overlay. The first stage implements idle following only. The legacy rotation preview framebuffer is disabled, and the source tree contains no explicit `altsyncram` primitive.

The generated programming file is `01_FPGA/ov5640_hdmi_1080p.runs/imple_1/ov5640_hdmi_1080p.jpsk`.
