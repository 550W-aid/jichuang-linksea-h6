`timescale 1ns / 1ps

// Module Function: locate the black video frame from the previous frame's green anchor.
module black_frame_green_anchor_detector #(
    parameter integer IMAGE_WIDTH = 1280,
    parameter integer IMAGE_HEIGHT = 720,
    parameter integer X_WIDTH = 12,
    parameter integer Y_WIDTH = 12,
    parameter [7:0] DARK_MAX = 8'd170,
    parameter [7:0] GREEN_MIN_G = 8'd80,
    parameter [8:0] GREEN_RG_DELTA = 9'd25,
    parameter [8:0] GREEN_BG_DELTA = 9'd18,
    parameter [7:0] GREEN_MIN_SPREAD = 8'd25,
    parameter [15:0] GREEN_ROW_MIN_RUN = 16'd48,
    parameter [15:0] GREEN_MIN_BAND_HEIGHT = 16'd12,
    parameter [15:0] BLACK_ROW_MIN_RUN = 16'd96,
    parameter [15:0] BLACK_ROW_MAX_RUN = 16'd760,
    parameter [15:0] BLACK_MIN_BAND_HEIGHT = 16'd3,
    parameter [15:0] BLACK_MAX_BAND_HEIGHT = 16'd64,
    parameter [X_WIDTH-1:0] EDGE_MARGIN = 12'd24,
    parameter [X_WIDTH-1:0] SEARCH_MARGIN_X = 12'd520,
    parameter [Y_WIDTH-1:0] SEARCH_MARGIN_TOP = 12'd460,
    parameter [Y_WIDTH-1:0] SIDE_SEARCH_BOTTOM_MARGIN = 12'd170,
    parameter [X_WIDTH-1:0] SEARCH_EDGE_GUARD = 12'd16,
    parameter [X_WIDTH-1:0] SIDE_TOLERANCE = 12'd32,
    parameter [X_WIDTH-1:0] TOP_LEFT_GREEN_MARGIN = 12'd80,
    parameter [X_WIDTH-1:0] TOP_RIGHT_GREEN_MARGIN = 12'd40,
    parameter [15:0] MIN_SIDE_ROWS = 16'd120,
    parameter [X_WIDTH-1:0] MIN_FRAME_WIDTH = 12'd180,
    parameter [Y_WIDTH-1:0] MIN_FRAME_HEIGHT = 12'd120
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 relocalize,
    input  wire                 sof,
    input  wire                 eof,
    input  wire                 pixel_valid,
    input  wire [X_WIDTH-1:0]   pixel_x,
    input  wire [Y_WIDTH-1:0]   pixel_y,
    input  wire [7:0]           pixel_r,
    input  wire [7:0]           pixel_g,
    input  wire [7:0]           pixel_b,
    output reg                  frame_valid,
    output reg [X_WIDTH-1:0]    left_x,
    output reg [X_WIDTH-1:0]    right_x,
    output reg [Y_WIDTH-1:0]    top_y,
    output reg [Y_WIDTH-1:0]    bottom_y,
    output reg                  candidate_valid,
    output reg [X_WIDTH-1:0]    candidate_left_x,
    output reg [X_WIDTH-1:0]    candidate_right_x,
    output reg [Y_WIDTH-1:0]    candidate_top_y,
    output reg [Y_WIDTH-1:0]    candidate_bottom_y,
    output reg                  left_side_valid,
    output reg                  right_side_valid,
    output reg                  green_anchor_valid,
    output reg [X_WIDTH-1:0]    green_anchor_x,
    output reg [Y_WIDTH-1:0]    green_anchor_y,
    output reg [X_WIDTH-1:0]    green_anchor_left_x,
    output reg [X_WIDTH-1:0]    green_anchor_right_x,
    output reg [Y_WIDTH-1:0]    green_anchor_top_y,
    output reg [Y_WIDTH-1:0]    green_anchor_bottom_y
);

    localparam [X_WIDTH-1:0] IMAGE_MAX_X = IMAGE_WIDTH - 1;
    localparam [Y_WIDTH-1:0] IMAGE_MAX_Y = IMAGE_HEIGHT - 1;
    localparam [X_WIDTH:0] ONE_X = {{X_WIDTH{1'b0}}, 1'b1};
    localparam [Y_WIDTH:0] ONE_Y = {{Y_WIDTH{1'b0}}, 1'b1};

    function [X_WIDTH:0] search_min_x_from_center;
        input [X_WIDTH:0] center_x;
        begin
            search_min_x_from_center =
                (center_x > {1'b0, SEARCH_MARGIN_X}) ?
                (center_x - {1'b0, SEARCH_MARGIN_X}) :
                {1'b0, EDGE_MARGIN};
        end
    endfunction

    function [X_WIDTH:0] search_max_x_from_center;
        input [X_WIDTH:0] center_x;
        begin
            search_max_x_from_center =
                ((center_x + {1'b0, SEARCH_MARGIN_X}) < {1'b0, IMAGE_MAX_X}) ?
                (center_x + {1'b0, SEARCH_MARGIN_X}) :
                {1'b0, IMAGE_MAX_X - EDGE_MARGIN};
        end
    endfunction

    function [Y_WIDTH:0] search_min_y_from_center;
        input [Y_WIDTH:0] center_y;
        begin
            search_min_y_from_center =
                (center_y > {1'b0, SEARCH_MARGIN_TOP}) ?
                (center_y - {1'b0, SEARCH_MARGIN_TOP}) :
                {1'b0, EDGE_MARGIN};
        end
    endfunction

    function [Y_WIDTH:0] search_max_y_from_center;
        input [Y_WIDTH:0] center_y;
        begin
            search_max_y_from_center =
                ((center_y + {1'b0, SIDE_SEARCH_BOTTOM_MARGIN}) < {1'b0, IMAGE_MAX_Y}) ?
                (center_y + {1'b0, SIDE_SEARCH_BOTTOM_MARGIN}) :
                {1'b0, IMAGE_MAX_Y - EDGE_MARGIN};
        end
    endfunction

    wire is_green;
    wire is_dark;
    wire line_boundary;
    wire in_search_window;
    wire [X_WIDTH:0] prev_green_center_x_wire;
    wire [Y_WIDTH:0] prev_green_center_y_wire;
    wire [X_WIDTH:0] search_min_x_wire;
    wire [X_WIDTH:0] search_max_x_wire;
    wire [Y_WIDTH:0] search_min_y_wire;
    wire [Y_WIDTH:0] search_max_y_wire;
    wire [X_WIDTH:0] side_tol_wire;
    wire [X_WIDTH:0] side_left_min_wire;
    wire [X_WIDTH:0] side_left_max_wire;
    wire [X_WIDTH:0] side_right_min_wire;
    wire [X_WIDTH:0] side_right_max_wire;
    wire side_left_pixel_wire;
    wire side_right_pixel_wire;

    reg line_active_reg;
    reg [Y_WIDTH-1:0] line_y_reg;

    reg [15:0] green_run_count_reg;
    reg [X_WIDTH-1:0] green_run_start_reg;
    reg [X_WIDTH-1:0] green_run_end_reg;
    reg [15:0] green_line_best_count_reg;
    reg [X_WIDTH-1:0] green_line_best_start_reg;
    reg [X_WIDTH-1:0] green_line_best_end_reg;
    reg green_band_active_reg;
    reg [Y_WIDTH-1:0] green_band_start_y_reg;
    reg [Y_WIDTH-1:0] green_band_end_y_reg;
    reg [X_WIDTH-1:0] green_band_left_reg;
    reg [X_WIDTH-1:0] green_band_right_reg;
    reg [15:0] green_band_height_reg;
    reg green_best_valid_reg;
    reg [15:0] green_best_height_reg;
    reg [Y_WIDTH-1:0] green_best_start_y_reg;
    reg [Y_WIDTH-1:0] green_best_end_y_reg;
    reg [X_WIDTH-1:0] green_best_left_reg;
    reg [X_WIDTH-1:0] green_best_right_reg;
    reg prev_green_valid_reg;
    reg [Y_WIDTH-1:0] prev_green_top_reg;
    reg [Y_WIDTH-1:0] prev_green_bottom_reg;
    reg [X_WIDTH-1:0] prev_green_left_reg;
    reg [X_WIDTH-1:0] prev_green_right_reg;
    reg [X_WIDTH:0] prev_green_center_x_reg;
    reg [Y_WIDTH:0] prev_green_center_y_reg;
    reg [X_WIDTH:0] search_min_x_reg;
    reg [X_WIDTH:0] search_max_x_reg;
    reg [Y_WIDTH:0] search_min_y_reg;
    reg [Y_WIDTH:0] search_max_y_reg;

    reg [15:0] black_run_count_reg;
    reg [X_WIDTH-1:0] black_run_start_reg;
    reg [X_WIDTH-1:0] black_run_end_reg;
    reg [15:0] black_line_best_count_reg;
    reg [X_WIDTH-1:0] black_line_best_start_reg;
    reg [X_WIDTH-1:0] black_line_best_end_reg;
    reg black_band_active_reg;
    reg [Y_WIDTH-1:0] black_band_start_y_reg;
    reg [Y_WIDTH-1:0] black_band_end_y_reg;
    reg [X_WIDTH-1:0] black_band_left_reg;
    reg [X_WIDTH-1:0] black_band_right_reg;
    reg [15:0] black_band_height_reg;
    reg black_top_found_reg;
    reg [Y_WIDTH-1:0] frame_top_acc_reg;
    reg [Y_WIDTH-1:0] frame_bottom_acc_reg;
    reg [X_WIDTH-1:0] frame_left_acc_reg;
    reg [X_WIDTH-1:0] frame_right_acc_reg;
    reg [X_WIDTH-1:0] frame_left_anchor_reg;
    reg [X_WIDTH-1:0] frame_right_anchor_reg;
    reg [15:0] frame_left_side_rows_reg;
    reg [15:0] frame_right_side_rows_reg;
    reg side_left_seen_reg;
    reg side_right_seen_reg;

    wire green_run_better_wire;
    wire [15:0] green_line_final_count_wire;
    wire [X_WIDTH-1:0] green_line_final_start_wire;
    wire [X_WIDTH-1:0] green_line_final_end_wire;
    wire green_line_candidate_valid_wire;
    wire green_band_qualified_wire;
    wire green_band_better_wire;

    wire black_run_candidate_wire;
    wire black_run_better_wire;
    wire [15:0] black_line_final_count_wire;
    wire [X_WIDTH-1:0] black_line_final_start_wire;
    wire [X_WIDTH-1:0] black_line_final_end_wire;
    wire black_line_candidate_valid_wire;
    wire black_band_qualified_wire;
    wire [X_WIDTH:0] frame_width_wire;
    wire [Y_WIDTH:0] frame_height_wire;
    wire frame_size_valid_wire;
    wire side_rows_valid_wire;

    assign is_green =
        pixel_valid &&
        (pixel_g >= GREEN_MIN_G) &&
        ({1'b0, pixel_g} >= ({1'b0, pixel_r} + GREEN_RG_DELTA)) &&
        ({1'b0, pixel_g} >= ({1'b0, pixel_b} + GREEN_BG_DELTA));

    assign is_dark =
        pixel_valid &&
        (pixel_r <= DARK_MAX) &&
        (pixel_g <= DARK_MAX) &&
        (pixel_b <= DARK_MAX);

    assign line_boundary = pixel_valid && line_active_reg && (pixel_y != line_y_reg);

    // These values only change at EOF. Registering them keeps the per-pixel side
    // detector from rebuilding the anchor-center and clamp arithmetic every cycle.
    assign prev_green_center_x_wire = prev_green_center_x_reg;
    assign prev_green_center_y_wire = prev_green_center_y_reg;
    assign search_min_x_wire = search_min_x_reg;
    assign search_max_x_wire = search_max_x_reg;
    assign search_min_y_wire = search_min_y_reg;
    assign search_max_y_wire = search_max_y_reg;
    assign in_search_window =
        prev_green_valid_reg &&
        ({1'b0, pixel_x} >= search_min_x_wire) &&
        ({1'b0, pixel_x} <= search_max_x_wire) &&
        ({1'b0, pixel_y} >= search_min_y_wire) &&
        ({1'b0, pixel_y} <= search_max_y_wire);

    assign side_tol_wire = {1'b0, SIDE_TOLERANCE};
    assign side_left_min_wire = ({1'b0, frame_left_anchor_reg} > side_tol_wire) ?
                                ({1'b0, frame_left_anchor_reg} - side_tol_wire) :
                                search_min_x_wire;
    assign side_left_max_wire = ({1'b0, frame_left_anchor_reg} + side_tol_wire);
    assign side_right_min_wire = ({1'b0, frame_right_anchor_reg} > side_tol_wire) ?
                                 ({1'b0, frame_right_anchor_reg} - side_tol_wire) :
                                 search_min_x_wire;
    assign side_right_max_wire = ({1'b0, frame_right_anchor_reg} + side_tol_wire);
    assign side_left_pixel_wire =
        black_top_found_reg &&
        is_dark &&
        in_search_window &&
        ({1'b0, pixel_x} >= side_left_min_wire) &&
        ({1'b0, pixel_x} <= side_left_max_wire);
    assign side_right_pixel_wire =
        black_top_found_reg &&
        is_dark &&
        in_search_window &&
        ({1'b0, pixel_x} >= side_right_min_wire) &&
        ({1'b0, pixel_x} <= side_right_max_wire);

    assign green_run_better_wire = green_run_count_reg > green_line_best_count_reg;
    assign green_line_final_count_wire = green_run_better_wire ?
                                         green_run_count_reg : green_line_best_count_reg;
    assign green_line_final_start_wire = green_run_better_wire ?
                                         green_run_start_reg : green_line_best_start_reg;
    assign green_line_final_end_wire = green_run_better_wire ?
                                       green_run_end_reg : green_line_best_end_reg;
    assign green_line_candidate_valid_wire =
        green_line_final_count_wire >= GREEN_ROW_MIN_RUN;
    assign green_band_qualified_wire =
        green_band_active_reg &&
        (green_band_height_reg >= GREEN_MIN_BAND_HEIGHT);
    assign green_band_better_wire =
        green_band_qualified_wire &&
        (!green_best_valid_reg || (green_band_height_reg > green_best_height_reg));

    assign black_run_candidate_wire =
        (black_run_count_reg >= BLACK_ROW_MIN_RUN) &&
        (black_run_count_reg <= BLACK_ROW_MAX_RUN) &&
        ({1'b0, black_run_start_reg} <= prev_green_center_x_wire) &&
        ({1'b0, black_run_end_reg} >= prev_green_center_x_wire) &&
        ({1'b0, black_run_start_reg} > (search_min_x_wire + {1'b0, SEARCH_EDGE_GUARD})) &&
        (({1'b0, black_run_start_reg} + {1'b0, TOP_LEFT_GREEN_MARGIN}) <
         {1'b0, prev_green_left_reg}) &&
        ({1'b0, black_run_end_reg} >
         ({1'b0, prev_green_right_reg} + {1'b0, TOP_RIGHT_GREEN_MARGIN}));
    assign black_run_better_wire =
        black_run_candidate_wire &&
        (black_run_count_reg > black_line_best_count_reg);
    assign black_line_final_count_wire = black_run_better_wire ?
                                         black_run_count_reg : black_line_best_count_reg;
    assign black_line_final_start_wire = black_run_better_wire ?
                                         black_run_start_reg : black_line_best_start_reg;
    assign black_line_final_end_wire = black_run_better_wire ?
                                       black_run_end_reg : black_line_best_end_reg;
    assign black_line_candidate_valid_wire =
        black_line_final_count_wire >= BLACK_ROW_MIN_RUN;
    assign black_band_qualified_wire =
        black_band_active_reg &&
        (black_band_height_reg >= BLACK_MIN_BAND_HEIGHT) &&
        (black_band_height_reg <= BLACK_MAX_BAND_HEIGHT);

    assign frame_width_wire =
        {1'b0, frame_right_acc_reg} - {1'b0, frame_left_acc_reg} + ONE_X;
    assign frame_height_wire =
        {1'b0, frame_bottom_acc_reg} - {1'b0, frame_top_acc_reg} + ONE_Y;
    assign frame_size_valid_wire =
        black_top_found_reg &&
        (frame_right_acc_reg > frame_left_acc_reg) &&
        (frame_bottom_acc_reg > frame_top_acc_reg) &&
        (frame_width_wire >= {1'b0, MIN_FRAME_WIDTH}) &&
        (frame_height_wire >= {1'b0, MIN_FRAME_HEIGHT});
    assign side_rows_valid_wire = 1'b1;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            line_active_reg <= 1'b0;
            line_y_reg <= {Y_WIDTH{1'b0}};
            green_run_count_reg <= 16'd0;
            green_run_start_reg <= {X_WIDTH{1'b0}};
            green_run_end_reg <= {X_WIDTH{1'b0}};
            green_line_best_count_reg <= 16'd0;
            green_line_best_start_reg <= {X_WIDTH{1'b0}};
            green_line_best_end_reg <= {X_WIDTH{1'b0}};
            green_band_active_reg <= 1'b0;
            green_band_start_y_reg <= {Y_WIDTH{1'b0}};
            green_band_end_y_reg <= {Y_WIDTH{1'b0}};
            green_band_left_reg <= {X_WIDTH{1'b0}};
            green_band_right_reg <= {X_WIDTH{1'b0}};
            green_band_height_reg <= 16'd0;
            green_best_valid_reg <= 1'b0;
            green_best_height_reg <= 16'd0;
            green_best_start_y_reg <= {Y_WIDTH{1'b0}};
            green_best_end_y_reg <= {Y_WIDTH{1'b0}};
            green_best_left_reg <= {X_WIDTH{1'b0}};
            green_best_right_reg <= {X_WIDTH{1'b0}};
            prev_green_valid_reg <= 1'b0;
            prev_green_top_reg <= {Y_WIDTH{1'b0}};
            prev_green_bottom_reg <= {Y_WIDTH{1'b0}};
            prev_green_left_reg <= {X_WIDTH{1'b0}};
            prev_green_right_reg <= {X_WIDTH{1'b0}};
            prev_green_center_x_reg <= {(X_WIDTH + 1){1'b0}};
            prev_green_center_y_reg <= {(Y_WIDTH + 1){1'b0}};
            search_min_x_reg <= {1'b0, EDGE_MARGIN};
            search_max_x_reg <= {1'b0, IMAGE_MAX_X - EDGE_MARGIN};
            search_min_y_reg <= {1'b0, EDGE_MARGIN};
            search_max_y_reg <= {1'b0, IMAGE_MAX_Y - EDGE_MARGIN};
            black_run_count_reg <= 16'd0;
            black_run_start_reg <= {X_WIDTH{1'b0}};
            black_run_end_reg <= {X_WIDTH{1'b0}};
            black_line_best_count_reg <= 16'd0;
            black_line_best_start_reg <= {X_WIDTH{1'b0}};
            black_line_best_end_reg <= {X_WIDTH{1'b0}};
            black_band_active_reg <= 1'b0;
            black_band_start_y_reg <= {Y_WIDTH{1'b0}};
            black_band_end_y_reg <= {Y_WIDTH{1'b0}};
            black_band_left_reg <= {X_WIDTH{1'b0}};
            black_band_right_reg <= {X_WIDTH{1'b0}};
            black_band_height_reg <= 16'd0;
            black_top_found_reg <= 1'b0;
            frame_top_acc_reg <= {Y_WIDTH{1'b0}};
            frame_bottom_acc_reg <= {Y_WIDTH{1'b0}};
            frame_left_acc_reg <= {X_WIDTH{1'b0}};
            frame_right_acc_reg <= {X_WIDTH{1'b0}};
            frame_left_anchor_reg <= {X_WIDTH{1'b0}};
            frame_right_anchor_reg <= {X_WIDTH{1'b0}};
            frame_left_side_rows_reg <= 16'd0;
            frame_right_side_rows_reg <= 16'd0;
            side_left_seen_reg <= 1'b0;
            side_right_seen_reg <= 1'b0;
            frame_valid <= 1'b0;
            left_x <= {X_WIDTH{1'b0}};
            right_x <= {X_WIDTH{1'b0}};
            top_y <= {Y_WIDTH{1'b0}};
            bottom_y <= {Y_WIDTH{1'b0}};
            candidate_valid <= 1'b0;
            candidate_left_x <= {X_WIDTH{1'b0}};
            candidate_right_x <= {X_WIDTH{1'b0}};
            candidate_top_y <= {Y_WIDTH{1'b0}};
            candidate_bottom_y <= {Y_WIDTH{1'b0}};
            left_side_valid <= 1'b0;
            right_side_valid <= 1'b0;
            green_anchor_valid <= 1'b0;
            green_anchor_x <= {X_WIDTH{1'b0}};
            green_anchor_y <= {Y_WIDTH{1'b0}};
            green_anchor_left_x <= {X_WIDTH{1'b0}};
            green_anchor_right_x <= {X_WIDTH{1'b0}};
            green_anchor_top_y <= {Y_WIDTH{1'b0}};
            green_anchor_bottom_y <= {Y_WIDTH{1'b0}};
        end else begin
            if (relocalize) begin
                line_active_reg <= 1'b0;
                green_run_count_reg <= 16'd0;
                green_line_best_count_reg <= 16'd0;
                green_band_active_reg <= 1'b0;
                green_best_valid_reg <= 1'b0;
                green_best_height_reg <= 16'd0;
                prev_green_valid_reg <= 1'b0;
                prev_green_top_reg <= {Y_WIDTH{1'b0}};
                prev_green_bottom_reg <= {Y_WIDTH{1'b0}};
                prev_green_left_reg <= {X_WIDTH{1'b0}};
                prev_green_right_reg <= {X_WIDTH{1'b0}};
                prev_green_center_x_reg <= {(X_WIDTH + 1){1'b0}};
                prev_green_center_y_reg <= {(Y_WIDTH + 1){1'b0}};
                search_min_x_reg <= {1'b0, EDGE_MARGIN};
                search_max_x_reg <= {1'b0, IMAGE_MAX_X - EDGE_MARGIN};
                search_min_y_reg <= {1'b0, EDGE_MARGIN};
                search_max_y_reg <= {1'b0, IMAGE_MAX_Y - EDGE_MARGIN};
                black_run_count_reg <= 16'd0;
                black_line_best_count_reg <= 16'd0;
                black_band_active_reg <= 1'b0;
                black_top_found_reg <= 1'b0;
                frame_top_acc_reg <= {Y_WIDTH{1'b0}};
                frame_bottom_acc_reg <= {Y_WIDTH{1'b0}};
                frame_left_acc_reg <= {X_WIDTH{1'b0}};
                frame_right_acc_reg <= {X_WIDTH{1'b0}};
                frame_left_anchor_reg <= {X_WIDTH{1'b0}};
                frame_right_anchor_reg <= {X_WIDTH{1'b0}};
                frame_left_side_rows_reg <= 16'd0;
                frame_right_side_rows_reg <= 16'd0;
                side_left_seen_reg <= 1'b0;
                side_right_seen_reg <= 1'b0;
                frame_valid <= 1'b0;
                candidate_valid <= 1'b0;
                left_side_valid <= 1'b0;
                right_side_valid <= 1'b0;
                green_anchor_valid <= 1'b0;
            end else if (sof) begin
                line_active_reg <= 1'b0;
                green_run_count_reg <= 16'd0;
                green_line_best_count_reg <= 16'd0;
                green_band_active_reg <= 1'b0;
                green_best_valid_reg <= 1'b0;
                green_best_height_reg <= 16'd0;
                black_run_count_reg <= 16'd0;
                black_line_best_count_reg <= 16'd0;
                black_band_active_reg <= 1'b0;
                black_top_found_reg <= 1'b0;
                frame_left_anchor_reg <= {X_WIDTH{1'b0}};
                frame_right_anchor_reg <= {X_WIDTH{1'b0}};
                frame_left_side_rows_reg <= 16'd0;
                frame_right_side_rows_reg <= 16'd0;
                side_left_seen_reg <= 1'b0;
                side_right_seen_reg <= 1'b0;
            end else if (pixel_valid) begin
                if (line_boundary) begin
                    if (green_line_candidate_valid_wire) begin
                        if (green_band_active_reg) begin
                            green_band_end_y_reg <= line_y_reg;
                            green_band_height_reg <= green_band_height_reg + 16'd1;
                            if (green_line_final_start_wire < green_band_left_reg) begin
                                green_band_left_reg <= green_line_final_start_wire;
                            end
                            if (green_line_final_end_wire > green_band_right_reg) begin
                                green_band_right_reg <= green_line_final_end_wire;
                            end
                        end else begin
                            green_band_active_reg <= 1'b1;
                            green_band_start_y_reg <= line_y_reg;
                            green_band_end_y_reg <= line_y_reg;
                            green_band_left_reg <= green_line_final_start_wire;
                            green_band_right_reg <= green_line_final_end_wire;
                            green_band_height_reg <= 16'd1;
                        end
                    end else begin
                        if (green_band_better_wire) begin
                            green_best_valid_reg <= 1'b1;
                            green_best_height_reg <= green_band_height_reg;
                            green_best_start_y_reg <= green_band_start_y_reg;
                            green_best_end_y_reg <= green_band_end_y_reg;
                            green_best_left_reg <= green_band_left_reg;
                            green_best_right_reg <= green_band_right_reg;
                        end
                        green_band_active_reg <= 1'b0;
                    end

                    if (!black_top_found_reg) begin
                        if (black_line_candidate_valid_wire) begin
                            if (black_band_active_reg) begin
                                black_band_end_y_reg <= line_y_reg;
                                black_band_height_reg <= black_band_height_reg + 16'd1;
                                if (black_line_final_start_wire < black_band_left_reg) begin
                                    black_band_left_reg <= black_line_final_start_wire;
                                end
                                if (black_line_final_end_wire > black_band_right_reg) begin
                                    black_band_right_reg <= black_line_final_end_wire;
                                end
                            end else begin
                                black_band_active_reg <= 1'b1;
                                black_band_start_y_reg <= line_y_reg;
                                black_band_end_y_reg <= line_y_reg;
                                black_band_left_reg <= black_line_final_start_wire;
                                black_band_right_reg <= black_line_final_end_wire;
                                black_band_height_reg <= 16'd1;
                            end
                        end else begin
                            if (black_band_qualified_wire) begin
                                black_top_found_reg <= 1'b1;
                                frame_top_acc_reg <= black_band_start_y_reg;
                                frame_bottom_acc_reg <= search_max_y_wire[Y_WIDTH-1:0];
                                frame_left_acc_reg <= black_band_left_reg;
                                frame_right_acc_reg <= black_band_right_reg;
                                frame_left_anchor_reg <= black_band_left_reg;
                                frame_right_anchor_reg <= black_band_right_reg;
                            end
                            black_band_active_reg <= 1'b0;
                        end
                    end else begin
                        if (side_left_seen_reg) begin
                            if (frame_left_side_rows_reg != 16'hffff) begin
                                frame_left_side_rows_reg <= frame_left_side_rows_reg + 16'd1;
                            end
                            frame_bottom_acc_reg <= line_y_reg;
                        end
                        if (side_right_seen_reg) begin
                            if (frame_right_side_rows_reg != 16'hffff) begin
                                frame_right_side_rows_reg <= frame_right_side_rows_reg + 16'd1;
                            end
                            frame_bottom_acc_reg <= line_y_reg;
                        end
                    end

                    line_y_reg <= pixel_y;
                    line_active_reg <= 1'b1;
                    green_run_count_reg <= is_green ? 16'd1 : 16'd0;
                    green_run_start_reg <= is_green ? pixel_x : {X_WIDTH{1'b0}};
                    green_run_end_reg <= is_green ? pixel_x : {X_WIDTH{1'b0}};
                    green_line_best_count_reg <= 16'd0;
                    green_line_best_start_reg <= {X_WIDTH{1'b0}};
                    green_line_best_end_reg <= {X_WIDTH{1'b0}};
                    black_run_count_reg <= (is_dark && in_search_window) ? 16'd1 : 16'd0;
                    black_run_start_reg <= (is_dark && in_search_window) ? pixel_x : {X_WIDTH{1'b0}};
                    black_run_end_reg <= (is_dark && in_search_window) ? pixel_x : {X_WIDTH{1'b0}};
                    black_line_best_count_reg <= 16'd0;
                    black_line_best_start_reg <= {X_WIDTH{1'b0}};
                    black_line_best_end_reg <= {X_WIDTH{1'b0}};
                    side_left_seen_reg <= 1'b0;
                    side_right_seen_reg <= 1'b0;
                end else begin
                    if (!line_active_reg) begin
                        line_active_reg <= 1'b1;
                        line_y_reg <= pixel_y;
                        green_run_count_reg <= is_green ? 16'd1 : 16'd0;
                        green_run_start_reg <= is_green ? pixel_x : {X_WIDTH{1'b0}};
                        green_run_end_reg <= is_green ? pixel_x : {X_WIDTH{1'b0}};
                        green_line_best_count_reg <= 16'd0;
                        green_line_best_start_reg <= {X_WIDTH{1'b0}};
                        green_line_best_end_reg <= {X_WIDTH{1'b0}};
                        black_run_count_reg <= (is_dark && in_search_window) ? 16'd1 : 16'd0;
                        black_run_start_reg <= (is_dark && in_search_window) ? pixel_x : {X_WIDTH{1'b0}};
                        black_run_end_reg <= (is_dark && in_search_window) ? pixel_x : {X_WIDTH{1'b0}};
                        black_line_best_count_reg <= 16'd0;
                        black_line_best_start_reg <= {X_WIDTH{1'b0}};
                        black_line_best_end_reg <= {X_WIDTH{1'b0}};
                        side_left_seen_reg <= 1'b0;
                        side_right_seen_reg <= 1'b0;
                    end else begin
                        if (is_green) begin
                            if (green_run_count_reg == 16'd0) begin
                                green_run_count_reg <= 16'd1;
                                green_run_start_reg <= pixel_x;
                            end else if (green_run_count_reg != 16'hffff) begin
                                green_run_count_reg <= green_run_count_reg + 16'd1;
                            end
                            green_run_end_reg <= pixel_x;
                        end else begin
                            if (green_run_better_wire) begin
                                green_line_best_count_reg <= green_run_count_reg;
                                green_line_best_start_reg <= green_run_start_reg;
                                green_line_best_end_reg <= green_run_end_reg;
                            end
                            green_run_count_reg <= 16'd0;
                        end

                        if (is_dark && in_search_window) begin
                            if (black_run_count_reg == 16'd0) begin
                                black_run_count_reg <= 16'd1;
                                black_run_start_reg <= pixel_x;
                            end else if (black_run_count_reg != 16'hffff) begin
                                black_run_count_reg <= black_run_count_reg + 16'd1;
                            end
                            black_run_end_reg <= pixel_x;
                        end else begin
                            if (black_run_better_wire) begin
                                black_line_best_count_reg <= black_run_count_reg;
                                black_line_best_start_reg <= black_run_start_reg;
                                black_line_best_end_reg <= black_run_end_reg;
                            end
                            black_run_count_reg <= 16'd0;
                        end

                        if (side_left_pixel_wire) begin
                            side_left_seen_reg <= 1'b1;
                            if ({1'b0, pixel_x} < {1'b0, frame_left_acc_reg}) begin
                                frame_left_acc_reg <= pixel_x;
                            end
                        end
                        if (side_right_pixel_wire) begin
                            side_right_seen_reg <= 1'b1;
                            if ({1'b0, pixel_x} > {1'b0, frame_right_acc_reg}) begin
                                frame_right_acc_reg <= pixel_x;
                            end
                        end

                    end
                end
            end

            if (!relocalize && eof) begin
                if (green_band_better_wire) begin
                    prev_green_valid_reg <= 1'b1;
                    prev_green_top_reg <= green_band_start_y_reg;
                    prev_green_bottom_reg <= green_band_end_y_reg;
                    prev_green_left_reg <= green_band_left_reg;
                    prev_green_right_reg <= green_band_right_reg;
                    prev_green_center_x_reg <=
                        ({1'b0, green_band_left_reg} + {1'b0, green_band_right_reg}) >> 1;
                    prev_green_center_y_reg <=
                        ({1'b0, green_band_start_y_reg} + {1'b0, green_band_end_y_reg}) >> 1;
                    search_min_x_reg <= search_min_x_from_center(
                        ({1'b0, green_band_left_reg} + {1'b0, green_band_right_reg}) >> 1);
                    search_max_x_reg <= search_max_x_from_center(
                        ({1'b0, green_band_left_reg} + {1'b0, green_band_right_reg}) >> 1);
                    search_min_y_reg <= search_min_y_from_center(
                        ({1'b0, green_band_start_y_reg} + {1'b0, green_band_end_y_reg}) >> 1);
                    search_max_y_reg <= search_max_y_from_center(
                        ({1'b0, green_band_start_y_reg} + {1'b0, green_band_end_y_reg}) >> 1);
                    green_anchor_valid <= 1'b1;
                    green_anchor_left_x <= green_band_left_reg;
                    green_anchor_right_x <= green_band_right_reg;
                    green_anchor_top_y <= green_band_start_y_reg;
                    green_anchor_bottom_y <= green_band_end_y_reg;
                    green_anchor_x <= (({1'b0, green_band_left_reg} + {1'b0, green_band_right_reg}) >> 1);
                    green_anchor_y <= (({1'b0, green_band_start_y_reg} + {1'b0, green_band_end_y_reg}) >> 1);
                end else if (green_best_valid_reg) begin
                    prev_green_valid_reg <= 1'b1;
                    prev_green_top_reg <= green_best_start_y_reg;
                    prev_green_bottom_reg <= green_best_end_y_reg;
                    prev_green_left_reg <= green_best_left_reg;
                    prev_green_right_reg <= green_best_right_reg;
                    prev_green_center_x_reg <=
                        ({1'b0, green_best_left_reg} + {1'b0, green_best_right_reg}) >> 1;
                    prev_green_center_y_reg <=
                        ({1'b0, green_best_start_y_reg} + {1'b0, green_best_end_y_reg}) >> 1;
                    search_min_x_reg <= search_min_x_from_center(
                        ({1'b0, green_best_left_reg} + {1'b0, green_best_right_reg}) >> 1);
                    search_max_x_reg <= search_max_x_from_center(
                        ({1'b0, green_best_left_reg} + {1'b0, green_best_right_reg}) >> 1);
                    search_min_y_reg <= search_min_y_from_center(
                        ({1'b0, green_best_start_y_reg} + {1'b0, green_best_end_y_reg}) >> 1);
                    search_max_y_reg <= search_max_y_from_center(
                        ({1'b0, green_best_start_y_reg} + {1'b0, green_best_end_y_reg}) >> 1);
                    green_anchor_valid <= 1'b1;
                    green_anchor_left_x <= green_best_left_reg;
                    green_anchor_right_x <= green_best_right_reg;
                    green_anchor_top_y <= green_best_start_y_reg;
                    green_anchor_bottom_y <= green_best_end_y_reg;
                    green_anchor_x <= (({1'b0, green_best_left_reg} + {1'b0, green_best_right_reg}) >> 1);
                    green_anchor_y <= (({1'b0, green_best_start_y_reg} + {1'b0, green_best_end_y_reg}) >> 1);
                end

                candidate_valid <= black_top_found_reg;
                candidate_left_x <= frame_left_acc_reg;
                candidate_right_x <= frame_right_acc_reg;
                candidate_top_y <= frame_top_acc_reg;
                candidate_bottom_y <= frame_bottom_acc_reg;

                if (frame_size_valid_wire && side_rows_valid_wire) begin
                    frame_valid <= 1'b1;
                    left_x <= frame_left_acc_reg;
                    right_x <= frame_right_acc_reg;
                    top_y <= frame_top_acc_reg;
                    bottom_y <= frame_bottom_acc_reg;
                    left_side_valid <= 1'b1;
                    right_side_valid <= 1'b1;
                end else begin
                    frame_valid <= 1'b0;
                    left_side_valid <= 1'b0;
                    right_side_valid <= 1'b0;
                end
            end
        end
    end

endmodule
