puts "TIMING_COMMANDS=[lsort [info commands *timing*]]"
puts "SLACK_COMMANDS=[lsort [info commands *slack*]]"
puts "PATH_COMMANDS=[lsort [info commands *path*]]"
puts "REPORT_COMMANDS=[lsort [info commands *report*]]"
exit 0
