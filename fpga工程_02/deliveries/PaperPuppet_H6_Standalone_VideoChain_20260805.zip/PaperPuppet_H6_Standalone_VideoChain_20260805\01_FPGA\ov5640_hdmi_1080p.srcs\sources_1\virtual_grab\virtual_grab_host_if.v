`timescale 1ns / 1ps

module virtual_grab_host_if #(
    parameter integer X_WIDTH           = 12,
    parameter integer Y_WIDTH           = 12,
    parameter integer AREA_WIDTH        = 16,
    parameter integer BTN_STABLE_CYCLES = 4
) (
    input  wire                   clk,              // Processing clock.
    input  wire                   rst_n,            // Active-low reset.
    input  wire                   rx_valid,         // Input command byte valid strobe.
    input  wire [7:0]             rx_data,          // Input command byte value.
    output wire                   tx_valid,         // Output packet byte valid strobe.
    output wire [7:0]             tx_data,          // Output packet byte value.
    output wire                   tx_last,          // Output packet end marker.
    input  wire                   tx_ready,         // Downstream byte-ready handshake.
    input  wire                   red_valid,        // Current red target valid bit.
    input  wire [X_WIDTH-1:0]     red_x,            // Current red target X coordinate.
    input  wire [Y_WIDTH-1:0]     red_y,            // Current red target Y coordinate.
    input  wire                   origin_valid,     // Current white origin valid bit.
    input  wire [X_WIDTH-1:0]     origin_x,         // Current white origin X coordinate.
    input  wire [Y_WIDTH-1:0]     origin_y,         // Current white origin Y coordinate.
    input  wire                   green_valid,      // Current green reference valid bit.
    input  wire [X_WIDTH-1:0]     green_x,          // Current green reference X coordinate.
    input  wire [Y_WIDTH-1:0]     green_y,          // Current green reference Y coordinate.
    input  wire [23:0]            red_pixel_count,  // Current red classifier pixel count.
    input  wire [23:0]            green_pixel_count,// Current green classifier pixel count.
    input  wire [23:0]            blue_pixel_count, // Current blue classifier pixel count.
    input  wire [23:0]            white_pixel_count,// Current white classifier pixel count.
    input  wire [23:0]            committed_pixel_count,
    input  wire [23:0]            live_pixel_count,
    input  wire [23:0]            loose_red_pixel_count,
    input  wire [7:0]             max_pixel_r,
    input  wire [7:0]             max_pixel_g,
    input  wire [7:0]             max_pixel_b,
    input  wire [7:0]             last_pixel_r,
    input  wire [7:0]             last_pixel_g,
    input  wire [7:0]             last_pixel_b,
    input  wire [7:0]             calib_debug_flags,
    input  wire [X_WIDTH-1:0]     red_min_x,
    input  wire [X_WIDTH-1:0]     red_max_x,
    input  wire [Y_WIDTH-1:0]     red_min_y,
    input  wire [Y_WIDTH-1:0]     red_max_y,
    input  wire [X_WIDTH-1:0]     red_width,
    input  wire [Y_WIDTH-1:0]     red_height,
    input  wire [7:0]             black_frame_debug_flags,
    input  wire [X_WIDTH-1:0]     black_frame_left_x,
    input  wire [X_WIDTH-1:0]     black_frame_right_x,
    input  wire [Y_WIDTH-1:0]     black_frame_top_y,
    input  wire [Y_WIDTH-1:0]     black_frame_bottom_y,
    input  wire                   hand_update,      // One-cycle pulse when fresh hand data is ready.
    input  wire                   hand_valid,       // Current hand valid bit.
    input  wire [X_WIDTH-1:0]     hand_x,           // Current hand X coordinate.
    input  wire [Y_WIDTH-1:0]     hand_y,           // Current hand Y coordinate.
    input  wire [AREA_WIDTH-1:0]  hand_area,        // Current hand area statistic.
    input  wire                   grab_btn_raw,     // Hidden raw grab button input.
    input  wire                   release_btn_raw,  // Hidden raw release button input.
    output wire                   streaming_enable, // High while periodic hand reporting is enabled.
    output wire                   light_mode_enable,// High while light-spot tracking is selected.
    output wire                   map_relocalize,
    output wire                   calibrated_valid, // High after a successful calibration snapshot.
    output wire                   overlay_circle_valid,
    output wire                   overlay_circle_grabbed,
    output wire [X_WIDTH-1:0]     overlay_circle_x,
    output wire [Y_WIDTH-1:0]     overlay_circle_y,
    output wire                   target_cross_valid,
    output wire [X_WIDTH-1:0]     target_cross_x,
    output wire [Y_WIDTH-1:0]     target_cross_y
);

    localparam [2:0] PACKET_KIND_CALIB     = 3'd0;
    localparam [2:0] PACKET_KIND_HAND      = 3'd1;
    localparam [2:0] PACKET_KIND_STATUS    = 3'd2;
    localparam [2:0] PACKET_KIND_DEBUG     = 3'd3;
    localparam [2:0] PACKET_KIND_RAW_DEBUG = 3'd4;
    localparam [2:0] PACKET_KIND_CALIB_DEBUG = 3'd5;

    localparam [7:0] RUN_STATE_IDLE       = 8'h00;
    localparam [7:0] RUN_STATE_CALIBRATED = 8'h01;
    localparam [7:0] RUN_STATE_STREAMING  = 8'h02;

    wire cmd_calibrate_wire;
    wire cmd_start_wire;
    wire cmd_light_start_wire;
    wire cmd_stop_wire;
    wire cmd_map_relocalize_wire;
    wire cmd_error_wire;
    wire grab_btn_event_wire;
    wire release_btn_event_wire;
    wire tx_busy_wire;

    reg streaming_enable_reg;
    reg light_mode_enable_reg;
    reg calibrated_valid_reg;
    reg [15:0] frame_id_reg;
    reg grab_event_pending_reg;
    reg release_event_pending_reg;

    reg pending_calib_rsp_reg;
    reg pending_debug_rsp_reg;
    reg pending_calib_debug_rsp_reg;
    reg pending_raw_debug_rsp_reg;
    reg pending_status_rsp_reg;
    reg pending_hand_rsp_reg;

    reg calib_valid_rsp_reg;
    reg [X_WIDTH-1:0] red_x_rsp_reg;
    reg [Y_WIDTH-1:0] red_y_rsp_reg;
    reg origin_valid_rsp_reg;
    reg [X_WIDTH-1:0] origin_x_rsp_reg;
    reg [Y_WIDTH-1:0] origin_y_rsp_reg;
    reg green_valid_rsp_reg;
    reg [X_WIDTH-1:0] green_x_rsp_reg;
    reg [Y_WIDTH-1:0] green_y_rsp_reg;

    reg [23:0] red_count_rsp_reg;
    reg [23:0] green_count_rsp_reg;
    reg [23:0] blue_count_rsp_reg;
    reg [23:0] white_count_rsp_reg;
    reg [23:0] committed_pixel_count_rsp_reg;
    reg [23:0] live_pixel_count_rsp_reg;
    reg [23:0] loose_red_count_rsp_reg;
    reg [7:0] max_r_rsp_reg;
    reg [7:0] max_g_rsp_reg;
    reg [7:0] max_b_rsp_reg;
    reg [7:0] last_r_rsp_reg;
    reg [7:0] last_g_rsp_reg;
    reg [7:0] last_b_rsp_reg;
    reg [7:0] calib_debug_flags_rsp_reg;
    reg [X_WIDTH-1:0] red_min_x_rsp_reg;
    reg [X_WIDTH-1:0] red_max_x_rsp_reg;
    reg [Y_WIDTH-1:0] red_min_y_rsp_reg;
    reg [Y_WIDTH-1:0] red_max_y_rsp_reg;
    reg [X_WIDTH-1:0] red_width_rsp_reg;
    reg [Y_WIDTH-1:0] red_height_rsp_reg;
    reg [7:0] black_frame_debug_flags_rsp_reg;
    reg [X_WIDTH-1:0] black_frame_left_x_rsp_reg;
    reg [X_WIDTH-1:0] black_frame_right_x_rsp_reg;
    reg [Y_WIDTH-1:0] black_frame_top_y_rsp_reg;
    reg [Y_WIDTH-1:0] black_frame_bottom_y_rsp_reg;

    reg [7:0] status_rsp_reg;

    reg [15:0] hand_frame_id_rsp_reg;
    reg hand_valid_rsp_reg;
    reg [X_WIDTH-1:0] hand_x_rsp_reg;
    reg [Y_WIDTH-1:0] hand_y_rsp_reg;
    reg [AREA_WIDTH-1:0] hand_area_rsp_reg;
    reg hand_grab_event_rsp_reg;
    reg hand_release_event_rsp_reg;

    wire start_calib_rsp_wire;
    wire start_debug_rsp_wire;
    wire start_calib_debug_rsp_wire;
    wire start_raw_debug_rsp_wire;
    wire start_status_rsp_wire;
    wire start_hand_rsp_wire;
    wire tx_start_wire;
    wire [2:0] tx_packet_kind_wire;
    wire capture_grab_event_wire;
    wire capture_release_event_wire;

    assign streaming_enable = streaming_enable_reg;
    assign light_mode_enable = light_mode_enable_reg;
    assign map_relocalize = cmd_map_relocalize_wire;
    assign calibrated_valid = calibrated_valid_reg;

    assign capture_grab_event_wire = grab_event_pending_reg | grab_btn_event_wire;
    assign capture_release_event_wire = release_event_pending_reg | release_btn_event_wire;

    assign start_calib_rsp_wire = (!tx_busy_wire) && pending_calib_rsp_reg;
    assign start_debug_rsp_wire = (!tx_busy_wire) && (!pending_calib_rsp_reg) && pending_debug_rsp_reg;
    assign start_calib_debug_rsp_wire = (!tx_busy_wire) && (!pending_calib_rsp_reg) && (!pending_debug_rsp_reg) && pending_calib_debug_rsp_reg;
    assign start_raw_debug_rsp_wire = (!tx_busy_wire) && (!pending_calib_rsp_reg) && (!pending_debug_rsp_reg) && (!pending_calib_debug_rsp_reg) && pending_raw_debug_rsp_reg;
    assign start_status_rsp_wire = (!tx_busy_wire) && (!pending_calib_rsp_reg) && (!pending_debug_rsp_reg) && (!pending_calib_debug_rsp_reg) && (!pending_raw_debug_rsp_reg) && pending_status_rsp_reg;
    assign start_hand_rsp_wire = (!tx_busy_wire) && (!pending_calib_rsp_reg) && (!pending_debug_rsp_reg) && (!pending_calib_debug_rsp_reg) && (!pending_raw_debug_rsp_reg) && (!pending_status_rsp_reg) && pending_hand_rsp_reg;

    assign tx_start_wire = start_calib_rsp_wire | start_debug_rsp_wire | start_calib_debug_rsp_wire | start_raw_debug_rsp_wire | start_status_rsp_wire | start_hand_rsp_wire;
    assign tx_packet_kind_wire =
        start_calib_rsp_wire ? PACKET_KIND_CALIB :
        start_debug_rsp_wire ? PACKET_KIND_DEBUG :
        start_calib_debug_rsp_wire ? PACKET_KIND_CALIB_DEBUG :
        start_raw_debug_rsp_wire ? PACKET_KIND_RAW_DEBUG :
        start_status_rsp_wire ? PACKET_KIND_STATUS :
                                PACKET_KIND_HAND;

    virtual_grab_cmd_rx u_cmd_rx (
        .clk              (clk),
        .rst_n            (rst_n),
        .rx_valid         (rx_valid),
        .rx_data          (rx_data),
        .cmd_calibrate    (cmd_calibrate_wire),
        .cmd_start        (cmd_start_wire),
        .cmd_light_start  (cmd_light_start_wire),
        .cmd_stop         (cmd_stop_wire),
        .cmd_map_relocalize(cmd_map_relocalize_wire),
        .overlay_circle_valid(overlay_circle_valid),
        .overlay_circle_grabbed(overlay_circle_grabbed),
        .overlay_circle_x (overlay_circle_x),
        .overlay_circle_y (overlay_circle_y),
        .target_cross_valid(target_cross_valid),
        .target_cross_x   (target_cross_x),
        .target_cross_y   (target_cross_y),
        .packet_error_pulse(cmd_error_wire)
    );

    virtual_grab_button_event #(
        .STABLE_CYCLES(BTN_STABLE_CYCLES)
    ) u_grab_btn (
        .clk        (clk),
        .rst_n      (rst_n),
        .button_raw (grab_btn_raw),
        .press_pulse(grab_btn_event_wire)
    );

    virtual_grab_button_event #(
        .STABLE_CYCLES(BTN_STABLE_CYCLES)
    ) u_release_btn (
        .clk        (clk),
        .rst_n      (rst_n),
        .button_raw (release_btn_raw),
        .press_pulse(release_btn_event_wire)
    );

    virtual_grab_packet_tx #(
        .X_WIDTH   (X_WIDTH),
        .Y_WIDTH   (Y_WIDTH),
        .AREA_WIDTH(AREA_WIDTH)
    ) u_packet_tx (
        .clk          (clk),
        .rst_n        (rst_n),
        .start        (tx_start_wire),
        .packet_kind  (tx_packet_kind_wire),
        .tx_ready     (tx_ready),
        .calib_valid  (calib_valid_rsp_reg),
        .red_x        (red_x_rsp_reg),
        .red_y        (red_y_rsp_reg),
        .origin_valid (origin_valid_rsp_reg),
        .origin_x     (origin_x_rsp_reg),
        .origin_y     (origin_y_rsp_reg),
        .green_valid  (green_valid_rsp_reg),
        .green_x      (green_x_rsp_reg),
        .green_y      (green_y_rsp_reg),
        .red_count    (red_count_rsp_reg),
        .green_count  (green_count_rsp_reg),
        .blue_count   (blue_count_rsp_reg),
        .white_count  (white_count_rsp_reg),
        .committed_pixel_count(committed_pixel_count_rsp_reg),
        .live_pixel_count(live_pixel_count_rsp_reg),
        .loose_red_count(loose_red_count_rsp_reg),
        .max_r(max_r_rsp_reg),
        .max_g(max_g_rsp_reg),
        .max_b(max_b_rsp_reg),
        .last_r(last_r_rsp_reg),
        .last_g(last_g_rsp_reg),
        .last_b(last_b_rsp_reg),
        .calib_debug_flags(calib_debug_flags_rsp_reg),
        .red_min_x(red_min_x_rsp_reg),
        .red_max_x(red_max_x_rsp_reg),
        .red_min_y(red_min_y_rsp_reg),
        .red_max_y(red_max_y_rsp_reg),
        .red_width(red_width_rsp_reg),
        .red_height(red_height_rsp_reg),
        .black_frame_debug_flags(black_frame_debug_flags_rsp_reg),
        .black_frame_left_x(black_frame_left_x_rsp_reg),
        .black_frame_right_x(black_frame_right_x_rsp_reg),
        .black_frame_top_y(black_frame_top_y_rsp_reg),
        .black_frame_bottom_y(black_frame_bottom_y_rsp_reg),
        .frame_id     (hand_frame_id_rsp_reg),
        .hand_valid   (hand_valid_rsp_reg),
        .hand_x       (hand_x_rsp_reg),
        .hand_y       (hand_y_rsp_reg),
        .hand_area    (hand_area_rsp_reg),
        .grab_event   (hand_grab_event_rsp_reg),
        .release_event(hand_release_event_rsp_reg),
        .run_state    (status_rsp_reg),
        .busy         (tx_busy_wire),
        .tx_valid     (tx_valid),
        .tx_data      (tx_data),
        .tx_last      (tx_last)
    );

    // Maintain run state, latch outgoing packet snapshots, and arbitrate packet launch order.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            streaming_enable_reg      <= 1'b0;
            light_mode_enable_reg     <= 1'b0;
            calibrated_valid_reg      <= 1'b0;
            frame_id_reg              <= 16'h0000;
            grab_event_pending_reg    <= 1'b0;
            release_event_pending_reg <= 1'b0;
            pending_calib_rsp_reg     <= 1'b0;
            pending_debug_rsp_reg     <= 1'b0;
            pending_calib_debug_rsp_reg <= 1'b0;
            pending_raw_debug_rsp_reg <= 1'b0;
            pending_status_rsp_reg    <= 1'b0;
            pending_hand_rsp_reg      <= 1'b0;
            calib_valid_rsp_reg       <= 1'b0;
            red_x_rsp_reg             <= {X_WIDTH{1'b0}};
            red_y_rsp_reg             <= {Y_WIDTH{1'b0}};
            origin_valid_rsp_reg      <= 1'b0;
            origin_x_rsp_reg          <= {X_WIDTH{1'b0}};
            origin_y_rsp_reg          <= {Y_WIDTH{1'b0}};
            green_valid_rsp_reg       <= 1'b0;
            green_x_rsp_reg           <= {X_WIDTH{1'b0}};
            green_y_rsp_reg           <= {Y_WIDTH{1'b0}};
            red_count_rsp_reg         <= 24'd0;
            green_count_rsp_reg       <= 24'd0;
            blue_count_rsp_reg        <= 24'd0;
            white_count_rsp_reg       <= 24'd0;
            committed_pixel_count_rsp_reg <= 24'd0;
            live_pixel_count_rsp_reg  <= 24'd0;
            loose_red_count_rsp_reg   <= 24'd0;
            max_r_rsp_reg             <= 8'd0;
            max_g_rsp_reg             <= 8'd0;
            max_b_rsp_reg             <= 8'd0;
            last_r_rsp_reg            <= 8'd0;
            last_g_rsp_reg            <= 8'd0;
            last_b_rsp_reg            <= 8'd0;
            calib_debug_flags_rsp_reg  <= 8'd0;
            red_min_x_rsp_reg          <= {X_WIDTH{1'b0}};
            red_max_x_rsp_reg          <= {X_WIDTH{1'b0}};
            red_min_y_rsp_reg          <= {Y_WIDTH{1'b0}};
            red_max_y_rsp_reg          <= {Y_WIDTH{1'b0}};
            red_width_rsp_reg          <= {X_WIDTH{1'b0}};
            red_height_rsp_reg         <= {Y_WIDTH{1'b0}};
            black_frame_debug_flags_rsp_reg <= 8'd0;
            black_frame_left_x_rsp_reg <= {X_WIDTH{1'b0}};
            black_frame_right_x_rsp_reg <= {X_WIDTH{1'b0}};
            black_frame_top_y_rsp_reg <= {Y_WIDTH{1'b0}};
            black_frame_bottom_y_rsp_reg <= {Y_WIDTH{1'b0}};
            status_rsp_reg            <= RUN_STATE_IDLE;
            hand_frame_id_rsp_reg     <= 16'h0000;
            hand_valid_rsp_reg        <= 1'b0;
            hand_x_rsp_reg            <= {X_WIDTH{1'b0}};
            hand_y_rsp_reg            <= {Y_WIDTH{1'b0}};
            hand_area_rsp_reg         <= {AREA_WIDTH{1'b0}};
            hand_grab_event_rsp_reg   <= 1'b0;
            hand_release_event_rsp_reg<= 1'b0;
        end else begin
            if (grab_btn_event_wire) begin
                grab_event_pending_reg <= 1'b1;
            end

            if (release_btn_event_wire) begin
                release_event_pending_reg <= 1'b1;
            end

            if (cmd_calibrate_wire) begin
                calibrated_valid_reg <= red_valid;
                streaming_enable_reg <= 1'b0;
                light_mode_enable_reg <= 1'b0;
                pending_calib_rsp_reg <= 1'b1;
                pending_debug_rsp_reg <= 1'b1;
                pending_calib_debug_rsp_reg <= 1'b1;
                pending_raw_debug_rsp_reg <= 1'b1;
                pending_status_rsp_reg <= 1'b0;
                pending_hand_rsp_reg <= 1'b0;
                frame_id_reg <= 16'h0000;
                grab_event_pending_reg <= 1'b0;
                release_event_pending_reg <= 1'b0;

                calib_valid_rsp_reg  <= red_valid;
                red_x_rsp_reg        <= red_x;
                red_y_rsp_reg        <= red_y;
                origin_valid_rsp_reg <= origin_valid;
                origin_x_rsp_reg     <= origin_x;
                origin_y_rsp_reg     <= origin_y;
                green_valid_rsp_reg  <= green_valid;
                green_x_rsp_reg      <= green_x;
                green_y_rsp_reg      <= green_y;
                red_count_rsp_reg    <= red_pixel_count;
                green_count_rsp_reg  <= green_pixel_count;
                blue_count_rsp_reg   <= blue_pixel_count;
                white_count_rsp_reg  <= white_pixel_count;
                committed_pixel_count_rsp_reg <= committed_pixel_count;
                live_pixel_count_rsp_reg <= live_pixel_count;
                loose_red_count_rsp_reg <= loose_red_pixel_count;
                max_r_rsp_reg <= max_pixel_r;
                max_g_rsp_reg <= max_pixel_g;
                max_b_rsp_reg <= max_pixel_b;
                last_r_rsp_reg <= last_pixel_r;
                last_g_rsp_reg <= last_pixel_g;
                last_b_rsp_reg <= last_pixel_b;
                calib_debug_flags_rsp_reg <= calib_debug_flags;
                red_min_x_rsp_reg <= red_min_x;
                red_max_x_rsp_reg <= red_max_x;
                red_min_y_rsp_reg <= red_min_y;
                red_max_y_rsp_reg <= red_max_y;
                red_width_rsp_reg <= red_width;
                red_height_rsp_reg <= red_height;
                black_frame_debug_flags_rsp_reg <= black_frame_debug_flags;
                black_frame_left_x_rsp_reg <= black_frame_left_x;
                black_frame_right_x_rsp_reg <= black_frame_right_x;
                black_frame_top_y_rsp_reg <= black_frame_top_y;
                black_frame_bottom_y_rsp_reg <= black_frame_bottom_y;
            end

            if (cmd_start_wire) begin
                light_mode_enable_reg <= 1'b0;
                if (calibrated_valid_reg) begin
                    streaming_enable_reg <= 1'b1;
                    status_rsp_reg <= RUN_STATE_STREAMING;
                end else begin
                    streaming_enable_reg <= 1'b0;
                    status_rsp_reg <= RUN_STATE_IDLE;
                end
                pending_status_rsp_reg <= 1'b1;
            end

            if (cmd_light_start_wire) begin
                light_mode_enable_reg <= 1'b1;
                if (calibrated_valid_reg) begin
                    streaming_enable_reg <= 1'b1;
                    status_rsp_reg <= RUN_STATE_STREAMING;
                end else begin
                    streaming_enable_reg <= 1'b0;
                    status_rsp_reg <= RUN_STATE_IDLE;
                end
                pending_status_rsp_reg <= 1'b1;
            end

            if (cmd_stop_wire) begin
                streaming_enable_reg <= 1'b0;
                light_mode_enable_reg <= 1'b0;
                status_rsp_reg <= calibrated_valid_reg ? RUN_STATE_CALIBRATED : RUN_STATE_IDLE;
                pending_status_rsp_reg <= 1'b1;
            end

            if (cmd_error_wire) begin
                status_rsp_reg <= streaming_enable_reg ? RUN_STATE_STREAMING :
                                  calibrated_valid_reg ? RUN_STATE_CALIBRATED :
                                  RUN_STATE_IDLE;
            end

            if (hand_update && streaming_enable_reg && !pending_hand_rsp_reg) begin
                pending_hand_rsp_reg       <= 1'b1;
                hand_frame_id_rsp_reg      <= frame_id_reg + 16'h0001;
                hand_valid_rsp_reg         <= hand_valid;
                hand_x_rsp_reg             <= hand_x;
                hand_y_rsp_reg             <= hand_y;
                hand_area_rsp_reg          <= hand_area;
                hand_grab_event_rsp_reg    <= capture_grab_event_wire;
                hand_release_event_rsp_reg <= capture_release_event_wire;
                frame_id_reg               <= frame_id_reg + 16'h0001;
                grab_event_pending_reg     <= 1'b0;
                release_event_pending_reg  <= 1'b0;
            end

            if (start_calib_rsp_wire) begin
                pending_calib_rsp_reg <= 1'b0;
            end

            if (start_debug_rsp_wire) begin
                pending_debug_rsp_reg <= 1'b0;
            end

            if (start_calib_debug_rsp_wire) begin
                pending_calib_debug_rsp_reg <= 1'b0;
            end

            if (start_raw_debug_rsp_wire) begin
                pending_raw_debug_rsp_reg <= 1'b0;
            end

            if (start_status_rsp_wire) begin
                pending_status_rsp_reg <= 1'b0;
            end

            if (start_hand_rsp_wire) begin
                pending_hand_rsp_reg <= 1'b0;
            end
        end
    end

endmodule
