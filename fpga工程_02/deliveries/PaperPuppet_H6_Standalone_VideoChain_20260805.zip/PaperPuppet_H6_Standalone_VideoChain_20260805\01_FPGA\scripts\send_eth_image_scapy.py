#!/usr/bin/env python3
"""Send still-image frames to the FPGA Ethernet video RX path.

The default path uses the Windows UDP stack so ARP, MAC lookup, buffering, and
NIC transmission stay in the kernel.  Scapy L2 mode remains available as a
fixed-MAC fallback for board bring-up.
"""

import argparse
import os
import socket
import sys
import time

from PIL import Image, ImageOps


WIDTH = 1280
HEIGHT = 720
HALF_WIDTH = WIDTH // 2
CHUNK_PIXELS = 320
CHUNKS_PER_HALF = HALF_WIDTH // CHUNK_PIXELS
CHUNKS_PER_LINE = WIDTH // CHUNK_PIXELS
CODEC_RGB888_LITERAL = 1
CODEC_RGB888_H2_LINE = 2
CODEC_RGB888_H2_CHUNK = 3
IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".bmp")


def pick_image(photo_dir):
    candidates = []
    for name in os.listdir(photo_dir):
        path = os.path.join(photo_dir, name)
        if os.path.isfile(path) and name.lower().endswith(IMAGE_EXTS):
            candidates.append(path)
    if not candidates:
        raise FileNotFoundError(f"no image found in {photo_dir}")
    candidates.sort(key=lambda p: (os.path.getmtime(p), p), reverse=True)
    return candidates[0]


def load_rgb_frame(path):
    image = Image.open(path).convert("RGB")
    image = ImageOps.fit(image, (WIDTH, HEIGHT), method=Image.Resampling.BICUBIC)
    return image.tobytes()


def make_header(frame_id, line, half, chunk, codec):
    return bytes(
        [
            0x45,
            0x56,
            frame_id & 0xFF,
            (line >> 8) & 0x07,
            line & 0xFF,
            half & 0x01,
            chunk & 0x03,
            codec & 0x03,
        ]
    )


def make_raw888_chunk(frame, line, half, chunk):
    x0 = half * HALF_WIDTH + chunk * CHUNK_PIXELS
    row0 = line * WIDTH * 3
    start = row0 + x0 * 3
    return frame[start : start + CHUNK_PIXELS * 3]


def make_h2_halfline(frame, line, half):
    x0 = half * HALF_WIDTH
    row0 = line * WIDTH * 3
    start = row0 + x0 * 3
    src = frame[start : start + HALF_WIDTH * 3]
    out = bytearray((HALF_WIDTH // 2) * 3)
    out[0::3] = src[0::6]
    out[1::3] = src[1::6]
    out[2::3] = src[2::6]
    return bytes(out)


def make_h2_chunk(frame, line, half, chunk):
    x0 = half * HALF_WIDTH + chunk * CHUNK_PIXELS
    row0 = line * WIDTH * 3
    start = row0 + x0 * 3
    src = frame[start : start + CHUNK_PIXELS * 3]
    out = bytearray((CHUNK_PIXELS // 2) * 3)
    out[0::3] = src[0::6]
    out[1::3] = src[1::6]
    out[2::3] = src[2::6]
    return bytes(out)


def frame_payloads(frame, frame_id, codec):
    for line in range(HEIGHT):
        sdram_bank = line & 1
        if codec == "h2":
            for segment in range(2):
                yield make_header(
                    frame_id, line, sdram_bank, segment, CODEC_RGB888_H2_LINE
                ) + make_h2_halfline(frame, line, segment)
            continue

        for segment in range(CHUNKS_PER_LINE):
            half = segment // CHUNKS_PER_HALF
            chunk = segment % CHUNKS_PER_HALF
            if codec == "h2chunk":
                body = make_h2_chunk(frame, line, half, chunk)
                codec_id = CODEC_RGB888_H2_CHUNK
            else:
                body = make_raw888_chunk(frame, line, half, chunk)
                codec_id = CODEC_RGB888_LITERAL
            yield make_header(frame_id, line, sdram_bank, segment, codec_id) + body


def packets_per_frame(codec):
    if codec == "h2":
        return HEIGHT * 2
    return HEIGHT * 2 * CHUNKS_PER_HALF


def open_udp_sender(args):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, args.send_buffer)
    if args.pc_ip:
        sock.bind((args.pc_ip, args.sport))
    sock.connect((args.fpga_ip, args.port))

    def tx_send(payload):
        return sock.send(payload)

    return f"kernel-udp local={sock.getsockname()[0]}:{sock.getsockname()[1]}", sock, tx_send


def open_scapy_sender(args):
    from scapy.all import Ether, IP, UDP, Raw, conf, get_if_addr, get_if_hwaddr

    if not args.pc_ip:
        raise RuntimeError("--pc-ip is required for --tx-mode scapy")

    iface = None
    for candidate in conf.ifaces.values():
        try:
            if get_if_addr(candidate.name) == args.pc_ip:
                iface = candidate
                break
        except Exception:
            pass
    if iface is None:
        raise RuntimeError(f"no Scapy/Npcap interface has IP {args.pc_ip}")

    src_mac = args.pc_mac or get_if_hwaddr(iface.name)
    sock = conf.L2socket(iface=iface.name)

    def tx_send(payload):
        pkt = (
            Ether(src=src_mac, dst=args.fpga_mac)
            / IP(src=args.pc_ip, dst=args.fpga_ip)
            / UDP(sport=args.sport, dport=args.port)
            / Raw(payload)
        )
        sock.send(pkt)
        return len(payload)

    return f"scapy-l2 iface={iface.name} src_mac={src_mac}", sock, tx_send


def open_sender(args):
    if args.tx_mode == "udp":
        return open_udp_sender(args)
    return open_scapy_sender(args)


def probe_fpga_arp(args):
    from scapy.all import ARP, Ether, conf, get_if_addr, get_if_hwaddr, srp

    iface = None
    for candidate in conf.ifaces.values():
        try:
            if get_if_addr(candidate.name) == args.pc_ip:
                iface = candidate
                break
        except Exception:
            pass
    if iface is None:
        raise RuntimeError(f"no Scapy/Npcap interface has IP {args.pc_ip}")

    pc_mac = args.pc_mac or get_if_hwaddr(iface.name)
    request = Ether(src=pc_mac, dst="ff:ff:ff:ff:ff:ff") / ARP(
        op=1,
        hwsrc=pc_mac,
        psrc=args.pc_ip,
        hwdst="00:00:00:00:00:00",
        pdst=args.fpga_ip,
    )
    answered, _ = srp(
        request,
        iface=iface.name,
        timeout=args.arp_timeout,
        retry=args.arp_retry,
        verbose=False,
    )
    expected_mac = args.fpga_mac.lower().replace("-", ":")
    for _, received in answered:
        reply = received.getlayer(ARP)
        if reply is None or int(reply.op) != 2:
            continue
        if str(reply.psrc) != args.fpga_ip or str(reply.pdst) != args.pc_ip:
            continue
        reply_mac = str(reply.hwsrc).lower().replace("-", ":")
        if reply_mac != expected_mac:
            raise RuntimeError(
                f"ARP reply MAC mismatch: expected {expected_mac}, received {reply_mac}"
            )
        return f"{iface.name} {args.fpga_ip}->{reply_mac}"
    raise RuntimeError(f"FPGA {args.fpga_ip} did not answer ARP on {iface.name}")


def send_image(args):
    image_path = args.image or pick_image(args.photo_dir)
    frame = load_rgb_frame(image_path)
    frame_period_s = 0.0 if args.fps <= 0 else 1.0 / args.fps
    packet_gap_s = args.packet_gap_us / 1_000_000.0

    arp_desc = probe_fpga_arp(args) if args.tx_mode == "udp" and args.probe_arp else "off"
    tx_desc, sock, tx_send = open_sender(args)
    try:
        print(f"tx_mode={args.tx_mode} tx={tx_desc}")
        print(f"arp_probe={arp_desc}")
        print(f"dst={args.fpga_ip}:{args.port}")
        if args.tx_mode == "scapy":
            print(f"dst_mac={args.fpga_mac}")
        print(f"image={os.path.abspath(image_path)}")
        print(
            f"codec={args.codec} packets_per_frame={packets_per_frame(args.codec)} "
            f"frames={args.frames} packet_gap_us={args.packet_gap_us}"
        )

        frame_id = args.frame_id & 0xFF
        for frame_index in range(args.frames):
            start = time.perf_counter()
            packets = 0
            payload_bytes = 0
            for payload in frame_payloads(frame, frame_id, args.codec):
                tx_send(payload)
                packets += 1
                payload_bytes += len(payload)
                if packet_gap_s > 0:
                    time.sleep(packet_gap_s)

            elapsed = time.perf_counter() - start
            payload_mbps = 0.0 if elapsed <= 0 else (payload_bytes * 8) / elapsed / 1_000_000.0
            print(
                f"frame={frame_id:02X} index={frame_index + 1}/{args.frames} "
                f"packets={packets} udp_payload_bytes={payload_bytes} "
                f"elapsed={elapsed:.3f}s payload_mbps={payload_mbps:.1f}"
            )
            frame_id = (frame_id + 1) & 0xFF

            if frame_period_s > elapsed and frame_index + 1 < args.frames:
                time.sleep(frame_period_s - elapsed)
    finally:
        try:
            sock.close()
        except Exception:
            pass


def main():
    parser = argparse.ArgumentParser(description="Send still images to FPGA over UDP.")
    parser.add_argument("--photo-dir", default=r"D:\Work\FPGA\eLinx\New_shader\photo")
    parser.add_argument("--image", default="")
    parser.add_argument("--pc-ip", default="192.168.1.102")
    parser.add_argument("--pc-mac", default="")
    parser.add_argument("--fpga-ip", default="192.168.1.10")
    parser.add_argument("--fpga-mac", default="00:11:22:33:44:55")
    parser.add_argument("--sport", type=int, default=43210)
    parser.add_argument("--port", type=int, default=1234)
    parser.add_argument("--frame-id", type=int, default=1)
    parser.add_argument("--frames", type=int, default=2)
    parser.add_argument("--fps", type=float, default=10.0, help="0 sends each frame as fast as possible")
    parser.add_argument("--codec", choices=["raw888", "h2", "h2chunk"], default="h2")
    parser.add_argument("--tx-mode", choices=["udp", "scapy"], default="udp")
    parser.add_argument("--send-buffer", type=int, default=8 * 1024 * 1024)
    parser.add_argument("--packet-gap-us", type=float, default=0.0)
    parser.add_argument("--probe-arp", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--arp-timeout", type=float, default=1.0)
    parser.add_argument("--arp-retry", type=int, default=2)
    args = parser.parse_args()

    if args.frames <= 0:
        parser.error("--frames must be > 0")
    if args.fps < 0:
        parser.error("--fps must be >= 0")
    if args.packet_gap_us < 0:
        parser.error("--packet-gap-us must be >= 0")
    if args.arp_timeout <= 0:
        parser.error("--arp-timeout must be > 0")
    if args.arp_retry < 0:
        parser.error("--arp-retry must be >= 0")
    send_image(args)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Stopped.")
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        sys.exit(1)
