// ============================================================================
// Module Function:
//   MDIO read/write test helper.
// ============================================================================
module mdio_rw_test(
    input         sys_clk,
    input         sys_rst_n,
    output        eth_mdc,
    inout         eth_mdio,
    input         touch_key,
    input         i_Key_GBCR,
    input         i_Key_ANAR,
    output [1:0]  led,

    output [4:0]  dbg_phy_addr,
    output        dbg_phy_found,
    output        dbg_bmsr_ack,
    output        dbg_physr_ack,
    output [15:0] dbg_bmsr,
    output [15:0] dbg_physr,
    output        dbg_update_toggle
);

wire        op_exec;
wire        op_rh_wl;
wire [4:0]  op_phy_addr;
wire [4:0]  op_addr;
wire [15:0] op_wr_data;
wire        op_done;
wire [15:0] op_rd_data;
wire        op_rd_ack;
wire        dri_clk;

mdio_dri #(
    .PHY_ADDR(5'b00001),
    .CLK_DIV (6'd10)
) u_mdio_dri (
    .clk_50M        (sys_clk),
    .rst_n          (sys_rst_n),
    .i_phy_addr     (op_phy_addr),
    .i_trig_start   (op_exec),
    .i_rh_wl        (op_rh_wl),
    .i_reg_addr     (op_addr),
    .i_wr_data      (op_wr_data),
    .o_transmit_done(op_done),
    .o_rd_data      (op_rd_data),
    .o_rd_ack       (op_rd_ack),
    .dri_clk        (dri_clk),
    .o_MDC          (eth_mdc),
    .io_MDIO        (eth_mdio)
);

mdio_ctrl u_mdio_ctrl (
    .clk              (dri_clk),
    .rst_n            (sys_rst_n),
    .i_Key_GBCR       (!i_Key_GBCR),
    .i_Key_ANAR       (!i_Key_ANAR),
    .soft_rst_trig    (!touch_key),
    .i_transmit_done  (op_done),
    .i_rd_data        (op_rd_data),
    .i_rd_ack         (op_rd_ack),
    .o_trigger_start  (op_exec),
    .o_rh_wl          (op_rh_wl),
    .o_phy_addr       (op_phy_addr),
    .o_addr           (op_addr),
    .o_wr_data        (op_wr_data),
    .led              (led),
    .dbg_phy_addr     (dbg_phy_addr),
    .dbg_phy_found    (dbg_phy_found),
    .dbg_bmsr_ack     (dbg_bmsr_ack),
    .dbg_physr_ack    (dbg_physr_ack),
    .dbg_bmsr         (dbg_bmsr),
    .dbg_physr        (dbg_physr),
    .dbg_update_toggle(dbg_update_toggle)
);

endmodule
