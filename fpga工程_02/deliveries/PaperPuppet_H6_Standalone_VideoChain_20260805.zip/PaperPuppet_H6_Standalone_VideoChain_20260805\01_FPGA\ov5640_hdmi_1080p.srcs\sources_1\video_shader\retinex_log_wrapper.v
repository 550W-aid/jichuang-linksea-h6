// Module Function:
//   Registers the fixed-point logarithm result and preserves a replaceable
//   boundary for a future vendor logarithm IP implementation.
module retinex_log_wrapper #(
    parameter IN_WIDTH  = 9,
    parameter FRAC_BITS = 8,
    parameter OUT_WIDTH = 12
) (
    clk,
    din,
    dout
);

    input clk;
    input [IN_WIDTH-1:0] din;
    output [OUT_WIDTH-1:0] dout;
    reg [OUT_WIDTH-1:0] dout;
    wire [OUT_WIDTH-1:0] dout_comb_w;

`ifdef ELINX_USE_FP_LOG_IP
    // FP_LOG requires IEEE floating-point input/output and has a long fixed latency.
    // The current project still needs FP_CONVERT and FP_ADD_SUB to build a complete
    // floating-point log-difference pipeline, so behavior simulation keeps the fixed-point
    // approximation active until those IP blocks are added.
    retinex_log2_approx #(
        .IN_WIDTH (IN_WIDTH),
        .FRAC_BITS(FRAC_BITS),
        .OUT_WIDTH(OUT_WIDTH)
    ) u_log_approx (
        .din (din),
        .dout(dout_comb_w)
    );
`else
    retinex_log2_approx #(
        .IN_WIDTH (IN_WIDTH),
        .FRAC_BITS(FRAC_BITS),
        .OUT_WIDTH(OUT_WIDTH)
    ) u_log_approx (
        .din (din),
        .dout(dout_comb_w)
    );
`endif

    always @(posedge clk) begin
        dout <= dout_comb_w;
    end

endmodule
