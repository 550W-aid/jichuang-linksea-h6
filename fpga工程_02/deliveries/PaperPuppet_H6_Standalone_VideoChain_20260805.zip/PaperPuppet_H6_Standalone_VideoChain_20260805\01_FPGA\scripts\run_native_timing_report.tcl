﻿set scriptDir [file dirname [file normalize [info script]]]
set dir [file normalize [file join $scriptDir ".."]]
set tclFile "D:/eLinx3.0/bin/shell/bin/run_timing_report.tcl"
cd "D:/eLinx3.0/bin/shell/bin"
set prj ov5640_hdmi_1080p
set topEntity TOP1
set seriesName "eHiChip6"
set deviceName "EQ6HL130"
set ImpleName imple_1
source $tclFile
run_tming_report $dir $prj $topEntity $seriesName $deviceName $ImpleName
exit 0

