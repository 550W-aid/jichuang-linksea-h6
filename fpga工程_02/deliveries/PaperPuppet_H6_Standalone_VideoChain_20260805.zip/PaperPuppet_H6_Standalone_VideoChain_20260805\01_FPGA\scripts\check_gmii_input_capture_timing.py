"""Gate post-route GMII input capture alignment using the eLinx timing DB."""

from __future__ import annotations

import argparse
import sqlite3
import sys
from pathlib import Path


PERIOD_PS = 8_000.0
PHY_SETUP_PS = 2_000.0
PHY_HOLD_PS = 500.0
MIN_RELEASE_MARGIN_PS = 250.0
EXPECTED_INPUTS = ["eth_rx_ctl"] + [f"eth_rxd[{bit}]" for bit in range(8)]
CAPTURE_CELL = "u_gmii_rx_input_capture"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", required=True, type=Path)
    return parser.parse_args()


def load_paths(connection: sqlite3.Connection, table: str) -> dict[str, sqlite3.Row]:
    rows = connection.execute(
        f"""
        SELECT from_cell_name, to_cell_name, total_delay, clock_skew,
               is_sink_clock_inverted
        FROM {table}
        WHERE from_cell_name LIKE 'eth_rx%~I/padio'
          AND to_cell_name LIKE '%u_gmii_rx_input_capture%|ff/D'
        """
    ).fetchall()
    result: dict[str, sqlite3.Row] = {}
    for row in rows:
        endpoint = str(row["from_cell_name"]).removesuffix("~I/padio")
        if endpoint not in EXPECTED_INPUTS:
            continue
        if CAPTURE_CELL not in str(row["to_cell_name"]):
            raise RuntimeError(f"{endpoint} does not terminate in {CAPTURE_CELL}")
        if endpoint in result:
            raise RuntimeError(f"duplicate capture path for {endpoint} in {table}")
        result[endpoint] = row
    missing = sorted(set(EXPECTED_INPUTS) - set(result))
    if missing:
        raise RuntimeError(f"missing GMII input capture paths in {table}: {', '.join(missing)}")
    return result


def main() -> int:
    args = parse_args()
    if not args.db.is_file():
        raise RuntimeError(f"timing database was not found: {args.db}")

    connection = sqlite3.connect(args.db)
    connection.row_factory = sqlite3.Row
    try:
        longest = load_paths(connection, "elinx_unconstrain_longest_path_report")
        shortest = load_paths(connection, "elinx_unconstrain_shortest_path_report")
    finally:
        connection.close()

    setup_margins: dict[str, float] = {}
    hold_margins: dict[str, float] = {}
    for endpoint in EXPECTED_INPUTS:
        max_row = longest[endpoint]
        min_row = shortest[endpoint]
        capture_phase_ps = (
            PERIOD_PS / 2.0 if int(max_row["is_sink_clock_inverted"]) else 0.0
        )
        capture_clock_ps = (
            float(max_row["clock_skew"]) * 1_000.0 + capture_phase_ps
        )
        setup_margins[endpoint] = (
            PHY_SETUP_PS + capture_clock_ps - float(max_row["total_delay"])
        )
        hold_margins[endpoint] = (
            PHY_HOLD_PS + float(min_row["total_delay"]) - capture_clock_ps
        )

    worst_setup = min(setup_margins.values())
    worst_hold = min(hold_margins.values())
    print(
        "GMII RX capture timing: "
        f"setup_margin={worst_setup / 1000.0:.3f} ns "
        f"hold_margin={worst_hold / 1000.0:.3f} ns"
    )
    for endpoint in EXPECTED_INPUTS:
        print(
            f"  {endpoint}: setup={setup_margins[endpoint] / 1000.0:.3f} ns "
            f"hold={hold_margins[endpoint] / 1000.0:.3f} ns"
        )

    failures = []
    if worst_setup < MIN_RELEASE_MARGIN_PS:
        failures.append(f"setup margin {worst_setup / 1000.0:.3f} ns")
    if worst_hold < MIN_RELEASE_MARGIN_PS:
        failures.append(f"hold margin {worst_hold / 1000.0:.3f} ns")
    if failures:
        print(
            "GMII RX capture gate failed: " + ", ".join(failures)
            + f"; required margin is {MIN_RELEASE_MARGIN_PS / 1000.0:.3f} ns",
            file=sys.stderr,
        )
        return 1
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RuntimeError, sqlite3.Error) as exc:
        print(f"GMII RX capture audit error: {exc}", file=sys.stderr)
        raise SystemExit(2)
