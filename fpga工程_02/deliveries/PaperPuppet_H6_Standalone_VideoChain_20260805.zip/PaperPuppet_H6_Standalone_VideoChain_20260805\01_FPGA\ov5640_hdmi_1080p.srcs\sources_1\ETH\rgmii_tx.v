// ============================================================================
// Module Function:
//   RGMII transmit interface that converts byte stream data into PHY DDR transmit signals.
// ============================================================================
module rgmii_tx(
    //GMII发送端口
    input              gmii_tx_clk ,   //GMII发送时钟 
    input              gmii_tx_en  ,   //GMII输出数据有效信号
    input       [7:0]  gmii_txd    ,   //GMII输出数据        
    //RGMII发送端口
    output             rgmii_txc   ,   //RGMII发送数据时钟    
    output  reg        rgmii_tx_ctl,   //RGMII输出数据有效信号
    output  reg [3:0]  rgmii_txd       //RGMII输出数据     
    );
assign rgmii_txc = gmii_tx_clk;
reg  rgmii_tx_state;
// reg [7:0] Dreg;
// always @(posedge gmii_tx_clk) Dreg<=
always @(posedge gmii_tx_clk) begin
    if(gmii_tx_en) begin
        rgmii_tx_ctl<=1'b1;
        if(!rgmii_tx_state)begin
            rgmii_tx_state<=1;
            rgmii_txd<=gmii_txd[3:0];
        end
        else begin
            rgmii_tx_state<=0;
            rgmii_txd<=gmii_txd[7:4];
        end
    end
    else begin   
        rgmii_tx_state<=0;
        rgmii_txd<='d0;
        rgmii_tx_ctl<=0;
    end
end

// SDR_DDR#(
//     .Data_Size ( 4 )
// )ddo_x4_inst(
//     .dataout  ( rgmii_txd  ),
//     .outclock ( gmii_tx_clk ),
//     .datain_l ( gmii_txd[7:4] ),
//     .datain_h  ( gmii_txd[3:0]  )
// );

// SDR_DDR#(
//     .Data_Size ( 1 )
// )ddo_x1_inst(
//     .dataout  ( rgmii_tx_ctl  ),
//     .outclock ( gmii_tx_clk ),
//     .datain_l ( gmii_tx_en ),
//     .datain_h  ( gmii_tx_en  )
// );

// SDR_DDR#(
//     .Data_Size ( 1 )
// )ddo_x1_clk(
//     .datain_h(1'b1),
//     .datain_l(1'b0),
//     .outclock(gmii_tx_clk), 
//     .dataout(rgmii_txc)
// );

endmodule