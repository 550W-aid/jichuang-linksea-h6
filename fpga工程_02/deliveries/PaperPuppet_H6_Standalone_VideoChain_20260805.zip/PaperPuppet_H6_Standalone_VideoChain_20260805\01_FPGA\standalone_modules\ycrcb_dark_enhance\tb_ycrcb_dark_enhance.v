`timescale 1ns / 1ps

// Module Function:
//   Checks the standalone YCrCb dark-enhancement arithmetic, saturation,
//   fixed latency, chroma alignment, control alignment, and valid-gap handling.
module tb_ycrcb_dark_enhance;
    localparam integer IMAGE_WIDTH = 5;
    localparam integer LATENCY     = 3;
    localparam integer PIXELS      = 25;

    reg clk;
    reg rst_n;
    reg in_valid;
    reg in_sof;
    reg in_eol;
    reg [7:0] in_y;
    reg [7:0] in_cr;
    reg [7:0] in_cb;

    wire       out_valid;
    wire       out_sof;
    wire       out_eol;
    wire [7:0] out_y;
    wire [7:0] out_cr;
    wire [7:0] out_cb;

    wire       sat_out_valid;
    wire       sat_out_sof;
    wire       sat_out_eol;
    wire [7:0] sat_out_y;
    wire [7:0] sat_out_cr;
    wire [7:0] sat_out_cb;

    reg expected_valid [0:LATENCY-1];
    reg expected_sof [0:LATENCY-1];
    reg expected_eol [0:LATENCY-1];
    reg [7:0] expected_y [0:LATENCY-1];
    reg [7:0] expected_cr [0:LATENCY-1];
    reg [7:0] expected_cb [0:LATENCY-1];
    reg [7:0] expected_sat_y [0:LATENCY-1];

    integer index;
    integer drive_index;
    integer errors;
    integer checked_pixels;

    ycrcb_dark_enhance #(
        .IMAGE_WIDTH(IMAGE_WIDTH)
    ) dut (
        .clk      (clk),
        .rst_n    (rst_n),
        .in_valid (in_valid),
        .in_sof   (in_sof),
        .in_eol   (in_eol),
        .in_y     (in_y),
        .in_cr    (in_cr),
        .in_cb    (in_cb),
        .out_valid(out_valid),
        .out_sof  (out_sof),
        .out_eol  (out_eol),
        .out_y    (out_y),
        .out_cr   (out_cr),
        .out_cb   (out_cb)
    );

    ycrcb_dark_enhance #(
        .IMAGE_WIDTH(IMAGE_WIDTH),
        .DETAIL_GAIN(0),
        .LIFT_GAIN  (2),
        .TARGET_LUMA(255)
    ) saturation_dut (
        .clk      (clk),
        .rst_n    (rst_n),
        .in_valid (in_valid),
        .in_sof   (in_sof),
        .in_eol   (in_eol),
        .in_y     (in_y),
        .in_cr    (in_cr),
        .in_cb    (in_cb),
        .out_valid(sat_out_valid),
        .out_sof  (sat_out_sof),
        .out_eol  (sat_out_eol),
        .out_y    (sat_out_y),
        .out_cr   (sat_out_cr),
        .out_cb   (sat_out_cb)
    );

    function [7:0] expected_default_luma;
        input [7:0] value;
        begin
            expected_default_luma = (value < 8'd36) ? 8'd36 : value;
        end
    endfunction

    function [7:0] expected_saturated_luma;
        input [7:0] value;
        reg [9:0] lifted;
        begin
            lifted = {2'd0, value} +
                     ((10'd255 - {2'd0, value}) << 1);
            expected_saturated_luma = (lifted > 10'd255) ?
                                      8'd255 : lifted[7:0];
        end
    endfunction

    task drive_idle;
        begin
            @(negedge clk);
            in_valid = 1'b0;
            in_sof   = 1'b0;
            in_eol   = 1'b0;
            in_y     = 8'd0;
            in_cr    = 8'd0;
            in_cb    = 8'd0;
        end
    endtask

    task drive_pixel;
        input integer pixel_number;
        input [7:0] luma;
        begin
            @(negedge clk);
            in_valid = 1'b1;
            in_sof   = (pixel_number == 0);
            in_eol   = ((pixel_number % IMAGE_WIDTH) == (IMAGE_WIDTH - 1));
            in_y     = luma;
            in_cr    = 8'h40 + pixel_number[7:0];
            in_cb    = 8'h90 + pixel_number[7:0];
        end
    endtask

    always #5 clk = ~clk;

    always @(posedge clk) begin
        if (!rst_n) begin
            for (index = 0; index < LATENCY; index = index + 1) begin
                expected_valid[index] = 1'b0;
                expected_sof[index] = 1'b0;
                expected_eol[index] = 1'b0;
                expected_y[index] = 8'd0;
                expected_cr[index] = 8'd0;
                expected_cb[index] = 8'd0;
                expected_sat_y[index] = 8'd0;
            end
        end else begin
            for (index = LATENCY - 1; index > 0; index = index - 1) begin
                expected_valid[index] = expected_valid[index-1];
                expected_sof[index] = expected_sof[index-1];
                expected_eol[index] = expected_eol[index-1];
                expected_y[index] = expected_y[index-1];
                expected_cr[index] = expected_cr[index-1];
                expected_cb[index] = expected_cb[index-1];
                expected_sat_y[index] = expected_sat_y[index-1];
            end
            expected_valid[0] = in_valid;
            expected_sof[0] = in_valid && in_sof;
            expected_eol[0] = in_valid && in_eol;
            if (in_valid) begin
                expected_y[0] = expected_default_luma(in_y);
                expected_cr[0] = in_cr;
                expected_cb[0] = in_cb;
                expected_sat_y[0] = expected_saturated_luma(in_y);
            end

            #1;
            if (out_valid !== expected_valid[LATENCY-1]) begin
                $display("FAIL: default valid latency mismatch");
                errors = errors + 1;
            end
            if (sat_out_valid !== expected_valid[LATENCY-1]) begin
                $display("FAIL: saturation valid latency mismatch");
                errors = errors + 1;
            end

            if (expected_valid[LATENCY-1]) begin
                checked_pixels = checked_pixels + 1;
                if ((out_sof !== expected_sof[LATENCY-1]) ||
                    (out_eol !== expected_eol[LATENCY-1])) begin
                    $display("FAIL: default SOF/EOL alignment mismatch");
                    errors = errors + 1;
                end
                if ((sat_out_sof !== expected_sof[LATENCY-1]) ||
                    (sat_out_eol !== expected_eol[LATENCY-1])) begin
                    $display("FAIL: saturation SOF/EOL alignment mismatch");
                    errors = errors + 1;
                end
                if ((out_y !== expected_y[LATENCY-1]) ||
                    (out_cr !== expected_cr[LATENCY-1]) ||
                    (out_cb !== expected_cb[LATENCY-1])) begin
                    $display("FAIL: default pixel mismatch y=%0d/%0d cr=%0d/%0d cb=%0d/%0d",
                             out_y, expected_y[LATENCY-1],
                             out_cr, expected_cr[LATENCY-1],
                             out_cb, expected_cb[LATENCY-1]);
                    errors = errors + 1;
                end
                if ((sat_out_y !== expected_sat_y[LATENCY-1]) ||
                    (sat_out_cr !== expected_cr[LATENCY-1]) ||
                    (sat_out_cb !== expected_cb[LATENCY-1])) begin
                    $display("FAIL: saturation pixel mismatch");
                    errors = errors + 1;
                end
                if ((^out_y === 1'bx) || (^out_cr === 1'bx) ||
                    (^out_cb === 1'bx) || (^sat_out_y === 1'bx)) begin
                    $display("FAIL: valid output contains X");
                    errors = errors + 1;
                end
            end
        end
    end

    initial begin
        clk = 1'b0;
        rst_n = 1'b0;
        in_valid = 1'b0;
        in_sof = 1'b0;
        in_eol = 1'b0;
        in_y = 8'd0;
        in_cr = 8'd0;
        in_cb = 8'd0;
        errors = 0;
        checked_pixels = 0;

        repeat (5) @(posedge clk);
        @(negedge clk);
        rst_n = 1'b1;

        // Three uniform rows exercise the first non-border line-buffer pixels.
        for (drive_index = 0; drive_index < 15; drive_index = drive_index + 1) begin
            drive_pixel(drive_index, 8'd8);
        end
        drive_idle();
        drive_idle();
        drive_idle();

        // A fresh SOF resets the geometry counters. These two border rows make
        // the exact threshold behavior easy to check with varied luma values.
        drive_pixel(0, 8'd0);
        drive_pixel(1, 8'd1);
        drive_pixel(2, 8'd8);
        drive_idle();
        drive_pixel(3, 8'd35);
        drive_pixel(4, 8'd36);
        drive_pixel(5, 8'd80);
        drive_pixel(6, 8'd200);
        drive_pixel(7, 8'd254);
        drive_idle();
        drive_pixel(8, 8'd255);
        drive_pixel(9, 8'd120);

        drive_idle();
        repeat (8) drive_idle();

        if (checked_pixels != PIXELS) begin
            $display("FAIL: checked pixel count %0d/%0d", checked_pixels, PIXELS);
            errors = errors + 1;
        end

        if (errors == 0) begin
            $display("PASS: ycrcb_dark_enhance arithmetic and alignment");
        end else begin
            $display("FAIL: ycrcb_dark_enhance errors=%0d", errors);
        end
        $finish;
    end
endmodule
