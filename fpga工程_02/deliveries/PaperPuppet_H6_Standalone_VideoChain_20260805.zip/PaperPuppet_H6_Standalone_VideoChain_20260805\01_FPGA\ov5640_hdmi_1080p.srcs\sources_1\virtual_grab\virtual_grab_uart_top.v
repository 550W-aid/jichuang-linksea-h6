`timescale 1ns / 1ps

module virtual_grab_uart_top #(
    parameter integer IMAGE_WIDTH        = 1920,
    parameter integer IMAGE_HEIGHT       = 1080,
    parameter integer X_WIDTH            = 12,
    parameter integer Y_WIDTH            = 12,
    parameter integer AREA_WIDTH         = 16,
    parameter integer CLK_FREQ_HZ        = 50000000,
    parameter integer CLK_FREQ_MHZ       = 50,
    parameter integer UART_BPS           = 115200,
    parameter integer CALIB_MIN_RED_PIXELS = 4096,
    parameter integer CALIB_MAX_RED_PIXELS = 50000,
    parameter integer CALIB_MIN_RED_WIDTH  = 24,
    parameter integer CALIB_MAX_RED_WIDTH  = 260,
    parameter integer CALIB_MIN_RED_HEIGHT = 24,
    parameter integer CALIB_MAX_RED_HEIGHT = 260,
    parameter integer CALIB_MIN_WHITE_PIXELS = 128,
    parameter integer CALIB_MIN_GREEN_PIXELS = 16,
    parameter integer CALIB_RED_ROI_MIN_X = 0,
    parameter integer CALIB_RED_ROI_MAX_X = IMAGE_WIDTH - 1,
    parameter integer CALIB_RED_ROI_MIN_Y = 0,
    parameter integer CALIB_RED_ROI_MAX_Y = IMAGE_HEIGHT - 1,
    parameter integer BLUE_HAND_HOLD_FRAMES = 15,
    parameter integer BTN_STABLE_CYCLES  = 4
) (
    input  wire                   clk,
    input  wire                   rst_n,
    input  wire                   sof,
    input  wire                   eof,
    input  wire                   pixel_valid,
    input  wire [X_WIDTH-1:0]     pixel_x,
    input  wire [Y_WIDTH-1:0]     pixel_y,
    input  wire [7:0]             pixel_r,
    input  wire [7:0]             pixel_g,
    input  wire [7:0]             pixel_b,
    input  wire                   scene_roi_valid,
    input  wire [X_WIDTH-1:0]     scene_roi_min_x,
    input  wire [X_WIDTH-1:0]     scene_roi_max_x,
    input  wire [Y_WIDTH-1:0]     scene_roi_min_y,
    input  wire [Y_WIDTH-1:0]     scene_roi_max_y,
    input  wire                   black_frame_candidate_valid,
    input  wire                   black_frame_valid,
    input  wire                   black_frame_left_side_valid,
    input  wire                   black_frame_right_side_valid,
    input  wire [X_WIDTH-1:0]     black_frame_candidate_left_x,
    input  wire [X_WIDTH-1:0]     black_frame_candidate_right_x,
    input  wire [Y_WIDTH-1:0]     black_frame_candidate_top_y,
    input  wire [Y_WIDTH-1:0]     black_frame_candidate_bottom_y,
    input  wire                   uart_rxd,
    output wire                   uart_txd,
    input  wire                   grab_btn_raw,
    input  wire                   release_btn_raw,
    output wire                   streaming_enable,
    output wire                   map_relocalize,
    output wire                   calibrated_valid,
    output wire                   red_target_valid,
    output wire [X_WIDTH-1:0]     red_target_center_x,
    output wire [Y_WIDTH-1:0]     red_target_center_y,
    output wire [X_WIDTH-1:0]     red_target_min_x,
    output wire [X_WIDTH-1:0]     red_target_max_x,
    output wire [Y_WIDTH-1:0]     red_target_min_y,
    output wire [Y_WIDTH-1:0]     red_target_max_y,
    output wire                   blue_hand_valid,
    output wire [X_WIDTH-1:0]     blue_hand_min_x,
    output wire [X_WIDTH-1:0]     blue_hand_max_x,
    output wire [Y_WIDTH-1:0]     blue_hand_min_y,
    output wire [Y_WIDTH-1:0]     blue_hand_max_y,
    output wire                   overlay_circle_valid,
    output wire                   overlay_circle_grabbed,
    output wire [X_WIDTH-1:0]     overlay_circle_x,
    output wire [Y_WIDTH-1:0]     overlay_circle_y,
    output wire                   target_cross_valid,
    output wire [X_WIDTH-1:0]     target_cross_x,
    output wire [Y_WIDTH-1:0]     target_cross_y,
    output wire                   laser_spot_valid,
    output wire [X_WIDTH-1:0]     laser_spot_x,
    output wire [Y_WIDTH-1:0]     laser_spot_y,
    output wire [23:0]            laser_spot_pixel_count
);

    wire rx_valid_wire;
    wire [7:0] rx_data_wire;
    wire tx_valid_wire;
    wire [7:0] tx_data_wire;
    wire tx_last_wire;
    wire tx_ready_wire;
    wire uart_tx_busy_wire;
    wire uart_tx_start_wire;

    assign tx_ready_wire = !uart_tx_busy_wire;
    assign uart_tx_start_wire = tx_valid_wire && tx_ready_wire;

    virtual_grab_uart_rx #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ),
        .UART_BPS   (UART_BPS)
    ) u_uart_rx (
        .clk       (clk),
        .rst_n     (rst_n),
        .uart_rxd  (uart_rxd),
        .rx_valid  (rx_valid_wire),
        .rx_data   (rx_data_wire)
    );

    virtual_grab_host_bridge_top #(
        .IMAGE_WIDTH       (IMAGE_WIDTH),
        .IMAGE_HEIGHT      (IMAGE_HEIGHT),
        .X_WIDTH           (X_WIDTH),
        .Y_WIDTH           (Y_WIDTH),
        .AREA_WIDTH        (AREA_WIDTH),
        .CALIB_MIN_RED_PIXELS(CALIB_MIN_RED_PIXELS),
        .CALIB_MAX_RED_PIXELS(CALIB_MAX_RED_PIXELS),
        .CALIB_MIN_RED_WIDTH (CALIB_MIN_RED_WIDTH),
        .CALIB_MAX_RED_WIDTH (CALIB_MAX_RED_WIDTH),
        .CALIB_MIN_RED_HEIGHT(CALIB_MIN_RED_HEIGHT),
        .CALIB_MAX_RED_HEIGHT(CALIB_MAX_RED_HEIGHT),
        .CALIB_MIN_WHITE_PIXELS(CALIB_MIN_WHITE_PIXELS),
        .CALIB_MIN_GREEN_PIXELS(CALIB_MIN_GREEN_PIXELS),
        .CALIB_RED_ROI_MIN_X(CALIB_RED_ROI_MIN_X),
        .CALIB_RED_ROI_MAX_X(CALIB_RED_ROI_MAX_X),
        .CALIB_RED_ROI_MIN_Y(CALIB_RED_ROI_MIN_Y),
        .CALIB_RED_ROI_MAX_Y(CALIB_RED_ROI_MAX_Y),
        .BLUE_HAND_HOLD_FRAMES(BLUE_HAND_HOLD_FRAMES),
        .BTN_STABLE_CYCLES (BTN_STABLE_CYCLES)
    ) u_bridge (
        .clk              (clk),
        .rst_n            (rst_n),
        .sof              (sof),
        .eof              (eof),
        .pixel_valid      (pixel_valid),
        .pixel_x          (pixel_x),
        .pixel_y          (pixel_y),
        .pixel_r          (pixel_r),
        .pixel_g          (pixel_g),
        .pixel_b          (pixel_b),
        .scene_roi_valid  (scene_roi_valid),
        .scene_roi_min_x  (scene_roi_min_x),
        .scene_roi_max_x  (scene_roi_max_x),
        .scene_roi_min_y  (scene_roi_min_y),
        .scene_roi_max_y  (scene_roi_max_y),
        .black_frame_candidate_valid(black_frame_candidate_valid),
        .black_frame_valid          (black_frame_valid),
        .black_frame_left_side_valid(black_frame_left_side_valid),
        .black_frame_right_side_valid(black_frame_right_side_valid),
        .black_frame_candidate_left_x(black_frame_candidate_left_x),
        .black_frame_candidate_right_x(black_frame_candidate_right_x),
        .black_frame_candidate_top_y(black_frame_candidate_top_y),
        .black_frame_candidate_bottom_y(black_frame_candidate_bottom_y),
        .rx_valid         (rx_valid_wire),
        .rx_data          (rx_data_wire),
        .tx_valid         (tx_valid_wire),
        .tx_data          (tx_data_wire),
        .tx_last          (tx_last_wire),
        .tx_ready         (tx_ready_wire),
        .grab_btn_raw     (grab_btn_raw),
        .release_btn_raw  (release_btn_raw),
        .streaming_enable (streaming_enable),
        .map_relocalize   (map_relocalize),
        .calibrated_valid (calibrated_valid),
        .red_target_valid (red_target_valid),
        .red_target_center_x(red_target_center_x),
        .red_target_center_y(red_target_center_y),
        .red_target_min_x(red_target_min_x),
        .red_target_max_x(red_target_max_x),
        .red_target_min_y(red_target_min_y),
        .red_target_max_y(red_target_max_y),
        .blue_hand_valid (blue_hand_valid),
        .blue_hand_min_x (blue_hand_min_x),
        .blue_hand_max_x (blue_hand_max_x),
        .blue_hand_min_y (blue_hand_min_y),
        .blue_hand_max_y (blue_hand_max_y),
        .overlay_circle_valid(overlay_circle_valid),
        .overlay_circle_grabbed(overlay_circle_grabbed),
        .overlay_circle_x(overlay_circle_x),
        .overlay_circle_y(overlay_circle_y),
        .target_cross_valid(target_cross_valid),
        .target_cross_x(target_cross_x),
        .target_cross_y(target_cross_y),
        .laser_spot_valid(laser_spot_valid),
        .laser_spot_x(laser_spot_x),
        .laser_spot_y(laser_spot_y),
        .laser_spot_pixel_count(laser_spot_pixel_count)
    );

    virtual_grab_uart_tx #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ),
        .UART_BPS   (UART_BPS)
    ) u_uart_tx (
        .clk      (clk),
        .rst_n    (rst_n),
        .tx_start (uart_tx_start_wire),
        .tx_data  (tx_data_wire),
        .tx_busy  (uart_tx_busy_wire),
        .uart_txd (uart_txd)
    );

endmodule
