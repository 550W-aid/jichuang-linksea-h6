from pathlib import Path
import re
import unittest


ROUTE_SCRIPT = (
    Path(__file__).resolve().parents[1]
    / "scripts"
    / "run_route_with_read_sdc.tcl"
)


class RouteStabilitySettingsTest(unittest.TestCase):
    def test_crashing_setup_repair_pass_is_disabled(self) -> None:
        source = ROUTE_SCRIPT.read_text(encoding="utf-8")
        self.assertRegex(
            source,
            re.compile(r"FIX_SETUP_SLACK\s+0(?:\s|$)"),
        )


if __name__ == "__main__":
    unittest.main()
