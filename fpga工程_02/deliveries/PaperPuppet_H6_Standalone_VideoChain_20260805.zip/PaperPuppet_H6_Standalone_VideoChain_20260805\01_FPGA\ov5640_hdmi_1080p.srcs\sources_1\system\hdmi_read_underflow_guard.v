// ============================================================================
// Module Function:
//   Prevents HDMI from reading an empty SDRAM FIFO and latches the remainder
//   of the affected output frame as invalid for frame-boundary recovery.
// ============================================================================
module hdmi_read_underflow_guard #(
    parameter [10:0] GUARD_WORDS = 11'd2
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        frame_active_i,
    input  wire        rd_req0_need_i,
    input  wire        rd_req1_need_i,
    input  wire [10:0] fifo0_words_i,
    input  wire [10:0] fifo1_words_i,
    output wire        rd_req0_o,
    output wire        rd_req1_o,
    output wire        pixel_valid_o,
    output wire        underflow_active_o,
    output reg         underflow_toggle_o
);

wire fifo0_starved_w;
wire fifo1_starved_w;
reg  underflow_active_r;

assign fifo0_starved_w = frame_active_i && rd_req0_need_i &&
                         (fifo0_words_i <= GUARD_WORDS);
assign fifo1_starved_w = frame_active_i && rd_req1_need_i &&
                         (fifo1_words_i <= GUARD_WORDS);

assign rd_req0_o = frame_active_i && rd_req0_need_i &&
                   !underflow_active_r && !fifo0_starved_w;
assign rd_req1_o = frame_active_i && rd_req1_need_i &&
                   !underflow_active_r && !fifo1_starved_w;
assign pixel_valid_o = frame_active_i && !underflow_active_r &&
                       !fifo0_starved_w && !fifo1_starved_w;
assign underflow_active_o = underflow_active_r;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        underflow_active_r <= 1'b0;
        underflow_toggle_o <= 1'b0;
    end else begin
        if (!frame_active_i) begin
            underflow_active_r <= 1'b0;
        end else if (!underflow_active_r &&
                     (fifo0_starved_w || fifo1_starved_w)) begin
            underflow_active_r <= 1'b1;
            underflow_toggle_o <= ~underflow_toggle_o;
        end
    end
end

endmodule
