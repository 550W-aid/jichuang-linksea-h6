from pathlib import Path
import re
import unittest


FPGA_ROOT = Path(__file__).resolve().parents[1]
SOURCES = FPGA_ROOT / "ov5640_hdmi_1080p.srcs" / "sources_1"
TOP = SOURCES / "system" / "eth_video_rotate_system.v"
RECEIVER = SOURCES / "ETH" / "eth_video_rx_to_sdram.v"
QSF = FPGA_ROOT / "ov5640_hdmi_1080p.qsf"


class Ethernet30IntegrationContractTests(unittest.TestCase):
    def test_receiver_supports_crc_and_duplicate_suppression(self) -> None:
        source = RECEIVER.read_text(encoding="utf-8")
        self.assertIn("ALLOW_PACKET_DUPLICATES", source)
        self.assertIn("RETRY_BAD_PACKET", source)
        self.assertIn("crc16", source.lower())

    def test_top_enables_reliable_receiver_policy(self) -> None:
        source = TOP.read_text(encoding="utf-8")
        self.assertIn(".ALLOW_PACKET_DUPLICATES (1'b1)", source)
        self.assertIn(".RETRY_BAD_PACKET        (1'b1)", source)

    def test_ethernet_commit_waits_for_bridge_grace_and_empty_write_fifos(self) -> None:
        source = TOP.read_text(encoding="utf-8")
        match = re.search(r"assign\s+cam_commit_w\s*=\s*(.*?);", source, re.S)
        self.assertIsNotNone(match)
        expression = match.group(1)
        for token in (
            "eth_sdram_bridge_drained_100_r",
            "commit_grace_expired_w",
            "wr_fifo_num0_w == 11'd0",
            "wr_fifo_num1_w == 11'd0",
            "wr_fifos_below_burst_w",
        ):
            with self.subTest(token=token):
                self.assertIn(token, expression)

    def test_hdmi_underflow_guard_is_isolated_to_ethernet_source(self) -> None:
        source = TOP.read_text(encoding="utf-8")
        qsf = QSF.read_text(encoding="utf-8")
        self.assertIn("hdmi_read_underflow_guard.v", qsf)
        self.assertIn("hdmi_read_underflow_guard_inst", source)
        self.assertIn("frame_ready_sync_hdmi_r & source_mode_hdmi_sync_r[1]", source)
        self.assertIn("source_mode_hdmi_sync_r[1] ? rd_req0_guard_w : rd_req0_need_w", source)
        self.assertIn("source_mode_hdmi_sync_r[1] ? rd_req1_guard_w : rd_req1_need_w", source)

if __name__ == "__main__":
    unittest.main()
