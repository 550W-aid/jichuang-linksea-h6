// Module Function:
//   Integrates the Retinex core into an HDMI RGB888 stream. It synchronizes
//   and frame-latches mode selection, generates pixel sidebands, and keeps
//   enhanced and bypass timing at the same fixed 13-cycle latency. The active
//   preset uses pointwise luma lift so line-buffer state cannot create bands.
module video_shader_path #(
    parameter integer IMAGE_WIDTH = 1280,
    parameter integer DETAIL_GAIN = 4,
    parameter integer LIFT_GAIN   = 1,
    parameter integer TARGET_LUMA = 64,
    parameter integer SCALE_MAX_Q8 = 384,
    parameter integer EDGE_GAIN   = 0,
    parameter integer SPATIAL_DETAIL_EN = 0,
    parameter integer SHADOW_TARGET = 192,
    parameter integer SHADOW_LOW_KNEE = 64,
    parameter integer CORE_LATENCY = 13
) (
    input  wire        pix_clk,
    input  wire        pix_rst_n,
    input  wire        shader_cfg_valid_i,
    input  wire        shader_enable_i,
    input  wire [7:0]  lowlight_level_i,
    input  wire        video_hs_i,
    input  wire        video_vs_i,
    input  wire        video_de_i,
    input  wire [23:0] video_rgb_i,
    output wire        video_hs_o,
    output wire        video_vs_o,
    output wire        video_de_o,
    output wire [23:0] video_rgb_o,
    output wire        shader_active_o
);
    reg shader_enable_pending_r;
    reg shader_enable_active_r;
    reg [7:0] lowlight_level_pending_r;
    reg [7:0] lowlight_level_active_r;
    reg [10:0] pixel_count_r;
    reg frame_sof_pending_r;

    wire core_in_sof_w;
    wire core_in_eol_w;
    wire core_valid_w;
    wire core_sof_w;
    wire core_eol_w;
    wire [7:0] core_r_w;
    wire [7:0] core_g_w;
    wire [7:0] core_b_w;
    wire delayed_hs_w;
    wire delayed_vs_w;
    wire delayed_de_w;
    wire [23:0] delayed_rgb_w;

    assign core_in_sof_w = video_de_i && frame_sof_pending_r &&
                           (pixel_count_r == 11'd0);
    assign core_in_eol_w = video_de_i &&
                           (pixel_count_r == IMAGE_WIDTH - 1);

    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n) begin
            shader_enable_pending_r <= 1'b0;
            shader_enable_active_r <= 1'b0;
            lowlight_level_pending_r <= 8'd0;
            lowlight_level_active_r <= 8'd0;
            pixel_count_r          <= 11'd0;
            frame_sof_pending_r    <= 1'b1;
        end else begin
            if (shader_cfg_valid_i) begin
                shader_enable_pending_r <= shader_enable_i;
                lowlight_level_pending_r <= lowlight_level_i;
            end

            // video_vs_i is low during the 720p vertical-sync interval. Mode
            // changes are committed there so no frame contains a mixed image.
            if (!video_vs_i) begin
                shader_enable_active_r <= shader_cfg_valid_i ?
                                          shader_enable_i :
                                          shader_enable_pending_r;
                lowlight_level_active_r <= shader_cfg_valid_i ?
                                           lowlight_level_i :
                                           lowlight_level_pending_r;
                pixel_count_r       <= 11'd0;
                frame_sof_pending_r <= 1'b1;
            end else if (video_de_i) begin
                if (frame_sof_pending_r) begin
                    frame_sof_pending_r <= 1'b0;
                end
                if (core_in_eol_w) begin
                    pixel_count_r <= 11'd0;
                end else begin
                    pixel_count_r <= pixel_count_r + 11'd1;
                end
            end
        end
    end

    retinex_core #(
        .IMAGE_WIDTH  (IMAGE_WIDTH),
        .DETAIL_GAIN  (DETAIL_GAIN),
        .LIFT_GAIN    (LIFT_GAIN),
        .TARGET_LUMA  (TARGET_LUMA),
        .SCALE_MAX_Q8 (SCALE_MAX_Q8),
        .EDGE_GAIN    (EDGE_GAIN),
        .SPATIAL_DETAIL_EN(SPATIAL_DETAIL_EN),
        .SHADOW_TARGET(SHADOW_TARGET),
        .SHADOW_LOW_KNEE(SHADOW_LOW_KNEE)
    ) retinex_core_inst (
        .clk             (pix_clk),
        .rst_n           (pix_rst_n),
        .lowlight_level_i(lowlight_level_active_r),
        .in_valid        (video_de_i),
        .in_sof          (core_in_sof_w),
        .in_eol          (core_in_eol_w),
        .in_r            (video_rgb_i[23:16]),
        .in_g            (video_rgb_i[15:8]),
        .in_b            (video_rgb_i[7:0]),
        .out_valid       (core_valid_w),
        .out_sof         (core_sof_w),
        .out_eol         (core_eol_w),
        .out_r           (core_r_w),
        .out_g           (core_g_w),
        .out_b           (core_b_w)
    );

    video_stream_delay #(
        .LATENCY(CORE_LATENCY)
    ) bypass_timing_delay_inst (
        .clk        (pix_clk),
        .rst_n      (pix_rst_n),
        .video_hs_i (video_hs_i),
        .video_vs_i (video_vs_i),
        .video_de_i (video_de_i),
        .video_rgb_i(video_rgb_i),
        .video_hs_o (delayed_hs_w),
        .video_vs_o (delayed_vs_w),
        .video_de_o (delayed_de_w),
        .video_rgb_o(delayed_rgb_w)
    );

    assign video_hs_o = delayed_hs_w;
    assign video_vs_o = delayed_vs_w;
    assign video_de_o = delayed_de_w;
    // HDMI ignores RGB while DE is low. Removing the redundant DE/core-valid
    // blanking levels leaves one 24-bit mode mux before the system register.
    assign video_rgb_o = shader_enable_active_r ?
                         {core_r_w, core_g_w, core_b_w} : delayed_rgb_w;
    assign shader_active_o = shader_enable_active_r;

    // synthesis translate_off
    always @(posedge pix_clk) begin
        if (pix_rst_n && (core_valid_w !== delayed_de_w)) begin
            $display("ASSERTION FAILED: Retinex valid and delayed DE are not aligned time=%0t core=%b de=%b input_de=%b",
                     $time, core_valid_w, delayed_de_w, video_de_i);
            $stop;
        end
        if (pix_rst_n && core_sof_w && !core_valid_w) begin
            $display("ASSERTION FAILED: Retinex SOF without valid");
            $stop;
        end
        if (pix_rst_n && core_eol_w && !core_valid_w) begin
            $display("ASSERTION FAILED: Retinex EOL without valid");
            $stop;
        end
    end
    // synthesis translate_on
endmodule
