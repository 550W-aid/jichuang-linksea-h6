`timescale 1ns / 1ps

module target_center_marker #(
    parameter integer X_WIDTH = 12,
    parameter integer Y_WIDTH = 12
) (
    input  wire                 target_valid,
    input  wire [X_WIDTH-1:0]   target_x,
    input  wire [Y_WIDTH-1:0]   target_y,
    input  wire [X_WIDTH-1:0]   pixel_x,
    input  wire [Y_WIDTH-1:0]   pixel_y,
    output wire                 marker_valid
);

assign marker_valid = target_valid &&
                      (pixel_x[X_WIDTH-1:2] == target_x[X_WIDTH-1:2]) &&
                      (pixel_y[Y_WIDTH-1:2] == target_y[Y_WIDTH-1:2]);

endmodule
