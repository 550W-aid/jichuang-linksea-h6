// ============================================================================
// Module Function:
//   MDIO control sequencer for Ethernet PHY configuration.
// ============================================================================
module mdio_ctrl(
    input         clk,
    input         rst_n,
    input         soft_rst_trig,
    input         i_Key_GBCR,
    input         i_Key_ANAR,
    input         i_transmit_done,
    input  [15:0] i_rd_data,
    input         i_rd_ack,
    output reg    o_trigger_start,
    output reg    o_rh_wl,
    output reg [4:0]  o_phy_addr,
    output reg [4:0]  o_addr,
    output reg [15:0] o_wr_data,
    output [1:0] led,

    output reg [4:0]  dbg_phy_addr,
    output reg        dbg_phy_found,
    output reg        dbg_bmsr_ack,
    output reg        dbg_physr_ack,
    output reg [15:0] dbg_bmsr,
    output reg [15:0] dbg_physr,
    output reg        dbg_update_toggle
);

parameter TIME_CNT = 24'd100_000;

localparam FLOW_IDLE       = 3'd0;
localparam FLOW_WAIT_WRITE = 3'd1;
localparam FLOW_WAIT_READ  = 3'd2;
localparam FLOW_GOT_BMSR   = 3'd3;
localparam FLOW_GOT_PHYSR  = 3'd4;
localparam FLOW_WAIT_GBCR  = 3'd5;
localparam FLOW_WAIT_ANAR  = 3'd6;

reg [23:0] timer_cnt;
reg        timer_done;
reg [2:0]  flow_cnt;
reg        read_next;
reg        link_error;
reg [1:0]  speed_status;
reg [4:0]  scan_phy_addr;
reg [4:0]  active_phy_addr;
reg [4:0]  locked_phy_addr;
reg        phy_locked;

reg soft_rst_d;
reg gbcr_d;
reg anar_d;

wire pos_rst_trig = soft_rst_trig & ~soft_rst_d;
wire pos_GBCR     = i_Key_GBCR & ~gbcr_d;
wire pos_ANAR     = i_Key_ANAR & ~anar_d;
wire [4:0] next_scan_phy_addr = scan_phy_addr + 5'd1;

assign led = link_error ? 2'b00 : speed_status;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        soft_rst_d <= 1'b0;
        gbcr_d <= 1'b0;
        anar_d <= 1'b0;
    end
    else begin
        soft_rst_d <= soft_rst_trig;
        gbcr_d <= i_Key_GBCR;
        anar_d <= i_Key_ANAR;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        timer_cnt <= 24'd0;
        timer_done <= 1'b0;
    end
    else if(timer_cnt == TIME_CNT - 1'b1) begin
        timer_cnt <= 24'd0;
        timer_done <= 1'b1;
    end
    else begin
        timer_cnt <= timer_cnt + 1'b1;
        timer_done <= 1'b0;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        flow_cnt <= FLOW_IDLE;
        read_next <= 1'b0;
        link_error <= 1'b1;
        speed_status <= 2'b00;
        scan_phy_addr <= 5'd0;
        active_phy_addr <= 5'd0;
        locked_phy_addr <= 5'd0;
        phy_locked <= 1'b0;
        o_trigger_start <= 1'b0;
        o_rh_wl <= 1'b0;
        o_phy_addr <= 5'd0;
        o_addr <= 5'd0;
        o_wr_data <= 16'd0;
        dbg_phy_addr <= 5'd0;
        dbg_phy_found <= 1'b0;
        dbg_bmsr_ack <= 1'b1;
        dbg_physr_ack <= 1'b1;
        dbg_bmsr <= 16'd0;
        dbg_physr <= 16'd0;
        dbg_update_toggle <= 1'b0;
    end
    else begin
        o_trigger_start <= 1'b0;

        case(flow_cnt)
            FLOW_IDLE: begin
                if(pos_rst_trig) begin
                    active_phy_addr <= phy_locked ? locked_phy_addr : scan_phy_addr;
                    o_phy_addr <= phy_locked ? locked_phy_addr : scan_phy_addr;
                    o_trigger_start <= 1'b1;
                    o_rh_wl <= 1'b0;
                    o_addr <= 5'h00;
                    o_wr_data <= 16'h1340;
                    flow_cnt <= FLOW_WAIT_WRITE;
                end
                else if(pos_GBCR) begin
                    active_phy_addr <= phy_locked ? locked_phy_addr : scan_phy_addr;
                    o_phy_addr <= phy_locked ? locked_phy_addr : scan_phy_addr;
                    o_trigger_start <= 1'b1;
                    o_rh_wl <= 1'b0;
                    o_addr <= 5'h09;
                    o_wr_data <= 16'h0000;
                    flow_cnt <= FLOW_WAIT_GBCR;
                end
                else if(pos_ANAR) begin
                    active_phy_addr <= phy_locked ? locked_phy_addr : scan_phy_addr;
                    o_phy_addr <= phy_locked ? locked_phy_addr : scan_phy_addr;
                    o_trigger_start <= 1'b1;
                    o_rh_wl <= 1'b0;
                    o_addr <= 5'h04;
                    o_wr_data <= 16'h0501;
                    flow_cnt <= FLOW_WAIT_ANAR;
                end
                else if(timer_done) begin
                    active_phy_addr <= phy_locked ? locked_phy_addr : scan_phy_addr;
                    o_phy_addr <= phy_locked ? locked_phy_addr : scan_phy_addr;
                    o_trigger_start <= 1'b1;
                    o_rh_wl <= 1'b1;
                    o_addr <= 5'h01; // BMSR
                    read_next <= 1'b0;
                    flow_cnt <= FLOW_WAIT_READ;
                end
            end

            FLOW_WAIT_WRITE: begin
                if(i_transmit_done)
                    flow_cnt <= FLOW_IDLE;
            end

            FLOW_WAIT_READ: begin
                if(i_transmit_done)
                    flow_cnt <= read_next ? FLOW_GOT_PHYSR : FLOW_GOT_BMSR;
            end

            FLOW_GOT_BMSR: begin
                dbg_phy_addr <= active_phy_addr;
                dbg_bmsr <= i_rd_data;
                dbg_bmsr_ack <= i_rd_ack;

                if(i_rd_ack == 1'b0) begin
                    phy_locked <= 1'b1;
                    locked_phy_addr <= active_phy_addr;
                    dbg_phy_found <= 1'b1;
                    link_error <= ~(i_rd_data[5] & i_rd_data[2]);
                    o_phy_addr <= active_phy_addr;
                    o_trigger_start <= 1'b1;
                    o_rh_wl <= 1'b1;
                    o_addr <= 5'h11; // RTL8211 PHYSR
                    read_next <= 1'b1;
                    flow_cnt <= FLOW_WAIT_READ;
                end
                else begin
                    if(phy_locked && active_phy_addr == locked_phy_addr)
                        phy_locked <= 1'b0;
                    dbg_phy_found <= phy_locked;
                    dbg_physr_ack <= 1'b1;
                    speed_status <= 2'b00;
                    link_error <= 1'b1;
                    scan_phy_addr <= next_scan_phy_addr;
                    dbg_update_toggle <= ~dbg_update_toggle;
                    flow_cnt <= FLOW_IDLE;
                end
            end

            FLOW_GOT_PHYSR: begin
                dbg_physr <= i_rd_data;
                dbg_physr_ack <= i_rd_ack;
                read_next <= 1'b0;
                if(i_rd_ack == 1'b0) begin
                    if(i_rd_data[15:14] == 2'b10)
                        speed_status <= 2'b11; // 1000 Mbps
                    else if(i_rd_data[15:14] == 2'b01)
                        speed_status <= 2'b10; // 100 Mbps
                    else if(i_rd_data[15:14] == 2'b00)
                        speed_status <= 2'b01; // 10 Mbps
                    else
                        speed_status <= 2'b00;
                end
                else begin
                    speed_status <= 2'b00;
                end
                scan_phy_addr <= locked_phy_addr;
                dbg_update_toggle <= ~dbg_update_toggle;
                flow_cnt <= FLOW_IDLE;
            end

            FLOW_WAIT_GBCR: begin
                if(i_transmit_done)
                    flow_cnt <= FLOW_IDLE;
            end

            FLOW_WAIT_ANAR: begin
                if(i_transmit_done)
                    flow_cnt <= FLOW_IDLE;
            end

            default: begin
                flow_cnt <= FLOW_IDLE;
            end
        endcase
    end
end

endmodule
