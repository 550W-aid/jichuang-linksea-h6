`timescale 1ns / 1ps

module blue_light_temporal_filter #(
    parameter integer X_WIDTH = 12,
    parameter integer Y_WIDTH = 12,
    parameter integer COUNT_W = 24,
    parameter integer HOLD_FRAMES = 6,
    parameter integer TRACK_GATE_X = 24,
    parameter integer TRACK_GATE_Y = 24,
    parameter integer PENDING_TOL_X = 16,
    parameter integer PENDING_TOL_Y = 16,
    parameter integer CONFIRM_FRAMES = 3,
    parameter integer SMOOTH_SHIFT = 2,
    parameter integer DIRECT_THRESHOLD = 8,
    parameter integer DEADBAND = 2,
    parameter integer BOX_HALF_WIDTH = 24,
    parameter integer BOX_HALF_HEIGHT = 24,
    parameter integer MAX_X = (1 << X_WIDTH) - 1,
    parameter integer MAX_Y = (1 << Y_WIDTH) - 1
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 frame_tick,
    input  wire                 candidate_valid,
    input  wire [X_WIDTH-1:0]   candidate_x,
    input  wire [Y_WIDTH-1:0]   candidate_y,
    input  wire [COUNT_W-1:0]   candidate_pixel_count,
    input  wire [X_WIDTH-1:0]   candidate_min_x,
    input  wire [X_WIDTH-1:0]   candidate_max_x,
    input  wire [Y_WIDTH-1:0]   candidate_min_y,
    input  wire [Y_WIDTH-1:0]   candidate_max_y,
    output reg                  track_valid,
    output reg  [X_WIDTH-1:0]   track_x,
    output reg  [Y_WIDTH-1:0]   track_y,
    output reg  [COUNT_W-1:0]   track_pixel_count,
    output reg  [X_WIDTH-1:0]   track_min_x,
    output reg  [X_WIDTH-1:0]   track_max_x,
    output reg  [Y_WIDTH-1:0]   track_min_y,
    output reg  [Y_WIDTH-1:0]   track_max_y
);

    localparam [X_WIDTH-1:0] MAX_X_W = MAX_X;
    localparam [Y_WIDTH-1:0] MAX_Y_W = MAX_Y;

    reg [7:0] miss_count_reg;
    reg       pending_valid_reg;
    reg [7:0] pending_count_reg;
    reg [X_WIDTH-1:0] pending_x_reg;
    reg [Y_WIDTH-1:0] pending_y_reg;

    wire [X_WIDTH-1:0] track_dx_wire =
        (candidate_x >= track_x) ? (candidate_x - track_x) : (track_x - candidate_x);
    wire [Y_WIDTH-1:0] track_dy_wire =
        (candidate_y >= track_y) ? (candidate_y - track_y) : (track_y - candidate_y);
    wire [X_WIDTH-1:0] pending_dx_wire =
        (candidate_x >= pending_x_reg) ?
        (candidate_x - pending_x_reg) : (pending_x_reg - candidate_x);
    wire [Y_WIDTH-1:0] pending_dy_wire =
        (candidate_y >= pending_y_reg) ?
        (candidate_y - pending_y_reg) : (pending_y_reg - candidate_y);

    wire track_near_wire =
        (track_dx_wire <= TRACK_GATE_X) && (track_dy_wire <= TRACK_GATE_Y);
    wire pending_near_wire =
        (pending_dx_wire <= PENDING_TOL_X) && (pending_dy_wire <= PENDING_TOL_Y);

    wire [X_WIDTH-1:0] smooth_x_step_wire =
        ((track_dx_wire >> SMOOTH_SHIFT) != {X_WIDTH{1'b0}}) ?
        (track_dx_wire >> SMOOTH_SHIFT) : {{(X_WIDTH-1){1'b0}}, 1'b1};
    wire [Y_WIDTH-1:0] smooth_y_step_wire =
        ((track_dy_wire >> SMOOTH_SHIFT) != {Y_WIDTH{1'b0}}) ?
        (track_dy_wire >> SMOOTH_SHIFT) : {{(Y_WIDTH-1){1'b0}}, 1'b1};

    wire [X_WIDTH-1:0] smoothed_x_wire =
        (track_dx_wire <= DEADBAND) ? track_x :
        (track_dx_wire > DIRECT_THRESHOLD) ? candidate_x :
        ((candidate_x > track_x) ?
         (track_x + smooth_x_step_wire) : (track_x - smooth_x_step_wire));
    wire [Y_WIDTH-1:0] smoothed_y_wire =
        (track_dy_wire <= DEADBAND) ? track_y :
        (track_dy_wire > DIRECT_THRESHOLD) ? candidate_y :
        ((candidate_y > track_y) ?
         (track_y + smooth_y_step_wire) : (track_y - smooth_y_step_wire));

    function [X_WIDTH-1:0] box_min_x;
        input [X_WIDTH-1:0] center;
        begin
            box_min_x = (center < BOX_HALF_WIDTH) ?
                        {X_WIDTH{1'b0}} : center - BOX_HALF_WIDTH;
        end
    endfunction

    function [X_WIDTH-1:0] box_max_x;
        input [X_WIDTH-1:0] center;
        begin
            box_max_x = (center > (MAX_X - BOX_HALF_WIDTH)) ?
                        MAX_X_W : center + BOX_HALF_WIDTH;
        end
    endfunction

    function [Y_WIDTH-1:0] box_min_y;
        input [Y_WIDTH-1:0] center;
        begin
            box_min_y = (center < BOX_HALF_HEIGHT) ?
                        {Y_WIDTH{1'b0}} : center - BOX_HALF_HEIGHT;
        end
    endfunction

    function [Y_WIDTH-1:0] box_max_y;
        input [Y_WIDTH-1:0] center;
        begin
            box_max_y = (center > (MAX_Y - BOX_HALF_HEIGHT)) ?
                        MAX_Y_W : center + BOX_HALF_HEIGHT;
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            track_valid <= 1'b0;
            track_x <= {X_WIDTH{1'b0}};
            track_y <= {Y_WIDTH{1'b0}};
            track_pixel_count <= {COUNT_W{1'b0}};
            track_min_x <= {X_WIDTH{1'b0}};
            track_max_x <= {X_WIDTH{1'b0}};
            track_min_y <= {Y_WIDTH{1'b0}};
            track_max_y <= {Y_WIDTH{1'b0}};
            miss_count_reg <= 8'd0;
            pending_valid_reg <= 1'b0;
            pending_count_reg <= 8'd0;
            pending_x_reg <= {X_WIDTH{1'b0}};
            pending_y_reg <= {Y_WIDTH{1'b0}};
        end else if (frame_tick) begin
            if (candidate_valid) begin
                miss_count_reg <= 8'd0;
                if (track_valid && track_near_wire) begin
                    track_x <= smoothed_x_wire;
                    track_y <= smoothed_y_wire;
                    track_pixel_count <= candidate_pixel_count;
                    track_min_x <= box_min_x(smoothed_x_wire);
                    track_max_x <= box_max_x(smoothed_x_wire);
                    track_min_y <= box_min_y(smoothed_y_wire);
                    track_max_y <= box_max_y(smoothed_y_wire);
                    pending_valid_reg <= 1'b0;
                    pending_count_reg <= 8'd0;
                end else if ((CONFIRM_FRAMES <= 1) ||
                             (pending_valid_reg && pending_near_wire &&
                              (pending_count_reg >= (CONFIRM_FRAMES - 1)))) begin
                    track_valid <= 1'b1;
                    track_x <= candidate_x;
                    track_y <= candidate_y;
                    track_pixel_count <= candidate_pixel_count;
                    track_min_x <= box_min_x(candidate_x);
                    track_max_x <= box_max_x(candidate_x);
                    track_min_y <= box_min_y(candidate_y);
                    track_max_y <= box_max_y(candidate_y);
                    pending_valid_reg <= 1'b0;
                    pending_count_reg <= 8'd0;
                end else if (pending_valid_reg && pending_near_wire) begin
                    pending_x_reg <= candidate_x;
                    pending_y_reg <= candidate_y;
                    pending_count_reg <= pending_count_reg + 8'd1;
                end else begin
                    pending_valid_reg <= 1'b1;
                    pending_x_reg <= candidate_x;
                    pending_y_reg <= candidate_y;
                    pending_count_reg <= 8'd1;
                end
            end else begin
                pending_valid_reg <= 1'b0;
                pending_count_reg <= 8'd0;
                if (track_valid) begin
                    if ((HOLD_FRAMES <= 1) ||
                        (miss_count_reg >= (HOLD_FRAMES - 1))) begin
                        track_valid <= 1'b0;
                        track_x <= {X_WIDTH{1'b0}};
                        track_y <= {Y_WIDTH{1'b0}};
                        track_pixel_count <= {COUNT_W{1'b0}};
                        track_min_x <= {X_WIDTH{1'b0}};
                        track_max_x <= {X_WIDTH{1'b0}};
                        track_min_y <= {Y_WIDTH{1'b0}};
                        track_max_y <= {Y_WIDTH{1'b0}};
                        miss_count_reg <= 8'd0;
                    end else begin
                        miss_count_reg <= miss_count_reg + 8'd1;
                    end
                end else begin
                    miss_count_reg <= 8'd0;
                end
            end
        end
    end

    // The detector's raw bounds are deliberately ignored. The output box is
    // centered on the stabilized coordinate so HDMI and UART cannot disagree.
    wire unused_candidate_bounds = ^{candidate_min_x, candidate_max_x,
                                     candidate_min_y, candidate_max_y};

endmodule
