// Camera-stream side tap for virtual grabbing. It never drives SDRAM writes.
`timescale 1ns/1ps

module unified_virtual_grab_feature #(
    parameter integer IMAGE_WIDTH = 1280,
    parameter integer IMAGE_HEIGHT = 720
) (
    input  wire        sys_clk,
    input  wire        rst_n,
    input  wire        camera_pclk,
    input  wire        camera_frame_start_i,
    input  wire        camera_pixel_valid_i,
    input  wire [15:0] camera_rgb565_i,
    input  wire        uart_rxd,
    output wire        uart_txd,
    input  wire [7:0]  fsmc_addr,
    inout  wire [15:0] fsmc_data,
    input  wire        fsmc_cs_n,
    input  wire        fsmc_rd_n,
    input  wire        fsmc_wr_n,
    output wire        fsmc_int,
    input  wire        grab_btn_raw,
    input  wire        release_btn_raw,
    input  wire        hdmi_pix_clk,
    input  wire        hdmi_rst_n,
    input  wire [11:0] hdmi_x_i,
    input  wire [11:0] hdmi_y_i,
    input  wire        hdmi_de_i,
    input  wire [23:0] hdmi_rgb_i,
    output wire [23:0] hdmi_rgb_o
);
    localparam [5:0] OVERLAY_CIRCLE_OUTER = 6'd28;
    localparam [5:0] OVERLAY_CIRCLE_INNER = 6'd22;
    localparam [6:0] OVERLAY_CIRCLE_OUTER_DIAG = 7'd40;
    localparam [6:0] OVERLAY_CIRCLE_INNER_DIAG = 7'd31;

    wire [15:0] fifo_q_w;
    wire [10:0] fifo_rdusedw_w;
    wire [10:0] fifo_wrusedw_w;
    wire fifo_rdreq_w;
    wire fifo_pixel_valid_w = fifo_rdreq_pipe_r[2];
    wire fifo_aclr_w = (~rst_n) | (fifo_aclr_pclk_r != 4'd0);
    reg [2:0] frame_toggle_sys_r;
    reg frame_toggle_pclk_r;
    reg [3:0] fifo_aclr_pclk_r;
    reg [3:0] fifo_pause_sys_r;
    reg [2:0] fifo_rdreq_pipe_r;
    reg camera_pixel_valid_r;
    reg [15:0] camera_rgb565_r;
    wire frame_start_sys_w = frame_toggle_sys_r[2] ^ frame_toggle_sys_r[1];
    assign fifo_rdreq_w = (fifo_pause_sys_r == 4'd0) &&
                          (fifo_rdusedw_w > 11'd8);

    wire sof_w;
    wire eof_w;
    wire pixel_valid_w;
    wire [11:0] pixel_x_w;
    wire [11:0] pixel_y_w;
    wire [7:0] pixel_r_w;
    wire [7:0] pixel_g_w;
    wire [7:0] pixel_b_w;
    wire frame_direct_valid_w;
    wire [11:0] frame_direct_left_w;
    wire [11:0] frame_direct_right_w;
    wire [11:0] frame_direct_top_w;
    wire [11:0] frame_direct_bottom_w;
    wire frame_candidate_valid_w;
    wire [11:0] frame_candidate_left_w;
    wire [11:0] frame_candidate_right_w;
    wire [11:0] frame_candidate_top_w;
    wire [11:0] frame_candidate_bottom_w;
    wire        green_anchor_valid_w;
    wire [11:0] green_anchor_left_w;
    wire [11:0] green_anchor_right_w;
    wire [11:0] green_anchor_top_w;
    wire [11:0] green_anchor_bottom_w;
    wire [12:0] green_anchor_width_w;
    wire [12:0] green_anchor_height_w;
    wire        frame_inferred_valid_w;
    wire [12:0] frame_inferred_left_offset_w;
    wire [12:0] frame_inferred_right_offset_w;
    wire [13:0] frame_inferred_top_offset_w;
    wire [12:0] frame_inferred_bottom_offset_w;
    wire [13:0] frame_inferred_right_sum_w;
    wire [13:0] frame_inferred_bottom_sum_w;
    wire [11:0] frame_inferred_left_w;
    wire [11:0] frame_inferred_right_w;
    wire [11:0] frame_inferred_top_w;
    wire [11:0] frame_inferred_bottom_w;
    wire frame_track_valid_w;
    wire frame_track_valid_masked_w;
    wire [11:0] frame_track_left_w;
    wire [11:0] frame_track_right_w;
    wire [11:0] frame_track_top_w;
    wire [11:0] frame_track_bottom_w;
    wire map_relocalize_req_w;
    wire map_relocalize_apply_w;
    wire streaming_enable_w;
    wire calibrated_valid_w;
    wire red_valid_w;
    wire [11:0] red_center_x_w;
    wire [11:0] red_center_y_w;
    wire [11:0] red_min_x_w;
    wire [11:0] red_max_x_w;
    wire [11:0] red_min_y_w;
    wire [11:0] red_max_y_w;
    wire blue_valid_w;
    wire [11:0] blue_min_x_w;
    wire [11:0] blue_max_x_w;
    wire [11:0] blue_min_y_w;
    wire [11:0] blue_max_y_w;
    wire overlay_circle_valid_w;
    wire overlay_circle_grabbed_w;
    wire [11:0] overlay_circle_x_w;
    wire [11:0] overlay_circle_y_w;
    wire laser_spot_valid_w;
    wire [11:0] laser_spot_x_w;
    wire [11:0] laser_spot_y_w;
    wire [23:0] laser_spot_pixel_count_w;
    wire target_cross_valid_w;
    wire [11:0] target_cross_x_w;
    wire [11:0] target_cross_y_w;

    wire target_result_valid_w;
    wire target_valid_w;
    wire [11:0] target_x_w;
    wire [11:0] target_y_w;
    wire [11:0] target_width_w;
    wire [11:0] target_height_w;
    wire [31:0] target_score_w;
    wire [3:0] target_support_w;
    wire [15:0] target_frame_id_w;
    wire target_roi_valid_w;
    wire [11:0] target_roi_left_w;
    wire [11:0] target_roi_right_w;
    wire [11:0] target_roi_top_w;
    wire [11:0] target_roi_bottom_w;
    wire target_frame_timeout_fault_w;
    wire vision_snapshot_commit_w;
    wire [15:0] vision_snapshot_status_w;
    wire [31:0] vision_snapshot_capture_ms_w;
    wire [15:0] vision_snapshot_laser_x_w;
    wire [15:0] vision_snapshot_laser_y_w;
    wire [15:0] vision_snapshot_target_x_w;
    wire [15:0] vision_snapshot_target_y_w;
    wire [15:0] vision_snapshot_error_x_w;
    wire [15:0] vision_snapshot_error_y_w;
    wire [15:0] vision_snapshot_target_w_w;
    wire [15:0] vision_snapshot_target_h_w;
    wire [15:0] vision_snapshot_quality_w;
    wire [15:0] vision_snapshot_roi_left_w;
    wire [15:0] vision_snapshot_roi_right_w;
    wire [15:0] vision_snapshot_roi_top_w;
    wire [15:0] vision_snapshot_roi_bottom_w;
    wire [15:0] vision_snapshot_laser_pixels_w;
    wire [31:0] vision_snapshot_target_score_w;
    wire [15:0] vision_snapshot_frame_id_w;
    reg [15:0] vision_ms_div_r;
    reg [31:0] vision_ms_counter_r;
    reg [15:0] vision_frame_id_r;
    reg vision_laser_commit_r;
    reg [15:0] vision_laser_frame_id_r;
    reg [31:0] vision_laser_capture_ms_r;

    reg frame_valid_h1_r, frame_valid_h2_r;
    reg [11:0] frame_left_h1_r, frame_left_h2_r;
    reg [11:0] frame_right_h1_r, frame_right_h2_r;
    reg [11:0] frame_top_h1_r, frame_top_h2_r;
    reg [11:0] frame_bottom_h1_r, frame_bottom_h2_r;
    reg streaming_h1_r, streaming_h2_r;
    reg red_valid_h1_r, red_valid_h2_r;
    reg [11:0] red_min_x_h1_r, red_min_x_h2_r, red_max_x_h1_r, red_max_x_h2_r;
    reg [11:0] red_min_y_h1_r, red_min_y_h2_r, red_max_y_h1_r, red_max_y_h2_r;
    reg blue_valid_h1_r, blue_valid_h2_r;
    reg [11:0] blue_min_x_h1_r, blue_min_x_h2_r, blue_max_x_h1_r, blue_max_x_h2_r;
    reg [11:0] blue_min_y_h1_r, blue_min_y_h2_r, blue_max_y_h1_r, blue_max_y_h2_r;
    reg overlay_circle_valid_h1_r, overlay_circle_valid_h2_r;
    reg overlay_circle_grabbed_h1_r, overlay_circle_grabbed_h2_r;
    reg [11:0] overlay_circle_x_h1_r, overlay_circle_x_h2_r;
    reg [11:0] overlay_circle_y_h1_r, overlay_circle_y_h2_r;
    reg overlay_circle_valid_active_r;
    reg overlay_circle_grabbed_active_r;
    reg [11:0] overlay_circle_x_active_r;
    reg [11:0] overlay_circle_y_active_r;
    reg frame_edge_r;
    reg red_edge_r;
    reg blue_edge_r;
    reg overlay_circle_stage_valid_r;
    reg overlay_circle_stage_grabbed_r;
    reg [5:0] overlay_circle_dx_stage_r;
    reg [5:0] overlay_circle_dy_stage_r;
    reg overlay_circle_dx_outer_stage_r;
    reg overlay_circle_dy_outer_stage_r;
    reg overlay_circle_dx_inner_stage_r;
    reg overlay_circle_dy_inner_stage_r;
    reg overlay_circle_ring_r;
    reg overlay_circle_grabbed_draw_r;
    reg target_cross_valid_h1_r, target_cross_valid_h2_r;
    reg [11:0] target_cross_x_h1_r, target_cross_x_h2_r;
    reg [11:0] target_cross_y_h1_r, target_cross_y_h2_r;
    reg target_cross_marker_r;
    reg [23:0] hdmi_rgb_r;
    reg map_relocalize_pending_r;
    reg map_relocalize_active_r;
    reg map_relocalize_applied_r;

    wire frame_edge_w = frame_valid_h2_r && hdmi_de_i &&
        (((hdmi_x_i == frame_left_h2_r || hdmi_x_i == frame_right_h2_r) &&
          hdmi_y_i >= frame_top_h2_r && hdmi_y_i <= frame_bottom_h2_r) ||
         ((hdmi_y_i == frame_top_h2_r || hdmi_y_i == frame_bottom_h2_r) &&
          hdmi_x_i >= frame_left_h2_r && hdmi_x_i <= frame_right_h2_r));
    wire red_edge_w = red_valid_h2_r && !streaming_h2_r && hdmi_de_i &&
        (((hdmi_x_i == red_min_x_h2_r || hdmi_x_i == red_max_x_h2_r) &&
          hdmi_y_i >= red_min_y_h2_r && hdmi_y_i <= red_max_y_h2_r) ||
         ((hdmi_y_i == red_min_y_h2_r || hdmi_y_i == red_max_y_h2_r) &&
          hdmi_x_i >= red_min_x_h2_r && hdmi_x_i <= red_max_x_h2_r));
    wire blue_edge_w = blue_valid_h2_r && streaming_h2_r && hdmi_de_i &&
        (((hdmi_x_i == blue_min_x_h2_r || hdmi_x_i == blue_max_x_h2_r) &&
          hdmi_y_i >= blue_min_y_h2_r && hdmi_y_i <= blue_max_y_h2_r) ||
         ((hdmi_y_i == blue_min_y_h2_r || hdmi_y_i == blue_max_y_h2_r) &&
          hdmi_x_i >= blue_min_x_h2_r && hdmi_x_i <= blue_max_x_h2_r));
    wire overlay_circle_frame_latch = hdmi_de_i &&
                                      (hdmi_x_i == 12'd0) &&
                                      (hdmi_y_i == 12'd0);
    wire [11:0] overlay_circle_dx_abs_w =
        (hdmi_x_i >= overlay_circle_x_active_r) ?
        (hdmi_x_i - overlay_circle_x_active_r) :
        (overlay_circle_x_active_r - hdmi_x_i);
    wire [11:0] overlay_circle_dy_abs_w =
        (hdmi_y_i >= overlay_circle_y_active_r) ?
        (hdmi_y_i - overlay_circle_y_active_r) :
        (overlay_circle_y_active_r - hdmi_y_i);
    wire [6:0] overlay_circle_manhattan_stage_w =
        {1'b0, overlay_circle_dx_stage_r} +
        {1'b0, overlay_circle_dy_stage_r};
    wire overlay_circle_ring_stage_w = overlay_circle_stage_valid_r &&
        overlay_circle_dx_outer_stage_r &&
        overlay_circle_dy_outer_stage_r &&
        (overlay_circle_manhattan_stage_w <= OVERLAY_CIRCLE_OUTER_DIAG) &&
        (overlay_circle_dx_inner_stage_r ||
         overlay_circle_dy_inner_stage_r ||
         (overlay_circle_manhattan_stage_w >= OVERLAY_CIRCLE_INNER_DIAG));
    wire target_cross_marker_w;
    assign hdmi_rgb_o = hdmi_rgb_r;
    assign map_relocalize_apply_w = sof_w &&
                                    (map_relocalize_pending_r ||
                                     map_relocalize_req_w);
    assign frame_track_valid_masked_w =
        frame_track_valid_w && !map_relocalize_active_r;

    always @(posedge camera_pclk or negedge rst_n) begin
        if (!rst_n) begin
            frame_toggle_pclk_r <= 1'b0;
            fifo_aclr_pclk_r <= 4'hf;
            camera_pixel_valid_r <= 1'b0;
            camera_rgb565_r <= 16'd0;
        end else begin
            camera_pixel_valid_r <= camera_pixel_valid_i;
            camera_rgb565_r <= camera_rgb565_i;
            if (camera_frame_start_i) begin
                frame_toggle_pclk_r <= ~frame_toggle_pclk_r;
                fifo_aclr_pclk_r <= 4'hf;
            end else if (fifo_aclr_pclk_r != 4'd0) begin
                fifo_aclr_pclk_r <= fifo_aclr_pclk_r - 4'd1;
            end
        end
    end
    always @(posedge sys_clk or negedge rst_n) begin
        if (!rst_n) begin
            frame_toggle_sys_r <= 3'b000;
            fifo_pause_sys_r <= 4'hf;
            fifo_rdreq_pipe_r <= 3'b000;
        end else begin
            frame_toggle_sys_r <= {frame_toggle_sys_r[1:0], frame_toggle_pclk_r};
            fifo_rdreq_pipe_r <= {fifo_rdreq_pipe_r[1:0], fifo_rdreq_w};
            if (frame_start_sys_w) begin
                fifo_pause_sys_r <= 4'hf;
                fifo_rdreq_pipe_r <= 3'b000;
            end else if (fifo_pause_sys_r != 4'd0) begin
                fifo_pause_sys_r <= fifo_pause_sys_r - 4'd1;
            end
        end
    end

    always @(posedge sys_clk or negedge rst_n) begin
        if (!rst_n) begin
            map_relocalize_pending_r <= 1'b0;
            map_relocalize_active_r <= 1'b0;
            map_relocalize_applied_r <= 1'b0;
        end else begin
            if (map_relocalize_req_w) begin
                map_relocalize_pending_r <= 1'b1;
                map_relocalize_active_r <= 1'b1;
                map_relocalize_applied_r <= 1'b0;
            end

            if (map_relocalize_apply_w) begin
                map_relocalize_pending_r <= 1'b0;
                map_relocalize_active_r <= 1'b1;
                map_relocalize_applied_r <= 1'b1;
            end else if (map_relocalize_active_r &&
                         map_relocalize_applied_r &&
                         frame_track_valid_w) begin
                map_relocalize_active_r <= 1'b0;
                map_relocalize_applied_r <= 1'b0;
            end
        end
    end

    fifo_data #(.LPM_NUMWORDS(2048), .LPM_WIDTHU(11)) u_stream_fifo (
        .aclr(fifo_aclr_w), .rdclk(sys_clk), .wrclk(camera_pclk),
        .data(camera_rgb565_r), .rdreq(fifo_rdreq_w),
        .wrreq(camera_pixel_valid_r), .rdusedw(fifo_rdusedw_w),
        .wrusedw(fifo_wrusedw_w), .q(fifo_q_w)
    );
    virtual_grab_rgb565_stream_adapter #(
        .IMAGE_WIDTH(IMAGE_WIDTH), .IMAGE_HEIGHT(IMAGE_HEIGHT),
        .X_WIDTH(12), .Y_WIDTH(12)
    ) u_stream_adapter (
        .clk(sys_clk), .rst_n(rst_n), .frame_start(frame_start_sys_w),
        .pixel_valid_i(fifo_pixel_valid_w), .pixel_rgb565_i(fifo_q_w),
        .sof(sof_w), .eof(eof_w), .pixel_valid_o(pixel_valid_w),
        .pixel_x(pixel_x_w), .pixel_y(pixel_y_w),
        .pixel_r(pixel_r_w), .pixel_g(pixel_g_w), .pixel_b(pixel_b_w)
    );
    black_frame_green_anchor_detector #(
        .IMAGE_WIDTH(IMAGE_WIDTH), .IMAGE_HEIGHT(IMAGE_HEIGHT),
        .X_WIDTH(12), .Y_WIDTH(12)
    ) u_black_frame (
        .clk(sys_clk), .rst_n(rst_n), .sof(sof_w), .eof(eof_w),
        .relocalize(1'b0),
        .pixel_valid(pixel_valid_w), .pixel_x(pixel_x_w), .pixel_y(pixel_y_w),
        .pixel_r(pixel_r_w), .pixel_g(pixel_g_w), .pixel_b(pixel_b_w),
        .frame_valid(frame_direct_valid_w), .left_x(frame_direct_left_w),
        .right_x(frame_direct_right_w), .top_y(frame_direct_top_w),
        .bottom_y(frame_direct_bottom_w),
        .candidate_valid(frame_candidate_valid_w),
        .candidate_left_x(frame_candidate_left_w),
        .candidate_right_x(frame_candidate_right_w),
        .candidate_top_y(frame_candidate_top_w),
        .candidate_bottom_y(frame_candidate_bottom_w),
        .left_side_valid(), .right_side_valid(),
        .green_anchor_valid(green_anchor_valid_w),
        .green_anchor_x(), .green_anchor_y(),
        .green_anchor_left_x(green_anchor_left_w),
        .green_anchor_right_x(green_anchor_right_w),
        .green_anchor_top_y(green_anchor_top_w),
        .green_anchor_bottom_y(green_anchor_bottom_w)
    );

    assign green_anchor_width_w =
        {1'b0, green_anchor_right_w} - {1'b0, green_anchor_left_w} + 13'd1;
    assign green_anchor_height_w =
        {1'b0, green_anchor_bottom_w} - {1'b0, green_anchor_top_w} + 13'd1;
    assign frame_inferred_valid_w =
        green_anchor_valid_w &&
        (green_anchor_right_w > green_anchor_left_w) &&
        (green_anchor_bottom_w > green_anchor_top_w) &&
        (green_anchor_width_w >= 13'd96) &&
        (green_anchor_width_w <= 13'd320) &&
        (green_anchor_height_w >= 13'd32) &&
        (green_anchor_height_w <= 13'd220);

    assign frame_inferred_left_offset_w =
        green_anchor_width_w +
        (green_anchor_width_w >> 3) +
        (green_anchor_width_w >> 4);
    assign frame_inferred_right_offset_w =
        green_anchor_width_w - (green_anchor_width_w >> 4);
    assign frame_inferred_top_offset_w =
        ({1'b0, green_anchor_width_w} << 1) +
        {1'b0, green_anchor_width_w} -
        ({1'b0, green_anchor_width_w} >> 4);
    assign frame_inferred_bottom_offset_w =
        (green_anchor_width_w >> 1) +
        (green_anchor_width_w >> 4);
    assign frame_inferred_right_sum_w =
        {2'b00, green_anchor_right_w} +
        {1'b0, frame_inferred_right_offset_w};
    assign frame_inferred_bottom_sum_w =
        {2'b00, green_anchor_bottom_w} +
        {1'b0, frame_inferred_bottom_offset_w};

    assign frame_inferred_left_w =
        ({1'b0, green_anchor_left_w} > frame_inferred_left_offset_w) ?
        (green_anchor_left_w - frame_inferred_left_offset_w[11:0]) :
        12'd0;
    assign frame_inferred_right_w =
        (frame_inferred_right_sum_w > IMAGE_WIDTH - 1) ?
        IMAGE_WIDTH - 1 : frame_inferred_right_sum_w[11:0];
    assign frame_inferred_top_w =
        ({2'b00, green_anchor_top_w} > frame_inferred_top_offset_w) ?
        (green_anchor_top_w - frame_inferred_top_offset_w[11:0]) :
        12'd0;
    assign frame_inferred_bottom_w =
        (frame_inferred_bottom_sum_w > IMAGE_HEIGHT - 1) ?
        IMAGE_HEIGHT - 1 : frame_inferred_bottom_sum_w[11:0];

    // Prefer the measured black border. The green-anchor estimate is only a
    // fallback for heavily occluded frames.
    black_frame_temporal_tracker #(
        .X_WIDTH(12), .LOCK_FRAMES(4), .LOCK_TOLERANCE(24),
        .UPDATE_INTERVAL_FRAMES(15), .UPDATE_MAX_DELTA(32)
    ) u_black_frame_tracker (
        .clk(sys_clk), .rst_n(rst_n), .frame_tick(sof_w),
        .relocalize(map_relocalize_apply_w),
        .freeze(streaming_enable_w),
        .direct_valid(frame_direct_valid_w),
        .direct_left(frame_direct_left_w), .direct_right(frame_direct_right_w),
        .direct_top(frame_direct_top_w), .direct_bottom(frame_direct_bottom_w),
        .inferred_valid(frame_inferred_valid_w),
        .inferred_left(frame_inferred_left_w),
        .inferred_right(frame_inferred_right_w),
        .inferred_top(frame_inferred_top_w),
        .inferred_bottom(frame_inferred_bottom_w),
        .track_valid(frame_track_valid_w), .track_left(frame_track_left_w),
        .track_right(frame_track_right_w), .track_top(frame_track_top_w),
        .track_bottom(frame_track_bottom_w)
    );
    virtual_grab_uart_top #(
        .IMAGE_WIDTH(IMAGE_WIDTH), .IMAGE_HEIGHT(IMAGE_HEIGHT),
        .CLK_FREQ_HZ(50000000), .CLK_FREQ_MHZ(50), .UART_BPS(115200),
        .CALIB_RED_ROI_MIN_X(0), .CALIB_RED_ROI_MAX_X(IMAGE_WIDTH-1),
        .CALIB_RED_ROI_MIN_Y(0), .CALIB_RED_ROI_MAX_Y(IMAGE_HEIGHT-1),
        .BLUE_HAND_HOLD_FRAMES(15)
    ) u_virtual_uart (
        .clk(sys_clk), .rst_n(rst_n), .sof(sof_w), .eof(eof_w),
        .pixel_valid(pixel_valid_w), .pixel_x(pixel_x_w), .pixel_y(pixel_y_w),
        .pixel_r(pixel_r_w), .pixel_g(pixel_g_w), .pixel_b(pixel_b_w),
        .scene_roi_valid(frame_track_valid_masked_w), .scene_roi_min_x(frame_track_left_w),
        .scene_roi_max_x(frame_track_right_w), .scene_roi_min_y(frame_track_top_w),
        .scene_roi_max_y(frame_track_bottom_w),
        .black_frame_candidate_valid(frame_track_valid_masked_w),
        .black_frame_valid(frame_track_valid_masked_w),
        .black_frame_left_side_valid(frame_track_valid_masked_w),
        .black_frame_right_side_valid(frame_track_valid_masked_w),
        .black_frame_candidate_left_x(frame_track_left_w),
        .black_frame_candidate_right_x(frame_track_right_w),
        .black_frame_candidate_top_y(frame_track_top_w),
        .black_frame_candidate_bottom_y(frame_track_bottom_w),
        .uart_rxd(uart_rxd), .uart_txd(uart_txd),
        .map_relocalize(map_relocalize_req_w),
        .grab_btn_raw(grab_btn_raw), .release_btn_raw(release_btn_raw),
        .streaming_enable(streaming_enable_w), .calibrated_valid(calibrated_valid_w),
        .red_target_valid(red_valid_w), .red_target_center_x(red_center_x_w),
        .red_target_center_y(red_center_y_w), .red_target_min_x(red_min_x_w),
        .red_target_max_x(red_max_x_w), .red_target_min_y(red_min_y_w),
        .red_target_max_y(red_max_y_w), .blue_hand_valid(blue_valid_w),
        .blue_hand_min_x(blue_min_x_w), .blue_hand_max_x(blue_max_x_w),
        .blue_hand_min_y(blue_min_y_w), .blue_hand_max_y(blue_max_y_w),
        .overlay_circle_valid(overlay_circle_valid_w),
        .overlay_circle_grabbed(overlay_circle_grabbed_w),
        .overlay_circle_x(overlay_circle_x_w),
        .overlay_circle_y(overlay_circle_y_w),
        .target_cross_valid(target_cross_valid_w),
        .target_cross_x(target_cross_x_w),
        .target_cross_y(target_cross_y_w),
        .laser_spot_valid(laser_spot_valid_w),
        .laser_spot_x(laser_spot_x_w),
        .laser_spot_y(laser_spot_y_w),
        .laser_spot_pixel_count(laser_spot_pixel_count_w)
    );

    always @(posedge sys_clk or negedge rst_n) begin
        if (!rst_n) begin
            vision_ms_div_r <= 16'd0;
            vision_ms_counter_r <= 32'd0;
            vision_frame_id_r <= 16'd0;
            vision_laser_commit_r <= 1'b0;
            vision_laser_frame_id_r <= 16'd0;
            vision_laser_capture_ms_r <= 32'd0;
        end else begin
            vision_laser_commit_r <= eof_w;
            if (vision_ms_div_r == 16'd49999) begin
                vision_ms_div_r <= 16'd0;
                vision_ms_counter_r <= vision_ms_counter_r + 32'd1;
            end else begin
                vision_ms_div_r <= vision_ms_div_r + 16'd1;
            end
            if (eof_w) begin
                vision_laser_frame_id_r <= vision_frame_id_r;
                vision_laser_capture_ms_r <= vision_ms_counter_r;
                vision_frame_id_r <= vision_frame_id_r + 16'd1;
            end
        end
    end

    target_rectangle_detector #(
        .IMAGE_WIDTH(IMAGE_WIDTH), .IMAGE_HEIGHT(IMAGE_HEIGHT)
    ) u_target_rectangle (
        .clk(sys_clk), .rst_n(rst_n), .sof(sof_w), .eof(eof_w),
        .pixel_valid(pixel_valid_w), .pixel_x(pixel_x_w), .pixel_y(pixel_y_w),
        .pixel_r(pixel_r_w), .pixel_g(pixel_g_w), .pixel_b(pixel_b_w),
        .scene_roi_valid(frame_track_valid_masked_w),
        .scene_roi_min_x(frame_track_left_w), .scene_roi_max_x(frame_track_right_w),
        .scene_roi_min_y(frame_track_top_w), .scene_roi_max_y(frame_track_bottom_w),
        .result_valid(target_result_valid_w), .target_valid(target_valid_w),
        .target_x(target_x_w), .target_y(target_y_w),
        .target_w(target_width_w), .target_h(target_height_w),
        .target_score(target_score_w), .target_support(target_support_w),
        .result_frame_id(target_frame_id_w), .result_roi_valid(target_roi_valid_w),
        .result_roi_left(target_roi_left_w), .result_roi_right(target_roi_right_w),
        .result_roi_top(target_roi_top_w), .result_roi_bottom(target_roi_bottom_w),
        .frame_timeout_fault(target_frame_timeout_fault_w)
    );

    vision_snapshot_assembler u_vision_snapshot (
        .clk(sys_clk), .rst_n(rst_n),
        .laser_commit_i(vision_laser_commit_r),
        .laser_frame_id_i(vision_laser_frame_id_r),
        .laser_capture_ms_i(vision_laser_capture_ms_r),
        .laser_valid_i(laser_spot_valid_w), .laser_x_i(laser_spot_x_w),
        .laser_y_i(laser_spot_y_w), .laser_pixels_i(laser_spot_pixel_count_w),
        .target_result_valid_i(target_result_valid_w), .target_valid_i(target_valid_w),
        .target_x_i(target_x_w), .target_y_i(target_y_w),
        .target_w_i(target_width_w), .target_h_i(target_height_w),
        .target_score_i(target_score_w), .target_support_i(target_support_w),
        .target_frame_id_i(target_frame_id_w), .target_roi_valid_i(target_roi_valid_w),
        .target_roi_left_i(target_roi_left_w), .target_roi_right_i(target_roi_right_w),
        .target_roi_top_i(target_roi_top_w), .target_roi_bottom_i(target_roi_bottom_w),
        .snapshot_commit_o(vision_snapshot_commit_w),
        .snapshot_status_o(vision_snapshot_status_w),
        .snapshot_capture_ms_o(vision_snapshot_capture_ms_w),
        .snapshot_laser_x_o(vision_snapshot_laser_x_w),
        .snapshot_laser_y_o(vision_snapshot_laser_y_w),
        .snapshot_target_x_o(vision_snapshot_target_x_w),
        .snapshot_target_y_o(vision_snapshot_target_y_w),
        .snapshot_error_x_o(vision_snapshot_error_x_w),
        .snapshot_error_y_o(vision_snapshot_error_y_w),
        .snapshot_target_w_o(vision_snapshot_target_w_w),
        .snapshot_target_h_o(vision_snapshot_target_h_w),
        .snapshot_quality_o(vision_snapshot_quality_w),
        .snapshot_roi_left_o(vision_snapshot_roi_left_w),
        .snapshot_roi_right_o(vision_snapshot_roi_right_w),
        .snapshot_roi_top_o(vision_snapshot_roi_top_w),
        .snapshot_roi_bottom_o(vision_snapshot_roi_bottom_w),
        .snapshot_laser_pixels_o(vision_snapshot_laser_pixels_w),
        .snapshot_target_score_o(vision_snapshot_target_score_w),
        .snapshot_frame_id_o(vision_snapshot_frame_id_w)
    );

    fsmc_vision_regs u_fsmc_vision_regs (
        .sys_clk(sys_clk), .rst_n(rst_n), .fsmc_addr(fsmc_addr),
        .fsmc_data(fsmc_data), .fsmc_cs_n(fsmc_cs_n),
        .fsmc_rd_n(fsmc_rd_n), .fsmc_wr_n(fsmc_wr_n), .fsmc_int(fsmc_int),
        .snapshot_commit_i(vision_snapshot_commit_w),
        .snapshot_status_i(vision_snapshot_status_w),
        .snapshot_capture_ms_i(vision_snapshot_capture_ms_w),
        .snapshot_laser_x_i(vision_snapshot_laser_x_w),
        .snapshot_laser_y_i(vision_snapshot_laser_y_w),
        .snapshot_target_x_i(vision_snapshot_target_x_w),
        .snapshot_target_y_i(vision_snapshot_target_y_w),
        .snapshot_error_x_i(vision_snapshot_error_x_w),
        .snapshot_error_y_i(vision_snapshot_error_y_w),
        .snapshot_target_w_i(vision_snapshot_target_w_w),
        .snapshot_target_h_i(vision_snapshot_target_h_w),
        .snapshot_quality_i(vision_snapshot_quality_w),
        .snapshot_roi_left_i(vision_snapshot_roi_left_w),
        .snapshot_roi_right_i(vision_snapshot_roi_right_w),
        .snapshot_roi_top_i(vision_snapshot_roi_top_w),
        .snapshot_roi_bottom_i(vision_snapshot_roi_bottom_w),
        .snapshot_laser_pixels_i(vision_snapshot_laser_pixels_w),
        .snapshot_target_score_i(vision_snapshot_target_score_w),
        .snapshot_frame_id_i(vision_snapshot_frame_id_w),
        .frame_timeout_fault_i(target_frame_timeout_fault_w)
    );

    target_center_marker u_target_cross_marker (
        .target_valid(target_cross_valid_h2_r),
        .target_x(target_cross_x_h2_r), .target_y(target_cross_y_h2_r),
        .pixel_x(hdmi_x_i), .pixel_y(hdmi_y_i),
        .marker_valid(target_cross_marker_w)
    );

    always @(posedge hdmi_pix_clk or negedge hdmi_rst_n) begin
        if (!hdmi_rst_n) begin
            frame_valid_h1_r <= 1'b0; frame_valid_h2_r <= 1'b0;
            streaming_h1_r <= 1'b0; streaming_h2_r <= 1'b0;
            red_valid_h1_r <= 1'b0; red_valid_h2_r <= 1'b0;
            blue_valid_h1_r <= 1'b0; blue_valid_h2_r <= 1'b0;
            overlay_circle_valid_h1_r <= 1'b0;
            overlay_circle_valid_h2_r <= 1'b0;
            overlay_circle_grabbed_h1_r <= 1'b0;
            overlay_circle_grabbed_h2_r <= 1'b0;
            overlay_circle_x_h1_r <= 12'd0;
            overlay_circle_x_h2_r <= 12'd0;
            overlay_circle_y_h1_r <= 12'd0;
            overlay_circle_y_h2_r <= 12'd0;
            overlay_circle_valid_active_r <= 1'b0;
            overlay_circle_grabbed_active_r <= 1'b0;
            overlay_circle_x_active_r <= 12'd0;
            overlay_circle_y_active_r <= 12'd0;
            target_cross_valid_h1_r <= 1'b0;
            target_cross_valid_h2_r <= 1'b0;
            target_cross_x_h1_r <= 12'd0;
            target_cross_x_h2_r <= 12'd0;
            target_cross_y_h1_r <= 12'd0;
            target_cross_y_h2_r <= 12'd0;
            target_cross_marker_r <= 1'b0;
            frame_edge_r <= 1'b0;
            red_edge_r <= 1'b0;
            blue_edge_r <= 1'b0;
            overlay_circle_stage_valid_r <= 1'b0;
            overlay_circle_stage_grabbed_r <= 1'b0;
            overlay_circle_dx_stage_r <= 6'd0;
            overlay_circle_dy_stage_r <= 6'd0;
            overlay_circle_dx_outer_stage_r <= 1'b0;
            overlay_circle_dy_outer_stage_r <= 1'b0;
            overlay_circle_dx_inner_stage_r <= 1'b0;
            overlay_circle_dy_inner_stage_r <= 1'b0;
            overlay_circle_ring_r <= 1'b0;
            overlay_circle_grabbed_draw_r <= 1'b0;
            hdmi_rgb_r <= 24'd0;
        end else begin
            frame_valid_h1_r <= frame_track_valid_masked_w; frame_valid_h2_r <= frame_valid_h1_r;
            frame_left_h1_r <= frame_track_left_w; frame_left_h2_r <= frame_left_h1_r;
            frame_right_h1_r <= frame_track_right_w; frame_right_h2_r <= frame_right_h1_r;
            frame_top_h1_r <= frame_track_top_w; frame_top_h2_r <= frame_top_h1_r;
            frame_bottom_h1_r <= frame_track_bottom_w; frame_bottom_h2_r <= frame_bottom_h1_r;
            streaming_h1_r <= streaming_enable_w; streaming_h2_r <= streaming_h1_r;
            red_valid_h1_r <= red_valid_w; red_valid_h2_r <= red_valid_h1_r;
            red_min_x_h1_r <= red_min_x_w; red_min_x_h2_r <= red_min_x_h1_r;
            red_max_x_h1_r <= red_max_x_w; red_max_x_h2_r <= red_max_x_h1_r;
            red_min_y_h1_r <= red_min_y_w; red_min_y_h2_r <= red_min_y_h1_r;
            red_max_y_h1_r <= red_max_y_w; red_max_y_h2_r <= red_max_y_h1_r;
            blue_valid_h1_r <= blue_valid_w; blue_valid_h2_r <= blue_valid_h1_r;
            blue_min_x_h1_r <= blue_min_x_w; blue_min_x_h2_r <= blue_min_x_h1_r;
            blue_max_x_h1_r <= blue_max_x_w; blue_max_x_h2_r <= blue_max_x_h1_r;
            blue_min_y_h1_r <= blue_min_y_w; blue_min_y_h2_r <= blue_min_y_h1_r;
            blue_max_y_h1_r <= blue_max_y_w; blue_max_y_h2_r <= blue_max_y_h1_r;
            overlay_circle_valid_h1_r <= overlay_circle_valid_w;
            overlay_circle_valid_h2_r <= overlay_circle_valid_h1_r;
            overlay_circle_grabbed_h1_r <= overlay_circle_grabbed_w;
            overlay_circle_grabbed_h2_r <= overlay_circle_grabbed_h1_r;
            overlay_circle_x_h1_r <= overlay_circle_x_w;
            overlay_circle_x_h2_r <= overlay_circle_x_h1_r;
            overlay_circle_y_h1_r <= overlay_circle_y_w;
            overlay_circle_y_h2_r <= overlay_circle_y_h1_r;
            target_cross_valid_h1_r <= target_cross_valid_w;
            target_cross_valid_h2_r <= target_cross_valid_h1_r;
            target_cross_x_h1_r <= target_cross_x_w;
            target_cross_x_h2_r <= target_cross_x_h1_r;
            target_cross_y_h1_r <= target_cross_y_w;
            target_cross_y_h2_r <= target_cross_y_h1_r;
            if (overlay_circle_frame_latch) begin
                overlay_circle_valid_active_r <= overlay_circle_valid_h2_r;
                overlay_circle_grabbed_active_r <= overlay_circle_grabbed_h2_r;
                overlay_circle_x_active_r <= overlay_circle_x_h2_r;
                overlay_circle_y_active_r <= overlay_circle_y_h2_r;
            end
            frame_edge_r <= frame_edge_w;
            red_edge_r <= red_edge_w;
            blue_edge_r <= blue_edge_w;
            overlay_circle_stage_valid_r <= streaming_h2_r &&
                                            overlay_circle_valid_active_r &&
                                            hdmi_de_i;
            overlay_circle_stage_grabbed_r <= overlay_circle_grabbed_active_r;
            overlay_circle_dx_stage_r <= overlay_circle_dx_abs_w[5:0];
            overlay_circle_dy_stage_r <= overlay_circle_dy_abs_w[5:0];
            overlay_circle_dx_outer_stage_r <=
                (overlay_circle_dx_abs_w <= OVERLAY_CIRCLE_OUTER);
            overlay_circle_dy_outer_stage_r <=
                (overlay_circle_dy_abs_w <= OVERLAY_CIRCLE_OUTER);
            overlay_circle_dx_inner_stage_r <=
                (overlay_circle_dx_abs_w >= OVERLAY_CIRCLE_INNER);
            overlay_circle_dy_inner_stage_r <=
                (overlay_circle_dy_abs_w >= OVERLAY_CIRCLE_INNER);
            overlay_circle_ring_r <= overlay_circle_ring_stage_w;
            overlay_circle_grabbed_draw_r <= overlay_circle_stage_grabbed_r;
            target_cross_marker_r <= target_cross_marker_w && hdmi_de_i;
            hdmi_rgb_r <= target_cross_marker_r ? 24'h00FFFF :
                          overlay_circle_ring_r ?
                          (overlay_circle_grabbed_draw_r ? 24'hFF2020 : 24'hFFFF00) :
                          blue_edge_r ? 24'h0080FF :
                          red_edge_r ? 24'hFF2020 :
                          frame_edge_r ? 24'h00FF40 : hdmi_rgb_i;
        end
    end
endmodule
