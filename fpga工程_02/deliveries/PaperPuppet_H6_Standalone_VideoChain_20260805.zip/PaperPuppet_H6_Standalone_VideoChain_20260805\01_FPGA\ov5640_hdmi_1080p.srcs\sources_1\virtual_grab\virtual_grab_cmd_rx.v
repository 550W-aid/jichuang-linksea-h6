`timescale 1ns / 1ps

module virtual_grab_cmd_rx (
    input  wire       clk,               // Processing clock.
    input  wire       rst_n,             // Active-low reset.
    input  wire       rx_valid,          // Input byte valid strobe.
    input  wire [7:0] rx_data,           // Input byte value.
    output reg        cmd_calibrate,     // One-cycle pulse for CALIBRATE_REQ.
    output reg        cmd_start,         // One-cycle pulse for START_REQ.
    output reg        cmd_light_start,   // One-cycle pulse for LIGHT_START_REQ.
    output reg        cmd_stop,          // One-cycle pulse for STOP_REQ.
    output reg        cmd_map_relocalize,
    output reg        overlay_circle_valid,
    output reg        overlay_circle_grabbed,
    output reg [11:0] overlay_circle_x,
    output reg [11:0] overlay_circle_y,
    output reg        target_cross_valid,
    output reg [11:0] target_cross_x,
    output reg [11:0] target_cross_y,
    output reg        packet_error_pulse // One-cycle pulse for malformed packets.
);

    localparam [2:0] RX_WAIT_HEADER0 = 3'd0;
    localparam [2:0] RX_WAIT_HEADER1 = 3'd1;
    localparam [2:0] RX_WAIT_TYPE    = 3'd2;
    localparam [2:0] RX_WAIT_LENGTH  = 3'd3;
    localparam [2:0] RX_WAIT_PAYLOAD = 3'd4;
    localparam [2:0] RX_WAIT_CHECK   = 3'd5;

    localparam [7:0] MSG_CALIBRATE_REQ = 8'h10;
    localparam [7:0] MSG_START_REQ     = 8'h11;
    localparam [7:0] MSG_STOP_REQ      = 8'h12;
    localparam [7:0] MSG_OVERLAY_CIRCLE_REQ = 8'h13;
    localparam [7:0] MSG_LIGHT_START_REQ = 8'h14;
    localparam [7:0] MSG_TARGET_CROSS_REQ = 8'h15;
    localparam [7:0] MSG_MAP_RELOCALIZE_REQ = 8'h16;

    reg [2:0] rx_state_reg;
    reg [7:0] msg_type_reg;
    reg [7:0] length_reg;
    reg [7:0] payload_count_reg;
    reg [7:0] checksum_reg;
    reg [7:0] overlay_flags_reg;
    reg [7:0] overlay_x_hi_reg;
    reg [7:0] overlay_x_lo_reg;
    reg [7:0] overlay_y_hi_reg;
    reg [7:0] overlay_y_lo_reg;

    // Parse the fixed packet format and emit command pulses only for valid packets.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rx_state_reg        <= RX_WAIT_HEADER0;
            msg_type_reg        <= 8'h00;
            length_reg          <= 8'h00;
            payload_count_reg   <= 8'h00;
            checksum_reg        <= 8'h00;
            cmd_calibrate       <= 1'b0;
            cmd_start           <= 1'b0;
            cmd_light_start     <= 1'b0;
            cmd_stop            <= 1'b0;
            cmd_map_relocalize  <= 1'b0;
            overlay_circle_valid <= 1'b0;
            overlay_circle_grabbed <= 1'b0;
            overlay_circle_x    <= 12'd0;
            overlay_circle_y    <= 12'd0;
            target_cross_valid  <= 1'b0;
            target_cross_x      <= 12'd0;
            target_cross_y      <= 12'd0;
            overlay_flags_reg   <= 8'h00;
            overlay_x_hi_reg    <= 8'h00;
            overlay_x_lo_reg    <= 8'h00;
            overlay_y_hi_reg    <= 8'h00;
            overlay_y_lo_reg    <= 8'h00;
            packet_error_pulse  <= 1'b0;
        end else begin
            cmd_calibrate      <= 1'b0;
            cmd_start          <= 1'b0;
            cmd_light_start    <= 1'b0;
            cmd_stop           <= 1'b0;
            cmd_map_relocalize <= 1'b0;
            packet_error_pulse <= 1'b0;

            if (rx_valid) begin
                case (rx_state_reg)
                    RX_WAIT_HEADER0: begin
                        if (rx_data == 8'h55) begin
                            rx_state_reg <= RX_WAIT_HEADER1;
                        end
                    end

                    RX_WAIT_HEADER1: begin
                        if (rx_data == 8'hAA) begin
                            rx_state_reg <= RX_WAIT_TYPE;
                        end else if (rx_data == 8'h55) begin
                            rx_state_reg <= RX_WAIT_HEADER1;
                            packet_error_pulse <= 1'b1;
                        end else begin
                            rx_state_reg <= RX_WAIT_HEADER0;
                            packet_error_pulse <= 1'b1;
                        end
                    end

                    RX_WAIT_TYPE: begin
                        msg_type_reg  <= rx_data;
                        checksum_reg  <= rx_data;
                        rx_state_reg  <= RX_WAIT_LENGTH;
                    end

                    RX_WAIT_LENGTH: begin
                        length_reg        <= rx_data;
                        payload_count_reg <= 8'h00;
                        checksum_reg      <= checksum_reg + rx_data;
                        overlay_flags_reg <= 8'h00;
                        overlay_x_hi_reg  <= 8'h00;
                        overlay_x_lo_reg  <= 8'h00;
                        overlay_y_hi_reg  <= 8'h00;
                        overlay_y_lo_reg  <= 8'h00;

                        if (rx_data == 8'h00) begin
                            rx_state_reg <= RX_WAIT_CHECK;
                        end else begin
                            rx_state_reg <= RX_WAIT_PAYLOAD;
                        end
                    end

                    RX_WAIT_PAYLOAD: begin
                        checksum_reg      <= checksum_reg + rx_data;
                        payload_count_reg <= payload_count_reg + 8'h01;

                        case (payload_count_reg)
                            8'd0: overlay_flags_reg <= rx_data;
                            8'd1: overlay_x_hi_reg  <= rx_data;
                            8'd2: overlay_x_lo_reg  <= rx_data;
                            8'd3: overlay_y_hi_reg  <= rx_data;
                            8'd4: overlay_y_lo_reg  <= rx_data;
                            default: begin
                            end
                        endcase

                        if (payload_count_reg + 8'h01 >= length_reg) begin
                            rx_state_reg <= RX_WAIT_CHECK;
                        end
                    end

                    RX_WAIT_CHECK: begin
                        if (rx_data == checksum_reg) begin
                            case (msg_type_reg)
                                MSG_CALIBRATE_REQ: begin
                                    if (length_reg == 8'h00) begin
                                        cmd_calibrate <= 1'b1;
                                    end else begin
                                        packet_error_pulse <= 1'b1;
                                    end
                                end
                                MSG_START_REQ: begin
                                    if (length_reg == 8'h00) begin
                                        cmd_start <= 1'b1;
                                    end else begin
                                        packet_error_pulse <= 1'b1;
                                    end
                                end
                                MSG_STOP_REQ: begin
                                    if (length_reg == 8'h00) begin
                                        cmd_stop <= 1'b1;
                                    end else begin
                                        packet_error_pulse <= 1'b1;
                                    end
                                end
                                MSG_OVERLAY_CIRCLE_REQ: begin
                                    if (length_reg == 8'h05) begin
                                        overlay_circle_valid <= overlay_flags_reg[0];
                                        overlay_circle_grabbed <= overlay_flags_reg[1];
                                        overlay_circle_x <= {overlay_x_hi_reg[3:0], overlay_x_lo_reg};
                                        overlay_circle_y <= {overlay_y_hi_reg[3:0], overlay_y_lo_reg};
                                    end else begin
                                        packet_error_pulse <= 1'b1;
                                    end
                                end
                                MSG_LIGHT_START_REQ: begin
                                    if (length_reg == 8'h00) begin
                                        cmd_light_start <= 1'b1;
                                    end else begin
                                        packet_error_pulse <= 1'b1;
                                    end
                                end
                                MSG_TARGET_CROSS_REQ: begin
                                    if (length_reg == 8'h05) begin
                                        target_cross_valid <= overlay_flags_reg[0];
                                        target_cross_x <= {overlay_x_hi_reg[3:0], overlay_x_lo_reg};
                                        target_cross_y <= {overlay_y_hi_reg[3:0], overlay_y_lo_reg};
                                    end else begin
                                        packet_error_pulse <= 1'b1;
                                    end
                                end
                                MSG_MAP_RELOCALIZE_REQ: begin
                                    if (length_reg == 8'h00) begin
                                        cmd_map_relocalize <= 1'b1;
                                    end else begin
                                        packet_error_pulse <= 1'b1;
                                    end
                                end
                                default: packet_error_pulse <= 1'b1;
                            endcase
                        end else begin
                            packet_error_pulse <= 1'b1;
                        end

                        rx_state_reg <= RX_WAIT_HEADER0;
                    end

                    default: begin
                        rx_state_reg       <= RX_WAIT_HEADER0;
                        packet_error_pulse <= 1'b1;
                    end
                endcase
            end
        end
    end

endmodule
