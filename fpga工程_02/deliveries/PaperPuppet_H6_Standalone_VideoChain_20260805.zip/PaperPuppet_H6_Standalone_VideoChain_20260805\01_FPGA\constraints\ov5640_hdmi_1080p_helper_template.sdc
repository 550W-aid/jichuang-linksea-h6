# Helper intake template for ov5640_hdmi_1080p
# Copy the lines you really need into the project's authoritative SDC.

create_clock -name sys_clk -period 20.000 [get_ports {sys_clk}]

# Example pixel clock
# create_clock -name pix_clk -period 14.286 [get_ports {ov5640_pclk}]

# Example input delays
# set_input_delay -clock [get_clocks {pix_clk}] -max 4.500 [get_ports {cam_data[*]}]
# set_input_delay -clock [get_clocks {pix_clk}] -min -1.000 [get_ports {cam_data[*]}]

# Example CDC false paths
# set_false_path -from [get_clocks {sys_clk}] -to [get_clocks {pix_clk}]
# set_false_path -from [get_clocks {pix_clk}] -to [get_clocks {sys_clk}]