$ErrorActionPreference = 'Stop'

$rtlPath = Join-Path $PSScriptRoot '..\ov5640_hdmi_1080p.srcs\sources_1\virtual_grab\unified_virtual_grab_feature.v'
$rtl = Get-Content -Raw -LiteralPath $rtlPath

$requiredPatterns = [ordered]@{
    'green-anchor validity is captured' = '\.green_anchor_valid\s*\(green_anchor_valid_w\)'
    'green-anchor left is captured' = '\.green_anchor_left_x\s*\(green_anchor_left_w\)'
    'green-anchor right is captured' = '\.green_anchor_right_x\s*\(green_anchor_right_w\)'
    'green-anchor top is captured' = '\.green_anchor_top_y\s*\(green_anchor_top_w\)'
    'green-anchor bottom is captured' = '\.green_anchor_bottom_y\s*\(green_anchor_bottom_w\)'
    'tracker receives inferred validity' = '\.inferred_valid\s*\(frame_inferred_valid_w\)'
    'tracker receives inferred left' = '\.inferred_left\s*\(frame_inferred_left_w\)'
    'tracker receives inferred right' = '\.inferred_right\s*\(frame_inferred_right_w\)'
    'tracker receives inferred top' = '\.inferred_top\s*\(frame_inferred_top_w\)'
    'tracker receives inferred bottom' = '\.inferred_bottom\s*\(frame_inferred_bottom_w\)'
}

$failures = @()
foreach ($entry in $requiredPatterns.GetEnumerator()) {
    if ($rtl -notmatch $entry.Value) {
        $failures += $entry.Key
    }
}

if ($rtl -match '\.inferred_valid\s*\(1''b0\)') {
    $failures += 'tracker still disables the green-anchor fallback'
}

if ($rtl -match '\.inferred_valid\s*\(frame_candidate_valid_w\)') {
    $failures += 'tracker incorrectly treats the partial black band as the full map ROI'
}

if ($failures.Count -ne 0) {
    Write-Error ("Green-anchor fallback regression:`n - " + ($failures -join "`n - "))
}

Write-Host 'PASS: green-anchor full-frame inference is connected to the temporal tracker.'
