`timescale 1ns / 1ps

module virtual_grab_host_bridge_top #(
    parameter integer IMAGE_WIDTH        = 1920,
    parameter integer IMAGE_HEIGHT       = 1080,
    parameter integer X_WIDTH            = 12,
    parameter integer Y_WIDTH            = 12,
    parameter integer AREA_WIDTH         = 16,
    parameter integer CALIB_MIN_RED_PIXELS = 4096,
    parameter integer CALIB_MAX_RED_PIXELS = 50000,
    parameter integer CALIB_MIN_RED_WIDTH  = 24,
    parameter integer CALIB_MAX_RED_WIDTH  = 260,
    parameter integer CALIB_MIN_RED_HEIGHT = 24,
    parameter integer CALIB_MAX_RED_HEIGHT = 260,
    parameter integer CALIB_MIN_WHITE_PIXELS = 128,
    parameter integer CALIB_MIN_GREEN_PIXELS = 16,
    parameter integer CALIB_RED_ROI_MIN_X = 0,
    parameter integer CALIB_RED_ROI_MAX_X = IMAGE_WIDTH - 1,
    parameter integer CALIB_RED_ROI_MIN_Y = 0,
    parameter integer CALIB_RED_ROI_MAX_Y = IMAGE_HEIGHT - 1,
    parameter integer BLUE_HAND_HOLD_FRAMES = 15,
    parameter integer BLUE_LIGHT_HOLD_FRAMES = 5,
    parameter integer BTN_STABLE_CYCLES  = 4
) (
    input  wire                   clk,              // Processing clock.
    input  wire                   rst_n,            // Active-low reset.
    input  wire                   sof,              // Start-of-frame pulse for the pixel stream.
    input  wire                   eof,              // End-of-frame pulse for the pixel stream.
    input  wire                   pixel_valid,      // Pixel-valid strobe for the pixel stream.
    input  wire [X_WIDTH-1:0]     pixel_x,          // Current pixel X coordinate.
    input  wire [Y_WIDTH-1:0]     pixel_y,          // Current pixel Y coordinate.
    input  wire [7:0]             pixel_r,          // Current pixel red component.
    input  wire [7:0]             pixel_g,          // Current pixel green component.
    input  wire [7:0]             pixel_b,          // Current pixel blue component.
    input  wire                   scene_roi_valid,  // High when dynamic scene bounds are usable.
    input  wire [X_WIDTH-1:0]     scene_roi_min_x,  // Dynamic scene ROI left edge.
    input  wire [X_WIDTH-1:0]     scene_roi_max_x,  // Dynamic scene ROI right edge.
    input  wire [Y_WIDTH-1:0]     scene_roi_min_y,  // Dynamic scene ROI top edge.
    input  wire [Y_WIDTH-1:0]     scene_roi_max_y,  // Dynamic scene ROI bottom edge.
    input  wire                   black_frame_candidate_valid,
    input  wire                   black_frame_valid,
    input  wire                   black_frame_left_side_valid,
    input  wire                   black_frame_right_side_valid,
    input  wire [X_WIDTH-1:0]     black_frame_candidate_left_x,
    input  wire [X_WIDTH-1:0]     black_frame_candidate_right_x,
    input  wire [Y_WIDTH-1:0]     black_frame_candidate_top_y,
    input  wire [Y_WIDTH-1:0]     black_frame_candidate_bottom_y,
    input  wire                   rx_valid,         // Input command byte valid strobe.
    input  wire [7:0]             rx_data,          // Input command byte value.
    output wire                   tx_valid,         // Output packet byte valid strobe.
    output wire [7:0]             tx_data,          // Output packet byte value.
    output wire                   tx_last,          // Output packet end marker.
    input  wire                   tx_ready,         // Downstream byte-ready handshake.
    input  wire                   grab_btn_raw,     // Hidden raw grab button input.
    input  wire                   release_btn_raw,  // Hidden raw release button input.
    output wire                   streaming_enable, // High while periodic hand reporting is enabled.
    output wire                   map_relocalize,
    output wire                   calibrated_valid, // High after a successful calibration snapshot.
    output wire                   red_target_valid,
    output wire [X_WIDTH-1:0]     red_target_center_x,
    output wire [Y_WIDTH-1:0]     red_target_center_y,
    output wire [X_WIDTH-1:0]     red_target_min_x,
    output wire [X_WIDTH-1:0]     red_target_max_x,
    output wire [Y_WIDTH-1:0]     red_target_min_y,
    output wire [Y_WIDTH-1:0]     red_target_max_y,
    output wire                   blue_hand_valid,
    output wire [X_WIDTH-1:0]     blue_hand_min_x,
    output wire [X_WIDTH-1:0]     blue_hand_max_x,
    output wire [Y_WIDTH-1:0]     blue_hand_min_y,
    output wire [Y_WIDTH-1:0]     blue_hand_max_y,
    output wire                   overlay_circle_valid,
    output wire                   overlay_circle_grabbed,
    output wire [X_WIDTH-1:0]     overlay_circle_x,
    output wire [Y_WIDTH-1:0]     overlay_circle_y,
    output wire                   target_cross_valid,
    output wire [X_WIDTH-1:0]     target_cross_x,
    output wire [Y_WIDTH-1:0]     target_cross_y,
    output wire                   laser_spot_valid,
    output wire [X_WIDTH-1:0]     laser_spot_x,
    output wire [Y_WIDTH-1:0]     laser_spot_y,
    output wire [23:0]            laser_spot_pixel_count
);

    wire origin_valid;
    wire [X_WIDTH-1:0] origin_x;
    wire [Y_WIDTH-1:0] origin_y;
    wire green_valid;
    wire [X_WIDTH-1:0] green_x;
    wire [Y_WIDTH-1:0] green_y;
    wire red_valid;
    wire [X_WIDTH-1:0] red_x;
    wire [Y_WIDTH-1:0] red_y;
    wire [X_WIDTH-1:0] red_min_x;
    wire [X_WIDTH-1:0] red_max_x;
    wire [Y_WIDTH-1:0] red_min_y;
    wire [Y_WIDTH-1:0] red_max_y;
    wire blue_valid;
    wire [X_WIDTH-1:0] blue_x;
    wire [Y_WIDTH-1:0] blue_y;
    wire [X_WIDTH-1:0] blue_min_x;
    wire [X_WIDTH-1:0] blue_max_x;
    wire [Y_WIDTH-1:0] blue_min_y;
    wire [Y_WIDTH-1:0] blue_max_y;
    wire light_valid;
    wire [X_WIDTH-1:0] light_x;
    wire [Y_WIDTH-1:0] light_y;
    wire [X_WIDTH-1:0] light_min_x;
    wire [X_WIDTH-1:0] light_max_x;
    wire [Y_WIDTH-1:0] light_min_y;
    wire [Y_WIDTH-1:0] light_max_y;
    wire [23:0] light_pixel_count;
    wire blue_track_valid;
    wire [X_WIDTH-1:0] blue_track_x;
    wire [Y_WIDTH-1:0] blue_track_y;
    wire [23:0] blue_track_pixel_count;
    wire [X_WIDTH-1:0] blue_track_min_x;
    wire [X_WIDTH-1:0] blue_track_max_x;
    wire [Y_WIDTH-1:0] blue_track_min_y;
    wire [Y_WIDTH-1:0] blue_track_max_y;
    wire light_track_valid;
    wire [X_WIDTH-1:0] light_track_x;
    wire [Y_WIDTH-1:0] light_track_y;
    wire [23:0] light_track_pixel_count;
    wire [X_WIDTH-1:0] light_track_min_x;
    wire [X_WIDTH-1:0] light_track_max_x;
    wire [Y_WIDTH-1:0] light_track_min_y;
    wire [Y_WIDTH-1:0] light_track_max_y;
    wire light_mode_enable;
    wire selected_track_valid;
    wire [X_WIDTH-1:0] selected_track_x;
    wire [Y_WIDTH-1:0] selected_track_y;
    wire [23:0] selected_track_pixel_count;
    wire [X_WIDTH-1:0] selected_track_min_x;
    wire [X_WIDTH-1:0] selected_track_max_x;
    wire [Y_WIDTH-1:0] selected_track_min_y;
    wire [Y_WIDTH-1:0] selected_track_max_y;
    wire [23:0] selected_detector_pixel_count;
    wire [23:0] white_pixel_count;
    wire [23:0] green_pixel_count;
    wire [23:0] red_pixel_count;
    wire [23:0] blue_pixel_count;
    wire [23:0] committed_pixel_count;
    wire [23:0] live_pixel_count;
    wire [23:0] loose_red_pixel_count;
    wire [7:0] max_pixel_r;
    wire [7:0] max_pixel_g;
    wire [7:0] max_pixel_b;
    wire [7:0] last_pixel_r;
    wire [7:0] last_pixel_g;
    wire [7:0] last_pixel_b;
    wire [AREA_WIDTH-1:0] hand_area_wire;
    wire calibration_red_valid_wire;
    wire calibration_origin_valid_wire;
    wire calibration_green_valid_wire;
    wire red_area_valid_wire;
    wire red_size_valid_wire;
    wire red_aspect_valid_wire;
    wire red_round_valid_wire;
    wire [X_WIDTH:0] red_box_width_wire;
    wire [Y_WIDTH:0] red_box_height_wire;
    wire [15:0] red_box_width_x2_wire;
    wire [15:0] red_box_height_x2_wire;
    wire [15:0] red_box_width_x3_wire;
    wire [15:0] red_box_height_x3_wire;
    wire [X_WIDTH:0] red_box_center_x_sum_wire;
    wire [Y_WIDTH:0] red_box_center_y_sum_wire;
    wire [X_WIDTH-1:0] red_box_center_x_wire;
    wire [Y_WIDTH-1:0] red_box_center_y_wire;
    wire [7:0] calib_debug_flags_wire;
    wire [7:0] black_frame_debug_flags_wire;

    assign laser_spot_valid = light_valid;
    assign laser_spot_x = light_x;
    assign laser_spot_y = light_y;
    assign laser_spot_pixel_count = light_pixel_count;

    reg frame_done_d1_reg;
    wire frame_commit_pulse;
    localparam [23:0] CALIB_MIN_RED_PIXELS_W = CALIB_MIN_RED_PIXELS;
    localparam [23:0] CALIB_MAX_RED_PIXELS_W = CALIB_MAX_RED_PIXELS;
    localparam [X_WIDTH:0] CALIB_MIN_RED_WIDTH_W = CALIB_MIN_RED_WIDTH;
    localparam [X_WIDTH:0] CALIB_MAX_RED_WIDTH_W = CALIB_MAX_RED_WIDTH;
    localparam [Y_WIDTH:0] CALIB_MIN_RED_HEIGHT_W = CALIB_MIN_RED_HEIGHT;
    localparam [Y_WIDTH:0] CALIB_MAX_RED_HEIGHT_W = CALIB_MAX_RED_HEIGHT;
    localparam [23:0] CALIB_MIN_WHITE_PIXELS_W = CALIB_MIN_WHITE_PIXELS;
    localparam [23:0] CALIB_MIN_GREEN_PIXELS_W = CALIB_MIN_GREEN_PIXELS;

    virtual_grab_detect_top #(
        .IMAGE_WIDTH (IMAGE_WIDTH),
        .IMAGE_HEIGHT(IMAGE_HEIGHT),
        .X_WIDTH     (X_WIDTH),
        .Y_WIDTH     (Y_WIDTH),
        .CALIB_RED_ROI_MIN_X(CALIB_RED_ROI_MIN_X),
        .CALIB_RED_ROI_MAX_X(CALIB_RED_ROI_MAX_X),
        .CALIB_RED_ROI_MIN_Y(CALIB_RED_ROI_MIN_Y),
        .CALIB_RED_ROI_MAX_Y(CALIB_RED_ROI_MAX_Y)
    ) u_detect_top (
        .clk        (clk),
        .rst        (~rst_n),
        .sof        (sof),
        .eof        (eof),
        .pixel_valid(pixel_valid),
        .pixel_x    (pixel_x),
        .pixel_y    (pixel_y),
        .pixel_r    (pixel_r),
        .pixel_g    (pixel_g),
        .pixel_b    (pixel_b),
        .scene_roi_valid(scene_roi_valid),
        .scene_roi_min_x(scene_roi_min_x),
        .scene_roi_max_x(scene_roi_max_x),
        .scene_roi_min_y(scene_roi_min_y),
        .scene_roi_max_y(scene_roi_max_y),
        .origin_x   (origin_x),
        .origin_y   (origin_y),
        .green_valid(green_valid),
        .green_x    (green_x),
        .green_y    (green_y),
        .red_valid  (red_valid),
        .red_x      (red_x),
        .red_y      (red_y),
        .red_min_x  (red_min_x),
        .red_max_x  (red_max_x),
        .red_min_y  (red_min_y),
        .red_max_y  (red_max_y),
        .blue_valid (blue_valid),
        .blue_x     (blue_x),
        .blue_y     (blue_y),
        .blue_min_x (blue_min_x),
        .blue_max_x (blue_max_x),
        .blue_min_y (blue_min_y),
        .blue_max_y (blue_max_y),
        .light_valid(light_valid),
        .light_x(light_x),
        .light_y(light_y),
        .light_min_x(light_min_x),
        .light_max_x(light_max_x),
        .light_min_y(light_min_y),
        .light_max_y(light_max_y),
        .light_pixel_count(light_pixel_count),
        .white_pixel_count(white_pixel_count),
        .green_pixel_count(green_pixel_count),
        .red_pixel_count(red_pixel_count),
        .blue_pixel_count(blue_pixel_count),
        .committed_pixel_count(committed_pixel_count),
        .live_pixel_count(live_pixel_count),
        .loose_red_pixel_count(loose_red_pixel_count),
        .max_pixel_r(max_pixel_r),
        .max_pixel_g(max_pixel_g),
        .max_pixel_b(max_pixel_b),
        .last_pixel_r(last_pixel_r),
        .last_pixel_g(last_pixel_g),
        .last_pixel_b(last_pixel_b)
    );

    assign origin_valid = calibration_origin_valid_wire;
    assign frame_commit_pulse = frame_done_d1_reg;
    assign calibration_origin_valid_wire = white_pixel_count >= CALIB_MIN_WHITE_PIXELS_W;
    assign calibration_green_valid_wire = green_valid && (green_pixel_count >= CALIB_MIN_GREEN_PIXELS_W);
    assign red_box_width_wire = {1'b0, red_max_x} - {1'b0, red_min_x} + {{X_WIDTH{1'b0}}, 1'b1};
    assign red_box_height_wire = {1'b0, red_max_y} - {1'b0, red_min_y} + {{Y_WIDTH{1'b0}}, 1'b1};
    assign red_box_center_x_sum_wire = {1'b0, red_min_x} + {1'b0, red_max_x};
    assign red_box_center_y_sum_wire = {1'b0, red_min_y} + {1'b0, red_max_y};
    assign red_box_center_x_wire = red_box_center_x_sum_wire[X_WIDTH:1];
    assign red_box_center_y_wire = red_box_center_y_sum_wire[Y_WIDTH:1];
    assign red_box_width_x2_wire = {3'b000, red_box_width_wire} << 1;
    assign red_box_height_x2_wire = {3'b000, red_box_height_wire} << 1;
    assign red_box_width_x3_wire = ({3'b000, red_box_width_wire} << 1) + {3'b000, red_box_width_wire};
    assign red_box_height_x3_wire = ({3'b000, red_box_height_wire} << 1) + {3'b000, red_box_height_wire};
    assign red_area_valid_wire =
        (red_pixel_count >= CALIB_MIN_RED_PIXELS_W) &&
        (red_pixel_count <= CALIB_MAX_RED_PIXELS_W);
    assign red_size_valid_wire =
        (red_box_width_wire >= CALIB_MIN_RED_WIDTH_W) &&
        (red_box_width_wire <= CALIB_MAX_RED_WIDTH_W) &&
        (red_box_height_wire >= CALIB_MIN_RED_HEIGHT_W) &&
        (red_box_height_wire <= CALIB_MAX_RED_HEIGHT_W);
    assign red_aspect_valid_wire =
        (red_box_width_wire <= (red_box_height_wire << 2)) &&
        (red_box_height_wire <= (red_box_width_wire << 2));
    assign red_round_valid_wire =
        (red_box_width_x2_wire <= red_box_height_x3_wire) &&
        (red_box_height_x2_wire <= red_box_width_x3_wire);
    assign calibration_red_valid_wire =
        red_valid &&
        (committed_pixel_count != 24'd0) &&
        red_size_valid_wire &&
        red_aspect_valid_wire;
    assign calib_debug_flags_wire = {
        red_round_valid_wire,
        calibration_red_valid_wire,
        calibration_green_valid_wire,
        calibration_origin_valid_wire,
        red_aspect_valid_wire,
        red_size_valid_wire,
        red_area_valid_wire,
        red_valid
    };
    assign black_frame_debug_flags_wire = {
        3'b000,
        scene_roi_valid,
        black_frame_right_side_valid,
        black_frame_left_side_valid,
        black_frame_valid,
        black_frame_candidate_valid
    };
    assign selected_track_valid = light_mode_enable ? light_track_valid : blue_track_valid;
    assign selected_track_x = light_mode_enable ? light_track_x : blue_track_x;
    assign selected_track_y = light_mode_enable ? light_track_y : blue_track_y;
    assign selected_track_pixel_count =
        light_mode_enable ? light_track_pixel_count : blue_track_pixel_count;
    assign selected_track_min_x = light_mode_enable ? light_track_min_x : blue_track_min_x;
    assign selected_track_max_x = light_mode_enable ? light_track_max_x : blue_track_max_x;
    assign selected_track_min_y = light_mode_enable ? light_track_min_y : blue_track_min_y;
    assign selected_track_max_y = light_mode_enable ? light_track_max_y : blue_track_max_y;
    assign selected_detector_pixel_count = light_mode_enable ? light_pixel_count : blue_pixel_count;
    assign hand_area_wire = (|selected_track_pixel_count[23:AREA_WIDTH]) ?
                            {AREA_WIDTH{1'b1}} :
                            selected_track_pixel_count[AREA_WIDTH-1:0];
    assign red_target_valid = red_valid;
    assign red_target_center_x = red_box_center_x_wire;
    assign red_target_center_y = red_box_center_y_wire;
    assign red_target_min_x = red_min_x;
    assign red_target_max_x = red_max_x;
    assign red_target_min_y = red_min_y;
    assign red_target_max_y = red_max_y;
    assign blue_hand_valid = selected_track_valid;
    assign blue_hand_min_x = selected_track_min_x;
    assign blue_hand_max_x = selected_track_max_x;
    assign blue_hand_min_y = selected_track_min_y;
    assign blue_hand_max_y = selected_track_max_y;

    // Delay the frame-end pulse so the host interface samples the detector outputs
    // after the blob statistics have committed the new frame result. The side-tap
    // adapter may assert eof at frame_start when a sampled frame is shorter than
    // the nominal image size, so eof is not always accompanied by pixel_valid.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            frame_done_d1_reg <= 1'b0;
        end else begin
            frame_done_d1_reg <= eof;
        end
    end

    blue_hand_temporal_filter #(
        .X_WIDTH(X_WIDTH),
        .Y_WIDTH(Y_WIDTH),
        .COUNT_W(24),
        .HOLD_FRAMES(BLUE_HAND_HOLD_FRAMES)
    ) u_blue_hand_temporal_filter (
        .clk(clk),
        .rst_n(rst_n),
        .frame_tick(frame_commit_pulse),
        .candidate_valid(blue_valid),
        .candidate_x(blue_x),
        .candidate_y(blue_y),
        .candidate_pixel_count(blue_pixel_count),
        .candidate_min_x(blue_min_x),
        .candidate_max_x(blue_max_x),
        .candidate_min_y(blue_min_y),
        .candidate_max_y(blue_max_y),
        .track_valid(blue_track_valid),
        .track_x(blue_track_x),
        .track_y(blue_track_y),
        .track_pixel_count(blue_track_pixel_count),
        .track_min_x(blue_track_min_x),
        .track_max_x(blue_track_max_x),
        .track_min_y(blue_track_min_y),
        .track_max_y(blue_track_max_y)
    );

    blue_light_temporal_filter #(
        .X_WIDTH(X_WIDTH),
        .Y_WIDTH(Y_WIDTH),
        .COUNT_W(24),
        .HOLD_FRAMES(BLUE_LIGHT_HOLD_FRAMES),
        .TRACK_GATE_X(24),
        .TRACK_GATE_Y(24),
        .PENDING_TOL_X(24),
        .PENDING_TOL_Y(24),
        .CONFIRM_FRAMES(3),
        .SMOOTH_SHIFT(1),
        .DIRECT_THRESHOLD(8),
        .DEADBAND(2),
        .BOX_HALF_WIDTH(24),
        .BOX_HALF_HEIGHT(24),
        .MAX_X(IMAGE_WIDTH - 1),
        .MAX_Y(IMAGE_HEIGHT - 1)
    ) u_blue_light_temporal_filter (
        .clk(clk),
        .rst_n(rst_n),
        .frame_tick(frame_commit_pulse),
        .candidate_valid(light_valid),
        .candidate_x(light_x),
        .candidate_y(light_y),
        .candidate_pixel_count(light_pixel_count),
        .candidate_min_x(light_min_x),
        .candidate_max_x(light_max_x),
        .candidate_min_y(light_min_y),
        .candidate_max_y(light_max_y),
        .track_valid(light_track_valid),
        .track_x(light_track_x),
        .track_y(light_track_y),
        .track_pixel_count(light_track_pixel_count),
        .track_min_x(light_track_min_x),
        .track_max_x(light_track_max_x),
        .track_min_y(light_track_min_y),
        .track_max_y(light_track_max_y)
    );

    virtual_grab_host_if #(
        .X_WIDTH          (X_WIDTH),
        .Y_WIDTH          (Y_WIDTH),
        .AREA_WIDTH       (AREA_WIDTH),
        .BTN_STABLE_CYCLES(BTN_STABLE_CYCLES)
    ) u_host_if (
        .clk             (clk),
        .rst_n           (rst_n),
        .rx_valid        (rx_valid),
        .rx_data         (rx_data),
        .tx_valid        (tx_valid),
        .tx_data         (tx_data),
        .tx_last         (tx_last),
        .tx_ready        (tx_ready),
        .red_valid       (red_valid),
        .red_x           (red_box_center_x_wire),
        .red_y           (red_box_center_y_wire),
        .origin_valid    (origin_valid),
        .origin_x        (origin_x),
        .origin_y        (origin_y),
        .green_valid     (green_valid),
        .green_x         (green_x),
        .green_y         (green_y),
        .red_pixel_count (red_pixel_count),
        .green_pixel_count(green_pixel_count),
        .blue_pixel_count(selected_detector_pixel_count),
        .white_pixel_count(white_pixel_count),
        .committed_pixel_count(committed_pixel_count),
        .live_pixel_count(live_pixel_count),
        .loose_red_pixel_count(loose_red_pixel_count),
        .max_pixel_r(max_pixel_r),
        .max_pixel_g(max_pixel_g),
        .max_pixel_b(max_pixel_b),
        .last_pixel_r(last_pixel_r),
        .last_pixel_g(last_pixel_g),
        .last_pixel_b(last_pixel_b),
        .calib_debug_flags(calib_debug_flags_wire),
        .red_min_x(red_min_x),
        .red_max_x(red_max_x),
        .red_min_y(red_min_y),
        .red_max_y(red_max_y),
        .red_width(red_box_width_wire[X_WIDTH-1:0]),
        .red_height(red_box_height_wire[Y_WIDTH-1:0]),
        .black_frame_debug_flags(black_frame_debug_flags_wire),
        .black_frame_left_x(black_frame_candidate_left_x),
        .black_frame_right_x(black_frame_candidate_right_x),
        .black_frame_top_y(black_frame_candidate_top_y),
        .black_frame_bottom_y(black_frame_candidate_bottom_y),
        .hand_update     (frame_commit_pulse),
        .hand_valid      (selected_track_valid),
        .hand_x          (selected_track_x),
        .hand_y          (selected_track_y),
        .hand_area       (hand_area_wire),
        .grab_btn_raw    (grab_btn_raw),
        .release_btn_raw (release_btn_raw),
        .streaming_enable(streaming_enable),
        .light_mode_enable(light_mode_enable),
        .map_relocalize  (map_relocalize),
        .calibrated_valid(calibrated_valid),
        .overlay_circle_valid(overlay_circle_valid),
        .overlay_circle_grabbed(overlay_circle_grabbed),
        .overlay_circle_x(overlay_circle_x),
        .overlay_circle_y(overlay_circle_y),
        .target_cross_valid(target_cross_valid),
        .target_cross_x  (target_cross_x),
        .target_cross_y  (target_cross_y)
    );

endmodule
