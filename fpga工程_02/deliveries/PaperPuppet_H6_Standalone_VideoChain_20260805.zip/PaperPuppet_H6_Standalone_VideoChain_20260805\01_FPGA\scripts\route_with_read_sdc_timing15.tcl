﻿# Legacy timing launcher retained for old shortcuts. eLinx 3.0 rejects lambda
# values above 1.0, so this alias now runs the verified standard route flow.
set scriptDir [file dirname [file normalize [info script]]]
set dir [file normalize [file join $scriptDir ".."]]
set tclFile [file join $scriptDir "run_route_with_read_sdc.tcl"]
cd "D:/eLinx3.0/bin/shell/bin"
set prj ov5640_hdmi_1080p
set topEntity TOP1
set seriesName "eHiChip6"
set deviceName "EQ6HL130"
set packageName "CSG484_H"
set synthName synth_1
set ImpleName imple_1

source $tclFile

run_route $dir $prj $topEntity $seriesName $deviceName $packageName $synthName $ImpleName
exit 0

