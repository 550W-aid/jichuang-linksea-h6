`timescale 1ns / 1ps

module vision_snapshot_assembler #(
    parameter integer X_WIDTH = 12,
    parameter integer Y_WIDTH = 12,
    parameter integer LASER_HOLD_FRAMES = 5,
    parameter integer TARGET_HOLD_FRAMES = 5
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 laser_commit_i,
    input  wire [15:0]          laser_frame_id_i,
    input  wire [31:0]          laser_capture_ms_i,
    input  wire                 laser_valid_i,
    input  wire [X_WIDTH-1:0]   laser_x_i,
    input  wire [Y_WIDTH-1:0]   laser_y_i,
    input  wire [23:0]          laser_pixels_i,
    input  wire                 target_result_valid_i,
    input  wire                 target_valid_i,
    input  wire [X_WIDTH-1:0]   target_x_i,
    input  wire [Y_WIDTH-1:0]   target_y_i,
    input  wire [X_WIDTH-1:0]   target_w_i,
    input  wire [Y_WIDTH-1:0]   target_h_i,
    input  wire [31:0]          target_score_i,
    input  wire [3:0]           target_support_i,
    input  wire [15:0]          target_frame_id_i,
    input  wire                 target_roi_valid_i,
    input  wire [X_WIDTH-1:0]   target_roi_left_i,
    input  wire [X_WIDTH-1:0]   target_roi_right_i,
    input  wire [Y_WIDTH-1:0]   target_roi_top_i,
    input  wire [Y_WIDTH-1:0]   target_roi_bottom_i,
    output reg                  snapshot_commit_o,
    output reg [15:0]           snapshot_status_o,
    output reg [31:0]           snapshot_capture_ms_o,
    output reg [15:0]           snapshot_laser_x_o,
    output reg [15:0]           snapshot_laser_y_o,
    output reg [15:0]           snapshot_target_x_o,
    output reg [15:0]           snapshot_target_y_o,
    output reg [15:0]           snapshot_error_x_o,
    output reg [15:0]           snapshot_error_y_o,
    output reg [15:0]           snapshot_target_w_o,
    output reg [15:0]           snapshot_target_h_o,
    output reg [15:0]           snapshot_quality_o,
    output reg [15:0]           snapshot_roi_left_o,
    output reg [15:0]           snapshot_roi_right_o,
    output reg [15:0]           snapshot_roi_top_o,
    output reg [15:0]           snapshot_roi_bottom_o,
    output reg [15:0]           snapshot_laser_pixels_o,
    output reg [31:0]           snapshot_target_score_o,
    output reg [15:0]           snapshot_frame_id_o
);

reg slot0_present_r;
reg slot0_valid_r;
reg [15:0] slot0_frame_id_r;
reg [31:0] slot0_capture_ms_r;
reg [X_WIDTH-1:0] slot0_x_r;
reg [Y_WIDTH-1:0] slot0_y_r;
reg [23:0] slot0_pixels_r;
reg slot1_present_r;
reg slot1_valid_r;
reg [15:0] slot1_frame_id_r;
reg [31:0] slot1_capture_ms_r;
reg [X_WIDTH-1:0] slot1_x_r;
reg [Y_WIDTH-1:0] slot1_y_r;
reg [23:0] slot1_pixels_r;

reg last_laser_valid_r;
reg [X_WIDTH-1:0] last_laser_x_r;
reg [Y_WIDTH-1:0] last_laser_y_r;
reg [7:0] laser_miss_count_r;
reg [3:0] laser_consistency_r;
reg last_target_valid_r;
reg [X_WIDTH-1:0] last_target_x_r;
reg [Y_WIDTH-1:0] last_target_y_r;
reg [X_WIDTH-1:0] last_target_w_r;
reg [Y_WIDTH-1:0] last_target_h_r;
reg [7:0] target_miss_count_r;
reg [3:0] target_consistency_r;

wire selected_slot_present_w = target_frame_id_i[0] ? slot1_present_r
                                                     : slot0_present_r;
wire [15:0] selected_slot_frame_id_w = target_frame_id_i[0] ? slot1_frame_id_r
                                                             : slot0_frame_id_r;
wire selected_slot_valid_w = target_frame_id_i[0] ? slot1_valid_r
                                                   : slot0_valid_r;
wire [31:0] selected_slot_capture_ms_w = target_frame_id_i[0] ? slot1_capture_ms_r
                                                              : slot0_capture_ms_r;
wire [X_WIDTH-1:0] selected_slot_x_w = target_frame_id_i[0] ? slot1_x_r
                                                            : slot0_x_r;
wire [Y_WIDTH-1:0] selected_slot_y_w = target_frame_id_i[0] ? slot1_y_r
                                                            : slot0_y_r;
wire [23:0] selected_slot_pixels_w = target_frame_id_i[0] ? slot1_pixels_r
                                                          : slot0_pixels_r;
wire laser_metadata_match_w = selected_slot_present_w &&
                              (selected_slot_frame_id_w == target_frame_id_i);
wire laser_fresh_w = laser_metadata_match_w && selected_slot_valid_w &&
                     target_roi_valid_i;
wire target_fresh_w = target_valid_i && target_roi_valid_i;
wire laser_held_w = !laser_fresh_w && last_laser_valid_r &&
                    (laser_miss_count_r < LASER_HOLD_FRAMES);
wire target_held_w = !target_fresh_w && last_target_valid_r &&
                     (target_miss_count_r < TARGET_HOLD_FRAMES);
wire laser_output_valid_w = laser_fresh_w || laser_held_w;
wire target_output_valid_w = target_fresh_w || target_held_w;
wire [X_WIDTH-1:0] selected_laser_x_w = laser_fresh_w ? selected_slot_x_w
                                                      : last_laser_x_r;
wire [Y_WIDTH-1:0] selected_laser_y_w = laser_fresh_w ? selected_slot_y_w
                                                      : last_laser_y_r;
wire [X_WIDTH-1:0] selected_target_x_w = target_fresh_w ? target_x_i
                                                        : last_target_x_r;
wire [Y_WIDTH-1:0] selected_target_y_w = target_fresh_w ? target_y_i
                                                        : last_target_y_r;
wire [X_WIDTH-1:0] selected_target_w_w = target_fresh_w ? target_w_i
                                                        : last_target_w_r;
wire [Y_WIDTH-1:0] selected_target_h_w = target_fresh_w ? target_h_i
                                                        : last_target_h_r;
wire error_valid_w = laser_fresh_w && target_fresh_w;
wire [15:0] error_x_w = {4'd0, target_x_i} - {4'd0, selected_slot_x_w};
wire [15:0] error_y_w = {4'd0, target_y_i} - {4'd0, selected_slot_y_w};
wire [3:0] laser_consistency_next_w = laser_fresh_w ?
    ((laser_consistency_r == 4'hf) ? 4'hf : laser_consistency_r + 4'd1) : 4'd0;
wire [3:0] target_consistency_next_w = target_fresh_w ?
    ((target_consistency_r == 4'hf) ? 4'hf : target_consistency_r + 4'd1) : 4'd0;
wire [1:0] target_source_w = target_fresh_w ? 2'b01 :
                             target_held_w ? 2'b10 : 2'b00;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        slot0_present_r <= 1'b0;
        slot0_valid_r <= 1'b0;
        slot0_frame_id_r <= 16'd0;
        slot0_capture_ms_r <= 32'd0;
        slot0_x_r <= {X_WIDTH{1'b0}};
        slot0_y_r <= {Y_WIDTH{1'b0}};
        slot0_pixels_r <= 24'd0;
        slot1_present_r <= 1'b0;
        slot1_valid_r <= 1'b0;
        slot1_frame_id_r <= 16'd0;
        slot1_capture_ms_r <= 32'd0;
        slot1_x_r <= {X_WIDTH{1'b0}};
        slot1_y_r <= {Y_WIDTH{1'b0}};
        slot1_pixels_r <= 24'd0;
        last_laser_valid_r <= 1'b0;
        last_laser_x_r <= {X_WIDTH{1'b0}};
        last_laser_y_r <= {Y_WIDTH{1'b0}};
        laser_miss_count_r <= 8'd0;
        laser_consistency_r <= 4'd0;
        last_target_valid_r <= 1'b0;
        last_target_x_r <= {X_WIDTH{1'b0}};
        last_target_y_r <= {Y_WIDTH{1'b0}};
        last_target_w_r <= {X_WIDTH{1'b0}};
        last_target_h_r <= {Y_WIDTH{1'b0}};
        target_miss_count_r <= 8'd0;
        target_consistency_r <= 4'd0;
        snapshot_commit_o <= 1'b0;
        snapshot_status_o <= 16'd0;
        snapshot_capture_ms_o <= 32'd0;
        snapshot_laser_x_o <= 16'hffff;
        snapshot_laser_y_o <= 16'hffff;
        snapshot_target_x_o <= 16'hffff;
        snapshot_target_y_o <= 16'hffff;
        snapshot_error_x_o <= 16'hffff;
        snapshot_error_y_o <= 16'hffff;
        snapshot_target_w_o <= 16'd0;
        snapshot_target_h_o <= 16'd0;
        snapshot_quality_o <= 16'd0;
        snapshot_roi_left_o <= 16'hffff;
        snapshot_roi_right_o <= 16'hffff;
        snapshot_roi_top_o <= 16'hffff;
        snapshot_roi_bottom_o <= 16'hffff;
        snapshot_laser_pixels_o <= 16'd0;
        snapshot_target_score_o <= 32'd0;
        snapshot_frame_id_o <= 16'd0;
    end else begin
        snapshot_commit_o <= 1'b0;

        if (laser_commit_i) begin
            if (laser_frame_id_i[0]) begin
                slot1_present_r <= 1'b1;
                slot1_valid_r <= laser_valid_i;
                slot1_frame_id_r <= laser_frame_id_i;
                slot1_capture_ms_r <= laser_capture_ms_i;
                slot1_x_r <= laser_x_i;
                slot1_y_r <= laser_y_i;
                slot1_pixels_r <= laser_pixels_i;
            end else begin
                slot0_present_r <= 1'b1;
                slot0_valid_r <= laser_valid_i;
                slot0_frame_id_r <= laser_frame_id_i;
                slot0_capture_ms_r <= laser_capture_ms_i;
                slot0_x_r <= laser_x_i;
                slot0_y_r <= laser_y_i;
                slot0_pixels_r <= laser_pixels_i;
            end
        end

        if (target_result_valid_i) begin
            snapshot_commit_o <= 1'b1;
            snapshot_status_o <= {
                7'd0,
                target_roi_valid_i,
                1'b1,
                error_valid_w,
                target_held_w,
                laser_held_w,
                target_fresh_w,
                laser_fresh_w,
                target_output_valid_w,
                laser_output_valid_w
            };
            snapshot_capture_ms_o <= laser_metadata_match_w ?
                                     selected_slot_capture_ms_w : 32'd0;
            snapshot_laser_x_o <= laser_output_valid_w ?
                                  {4'd0, selected_laser_x_w} : 16'hffff;
            snapshot_laser_y_o <= laser_output_valid_w ?
                                  {4'd0, selected_laser_y_w} : 16'hffff;
            snapshot_target_x_o <= target_output_valid_w ?
                                   {4'd0, selected_target_x_w} : 16'hffff;
            snapshot_target_y_o <= target_output_valid_w ?
                                   {4'd0, selected_target_y_w} : 16'hffff;
            snapshot_error_x_o <= error_valid_w ? error_x_w : 16'hffff;
            snapshot_error_y_o <= error_valid_w ? error_y_w : 16'hffff;
            snapshot_target_w_o <= target_output_valid_w ?
                                   {4'd0, selected_target_w_w} : 16'd0;
            snapshot_target_h_o <= target_output_valid_w ?
                                   {4'd0, selected_target_h_w} : 16'd0;
            snapshot_quality_o <= {
                laser_fresh_w,
                target_fresh_w,
                target_source_w,
                target_fresh_w ? target_support_i : 4'd0,
                laser_consistency_next_w,
                target_consistency_next_w
            };
            snapshot_roi_left_o <= target_roi_valid_i ?
                                   {4'd0, target_roi_left_i} : 16'hffff;
            snapshot_roi_right_o <= target_roi_valid_i ?
                                    {4'd0, target_roi_right_i} : 16'hffff;
            snapshot_roi_top_o <= target_roi_valid_i ?
                                  {4'd0, target_roi_top_i} : 16'hffff;
            snapshot_roi_bottom_o <= target_roi_valid_i ?
                                     {4'd0, target_roi_bottom_i} : 16'hffff;
            snapshot_laser_pixels_o <= laser_fresh_w ?
                ((selected_slot_pixels_w > 24'h00ffff) ? 16'hffff :
                 selected_slot_pixels_w[15:0]) : 16'd0;
            snapshot_target_score_o <= target_fresh_w ? target_score_i : 32'd0;
            snapshot_frame_id_o <= target_frame_id_i;

            if (laser_fresh_w) begin
                last_laser_valid_r <= 1'b1;
                last_laser_x_r <= selected_slot_x_w;
                last_laser_y_r <= selected_slot_y_w;
                laser_miss_count_r <= 8'd0;
                laser_consistency_r <= laser_consistency_next_w;
            end else begin
                laser_consistency_r <= 4'd0;
                if (laser_held_w)
                    laser_miss_count_r <= laser_miss_count_r + 8'd1;
                else begin
                    last_laser_valid_r <= 1'b0;
                    laser_miss_count_r <= 8'd0;
                end
            end

            if (target_fresh_w) begin
                last_target_valid_r <= 1'b1;
                last_target_x_r <= target_x_i;
                last_target_y_r <= target_y_i;
                last_target_w_r <= target_w_i;
                last_target_h_r <= target_h_i;
                target_miss_count_r <= 8'd0;
                target_consistency_r <= target_consistency_next_w;
            end else begin
                target_consistency_r <= 4'd0;
                if (target_held_w)
                    target_miss_count_r <= target_miss_count_r + 8'd1;
                else begin
                    last_target_valid_r <= 1'b0;
                    target_miss_count_r <= 8'd0;
                end
            end
        end
    end
end

endmodule
