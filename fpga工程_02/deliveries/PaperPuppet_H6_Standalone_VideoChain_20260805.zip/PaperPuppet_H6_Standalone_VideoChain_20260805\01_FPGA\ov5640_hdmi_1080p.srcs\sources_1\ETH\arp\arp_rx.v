// ============================================================================
// Module Function:
//   Parses GMII ARP frames, validates the Ethernet/ARP headers and target IP,
//   then publishes the sender MAC/IP atomically with a one-cycle done pulse.
//   Both normal GMII preamble/SFD input and PHY-stripped preamble input work.
// ============================================================================
module arp_rx
  #(
    parameter BOARD_MAC = 48'h00_11_22_33_44_55,
    parameter BOARD_IP  = {8'd192, 8'd168, 8'd1, 8'd10}
    )
   (
    input               clk,
    input               rst_n,

    input               gmii_rx_dv,
    input      [7:0]    gmii_rxd,
    output reg          arp_rx_done,
    output reg          arp_rx_type,
    output reg [47:0]   src_mac,
    output reg [31:0]   src_ip
    );

localparam [1:0] ST_WAIT_START = 2'd0;
localparam [1:0] ST_WAIT_SFD   = 2'd1;
localparam [1:0] ST_PARSE      = 2'd2;
localparam [1:0] ST_DROP       = 2'd3;

reg [1:0]  state;
reg [5:0]  byte_index;
reg        dst_board_match;
reg        dst_bcast_match;
reg        header_valid;
reg        opcode_valid;
reg        opcode_is_reply;
reg        target_ip_match;
reg [47:0] src_mac_work;
reg [31:0] src_ip_work;

// Register byte comparisons before the parser. This keeps the 125 MHz input
// byte out of the parser's state/selector cone while preserving one byte per
// clock throughput.
reg        gmii_rx_dv_d;
reg [7:0]  gmii_rxd_d;
reg        match_55_d;
reg        match_d5_d;
reg        match_ff_d;
reg        match_08_d;
reg        match_06_d;
reg        match_04_d;
reg        match_02_d;
reg        match_01_d;
reg        match_00_d;
reg [5:0]  match_board_mac_d;
reg [3:0]  match_board_ip_d;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        gmii_rx_dv_d     <= 1'b0;
        gmii_rxd_d       <= 8'd0;
        match_55_d       <= 1'b0;
        match_d5_d       <= 1'b0;
        match_ff_d       <= 1'b0;
        match_08_d       <= 1'b0;
        match_06_d       <= 1'b0;
        match_04_d       <= 1'b0;
        match_02_d       <= 1'b0;
        match_01_d       <= 1'b0;
        match_00_d       <= 1'b0;
        match_board_mac_d <= 6'd0;
        match_board_ip_d  <= 4'd0;
    end
    else begin
        gmii_rx_dv_d <= gmii_rx_dv;
        gmii_rxd_d   <= gmii_rxd;
        match_55_d   <= (gmii_rxd == 8'h55);
        match_d5_d   <= (gmii_rxd == 8'hd5);
        match_ff_d   <= (gmii_rxd == 8'hff);
        match_08_d   <= (gmii_rxd == 8'h08);
        match_06_d   <= (gmii_rxd == 8'h06);
        match_04_d   <= (gmii_rxd == 8'h04);
        match_02_d   <= (gmii_rxd == 8'h02);
        match_01_d   <= (gmii_rxd == 8'h01);
        match_00_d   <= (gmii_rxd == 8'h00);
        match_board_mac_d[5] <= (gmii_rxd == BOARD_MAC[47:40]);
        match_board_mac_d[4] <= (gmii_rxd == BOARD_MAC[39:32]);
        match_board_mac_d[3] <= (gmii_rxd == BOARD_MAC[31:24]);
        match_board_mac_d[2] <= (gmii_rxd == BOARD_MAC[23:16]);
        match_board_mac_d[1] <= (gmii_rxd == BOARD_MAC[15:8]);
        match_board_mac_d[0] <= (gmii_rxd == BOARD_MAC[7:0]);
        match_board_ip_d[3]  <= (gmii_rxd == BOARD_IP[31:24]);
        match_board_ip_d[2]  <= (gmii_rxd == BOARD_IP[23:16]);
        match_board_ip_d[1]  <= (gmii_rxd == BOARD_IP[15:8]);
        match_board_ip_d[0]  <= (gmii_rxd == BOARD_IP[7:0]);
    end
end

task start_frame;
    begin
        byte_index       <= 6'd0;
        dst_board_match  <= 1'b1;
        dst_bcast_match  <= 1'b1;
        header_valid     <= 1'b1;
        opcode_valid     <= 1'b0;
        opcode_is_reply  <= 1'b0;
        target_ip_match  <= 1'b1;
        src_mac_work     <= 48'd0;
        src_ip_work      <= 32'd0;
    end
endtask

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        state             <= ST_WAIT_START;
        byte_index        <= 6'd0;
        dst_board_match   <= 1'b0;
        dst_bcast_match   <= 1'b0;
        header_valid      <= 1'b0;
        opcode_valid      <= 1'b0;
        opcode_is_reply   <= 1'b0;
        target_ip_match   <= 1'b0;
        src_mac_work      <= 48'd0;
        src_ip_work       <= 32'd0;
        arp_rx_done       <= 1'b0;
        arp_rx_type       <= 1'b0;
        src_mac           <= 48'd0;
        src_ip            <= 32'd0;
    end
    else begin
        arp_rx_done <= 1'b0;

        if(!gmii_rx_dv_d) begin
            state      <= ST_WAIT_START;
            byte_index <= 6'd0;
        end
        else begin
            case(state)
                ST_WAIT_START: begin
                    if(match_55_d) begin
                        state <= ST_WAIT_SFD;
                    end
                    else if(match_d5_d) begin
                        start_frame();
                        state <= ST_PARSE;
                    end
                    else begin
                        // Some PHY/MAC interfaces remove preamble and SFD.
                        // In that mode the first valid byte is destination MAC[47:40].
                        start_frame();
                        dst_board_match <= match_board_mac_d[5];
                        dst_bcast_match <= match_ff_d;
                        byte_index      <= 6'd1;
                        state           <= ST_PARSE;
                    end
                end

                ST_WAIT_SFD: begin
                    if(match_d5_d) begin
                        start_frame();
                        state <= ST_PARSE;
                    end
                    else if(!match_55_d) begin
                        state <= ST_DROP;
                    end
                end

                ST_PARSE: begin
                    case(byte_index)
                        6'd0: begin
                            dst_board_match <= match_board_mac_d[5];
                            dst_bcast_match <= match_ff_d;
                        end
                        6'd1: begin
                            dst_board_match <= dst_board_match && match_board_mac_d[4];
                            dst_bcast_match <= dst_bcast_match && match_ff_d;
                        end
                        6'd2: begin
                            dst_board_match <= dst_board_match && match_board_mac_d[3];
                            dst_bcast_match <= dst_bcast_match && match_ff_d;
                        end
                        6'd3: begin
                            dst_board_match <= dst_board_match && match_board_mac_d[2];
                            dst_bcast_match <= dst_bcast_match && match_ff_d;
                        end
                        6'd4: begin
                            dst_board_match <= dst_board_match && match_board_mac_d[1];
                            dst_bcast_match <= dst_bcast_match && match_ff_d;
                        end
                        6'd5: begin
                            dst_board_match <= dst_board_match && match_board_mac_d[0];
                            dst_bcast_match <= dst_bcast_match && match_ff_d;
                        end

                        // Ethernet type, ARP hardware/protocol types and lengths.
                        6'd12: header_valid <= header_valid && match_08_d;
                        6'd13: header_valid <= header_valid && match_06_d;
                        6'd14: header_valid <= header_valid && match_00_d;
                        6'd15: header_valid <= header_valid && match_01_d;
                        6'd16: header_valid <= header_valid && match_08_d;
                        6'd17: header_valid <= header_valid && match_00_d;
                        6'd18: header_valid <= header_valid && match_06_d;
                        6'd19: header_valid <= header_valid && match_04_d;
                        6'd20: header_valid <= header_valid && match_00_d;
                        6'd21: begin
                            opcode_valid    <= match_01_d || match_02_d;
                            opcode_is_reply <= match_02_d;
                        end

                        6'd22: src_mac_work[47:40] <= gmii_rxd_d;
                        6'd23: src_mac_work[39:32] <= gmii_rxd_d;
                        6'd24: src_mac_work[31:24] <= gmii_rxd_d;
                        6'd25: src_mac_work[23:16] <= gmii_rxd_d;
                        6'd26: src_mac_work[15:8]  <= gmii_rxd_d;
                        6'd27: src_mac_work[7:0]   <= gmii_rxd_d;
                        6'd28: src_ip_work[31:24]  <= gmii_rxd_d;
                        6'd29: src_ip_work[23:16]  <= gmii_rxd_d;
                        6'd30: src_ip_work[15:8]   <= gmii_rxd_d;
                        6'd31: src_ip_work[7:0]    <= gmii_rxd_d;

                        6'd38: target_ip_match <= match_board_ip_d[3];
                        6'd39: target_ip_match <= target_ip_match && match_board_ip_d[2];
                        6'd40: target_ip_match <= target_ip_match && match_board_ip_d[1];
                        6'd41: begin
                            if((dst_board_match || dst_bcast_match) &&
                               header_valid && opcode_valid && target_ip_match &&
                               match_board_ip_d[0]) begin
                                src_mac     <= src_mac_work;
                                src_ip      <= src_ip_work;
                                arp_rx_type <= opcode_is_reply;
                                arp_rx_done <= 1'b1;
                            end
                            state <= ST_DROP;
                        end
                        default: begin end
                    endcase

                    if(byte_index != 6'd41)
                        byte_index <= byte_index + 6'd1;
                end

                default: begin
                    // Ignore padding/FCS or a malformed frame until RX_DV drops.
                    state <= ST_DROP;
                end
            endcase
        end
    end
end

endmodule
