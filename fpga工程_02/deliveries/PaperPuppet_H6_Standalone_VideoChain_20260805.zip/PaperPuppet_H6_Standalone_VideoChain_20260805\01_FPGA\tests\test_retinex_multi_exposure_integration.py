from pathlib import Path
import unittest


FPGA_ROOT = Path(__file__).resolve().parents[1]
SOURCES = FPGA_ROOT / "ov5640_hdmi_1080p.srcs" / "sources_1"
TOP = SOURCES / "system" / "eth_video_rotate_system.v"
FUSION_TOP = SOURCES / "multi_exposure" / "multi_exposure_video_path.v"
QSF = FPGA_ROOT / "ov5640_hdmi_1080p.qsf"
ROUTER = SOURCES / "system" / "unified_uart_mode_router.v"


class RetinexMultiExposureIntegrationTests(unittest.TestCase):
    def test_final_fusion_interface_exposes_lut_ready(self) -> None:
        source = FUSION_TOP.read_text(encoding="utf-8")
        self.assertIn("output wire        fusion_lut_ready_o", source)
        self.assertIn(".fusion_lut_ready_o      (fusion_lut_ready_o)", source)

    def test_top_selects_rgb_and_sync_from_the_same_effect_path(self) -> None:
        source = TOP.read_text(encoding="utf-8")
        required = (
            "fusion_output_select_hdmi_w",
            "video_hs_effect_path_w",
            "video_vs_effect_path_w",
            "video_de_effect_path_w",
            ".fusion_lut_ready_o  (fusion_lut_ready_hdmi_w)",
            "hdmi_hsync_d1_r <= video_hs_effect_path_w",
            "hdmi_vsync_d1_r <= video_vs_effect_path_w",
            "hdmi_de_d1_r    <= video_de_effect_path_w",
        )
        for token in required:
            with self.subTest(token=token):
                self.assertIn(token, source)

    def test_fusion_is_available_for_camera_and_ethernet_sources(self) -> None:
        source = TOP.read_text(encoding="utf-8")
        self.assertRegex(
            source,
            r"assign\s+fusion_output_select_hdmi_w\s*=\s*"
            r"fusion_active_hdmi_w\s*;",
        )
        self.assertNotRegex(
            source,
            r"fusion_output_select_hdmi_w\s*=.*source_mode_hdmi_sync_r",
        )

    def test_shared_video_delay_has_only_one_project_registration(self) -> None:
        source = QSF.read_text(encoding="utf-8")
        registrations = [line for line in source.splitlines() if "video_stream_delay.v" in line]
        self.assertEqual(len(registrations), 1)
        self.assertIn("video_shader/video_stream_delay.v", registrations[0])

    def test_existing_mode_commands_are_preserved(self) -> None:
        source = ROUTER.read_text(encoding="utf-8")
        for command in ("8'hA0", "8'hAC", "8'hAD", "8'hAA", "8'h01", "8'h02", "8'h03"):
            with self.subTest(command=command):
                self.assertIn(command, source)


if __name__ == "__main__":
    unittest.main()
