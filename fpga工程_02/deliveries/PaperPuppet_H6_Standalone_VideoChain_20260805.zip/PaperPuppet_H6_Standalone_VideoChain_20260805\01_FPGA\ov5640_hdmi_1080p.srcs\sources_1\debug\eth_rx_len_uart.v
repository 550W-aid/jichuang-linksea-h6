// ============================================================================
// Module Function:
//   UART helper that reports Ethernet receive packet lengths.
// ============================================================================
module eth_rx_len_uart #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD   = 115200
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        trigger_i,
    input  wire [15:0] length_i,
    output wire        uart_tx_o
);

    reg [15:0] length_r;
    reg        pending_r;
    reg [3:0]  index_r;
    reg [1:0]  state_r;
    reg [7:0]  uart_data_r;
    reg        uart_valid_r;
    wire       uart_busy_w;

    localparam [1:0] ST_IDLE = 2'd0;
    localparam [1:0] ST_BUSY = 2'd1;
    localparam [1:0] ST_WAIT = 2'd2;

    function [7:0] hex_ascii;
        input [3:0] value;
        begin
            hex_ascii = (value < 4'd10) ? (8'h30 + {4'd0, value}) :
                        (8'h41 + {4'd0, value - 4'd10});
        end
    endfunction

    function [7:0] msg_byte;
        input [3:0] index;
        input [15:0] length;
        begin
            case (index)
                4'd0: msg_byte = "R";
                4'd1: msg_byte = "X";
                4'd2: msg_byte = "=";
                4'd3: msg_byte = hex_ascii(length[15:12]);
                4'd4: msg_byte = hex_ascii(length[11:8]);
                4'd5: msg_byte = hex_ascii(length[7:4]);
                4'd6: msg_byte = hex_ascii(length[3:0]);
                4'd7: msg_byte = 8'h0D;
                default: msg_byte = 8'h0A;
            endcase
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            length_r     <= 16'd0;
            pending_r    <= 1'b0;
            index_r      <= 4'd0;
            state_r      <= ST_IDLE;
            uart_data_r  <= 8'd0;
            uart_valid_r <= 1'b0;
        end else begin
            uart_valid_r <= 1'b0;

            if (trigger_i) begin
                length_r  <= length_i;
                pending_r <= 1'b1;
                if (state_r == ST_IDLE)
                    index_r <= 4'd0;
            end

            case (state_r)
                ST_IDLE: begin
                    if (pending_r && !uart_busy_w) begin
                        uart_data_r  <= msg_byte(index_r, length_r);
                        uart_valid_r <= 1'b1;
                        state_r      <= ST_BUSY;
                    end
                end
                ST_BUSY: begin
                    if (uart_busy_w)
                        state_r <= ST_WAIT;
                end
                default: begin
                    if (!uart_busy_w) begin
                        if (index_r == 4'd8) begin
                            pending_r <= 1'b0;
                            index_r   <= 4'd0;
                        end else begin
                            index_r <= index_r + 4'd1;
                        end
                        state_r <= ST_IDLE;
                    end
                end
            endcase
        end
    end

    uart_tx #(
        .CLK_HZ(CLK_HZ),
        .BAUD(BAUD)
    ) u_uart_tx (
        .clk(clk),
        .rst_n(rst_n),
        .data_i(uart_data_r),
        .data_valid_i(uart_valid_r),
        .tx_o(uart_tx_o),
        .busy_o(uart_busy_w)
    );

endmodule
