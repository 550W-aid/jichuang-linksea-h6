from pathlib import Path
import re
import unittest


RTL = (
    Path(__file__).resolve().parents[1]
    / "ov5640_hdmi_1080p.srcs"
    / "sources_1"
    / "virtual_grab"
    / "unified_virtual_grab_feature.v"
)
SYSTEM_RTL = RTL.parents[1] / "system" / "eth_video_rotate_system.v"


def instance_body(source: str, module: str, instance: str) -> str:
    pattern = rf"{module}\s*(?:#\s*\(.*?\)\s*)?{instance}\s*\((.*?)\);"
    match = re.search(pattern, source, flags=re.DOTALL)
    if match is None:
        raise AssertionError(f"missing instance {module} {instance}")
    return match.group(1)


class VirtualGrabRelocalizeWiringTest(unittest.TestCase):
    def test_relocalize_preserves_detector_and_resets_only_tracker(self) -> None:
        source = RTL.read_text(encoding="utf-8")
        system_source = SYSTEM_RTL.read_text(encoding="utf-8")
        self.assertRegex(system_source, r"ETH_SERIAL_DIAG_MODE\s*=\s*1'b0")
        detector = instance_body(
            source, "black_frame_green_anchor_detector", "u_black_frame"
        )
        tracker = instance_body(
            source, "black_frame_temporal_tracker", "u_black_frame_tracker"
        )

        self.assertRegex(detector, r"\.relocalize\s*\(\s*1'b0\s*\)")
        self.assertRegex(
            tracker,
            r"\.relocalize\s*\(\s*map_relocalize_apply_w\s*\)",
        )


if __name__ == "__main__":
    unittest.main()
