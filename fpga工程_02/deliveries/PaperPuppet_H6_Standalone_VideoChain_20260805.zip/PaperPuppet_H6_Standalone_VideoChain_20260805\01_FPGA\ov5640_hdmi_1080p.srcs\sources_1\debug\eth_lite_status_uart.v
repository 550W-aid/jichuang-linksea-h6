// ============================================================================
// Module Function:
//   Compact periodic UART reporter for PHY state, Ethernet clocks, receive
//   RX/TX headers and ARP request/reply counters during board bring-up.
// ============================================================================
module eth_lite_status_uart #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD   = 115200,
    parameter integer PERIOD_CYCLES = 25_000_000
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire [7:0]  raw_count_i,
    input  wire [7:0]  pkt_count_i,
    input  wire [15:0] last_len_i,
    input  wire [95:0] raw_head_i,
    input  wire [95:0] raw_tx_head_i,
    input  wire [31:0] arp_counts_i,
    input  wire        phy_reset_n_i,
    input  wire        pll_locked_i,
    input  wire [1:0]  link_speed_i,
    input  wire [7:0]  tx_clk_mon_i,
    output wire        uart_tx_o
);

    reg [24:0] period_cnt_r;
    reg [7:0]  raw_count_seen_r;
    reg [7:0]  pkt_count_seen_r;
    reg [15:0] last_len_seen_r;
    reg [95:0] raw_head_seen_r;
    reg [95:0] raw_tx_head_seen_r;
    reg [31:0] arp_counts_seen_r;
    reg [7:0]  raw_count_cap_r;
    reg [7:0]  pkt_count_cap_r;
    reg [15:0] last_len_cap_r;
    reg [95:0] raw_head_cap_r;
    reg [95:0] raw_tx_head_cap_r;
    reg [31:0] arp_counts_cap_r;
    reg [7:0]  raw_count_r;
    reg [7:0]  pkt_count_r;
    reg [15:0] last_len_r;
    reg [95:0] raw_head_r;
    reg [95:0] raw_tx_head_r;
    reg [31:0] arp_counts_r;
    reg        phy_reset_n_r;
    reg        pll_locked_r;
    reg [1:0]  link_speed_r;
    reg [7:0]  tx_clk_mon_r;
    reg        dirty_r;
    reg        pending_r;
    reg [6:0]  index_r;
    reg [1:0]  state_r;
    reg [7:0]  uart_data_r;
    reg        uart_valid_r;
    wire       uart_busy_w;

    localparam [1:0] ST_IDLE = 2'd0;
    localparam [1:0] ST_BUSY = 2'd1;
    localparam [1:0] ST_WAIT = 2'd2;
    localparam [6:0] MSG_LAST_INDEX = 7'd91;
    wire             event_change_w;
    wire             period_ready_w;

    assign event_change_w =
        (raw_count_i  != raw_count_seen_r)  ||
        (pkt_count_i  != pkt_count_seen_r)  ||
        (last_len_i   != last_len_seen_r)   ||
        (raw_head_i   != raw_head_seen_r)   ||
        (raw_tx_head_i != raw_tx_head_seen_r) ||
        (arp_counts_i != arp_counts_seen_r);

    assign period_ready_w = (period_cnt_r >= (PERIOD_CYCLES - 1));

    function [7:0] hex_ascii;
        input [3:0] value;
        begin
            hex_ascii = (value < 4'd10) ? (8'h30 + {4'd0, value}) :
                        (8'h41 + {4'd0, value - 4'd10});
        end
    endfunction

    function [3:0] raw_head_nibble;
        input [95:0] raw_head;
        input [4:0]  nibble_index;
        begin
            case (nibble_index)
                5'd0:  raw_head_nibble = raw_head[95:92];
                5'd1:  raw_head_nibble = raw_head[91:88];
                5'd2:  raw_head_nibble = raw_head[87:84];
                5'd3:  raw_head_nibble = raw_head[83:80];
                5'd4:  raw_head_nibble = raw_head[79:76];
                5'd5:  raw_head_nibble = raw_head[75:72];
                5'd6:  raw_head_nibble = raw_head[71:68];
                5'd7:  raw_head_nibble = raw_head[67:64];
                5'd8:  raw_head_nibble = raw_head[63:60];
                5'd9:  raw_head_nibble = raw_head[59:56];
                5'd10: raw_head_nibble = raw_head[55:52];
                5'd11: raw_head_nibble = raw_head[51:48];
                5'd12: raw_head_nibble = raw_head[47:44];
                5'd13: raw_head_nibble = raw_head[43:40];
                5'd14: raw_head_nibble = raw_head[39:36];
                5'd15: raw_head_nibble = raw_head[35:32];
                5'd16: raw_head_nibble = raw_head[31:28];
                5'd17: raw_head_nibble = raw_head[27:24];
                5'd18: raw_head_nibble = raw_head[23:20];
                5'd19: raw_head_nibble = raw_head[19:16];
                5'd20: raw_head_nibble = raw_head[15:12];
                5'd21: raw_head_nibble = raw_head[11:8];
                5'd22: raw_head_nibble = raw_head[7:4];
                default: raw_head_nibble = raw_head[3:0];
            endcase
        end
    endfunction

    function [3:0] arp_count_nibble;
        input [31:0] arp_counts;
        input [2:0]  nibble_index;
        begin
            case (nibble_index)
                3'd0: arp_count_nibble = arp_counts[31:28];
                3'd1: arp_count_nibble = arp_counts[27:24];
                3'd2: arp_count_nibble = arp_counts[23:20];
                3'd3: arp_count_nibble = arp_counts[19:16];
                3'd4: arp_count_nibble = arp_counts[15:12];
                3'd5: arp_count_nibble = arp_counts[11:8];
                3'd6: arp_count_nibble = arp_counts[7:4];
                default: arp_count_nibble = arp_counts[3:0];
            endcase
        end
    endfunction

    function [7:0] msg_byte;
        input [6:0] index;
        input [7:0] raw_count;
        input [7:0] pkt_count;
        input [15:0] last_len;
        input [95:0] raw_head;
        input [95:0] raw_tx_head;
        input [31:0] arp_counts;
        input        phy_reset_n;
        input        pll_locked;
        input [1:0]  link_speed;
        input [7:0]  tx_clk_mon;
        begin
            case (index)
                5'd0:  msg_byte = "E";
                5'd1:  msg_byte = " ";
                5'd2:  msg_byte = "R";
                5'd3:  msg_byte = hex_ascii(raw_count[7:4]);
                5'd4:  msg_byte = hex_ascii(raw_count[3:0]);
                5'd5:  msg_byte = " ";
                5'd6:  msg_byte = "P";
                5'd7:  msg_byte = hex_ascii(pkt_count[7:4]);
                5'd8:  msg_byte = hex_ascii(pkt_count[3:0]);
                5'd9:  msg_byte = " ";
                5'd10: msg_byte = "L";
                5'd11: msg_byte = hex_ascii(last_len[15:12]);
                5'd12: msg_byte = hex_ascii(last_len[11:8]);
                5'd13: msg_byte = hex_ascii(last_len[7:4]);
                5'd14: msg_byte = hex_ascii(last_len[3:0]);
                5'd15: msg_byte = " ";
                5'd16: msg_byte = "H";
                5'd17: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd0));
                5'd18: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd1));
                5'd19: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd2));
                5'd20: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd3));
                5'd21: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd4));
                5'd22: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd5));
                5'd23: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd6));
                5'd24: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd7));
                5'd25: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd8));
                5'd26: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd9));
                5'd27: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd10));
                5'd28: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd11));
                5'd29: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd12));
                5'd30: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd13));
                5'd31: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd14));
                6'd32: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd15));
                6'd33: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd16));
                6'd34: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd17));
                6'd35: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd18));
                6'd36: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd19));
                6'd37: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd20));
                6'd38: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd21));
                6'd39: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd22));
                6'd40: msg_byte = hex_ascii(raw_head_nibble(raw_head, 5'd23));
                6'd41: msg_byte = " ";
                6'd42: msg_byte = "A";
                6'd43: msg_byte = hex_ascii(arp_count_nibble(arp_counts, 3'd0));
                6'd44: msg_byte = hex_ascii(arp_count_nibble(arp_counts, 3'd1));
                6'd45: msg_byte = hex_ascii(arp_count_nibble(arp_counts, 3'd2));
                6'd46: msg_byte = hex_ascii(arp_count_nibble(arp_counts, 3'd3));
                6'd47: msg_byte = hex_ascii(arp_count_nibble(arp_counts, 3'd4));
                6'd48: msg_byte = hex_ascii(arp_count_nibble(arp_counts, 3'd5));
                6'd49: msg_byte = hex_ascii(arp_count_nibble(arp_counts, 3'd6));
                6'd50: msg_byte = hex_ascii(arp_count_nibble(arp_counts, 3'd7));
                6'd51: msg_byte = " ";
                6'd52: msg_byte = "X";
                6'd53: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd0));
                6'd54: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd1));
                6'd55: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd2));
                6'd56: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd3));
                6'd57: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd4));
                6'd58: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd5));
                6'd59: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd6));
                6'd60: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd7));
                6'd61: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd8));
                6'd62: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd9));
                6'd63: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd10));
                7'd64: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd11));
                7'd65: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd12));
                7'd66: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd13));
                7'd67: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd14));
                7'd68: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd15));
                7'd69: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd16));
                7'd70: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd17));
                7'd71: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd18));
                7'd72: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd19));
                7'd73: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd20));
                7'd74: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd21));
                7'd75: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd22));
                7'd76: msg_byte = hex_ascii(raw_head_nibble(raw_tx_head, 5'd23));
                7'd77: msg_byte = " ";
                7'd78: msg_byte = "S";
                7'd79: msg_byte = phy_reset_n ? "1" : "0";
                7'd80: msg_byte = " ";
                7'd81: msg_byte = "V";
                7'd82: msg_byte = hex_ascii({2'd0, link_speed});
                7'd83: msg_byte = " ";
                7'd84: msg_byte = "T";
                7'd85: msg_byte = hex_ascii(tx_clk_mon[7:4]);
                7'd86: msg_byte = hex_ascii(tx_clk_mon[3:0]);
                7'd87: msg_byte = " ";
                7'd88: msg_byte = "K";
                7'd89: msg_byte = pll_locked ? "1" : "0";
                7'd90: msg_byte = 8'h0D;
                7'd91: msg_byte = 8'h0A;
                default: msg_byte = 8'h0A;
            endcase
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            period_cnt_r <= (PERIOD_CYCLES - 1);
            raw_count_seen_r <= 8'd0;
            pkt_count_seen_r <= 8'd0;
            last_len_seen_r  <= 16'd0;
            raw_head_seen_r  <= 96'd0;
            raw_tx_head_seen_r <= 96'd0;
            arp_counts_seen_r <= 32'd0;
            raw_count_cap_r <= 8'd0;
            pkt_count_cap_r <= 8'd0;
            last_len_cap_r  <= 16'd0;
            raw_head_cap_r  <= 96'd0;
            raw_tx_head_cap_r <= 96'd0;
            arp_counts_cap_r <= 32'd0;
            raw_count_r  <= 8'd0;
            pkt_count_r  <= 8'd0;
            last_len_r   <= 16'd0;
            raw_head_r   <= 96'd0;
            raw_tx_head_r <= 96'd0;
            arp_counts_r <= 32'd0;
            phy_reset_n_r <= 1'b0;
            pll_locked_r <= 1'b0;
            link_speed_r  <= 2'd0;
            tx_clk_mon_r  <= 8'd0;
            dirty_r      <= 1'b0;
            pending_r    <= 1'b0;
            index_r      <= 7'd0;
            state_r      <= ST_IDLE;
            uart_data_r  <= 8'd0;
            uart_valid_r <= 1'b0;
        end else begin
            uart_valid_r <= 1'b0;

            if (!period_ready_w) begin
                period_cnt_r <= period_cnt_r + 25'd1;
            end

            if (event_change_w) begin
                raw_count_seen_r  <= raw_count_i;
                pkt_count_seen_r  <= pkt_count_i;
                last_len_seen_r   <= last_len_i;
                raw_head_seen_r   <= raw_head_i;
                raw_tx_head_seen_r <= raw_tx_head_i;
                arp_counts_seen_r <= arp_counts_i;

                raw_count_cap_r  <= raw_count_i;
                pkt_count_cap_r  <= pkt_count_i;
                last_len_cap_r   <= last_len_i;
                raw_head_cap_r   <= raw_head_i;
                raw_tx_head_cap_r <= raw_tx_head_i;
                arp_counts_cap_r <= arp_counts_i;
                dirty_r          <= 1'b1;
            end

            if (!pending_r && period_ready_w && (state_r == ST_IDLE)) begin
                raw_count_r  <= raw_count_i;
                pkt_count_r  <= pkt_count_i;
                last_len_r   <= last_len_i;
                raw_head_r   <= raw_head_i;
                raw_tx_head_r <= raw_tx_head_i;
                arp_counts_r <= arp_counts_i;
                phy_reset_n_r <= phy_reset_n_i;
                pll_locked_r <= pll_locked_i;
                link_speed_r  <= link_speed_i;
                tx_clk_mon_r  <= tx_clk_mon_i;
                pending_r    <= 1'b1;
                dirty_r      <= 1'b0;
                index_r      <= 7'd0;
            end

            case (state_r)
                ST_IDLE: begin
                    if (pending_r && !uart_busy_w) begin
                        uart_data_r  <= msg_byte(index_r, raw_count_r, pkt_count_r, last_len_r,
                                                 raw_head_r, raw_tx_head_r, arp_counts_r, phy_reset_n_r,
                                                 pll_locked_r, link_speed_r, tx_clk_mon_r);
                        uart_valid_r <= 1'b1;
                        state_r      <= ST_BUSY;
                    end
                end
                ST_BUSY: begin
                    if (uart_busy_w)
                        state_r <= ST_WAIT;
                end
                default: begin
                    if (!uart_busy_w) begin
                        if (index_r == MSG_LAST_INDEX) begin
                            pending_r <= 1'b0;
                            index_r   <= 7'd0;
                            period_cnt_r <= 25'd0;
                        end else begin
                            index_r <= index_r + 7'd1;
                        end
                        state_r <= ST_IDLE;
                    end
                end
            endcase
        end
    end

    uart_tx #(
        .CLK_HZ(CLK_HZ),
        .BAUD(BAUD)
    ) u_uart_tx (
        .clk(clk),
        .rst_n(rst_n),
        .data_i(uart_data_r),
        .data_valid_i(uart_valid_r),
        .tx_o(uart_tx_o),
        .busy_o(uart_busy_w)
    );

endmodule
