`timescale 1ns / 1ps

module blue_hand_run_selector #(
    parameter X_WIDTH = 12,
    parameter Y_WIDTH = 12,
    parameter COUNT_W = 24,
    parameter [X_WIDTH:0] MIN_RUN = 13'd20,
    parameter [X_WIDTH:0] MAX_RUN = 13'd280,
    parameter [X_WIDTH:0] MAX_GAP = 13'd0,
    parameter [X_WIDTH:0] TRACK_HALF_WIDTH = 13'd80,
    parameter [Y_WIDTH:0] TRACK_HALF_HEIGHT = 13'd64
) (
    input  wire                  clk,
    input  wire                  rst,
    input  wire                  sof,
    input  wire                  eof,
    input  wire                  pixel_valid,
    input  wire                  pixel_match,
    input  wire [X_WIDTH-1:0]    pixel_x,
    input  wire [Y_WIDTH-1:0]    pixel_y,
    input  wire [X_WIDTH-1:0]    roi_min_x,
    input  wire [X_WIDTH-1:0]    roi_max_x,
    input  wire [Y_WIDTH-1:0]    roi_min_y,
    input  wire [Y_WIDTH-1:0]    roi_max_y,
    output reg                   blob_valid,
    output reg  [X_WIDTH-1:0]    center_x,
    output reg  [Y_WIDTH-1:0]    center_y,
    output reg  [COUNT_W-1:0]    pixel_count,
    output reg  [X_WIDTH-1:0]    min_x,
    output reg  [X_WIDTH-1:0]    max_x,
    output reg  [Y_WIDTH-1:0]    min_y,
    output reg  [Y_WIDTH-1:0]    max_y
);

    localparam [X_WIDTH:0] ONE_X = {{X_WIDTH{1'b0}}, 1'b1};

    reg                    run_active_reg;
    reg [X_WIDTH-1:0]      run_start_x_reg;
    reg [X_WIDTH-1:0]      run_end_x_reg;
    reg [Y_WIDTH-1:0]      run_y_reg;
    reg [X_WIDTH:0]        run_len_reg;
    reg                    best_valid_reg;
    reg [X_WIDTH-1:0]      best_start_x_reg;
    reg [X_WIDTH-1:0]      best_end_x_reg;
    reg [Y_WIDTH-1:0]      best_y_reg;
    reg [X_WIDTH:0]        best_run_len_reg;

    wire run_contiguous_wire;
    wire run_candidate_valid_wire;
    wire run_candidate_better_wire;
    wire emit_use_run_wire;
    wire emit_valid_wire;
    wire [X_WIDTH-1:0] emit_start_x_wire;
    wire [X_WIDTH-1:0] emit_end_x_wire;
    wire [Y_WIDTH-1:0] emit_y_wire;
    wire [X_WIDTH:0] emit_run_len_wire;
    wire [X_WIDTH:0] emit_center_x_sum_wire;
    wire [X_WIDTH-1:0] emit_center_x_wire;
    wire [X_WIDTH:0] emit_center_x_ext_wire;
    wire [X_WIDTH:0] emit_min_x_candidate_wire;
    wire [X_WIDTH:0] emit_max_x_candidate_wire;
    wire [Y_WIDTH:0] emit_y_ext_wire;
    wire [Y_WIDTH:0] emit_min_y_candidate_wire;
    wire [Y_WIDTH:0] emit_max_y_candidate_wire;
    wire [X_WIDTH-1:0] emit_min_x_wire;
    wire [X_WIDTH-1:0] emit_max_x_wire;
    wire [Y_WIDTH-1:0] emit_min_y_wire;
    wire [Y_WIDTH-1:0] emit_max_y_wire;

    // MAX_GAP remains in the interface for project compatibility; this
    // selector intentionally accepts only strictly adjacent blue pixels.
    wire unused_max_gap_wire = |MAX_GAP;

    assign run_contiguous_wire =
        run_active_reg &&
        (pixel_y == run_y_reg) &&
        ({1'b0, pixel_x} == ({1'b0, run_end_x_reg} + ONE_X));
    assign run_candidate_valid_wire =
        run_active_reg &&
        (run_len_reg >= MIN_RUN) &&
        (run_len_reg <= MAX_RUN);
    assign run_candidate_better_wire =
        run_candidate_valid_wire &&
        (!best_valid_reg || (run_len_reg > best_run_len_reg));

    assign emit_use_run_wire = run_candidate_better_wire;
    assign emit_valid_wire = best_valid_reg || run_candidate_valid_wire;
    assign emit_start_x_wire = emit_use_run_wire ? run_start_x_reg : best_start_x_reg;
    assign emit_end_x_wire = emit_use_run_wire ? run_end_x_reg : best_end_x_reg;
    assign emit_y_wire = emit_use_run_wire ? run_y_reg : best_y_reg;
    assign emit_run_len_wire = emit_use_run_wire ? run_len_reg : best_run_len_reg;
    assign emit_center_x_sum_wire =
        {1'b0, emit_start_x_wire} + {1'b0, emit_end_x_wire};
    assign emit_center_x_wire = emit_center_x_sum_wire[X_WIDTH:1];
    assign emit_center_x_ext_wire = {1'b0, emit_center_x_wire};
    assign emit_min_x_candidate_wire =
        (emit_center_x_ext_wire > TRACK_HALF_WIDTH) ?
        (emit_center_x_ext_wire - TRACK_HALF_WIDTH) :
        {(X_WIDTH+1){1'b0}};
    assign emit_max_x_candidate_wire =
        emit_center_x_ext_wire + TRACK_HALF_WIDTH;
    assign emit_y_ext_wire = {1'b0, emit_y_wire};
    assign emit_min_y_candidate_wire =
        (emit_y_ext_wire > TRACK_HALF_HEIGHT) ?
        (emit_y_ext_wire - TRACK_HALF_HEIGHT) :
        {(Y_WIDTH+1){1'b0}};
    assign emit_max_y_candidate_wire = emit_y_ext_wire + TRACK_HALF_HEIGHT;
    assign emit_min_x_wire =
        (emit_min_x_candidate_wire < {1'b0, roi_min_x}) ?
        roi_min_x : emit_min_x_candidate_wire[X_WIDTH-1:0];
    assign emit_max_x_wire =
        (emit_max_x_candidate_wire > {1'b0, roi_max_x}) ?
        roi_max_x : emit_max_x_candidate_wire[X_WIDTH-1:0];
    assign emit_min_y_wire =
        (emit_min_y_candidate_wire < {1'b0, roi_min_y}) ?
        roi_min_y : emit_min_y_candidate_wire[Y_WIDTH-1:0];
    assign emit_max_y_wire =
        (emit_max_y_candidate_wire > {1'b0, roi_max_y}) ?
        roi_max_y : emit_max_y_candidate_wire[Y_WIDTH-1:0];

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            run_active_reg <= 1'b0;
            run_start_x_reg <= {X_WIDTH{1'b0}};
            run_end_x_reg <= {X_WIDTH{1'b0}};
            run_y_reg <= {Y_WIDTH{1'b0}};
            run_len_reg <= {(X_WIDTH+1){1'b0}};
            best_valid_reg <= 1'b0;
            best_start_x_reg <= {X_WIDTH{1'b0}};
            best_end_x_reg <= {X_WIDTH{1'b0}};
            best_y_reg <= {Y_WIDTH{1'b0}};
            best_run_len_reg <= {(X_WIDTH+1){1'b0}};
            blob_valid <= 1'b0;
            center_x <= {X_WIDTH{1'b0}};
            center_y <= {Y_WIDTH{1'b0}};
            pixel_count <= {COUNT_W{1'b0}};
            min_x <= {X_WIDTH{1'b0}};
            max_x <= {X_WIDTH{1'b0}};
            min_y <= {Y_WIDTH{1'b0}};
            max_y <= {Y_WIDTH{1'b0}};
        end else begin
            if (sof && !eof) begin
                run_active_reg <= 1'b0;
                run_len_reg <= {(X_WIDTH+1){1'b0}};
                best_valid_reg <= 1'b0;
                best_run_len_reg <= {(X_WIDTH+1){1'b0}};
            end else if (pixel_valid) begin
                if (pixel_match) begin
                    if (run_contiguous_wire) begin
                        run_end_x_reg <= pixel_x;
                        run_len_reg <= run_len_reg + ONE_X;
                    end else begin
                        if (run_candidate_better_wire) begin
                            best_valid_reg <= 1'b1;
                            best_start_x_reg <= run_start_x_reg;
                            best_end_x_reg <= run_end_x_reg;
                            best_y_reg <= run_y_reg;
                            best_run_len_reg <= run_len_reg;
                        end
                        run_active_reg <= 1'b1;
                        run_start_x_reg <= pixel_x;
                        run_end_x_reg <= pixel_x;
                        run_y_reg <= pixel_y;
                        run_len_reg <= ONE_X;
                    end
                end else begin
                    if (run_candidate_better_wire) begin
                        best_valid_reg <= 1'b1;
                        best_start_x_reg <= run_start_x_reg;
                        best_end_x_reg <= run_end_x_reg;
                        best_y_reg <= run_y_reg;
                        best_run_len_reg <= run_len_reg;
                    end
                    run_active_reg <= 1'b0;
                    run_len_reg <= {(X_WIDTH+1){1'b0}};
                end
            end

            if (eof) begin
                if (emit_valid_wire) begin
                    blob_valid <= 1'b1;
                    center_x <= emit_center_x_wire;
                    center_y <= emit_y_wire;
                    pixel_count <= {{(COUNT_W-X_WIDTH-1){1'b0}}, emit_run_len_wire};
                    min_x <= emit_min_x_wire;
                    max_x <= emit_max_x_wire;
                    min_y <= emit_min_y_wire;
                    max_y <= emit_max_y_wire;
                end else begin
                    blob_valid <= 1'b0;
                    center_x <= {X_WIDTH{1'b0}};
                    center_y <= {Y_WIDTH{1'b0}};
                    pixel_count <= {COUNT_W{1'b0}};
                    min_x <= {X_WIDTH{1'b0}};
                    max_x <= {X_WIDTH{1'b0}};
                    min_y <= {Y_WIDTH{1'b0}};
                    max_y <= {Y_WIDTH{1'b0}};
                end
                run_active_reg <= 1'b0;
                run_len_reg <= {(X_WIDTH+1){1'b0}};
                best_valid_reg <= 1'b0;
                best_run_len_reg <= {(X_WIDTH+1){1'b0}};
            end
        end
    end

endmodule
