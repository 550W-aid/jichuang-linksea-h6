// Selects the algorithm and image source from shared UART frames. A validated
// Ethernet video frame start also selects the Ethernet source automatically.
`timescale 1ns/1ps

module unified_uart_mode_router #(
    parameter integer CLK_FREQ_HZ = 50000000,
    parameter integer UART_BPS = 115200
) (
    input  wire clk,
    input  wire rst_n,
    input  wire uart_rxd,
    input  wire eth_activity_i,
    output reg  [1:0] algorithm_mode_o,
    output reg        ethernet_source_mode_o,
    output reg  [7:0] lowlight_level_o,
    output reg        shader_cfg_toggle_o,
    output reg        fusion_mode_o
);
    localparam [1:0] ALGORITHM_IDLE         = 2'd0;
    localparam [1:0] ALGORITHM_ROTATE       = 2'd1;
    localparam [1:0] ALGORITHM_VIRTUAL_GRAB = 2'd2;
    localparam [1:0] ALGORITHM_SHADER       = 2'd3;

    wire rx_valid_w;
    wire [7:0] rx_data_w;
    wire       lowlight_ascii_valid_w;
    wire [7:0] lowlight_ascii_level_w;
    reg saw_head_r;

    virtual_grab_uart_rx #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ),
        .UART_BPS(UART_BPS)
    ) u_mode_uart_rx (
        .clk(clk),
        .rst_n(rst_n),
        .uart_rxd(uart_rxd),
        .rx_valid(rx_valid_w),
        .rx_data(rx_data_w)
    );

    uart_lowlight_ascii_parser u_lowlight_ascii_parser (
        .clk          (clk),
        .rst_n        (rst_n),
        .rx_valid_i   (rx_valid_w),
        .rx_data_i    (rx_data_w),
        .level_valid_o(lowlight_ascii_valid_w),
        .level_o      (lowlight_ascii_level_w)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            algorithm_mode_o <= ALGORITHM_IDLE;
            ethernet_source_mode_o <= 1'b0;
            lowlight_level_o <= 8'd0;
            shader_cfg_toggle_o <= 1'b0;
            fusion_mode_o <= 1'b0;
            saw_head_r <= 1'b0;
        end else begin
            // Network-only operation must not depend on a second UART cable.
            // The first accepted EV frame switches the shared SDRAM writer;
            // the PC sender repeats still images so the post-switch frame is
            // complete after the mode-change FIFO flush.
            if (eth_activity_i) begin
                ethernet_source_mode_o <= 1'b1;
            end

            if (lowlight_ascii_valid_w) begin
                lowlight_level_o <= lowlight_ascii_level_w;
                algorithm_mode_o <= (lowlight_ascii_level_w == 8'd0) ?
                                    ALGORITHM_IDLE : ALGORITHM_SHADER;
                fusion_mode_o <= 1'b0;
                shader_cfg_toggle_o <= ~shader_cfg_toggle_o;
            end

            if (rx_valid_w) begin
                if (!saw_head_r) begin
                    saw_head_r <= (rx_data_w == 8'h55);
                end else begin
                    saw_head_r <= (rx_data_w == 8'h55);
                    if (rx_data_w == 8'hAA) begin
                        algorithm_mode_o <= ALGORITHM_VIRTUAL_GRAB;
                        fusion_mode_o <= 1'b0;
                        shader_cfg_toggle_o <= ~shader_cfg_toggle_o;
                    end else if (rx_data_w == 8'hA0) begin
                        algorithm_mode_o <= ALGORITHM_IDLE;
                        lowlight_level_o <= 8'd0;
                        fusion_mode_o <= 1'b0;
                        shader_cfg_toggle_o <= ~shader_cfg_toggle_o;
                    end else if (rx_data_w == 8'hAC) begin
                        algorithm_mode_o <= ALGORITHM_SHADER;
                        lowlight_level_o <= 8'hFF;
                        fusion_mode_o <= 1'b0;
                        shader_cfg_toggle_o <= ~shader_cfg_toggle_o;
                    end else if (rx_data_w == 8'hAD) begin
                        // 55 AD selects the direct multi-exposure fusion path.
                        // It shares the shader timing/control transport but
                        // never changes the legacy AC/A0 command meanings.
                        algorithm_mode_o <= ALGORITHM_SHADER;
                        lowlight_level_o <= 8'hFF;
                        fusion_mode_o <= 1'b1;
                        shader_cfg_toggle_o <= ~shader_cfg_toggle_o;
                    end else if ((rx_data_w == 8'h01) ||
                                 (rx_data_w == 8'h02) ||
                                 (rx_data_w == 8'h03)) begin
                        algorithm_mode_o <= ALGORITHM_ROTATE;
                        fusion_mode_o <= 1'b0;
                        shader_cfg_toggle_o <= ~shader_cfg_toggle_o;
                    end else if (rx_data_w == 8'hE0) begin
                        ethernet_source_mode_o <= 1'b0;
                    end else if (rx_data_w == 8'hE1) begin
                        ethernet_source_mode_o <= 1'b1;
                    end
                end
            end
        end
    end

endmodule
