// ============================================================================
// Module Function:
//   ARP + UDP receive-only Ethernet core for PC-to-FPGA video/image streaming.
//   UDP transmit and ICMP echo are intentionally not implemented on this path.
// ============================================================================
module eth_udp_loop(
    input              sys_clk,
    input              sys_rst_n,
    input              eth_rxc,
    input              eth_rx_ctl,
    input      [7:0]   eth_rxd,
    input              eth_txc,
    output             eth_tx_ctl,
    output     [7:0]   eth_txd,
    output             eth_rst_n,
    output             rec_en,
    output     [7:0]   rec_data,
    output     [15:0]  rec_byte_num,
    output             rec_pkt_done,
    output             tx_req,
    output             tx_done,
    input              tx_start_en,
    input     [15:0]   tx_byte_num,
    input     [7:0]    tx_data,
    output             dbg_arp_req_tx,
    output             dbg_arp_tx_en,
    output             dbg_arp_tx_done,
    output     [47:0]  dbg_arp_des_mac,
    output     [31:0]  dbg_arp_des_ip
);

parameter BOARD_MAC = 48'h00_11_22_33_44_55;
parameter BOARD_IP  = {8'd192,8'd168,8'd1,8'd10};
parameter DES_MAC   = 48'hff_ff_ff_ff_ff_ff;
parameter DES_IP    = {8'd192,8'd168,8'd1,8'd255};

wire        gmii_rx_clk;
wire        gmii_rx_dv;
wire [7:0]  gmii_rxd;
wire        gmii_tx_clk;
wire        arp_gmii_tx_en;
wire [7:0]  arp_gmii_txd;
wire        arp_rx_done;
wire        arp_rx_type;
wire [47:0] arp_src_mac;
wire [31:0] arp_src_ip;
wire        arp_tx_done;

reg         gmii_rx_dv_r;
reg  [7:0]  gmii_rxd_r;
reg         arp_req_pending_rx;
reg         arp_req_toggle_rx;
reg  [47:0] arp_src_mac_hold_rx;
reg  [31:0] arp_src_ip_hold_rx;
reg         arp_req_toggle_tx_d0;
reg         arp_req_toggle_tx_d1;
reg         arp_req_toggle_tx_d2;
reg  [47:0] arp_src_mac_tx_d0;
reg  [47:0] arp_src_mac_tx_d1;
reg  [31:0] arp_src_ip_tx_d0;
reg  [31:0] arp_src_ip_tx_d1;
reg         arp_tx_en_r;
reg         arp_reply_pending_tx;
reg         arp_tx_busy_r;
reg  [47:0] arp_des_mac_r;
reg  [31:0] arp_des_ip_r;

wire        arp_req_tx_w = arp_req_toggle_tx_d2 ^ arp_req_toggle_tx_d1;
wire        legacy_tx_inputs_unused = eth_txc | tx_start_en |
                                      (|tx_byte_num) | (|tx_data);

assign gmii_rx_clk     = eth_rxc;
assign gmii_rx_dv      = gmii_rx_dv_r;
assign gmii_rxd        = gmii_rxd_r;
assign gmii_tx_clk     = sys_clk;
assign eth_rst_n       = sys_rst_n;
assign eth_tx_ctl      = arp_gmii_tx_en;
assign eth_txd         = arp_gmii_txd;
assign tx_req          = legacy_tx_inputs_unused & 1'b0;
assign tx_done         = 1'b0;
assign dbg_arp_req_tx  = arp_req_tx_w;
assign dbg_arp_tx_en   = arp_tx_en_r;
assign dbg_arp_tx_done = arp_tx_done;
assign dbg_arp_des_mac = arp_des_mac_r;
assign dbg_arp_des_ip  = arp_des_ip_r;

always @(posedge gmii_rx_clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
        gmii_rx_dv_r <= 1'b0;
        gmii_rxd_r   <= 8'd0;
    end
    else begin
        gmii_rx_dv_r <= eth_rx_ctl;
        gmii_rxd_r   <= eth_rxd;
    end
end

always @(posedge gmii_rx_clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
        arp_req_pending_rx <= 1'b0;
        arp_req_toggle_rx   <= 1'b0;
        arp_src_mac_hold_rx <= 48'd0;
        arp_src_ip_hold_rx  <= 32'd0;
    end
    else if(arp_req_pending_rx) begin
        arp_req_toggle_rx   <= ~arp_req_toggle_rx;
        arp_req_pending_rx  <= 1'b0;
    end
    else if(arp_rx_done && (arp_rx_type == 1'b0)) begin
        arp_src_mac_hold_rx <= arp_src_mac;
        arp_src_ip_hold_rx  <= arp_src_ip;
        arp_req_pending_rx  <= 1'b1;
    end
end

always @(posedge gmii_tx_clk or negedge sys_rst_n) begin
    if(!sys_rst_n) begin
        arp_req_toggle_tx_d0 <= 1'b0;
        arp_req_toggle_tx_d1 <= 1'b0;
        arp_req_toggle_tx_d2 <= 1'b0;
        arp_src_mac_tx_d0    <= 48'd0;
        arp_src_mac_tx_d1    <= 48'd0;
        arp_src_ip_tx_d0     <= 32'd0;
        arp_src_ip_tx_d1     <= 32'd0;
        arp_tx_en_r          <= 1'b0;
        arp_reply_pending_tx <= 1'b0;
        arp_tx_busy_r        <= 1'b0;
        arp_des_mac_r        <= DES_MAC;
        arp_des_ip_r         <= DES_IP;
    end
    else begin
        arp_req_toggle_tx_d0 <= arp_req_toggle_rx;
        arp_req_toggle_tx_d1 <= arp_req_toggle_tx_d0;
        arp_req_toggle_tx_d2 <= arp_req_toggle_tx_d1;
        arp_src_mac_tx_d0    <= arp_src_mac_hold_rx;
        arp_src_mac_tx_d1    <= arp_src_mac_tx_d0;
        arp_src_ip_tx_d0     <= arp_src_ip_hold_rx;
        arp_src_ip_tx_d1     <= arp_src_ip_tx_d0;

        arp_tx_en_r <= 1'b0;
        if(arp_tx_done) begin
            arp_tx_busy_r <= 1'b0;
        end

        if(arp_req_tx_w) begin
            arp_des_mac_r        <= arp_src_mac_tx_d1;
            arp_des_ip_r         <= arp_src_ip_tx_d1;
            arp_reply_pending_tx <= 1'b1;
        end

        if(arp_reply_pending_tx && !arp_tx_busy_r) begin
            arp_tx_en_r          <= 1'b1;
            arp_reply_pending_tx <= 1'b0;
            arp_tx_busy_r        <= 1'b1;
        end
    end
end

arp #(
    .BOARD_MAC(BOARD_MAC),
    .BOARD_IP (BOARD_IP ),
    .DES_MAC  (DES_MAC  ),
    .DES_IP   (DES_IP   )
) u_arp(
    .rst_n      (sys_rst_n),
    .gmii_rx_clk(gmii_rx_clk),
    .gmii_rx_dv (gmii_rx_dv),
    .gmii_rxd   (gmii_rxd),
    .gmii_tx_clk(gmii_tx_clk),
    .gmii_tx_en (arp_gmii_tx_en),
    .gmii_txd   (arp_gmii_txd),
    .arp_rx_done(arp_rx_done),
    .arp_rx_type(arp_rx_type),
    .src_mac    (arp_src_mac),
    .src_ip     (arp_src_ip),
    .arp_tx_en  (arp_tx_en_r),
    .arp_tx_type(1'b1),
    .des_mac    (arp_des_mac_r),
    .des_ip     (arp_des_ip_r),
    .tx_done    (arp_tx_done)
);

udp_rx #(
    .BOARD_MAC(BOARD_MAC),
    .BOARD_IP (BOARD_IP )
) u_udp_rx(
    .clk          (gmii_rx_clk),
    .rst_n        (sys_rst_n),
    .gmii_rx_dv   (gmii_rx_dv),
    .gmii_rxd     (gmii_rxd),
    .rec_pkt_done (rec_pkt_done),
    .rec_en       (rec_en),
    .rec_data     (rec_data),
    .rec_byte_num (rec_byte_num)
);

endmodule
