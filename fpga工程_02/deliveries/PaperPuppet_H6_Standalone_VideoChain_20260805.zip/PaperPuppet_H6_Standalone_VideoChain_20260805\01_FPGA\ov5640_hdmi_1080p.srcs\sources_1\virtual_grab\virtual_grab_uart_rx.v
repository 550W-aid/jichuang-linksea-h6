`timescale 1ns / 1ps

module virtual_grab_uart_rx #(
    parameter integer CLK_FREQ_HZ = 50000000,
    parameter integer UART_BPS    = 115200
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       uart_rxd,
    output reg        rx_valid,
    output reg [7:0]  rx_data
);

    localparam integer CLKS_PER_BIT = CLK_FREQ_HZ / UART_BPS;

    localparam [2:0] RX_IDLE  = 3'd0;
    localparam [2:0] RX_START = 3'd1;
    localparam [2:0] RX_DATA  = 3'd2;
    localparam [2:0] RX_STOP  = 3'd3;

    reg uart_rx_meta_reg;
    reg uart_rx_sync_reg;
    reg [2:0] state_reg;
    reg [15:0] clk_count_reg;
    reg [2:0] bit_index_reg;
    reg [7:0] data_shift_reg;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            uart_rx_meta_reg <= 1'b1;
            uart_rx_sync_reg <= 1'b1;
        end else begin
            uart_rx_meta_reg <= uart_rxd;
            uart_rx_sync_reg <= uart_rx_meta_reg;
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_reg      <= RX_IDLE;
            clk_count_reg  <= 16'd0;
            bit_index_reg  <= 3'd0;
            data_shift_reg <= 8'h00;
            rx_valid       <= 1'b0;
            rx_data        <= 8'h00;
        end else begin
            rx_valid <= 1'b0;

            case (state_reg)
                RX_IDLE: begin
                    clk_count_reg <= 16'd0;
                    bit_index_reg <= 3'd0;

                    if (!uart_rx_sync_reg) begin
                        state_reg <= RX_START;
                    end
                end

                RX_START: begin
                    if (clk_count_reg == (CLKS_PER_BIT / 2)) begin
                        if (!uart_rx_sync_reg) begin
                            clk_count_reg <= 16'd0;
                            state_reg <= RX_DATA;
                        end else begin
                            state_reg <= RX_IDLE;
                        end
                    end else begin
                        clk_count_reg <= clk_count_reg + 16'd1;
                    end
                end

                RX_DATA: begin
                    if (clk_count_reg == CLKS_PER_BIT - 1) begin
                        clk_count_reg <= 16'd0;
                        data_shift_reg[bit_index_reg] <= uart_rx_sync_reg;

                        if (bit_index_reg == 3'd7) begin
                            bit_index_reg <= 3'd0;
                            state_reg <= RX_STOP;
                        end else begin
                            bit_index_reg <= bit_index_reg + 3'd1;
                        end
                    end else begin
                        clk_count_reg <= clk_count_reg + 16'd1;
                    end
                end

                RX_STOP: begin
                    if (clk_count_reg == CLKS_PER_BIT - 1) begin
                        clk_count_reg <= 16'd0;
                        state_reg <= RX_IDLE;

                        if (uart_rx_sync_reg) begin
                            rx_data <= data_shift_reg;
                            rx_valid <= 1'b1;
                        end
                    end else begin
                        clk_count_reg <= clk_count_reg + 16'd1;
                    end
                end

                default: begin
                    state_reg <= RX_IDLE;
                    clk_count_reg <= 16'd0;
                    bit_index_reg <= 3'd0;
                end
            endcase
        end
    end

endmodule
