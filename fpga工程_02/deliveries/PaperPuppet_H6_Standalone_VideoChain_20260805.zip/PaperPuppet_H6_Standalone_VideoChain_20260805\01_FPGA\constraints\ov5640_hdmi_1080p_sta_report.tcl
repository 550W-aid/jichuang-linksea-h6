load_package report

create_timing_netlist
read_sdc
update_timing_netlist

report_clocks
report_timing -setup -npaths 20
report_timing -hold -npaths 20