// ============================================================================
// Module Function:
//   Capture mapping for the routed 480x270 RGB454 even/odd-column banks.
//   Preview sampling address mapper used to downsample source pixels into the rotate BRAM banks.
// ============================================================================
`timescale 1ns / 1ps

module rotate_preview_capture_map_720p #(
    parameter integer SRC_FRAME_W = 1280,
    parameter integer SRC_FRAME_H = 720,
    parameter integer PREVIEW_W   = 256,
    parameter integer PREVIEW_H   = 144
) (
    input  wire [10:0] src_x_i,
    input  wire [10:0] src_y_i,
    input  wire        src_valid_i,
    output wire        take_o,
    output wire        bank_o,
    output wire [16:0] addr_o
);

    // Spread neighboring columns across the banks instead of splitting the
    // preview into left and right halves.
    localparam integer BANK_STRIDE =
        (PREVIEW_W > 256) ? ((PREVIEW_W + 1) / 2) : PREVIEW_W;

    wire [9:0] preview_x_w;
    wire [8:0] preview_y_w;
    wire [9:0] bank_x_w;
    wire       take_x_w;
    wire       take_y_w;
    wire [16:0] row_addr_w;

    function [9:0] preview_x_map_fn;
        input [10:0] src_x;
        reg [12:0] scaled_r;
        begin
            if ((SRC_FRAME_W == 1920) && (PREVIEW_W == 256)) begin
                preview_x_map_fn = src_x[10:3];
            end else if ((SRC_FRAME_W == 1280) && (PREVIEW_W == 480)) begin
                scaled_r = ({2'd0, src_x} << 1) + {2'd0, src_x};
                preview_x_map_fn = scaled_r[11:3];
            end else if ((SRC_FRAME_W == 1280) && (PREVIEW_W == 640)) begin
                preview_x_map_fn = src_x[10:1];
            end else if ((SRC_FRAME_W == 1280) && (PREVIEW_W == 512)) begin
                scaled_r = {src_x, 1'b0};
                preview_x_map_fn = scaled_r / 13'd5;
            end else begin
                preview_x_map_fn = {1'b0, src_x[10:2]};
            end
        end
    endfunction

    function [8:0] preview_y_map_fn;
        input [10:0] src_y;
        reg [12:0] scaled_r;
        begin
            if ((SRC_FRAME_H == 1080) && (PREVIEW_H == 144)) begin
                preview_y_map_fn = src_y[10:3];
            end else if ((SRC_FRAME_H == 720) && (PREVIEW_H == 270)) begin
                scaled_r = ({2'd0, src_y} << 1) + {2'd0, src_y};
                preview_y_map_fn = scaled_r[11:3];
            end else if ((SRC_FRAME_H == 720) && (PREVIEW_H == 360)) begin
                preview_y_map_fn = src_y[9:1];
            end else if ((SRC_FRAME_H == 720) && (PREVIEW_H == 288)) begin
                scaled_r = {src_y, 1'b0};
                preview_y_map_fn = scaled_r / 13'd5;
            end else begin
                preview_y_map_fn = {1'b0, src_y[9:2]};
            end
        end
    endfunction

    function take_x_fn;
        input [10:0] src_x;
        begin
            if ((SRC_FRAME_W == 1920) && (PREVIEW_W == 256)) begin
                take_x_fn = (src_x[2:0] == 3'd4);
            end else if ((SRC_FRAME_W == 1280) && (PREVIEW_W == 480)) begin
                take_x_fn = (src_x[2:0] == 3'd2) ||
                            (src_x[2:0] == 3'd5) ||
                            (src_x[2:0] == 3'd7);
            end else if ((SRC_FRAME_W == 1280) && (PREVIEW_W == 640)) begin
                take_x_fn = ~src_x[0];
            end else if ((SRC_FRAME_W == 1280) && (PREVIEW_W == 512)) begin
                take_x_fn = ((src_x % 5) == 11'd2) ||
                            ((src_x % 5) == 11'd4);
            end else begin
                take_x_fn = (src_x[1:0] == 2'b00);
            end
        end
    endfunction

    function take_y_fn;
        input [10:0] src_y;
        begin
            if ((SRC_FRAME_H == 1080) && (PREVIEW_H == 144)) begin
                take_y_fn = (src_y[2:0] == 3'd4);
            end else if ((SRC_FRAME_H == 720) && (PREVIEW_H == 270)) begin
                take_y_fn = (src_y[2:0] == 3'd2) ||
                            (src_y[2:0] == 3'd5) ||
                            (src_y[2:0] == 3'd7);
            end else if ((SRC_FRAME_H == 720) && (PREVIEW_H == 360)) begin
                take_y_fn = ~src_y[0];
            end else if ((SRC_FRAME_H == 720) && (PREVIEW_H == 288)) begin
                take_y_fn = ((src_y % 5) == 11'd2) ||
                            ((src_y % 5) == 11'd4);
            end else begin
                take_y_fn = (src_y[1:0] == 2'b00);
            end
        end
    endfunction

    assign preview_x_w = preview_x_map_fn(src_x_i);
    assign preview_y_w = preview_y_map_fn(src_y_i);
    assign bank_x_w    = (PREVIEW_W > 256) ? {1'b0, preview_x_w[9:1]} : preview_x_w;
    assign take_x_w    = take_x_fn(src_x_i);
    assign take_y_w    = take_y_fn(src_y_i);
    assign row_addr_w  = (BANK_STRIDE == 256) ?
                         ({8'd0, preview_y_w} << 8) :
                         ({8'd0, preview_y_w} * BANK_STRIDE);

    assign take_o = src_valid_i &&
                    (src_x_i < SRC_FRAME_W[10:0]) &&
                    (src_y_i < SRC_FRAME_H[10:0]) &&
                    take_x_w &&
                    take_y_w;

    assign bank_o = (PREVIEW_W > 256) ? preview_x_w[0] : 1'b0;
    assign addr_o = row_addr_w + {7'd0, bank_x_w};

endmodule
