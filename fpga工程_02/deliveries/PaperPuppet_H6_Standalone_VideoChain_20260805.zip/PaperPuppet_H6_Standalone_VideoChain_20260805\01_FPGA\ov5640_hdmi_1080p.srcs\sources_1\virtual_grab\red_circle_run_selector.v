`timescale 1ns / 1ps

module red_circle_run_selector #(
    parameter X_WIDTH      = 12,
    parameter Y_WIDTH      = 12,
    parameter COUNT_W      = 24,
    parameter [X_WIDTH:0] MIN_RUN      = 13'd3,
    parameter [X_WIDTH:0] MAX_RUN      = 13'd190,
    parameter MIN_ROWS     = 12,
    parameter [COUNT_W-1:0] MIN_PIXELS = 24'd500,
    parameter [X_WIDTH:0] MIN_WIDTH    = 13'd20,
    parameter [X_WIDTH:0] MAX_WIDTH    = 13'd220,
    parameter [Y_WIDTH:0] MIN_HEIGHT   = 13'd20,
    parameter [Y_WIDTH:0] MAX_HEIGHT   = 13'd150,
    parameter EXPIRE_WIDTH = 280,
    parameter EXPIRE_HEIGHT = 155,
    parameter CENTER_TOL   = 80,
    parameter X_MERGE_MARGIN = 50,
    parameter [X_WIDTH:0] MAX_GAP      = 13'd5
) (
    input  wire                  clk,
    input  wire                  rst,
    input  wire                  sof,
    input  wire                  eof,
    input  wire                  pixel_valid,
    input  wire                  pixel_match,
    input  wire [X_WIDTH-1:0]    pixel_x,
    input  wire [Y_WIDTH-1:0]    pixel_y,
    input  wire                  green_valid,
    input  wire [X_WIDTH-1:0]    green_x,
    output reg                   blob_valid,
    output reg [X_WIDTH-1:0]     center_x,
    output reg [Y_WIDTH-1:0]     center_y,
    output reg [COUNT_W-1:0]     pixel_count,
    output reg [X_WIDTH-1:0]     min_x,
    output reg [X_WIDTH-1:0]     max_x,
    output reg [Y_WIDTH-1:0]     min_y,
    output reg [Y_WIDTH-1:0]     max_y
);

    localparam [X_WIDTH:0] MIN_RUN_W = MIN_RUN;
    localparam [X_WIDTH:0] MAX_RUN_W = MAX_RUN;
    localparam [X_WIDTH:0] MAX_GAP_W = MAX_GAP;
    localparam [COUNT_W-1:0] MIN_PIXELS_W = MIN_PIXELS;
    localparam [X_WIDTH:0] MIN_WIDTH_W = MIN_WIDTH;
    localparam [X_WIDTH:0] MAX_WIDTH_W = MAX_WIDTH;
    localparam [Y_WIDTH:0] MIN_HEIGHT_W = MIN_HEIGHT;
    localparam [Y_WIDTH:0] MAX_HEIGHT_W = MAX_HEIGHT;

    reg line_active_reg;
    reg [Y_WIDTH-1:0] line_y_reg;
    reg run_active_reg;
    reg [X_WIDTH-1:0] run_start_x_reg;
    reg [X_WIDTH-1:0] run_end_x_reg;
    reg [X_WIDTH:0] run_len_reg;
    reg [X_WIDTH:0] run_hit_count_reg;
    reg [X_WIDTH:0] gap_count_reg;

    reg best_valid_reg;
    reg [X_WIDTH-1:0] best_start_x_reg;
    reg [X_WIDTH-1:0] best_end_x_reg;
    reg [Y_WIDTH-1:0] best_y_reg;
    reg [X_WIDTH:0] best_run_len_reg;
    reg [X_WIDTH:0] best_hit_count_reg;
    reg [COUNT_W-1:0] match_count_reg;
    reg [X_WIDTH-1:0] match_min_x_reg;
    reg [X_WIDTH-1:0] match_max_x_reg;
    reg [Y_WIDTH-1:0] match_min_y_reg;
    reg [Y_WIDTH-1:0] match_max_y_reg;

    wire line_boundary_wire = pixel_valid && line_active_reg && (pixel_y != line_y_reg);
    wire [X_WIDTH:0] one_x_wire = {{X_WIDTH{1'b0}}, 1'b1};
    wire add_match_wire = pixel_valid && pixel_match;
    wire [COUNT_W-1:0] next_match_count_wire =
        match_count_reg + {{(COUNT_W-1){1'b0}}, add_match_wire};
    wire [X_WIDTH-1:0] next_match_min_x_wire =
        !add_match_wire ? match_min_x_reg :
        (match_count_reg == {COUNT_W{1'b0}}) ? pixel_x :
        ((pixel_x < match_min_x_reg) ? pixel_x : match_min_x_reg);
    wire [X_WIDTH-1:0] next_match_max_x_wire =
        !add_match_wire ? match_max_x_reg :
        (match_count_reg == {COUNT_W{1'b0}}) ? pixel_x :
        ((pixel_x > match_max_x_reg) ? pixel_x : match_max_x_reg);
    wire [Y_WIDTH-1:0] next_match_min_y_wire =
        !add_match_wire ? match_min_y_reg :
        (match_count_reg == {COUNT_W{1'b0}}) ? pixel_y :
        ((pixel_y < match_min_y_reg) ? pixel_y : match_min_y_reg);
    wire [Y_WIDTH-1:0] next_match_max_y_wire =
        !add_match_wire ? match_max_y_reg :
        (match_count_reg == {COUNT_W{1'b0}}) ? pixel_y :
        ((pixel_y > match_max_y_reg) ? pixel_y : match_max_y_reg);
    wire [X_WIDTH:0] fallback_width_wire =
        {1'b0, match_max_x_reg} - {1'b0, match_min_x_reg} + one_x_wire;
    wire [Y_WIDTH:0] fallback_height_wire =
        {1'b0, match_max_y_reg} - {1'b0, match_min_y_reg} + {{Y_WIDTH{1'b0}}, 1'b1};
    wire [X_WIDTH:0] fallback_center_x_sum_wire =
        {1'b0, match_min_x_reg} + {1'b0, match_max_x_reg};
    wire [Y_WIDTH:0] fallback_center_y_sum_wire =
        {1'b0, match_min_y_reg} + {1'b0, match_max_y_reg};
    wire [X_WIDTH+2:0] fallback_width_x4_wire = {2'b00, fallback_width_wire} << 2;
    wire [Y_WIDTH+2:0] fallback_height_x4_wire = {2'b00, fallback_height_wire} << 2;
    wire fallback_valid_wire =
        (match_count_reg >= MIN_PIXELS_W) &&
        (fallback_width_wire >= MIN_WIDTH_W) &&
        (fallback_width_wire <= MAX_WIDTH_W) &&
        (fallback_height_wire >= MIN_HEIGHT_W) &&
        (fallback_height_wire <= MAX_HEIGHT_W) &&
        ({2'b00, fallback_width_wire} <= fallback_height_x4_wire) &&
        ({2'b00, fallback_height_wire} <= fallback_width_x4_wire);
    wire [X_WIDTH:0] matched_run_len_wire =
        {1'b0, pixel_x} - {1'b0, run_start_x_reg} + one_x_wire;
    wire run_hit_candidate_valid_wire =
        (run_hit_count_reg >= MIN_RUN_W) &&
        ((run_hit_count_reg + run_hit_count_reg) >= run_len_reg);
    wire run_candidate_valid_wire =
        run_active_reg &&
        (run_len_reg >= MIN_RUN_W) &&
        (run_len_reg <= MAX_RUN_W) &&
        run_hit_candidate_valid_wire;
    wire run_candidate_better_wire =
        run_candidate_valid_wire &&
        (!best_valid_reg ||
         (run_len_reg > best_run_len_reg) ||
         ((run_len_reg == best_run_len_reg) && (run_hit_count_reg > best_hit_count_reg)));

    wire emit_use_run_wire = run_candidate_better_wire;
    wire emit_valid_wire = best_valid_reg || run_candidate_valid_wire;
    wire [X_WIDTH-1:0] emit_start_x_wire =
        emit_use_run_wire ? run_start_x_reg : best_start_x_reg;
    wire [X_WIDTH-1:0] emit_end_x_wire =
        emit_use_run_wire ? run_end_x_reg : best_end_x_reg;
    wire [Y_WIDTH-1:0] emit_y_wire =
        emit_use_run_wire ? line_y_reg : best_y_reg;
    wire [X_WIDTH:0] emit_run_len_wire =
        emit_use_run_wire ? run_len_reg : best_run_len_reg;

    wire [X_WIDTH:0] emit_center_x_sum_wire =
        {1'b0, emit_start_x_wire} + {1'b0, emit_end_x_wire};
    wire [Y_WIDTH:0] emit_half_height_wire =
        {1'b0, emit_run_len_wire[Y_WIDTH:1]};
    wire [Y_WIDTH:0] emit_y_ext_wire = {1'b0, emit_y_wire};
    wire [Y_WIDTH:0] emit_min_y_wire =
        (emit_y_ext_wire > emit_half_height_wire) ?
        (emit_y_ext_wire - emit_half_height_wire) :
        {(Y_WIDTH+1){1'b0}};
    wire [Y_WIDTH:0] emit_max_y_wire = emit_y_ext_wire + emit_half_height_wire;
    wire [Y_WIDTH-1:0] emit_max_y_sat_wire =
        emit_max_y_wire[Y_WIDTH] ? {Y_WIDTH{1'b1}} : emit_max_y_wire[Y_WIDTH-1:0];

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            line_active_reg <= 1'b0;
            line_y_reg <= {Y_WIDTH{1'b0}};
            run_active_reg <= 1'b0;
            run_start_x_reg <= {X_WIDTH{1'b0}};
            run_end_x_reg <= {X_WIDTH{1'b0}};
            run_len_reg <= {(X_WIDTH+1){1'b0}};
            run_hit_count_reg <= {(X_WIDTH+1){1'b0}};
            gap_count_reg <= {(X_WIDTH+1){1'b0}};
            best_valid_reg <= 1'b0;
            best_start_x_reg <= {X_WIDTH{1'b0}};
            best_end_x_reg <= {X_WIDTH{1'b0}};
            best_y_reg <= {Y_WIDTH{1'b0}};
            best_run_len_reg <= {(X_WIDTH+1){1'b0}};
            best_hit_count_reg <= {(X_WIDTH+1){1'b0}};
            match_count_reg <= {COUNT_W{1'b0}};
            match_min_x_reg <= {X_WIDTH{1'b1}};
            match_max_x_reg <= {X_WIDTH{1'b0}};
            match_min_y_reg <= {Y_WIDTH{1'b1}};
            match_max_y_reg <= {Y_WIDTH{1'b0}};
            blob_valid <= 1'b0;
            center_x <= {X_WIDTH{1'b0}};
            center_y <= {Y_WIDTH{1'b0}};
            pixel_count <= {COUNT_W{1'b0}};
            min_x <= {X_WIDTH{1'b0}};
            max_x <= {X_WIDTH{1'b0}};
            min_y <= {Y_WIDTH{1'b0}};
            max_y <= {Y_WIDTH{1'b0}};
        end else begin
            if (sof && !eof) begin
                line_active_reg <= 1'b0;
                run_active_reg <= 1'b0;
                run_len_reg <= {(X_WIDTH+1){1'b0}};
                run_hit_count_reg <= {(X_WIDTH+1){1'b0}};
                gap_count_reg <= {(X_WIDTH+1){1'b0}};
                best_valid_reg <= 1'b0;
                best_run_len_reg <= {(X_WIDTH+1){1'b0}};
                best_hit_count_reg <= {(X_WIDTH+1){1'b0}};
                match_count_reg <= {COUNT_W{1'b0}};
                match_min_x_reg <= {X_WIDTH{1'b1}};
                match_max_x_reg <= {X_WIDTH{1'b0}};
                match_min_y_reg <= {Y_WIDTH{1'b1}};
                match_max_y_reg <= {Y_WIDTH{1'b0}};
            end else begin
                if (pixel_valid) begin
                    if (pixel_match) begin
                        match_count_reg <= next_match_count_wire;
                        match_min_x_reg <= next_match_min_x_wire;
                        match_max_x_reg <= next_match_max_x_wire;
                        match_min_y_reg <= next_match_min_y_wire;
                        match_max_y_reg <= next_match_max_y_wire;
                    end

                    if (line_boundary_wire) begin
                        if (run_candidate_better_wire) begin
                            best_valid_reg <= 1'b1;
                            best_start_x_reg <= run_start_x_reg;
                            best_end_x_reg <= run_end_x_reg;
                            best_y_reg <= line_y_reg;
                            best_run_len_reg <= run_len_reg;
                            best_hit_count_reg <= run_hit_count_reg;
                        end
                        line_active_reg <= 1'b1;
                        line_y_reg <= pixel_y;
                        if (pixel_match) begin
                            run_active_reg <= 1'b1;
                            run_start_x_reg <= pixel_x;
                            run_end_x_reg <= pixel_x;
                            run_len_reg <= one_x_wire;
                            run_hit_count_reg <= one_x_wire;
                            gap_count_reg <= {(X_WIDTH+1){1'b0}};
                        end else begin
                            run_active_reg <= 1'b0;
                            run_len_reg <= {(X_WIDTH+1){1'b0}};
                            run_hit_count_reg <= {(X_WIDTH+1){1'b0}};
                            gap_count_reg <= {(X_WIDTH+1){1'b0}};
                        end
                    end else begin
                        if (!line_active_reg) begin
                            line_active_reg <= 1'b1;
                            line_y_reg <= pixel_y;
                        end
                        if (pixel_match) begin
                            if (!run_active_reg) begin
                                run_active_reg <= 1'b1;
                                run_start_x_reg <= pixel_x;
                                run_end_x_reg <= pixel_x;
                                run_len_reg <= one_x_wire;
                                run_hit_count_reg <= one_x_wire;
                                gap_count_reg <= {(X_WIDTH+1){1'b0}};
                            end else begin
                                run_end_x_reg <= pixel_x;
                                run_len_reg <= matched_run_len_wire;
                                run_hit_count_reg <= run_hit_count_reg + one_x_wire;
                                gap_count_reg <= {(X_WIDTH+1){1'b0}};
                            end
                        end else begin
                            if (run_active_reg && (gap_count_reg < MAX_GAP_W)) begin
                                gap_count_reg <= gap_count_reg + one_x_wire;
                            end else begin
                                if (run_candidate_better_wire) begin
                                    best_valid_reg <= 1'b1;
                                    best_start_x_reg <= run_start_x_reg;
                                    best_end_x_reg <= run_end_x_reg;
                                    best_y_reg <= line_y_reg;
                                    best_run_len_reg <= run_len_reg;
                                    best_hit_count_reg <= run_hit_count_reg;
                                end
                                run_active_reg <= 1'b0;
                                run_len_reg <= {(X_WIDTH+1){1'b0}};
                                run_hit_count_reg <= {(X_WIDTH+1){1'b0}};
                                gap_count_reg <= {(X_WIDTH+1){1'b0}};
                            end
                        end
                    end
                end

                if (eof) begin
                    run_active_reg <= 1'b0;
                    line_active_reg <= 1'b0;
                    run_len_reg <= {(X_WIDTH+1){1'b0}};
                    run_hit_count_reg <= {(X_WIDTH+1){1'b0}};
                    gap_count_reg <= {(X_WIDTH+1){1'b0}};
                    best_valid_reg <= 1'b0;
                    best_start_x_reg <= {X_WIDTH{1'b0}};
                    best_end_x_reg <= {X_WIDTH{1'b0}};
                    best_y_reg <= {Y_WIDTH{1'b0}};
                    best_run_len_reg <= {(X_WIDTH+1){1'b0}};
                    best_hit_count_reg <= {(X_WIDTH+1){1'b0}};
                    match_count_reg <= {COUNT_W{1'b0}};
                    match_min_x_reg <= {X_WIDTH{1'b1}};
                    match_max_x_reg <= {X_WIDTH{1'b0}};
                    match_min_y_reg <= {Y_WIDTH{1'b1}};
                    match_max_y_reg <= {Y_WIDTH{1'b0}};
                    if (emit_valid_wire) begin
                        blob_valid <= 1'b1;
                        center_x <= emit_center_x_sum_wire[X_WIDTH:1];
                        center_y <= emit_y_wire;
                        pixel_count <= {{(COUNT_W-X_WIDTH-1){1'b0}}, emit_run_len_wire};
                        min_x <= emit_start_x_wire;
                        max_x <= emit_end_x_wire;
                        min_y <= emit_min_y_wire[Y_WIDTH-1:0];
                        max_y <= emit_max_y_sat_wire;
                    end else if (fallback_valid_wire) begin
                        blob_valid <= 1'b1;
                        center_x <= fallback_center_x_sum_wire[X_WIDTH:1];
                        center_y <= fallback_center_y_sum_wire[Y_WIDTH:1];
                        pixel_count <= match_count_reg;
                        min_x <= match_min_x_reg;
                        max_x <= match_max_x_reg;
                        min_y <= match_min_y_reg;
                        max_y <= match_max_y_reg;
                    end else begin
                        blob_valid <= 1'b0;
                        center_x <= {X_WIDTH{1'b0}};
                        center_y <= {Y_WIDTH{1'b0}};
                        pixel_count <= {COUNT_W{1'b0}};
                        min_x <= {X_WIDTH{1'b0}};
                        max_x <= {X_WIDTH{1'b0}};
                        min_y <= {Y_WIDTH{1'b0}};
                        max_y <= {Y_WIDTH{1'b0}};
                    end
                end
            end
        end
    end

endmodule
