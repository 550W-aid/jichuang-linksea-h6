#!/usr/bin/env python3
"""Stream RGB888 video frames to the FPGA.

The default path uses the Windows UDP stack, which is much faster than sending
every Ethernet frame through Scapy.  A Scapy L2 mode is still available as a
fixed-MAC fallback when ARP or routing is not behaving.
"""

import argparse
import os
import socket
import struct
import subprocess
import sys
import time

from scapy.all import ARP, Ether, conf, get_if_addr, get_if_hwaddr, srp


WIDTH = 1280
HEIGHT = 720
HALF_WIDTH = WIDTH // 2
CHUNK_PIXELS = 320
CHUNKS_PER_HALF = HALF_WIDTH // CHUNK_PIXELS
CHUNKS_PER_LINE = WIDTH // CHUNK_PIXELS
CODEC_RGB888_LITERAL = 1
CODEC_RGB888_H2_LINE = 2
CODEC_RGB888_H2_CHUNK = 3
FRAME_BYTES = WIDTH * HEIGHT * 3
VIDEO_EXTS = (".mp4", ".mov", ".avi", ".mkv")


def wait_until(deadline):
    """High-resolution pacing for sub-millisecond packet spacing on Windows."""
    while True:
        remaining = deadline - time.perf_counter()
        if remaining <= 0:
            return
        if remaining > 0.002:
            time.sleep(remaining - 0.001)
        elif remaining > 0.00025:
            time.sleep(0)


def packets_per_frame(codec):
    if codec == "h2":
        return HEIGHT * 2
    return HEIGHT * 2 * CHUNKS_PER_HALF


def mac_bytes(text):
    return bytes(int(part, 16) for part in text.replace("-", ":").split(":"))


def ip_bytes(text):
    return bytes(int(part, 10) for part in text.split("."))


def checksum16(data):
    if len(data) & 1:
        data += b"\x00"
    total = 0
    for idx in range(0, len(data), 2):
        total += (data[idx] << 8) | data[idx + 1]
        total = (total & 0xFFFF) + (total >> 16)
    return (~total) & 0xFFFF


def pick_video(video_dir):
    candidates = []
    for name in os.listdir(video_dir):
        path = os.path.join(video_dir, name)
        if os.path.isfile(path) and name.lower().endswith(VIDEO_EXTS):
            candidates.append(path)
    if not candidates:
        raise FileNotFoundError(f"no video found in {video_dir}")
    candidates.sort(key=lambda p: (os.path.getmtime(p), p), reverse=True)
    return candidates[0]


def find_iface_by_ip(ip_addr):
    for iface in conf.ifaces.values():
        try:
            if get_if_addr(iface.name) == ip_addr:
                return iface
        except Exception:
            pass
    raise RuntimeError(f"no Scapy/Npcap interface has IP {ip_addr}")


def ffmpeg_exe():
    try:
        import imageio_ffmpeg
    except ImportError as exc:
        raise RuntimeError(
            "imageio-ffmpeg is required. Install with: python -m pip install --user imageio-ffmpeg"
        ) from exc
    return imageio_ffmpeg.get_ffmpeg_exe()


def iter_video_frames(video_path, fps, loop):
    cmd = [
        ffmpeg_exe(),
        "-hide_banner",
        "-loglevel",
        "error",
    ]
    if loop:
        cmd += ["-stream_loop", "-1"]
    vf = f"fps={fps},scale={WIDTH}:{HEIGHT}:flags=bicubic"
    cmd += [
        "-i",
        video_path,
        "-vf",
        vf,
        "-f",
        "rawvideo",
        "-pix_fmt",
        "rgb24",
        "-",
    ]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    try:
        while True:
            frame = proc.stdout.read(FRAME_BYTES)
            if len(frame) != FRAME_BYTES:
                break
            yield frame
    finally:
        proc.kill()


def make_h2_halfline(frame, line, half):
    x0 = half * HALF_WIDTH
    row0 = line * WIDTH * 3
    start = row0 + x0 * 3
    src = frame[start : start + HALF_WIDTH * 3]
    out = bytearray((HALF_WIDTH // 2) * 3)
    out[0::3] = src[0::6]
    out[1::3] = src[1::6]
    out[2::3] = src[2::6]
    return bytes(out)


def make_h2_chunk(frame, line, half, chunk):
    x0 = half * HALF_WIDTH + chunk * CHUNK_PIXELS
    row0 = line * WIDTH * 3
    start = row0 + x0 * 3
    src = frame[start : start + CHUNK_PIXELS * 3]
    out = bytearray((CHUNK_PIXELS // 2) * 3)
    out[0::3] = src[0::6]
    out[1::3] = src[1::6]
    out[2::3] = src[2::6]
    return bytes(out)


def make_raw888_chunk(frame, line, half, chunk):
    x0 = half * HALF_WIDTH + chunk * CHUNK_PIXELS
    row0 = line * WIDTH * 3
    start = row0 + x0 * 3
    return frame[start : start + CHUNK_PIXELS * 3]


def make_udp_payload(frame_id, line, half, chunk, codec, chunk_data):
    return bytes(
        [
            0x45,
            0x56,
            frame_id & 0xFF,
            (line >> 8) & 0x07,
            line & 0xFF,
            half & 0x01,
            chunk & 0x03,
            codec & 0x03,
        ]
    ) + chunk_data


def make_ipv4_udp_frame(dst_mac, src_mac, src_ip, dst_ip, sport, dport, payload, ip_id):
    total_len = 20 + 8 + len(payload)
    ip_header_wo_sum = struct.pack(
        "!BBHHHBBH4s4s",
        0x45,
        0,
        total_len,
        ip_id & 0xFFFF,
        0,
        64,
        17,
        0,
        src_ip,
        dst_ip,
    )
    ip_sum = checksum16(ip_header_wo_sum)
    ip_header = struct.pack(
        "!BBHHHBBH4s4s",
        0x45,
        0,
        total_len,
        ip_id & 0xFFFF,
        0,
        64,
        17,
        ip_sum,
        src_ip,
        dst_ip,
    )
    udp_header = struct.pack("!HHHH", sport, dport, 8 + len(payload), 0)
    return dst_mac + src_mac + b"\x08\x00" + ip_header + udp_header + payload


def probe_fpga_arp(args):
    iface = find_iface_by_ip(args.pc_ip)
    pc_mac = args.pc_mac or get_if_hwaddr(iface.name)
    request = Ether(src=pc_mac, dst="ff:ff:ff:ff:ff:ff") / ARP(
        op=1,
        hwsrc=pc_mac,
        psrc=args.pc_ip,
        hwdst="00:00:00:00:00:00",
        pdst=args.fpga_ip,
    )
    answered, _ = srp(
        request,
        iface=iface.name,
        timeout=args.arp_timeout,
        retry=args.arp_retry,
        verbose=False,
    )
    expected_mac = args.fpga_mac.lower().replace("-", ":")
    for _, received in answered:
        reply = received.getlayer(ARP)
        if reply is None or int(reply.op) != 2:
            continue
        if str(reply.psrc) != args.fpga_ip or str(reply.pdst) != args.pc_ip:
            continue
        reply_mac = str(reply.hwsrc).lower().replace("-", ":")
        if reply_mac != expected_mac:
            raise RuntimeError(
                f"ARP reply MAC mismatch: expected {expected_mac}, received {reply_mac}"
            )
        return f"{iface.name} {args.fpga_ip}->{reply_mac}"
    raise RuntimeError(f"FPGA {args.fpga_ip} did not answer ARP on {iface.name}")


def open_tx(args):
    if args.tx_mode == "udp":
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, args.send_buffer)
        sock.bind((args.pc_ip, args.sport))
        sock.connect((args.fpga_ip, args.port))

        def tx_send(payload, ip_id):
            sock.send(payload)

        return "kernel-udp", sock, tx_send

    iface = find_iface_by_ip(args.pc_ip)
    src_mac_text = args.pc_mac or get_if_hwaddr(iface.name)
    dst_mac = mac_bytes(args.fpga_mac)
    src_mac = mac_bytes(src_mac_text)
    src_ip = ip_bytes(args.pc_ip)
    dst_ip = ip_bytes(args.fpga_ip)
    sock = conf.L2socket(iface=iface.name)

    def tx_send(payload, ip_id):
        sock.send(
            make_ipv4_udp_frame(
                dst_mac,
                src_mac,
                src_ip,
                dst_ip,
                args.sport,
                args.port,
                payload,
                ip_id,
            )
        )

    return iface.name, sock, tx_send


def send_video(args):
    video_path = args.video or pick_video(args.video_dir)
    packet_gap_s = args.packet_gap_us / 1_000_000.0
    frame_guard_s = args.frame_guard_us / 1_000_000.0
    target_period_s = 0.0 if args.output_fps <= 0 else 1.0 / args.output_fps
    expected_packets = packets_per_frame(args.codec)
    packet_send_window_s = max(0.0, target_period_s - frame_guard_s)
    paced_packet_period_s = (
        packet_send_window_s / expected_packets
        if args.pace_packets and target_period_s > 0 and expected_packets > 0
        else 0.0
    )
    arp_desc = probe_fpga_arp(args) if args.tx_mode == "udp" and args.probe_arp else "off"
    tx_name, sock, tx_send = open_tx(args)

    print(f"tx_mode={args.tx_mode} tx={tx_name}")
    print(f"arp_probe={arp_desc}")
    print(f"src_ip={args.pc_ip}:{args.sport}")
    print(f"dst={args.fpga_ip}:{args.port}")
    print(f"video={os.path.abspath(video_path)}")
    print(
        f"codec={args.codec} decode_fps={args.decode_fps} "
        f"output_fps={args.output_fps} packet_gap_us={args.packet_gap_us} "
        f"frame_guard_us={args.frame_guard_us} pace_packets={args.pace_packets}"
    )
    if args.codec == "h2":
        print("format=h2-halfline payload=968B packets_per_frame=1440")
    elif args.codec == "h2chunk":
        print("format=h2-320chunk payload=488B packets_per_frame=2880")
    else:
        print("format=raw888 payload=968B packets_per_frame=2880")
    print("Press Ctrl+C to stop.")

    frame_id = args.frame_id & 0xFF
    sent_frames = 0
    ip_id = 0
    frames = iter_video_frames(video_path, args.decode_fps, args.loop)
    try:
        for frame in frames:
            start = time.perf_counter()
            next_packet_time = start
            packets = 0
            for line in range(HEIGHT):
                sdram_bank = line & 1
                if args.codec == "h2":
                    for segment in range(2):
                        payload = make_udp_payload(
                            frame_id,
                            line,
                            sdram_bank,
                            segment,
                            CODEC_RGB888_H2_LINE,
                            make_h2_halfline(frame, line, segment),
                        )
                        tx_send(payload, ip_id)
                        ip_id = (ip_id + 1) & 0xFFFF
                        packets += 1
                        if paced_packet_period_s > 0:
                            next_packet_time += paced_packet_period_s
                            wait_until(next_packet_time)
                        elif packet_gap_s > 0:
                            time.sleep(packet_gap_s)
                    continue

                for segment in range(CHUNKS_PER_LINE):
                    half = segment // CHUNKS_PER_HALF
                    chunk = segment % CHUNKS_PER_HALF
                    if args.codec == "h2chunk":
                        codec = CODEC_RGB888_H2_CHUNK
                        chunk_data = make_h2_chunk(frame, line, half, chunk)
                    else:
                        codec = CODEC_RGB888_LITERAL
                        chunk_data = make_raw888_chunk(frame, line, half, chunk)
                    payload = make_udp_payload(
                        frame_id, line, sdram_bank, segment, codec, chunk_data
                    )
                    tx_send(payload, ip_id)
                    ip_id = (ip_id + 1) & 0xFFFF
                    packets += 1
                    if paced_packet_period_s > 0:
                        next_packet_time += paced_packet_period_s
                        wait_until(next_packet_time)
                    elif packet_gap_s > 0:
                        time.sleep(packet_gap_s)

            elapsed = time.perf_counter() - start
            print(f"frame={frame_id:02X} packets={packets} send_time={elapsed:.3f}s")
            frame_id = (frame_id + 1) & 0xFF
            sent_frames += 1
            if args.frames and sent_frames >= args.frames:
                break
            if target_period_s > elapsed:
                time.sleep(target_period_s - elapsed)
    except KeyboardInterrupt:
        print("Stopped.")
    finally:
        sock.close()


def main():
    parser = argparse.ArgumentParser(description="Stream an MP4 to FPGA over UDP.")
    parser.add_argument("--video-dir", default=r"D:\Work\FPGA\eLinx\New_ETH_Vudeo_2\video")
    parser.add_argument("--video", default="")
    parser.add_argument("--pc-ip", default="192.168.1.102")
    parser.add_argument("--pc-mac", default="")
    parser.add_argument("--fpga-ip", default="192.168.1.10")
    parser.add_argument("--fpga-mac", default="00:11:22:33:44:55")
    parser.add_argument("--sport", type=int, default=43210)
    parser.add_argument("--port", type=int, default=1234)
    parser.add_argument("--frame-id", type=int, default=1)
    parser.add_argument("--frames", type=int, default=0, help="0 means stream until Ctrl+C or video ends")
    parser.add_argument("--tx-mode", choices=["udp", "scapy"], default="udp")
    parser.add_argument("--probe-arp", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--arp-timeout", type=float, default=1.0)
    parser.add_argument("--arp-retry", type=int, default=2)
    parser.add_argument("--send-buffer", type=int, default=4 * 1024 * 1024)
    parser.add_argument("--codec", choices=["h2", "h2chunk", "raw888"], default="h2")
    parser.add_argument("--decode-fps", type=float, default=30.0)
    parser.add_argument("--output-fps", type=float, default=30.0, help="0 means as fast as packets can be sent")
    parser.add_argument(
        "--pace-packets",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="spread packets across each output frame instead of sending a burst",
    )
    parser.add_argument("--packet-gap-us", type=float, default=0.0)
    parser.add_argument(
        "--frame-guard-us",
        type=float,
        default=250.0,
        help="quiet interval reserved inside each output frame for FPGA commit/reset",
    )
    parser.add_argument("--loop", action=argparse.BooleanOptionalAction, default=True)
    args = parser.parse_args()

    if args.frames < 0:
        parser.error("--frames must be >= 0")
    if args.decode_fps <= 0:
        parser.error("--decode-fps must be > 0")
    if args.output_fps < 0:
        parser.error("--output-fps must be >= 0")
    if args.packet_gap_us < 0:
        parser.error("--packet-gap-us must be >= 0")
    if args.frame_guard_us < 0:
        parser.error("--frame-guard-us must be >= 0")
    if args.arp_timeout <= 0:
        parser.error("--arp-timeout must be > 0")
    if args.arp_retry < 0:
        parser.error("--arp-retry must be >= 0")
    send_video(args)


if __name__ == "__main__":
    main()
