$ErrorActionPreference = 'Stop'

$moduleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$rtl = Join-Path $moduleRoot 'ycrcb_dark_enhance.v'
$testbench = Join-Path $moduleRoot 'tb_ycrcb_dark_enhance.v'
$simRoot = Join-Path $moduleRoot '.sim'
$outputFile = Join-Path $simRoot 'tb_ycrcb_dark_enhance.vvp'
$iverilog = (Get-Command iverilog -ErrorAction Stop).Source
$vvp = (Get-Command vvp -ErrorAction Stop).Source
$model220 = 'D:\eLinx\eLinx3.0\Simulation\elinx_lib\220model.v'
$alteraMf = 'D:\eLinx\eLinx3.0\Simulation\elinx_lib\altera_mf.v'

New-Item -ItemType Directory -Force -Path $simRoot | Out-Null

& $iverilog -g2005-sv -s tb_ycrcb_dark_enhance -o $outputFile `
    $model220 $alteraMf $rtl $testbench
if ($LASTEXITCODE -ne 0) { throw "iverilog failed: $LASTEXITCODE" }

$capturedOutput = @()
& $vvp -n $outputFile 2>&1 | Tee-Object -Variable capturedOutput
if ($LASTEXITCODE -ne 0) { throw "vvp failed: $LASTEXITCODE" }

$text = $capturedOutput -join "`n"
if ($text -match 'FAIL:|ASSERTION FAILED:') {
    throw 'RTL simulation reported a failing assertion.'
}
if ($text -notmatch 'PASS: ycrcb_dark_enhance') {
    throw 'RTL simulation did not report its PASS marker.'
}
