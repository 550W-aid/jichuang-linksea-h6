`timescale 1ns / 1ps

// Module Function:
//   Standalone YCrCb444 low-light enhancement block extracted from the Retinex
//   shader. Only Y is enhanced; Cr, Cb, valid, SOF, and EOL are delayed by the
//   same fixed three-clock pipeline so every output pixel remains aligned.
module ycrcb_dark_enhance #(
    parameter integer IMAGE_WIDTH = 1280,
    parameter integer DETAIL_GAIN = 4,
    parameter integer LIFT_GAIN   = 1,
    parameter integer TARGET_LUMA = 36
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       in_valid,
    input  wire       in_sof,
    input  wire       in_eol,
    input  wire [7:0] in_y,
    input  wire [7:0] in_cr,
    input  wire [7:0] in_cb,
    output reg        out_valid,
    output reg        out_sof,
    output reg        out_eol,
    output reg  [7:0] out_y,
    output reg  [7:0] out_cr,
    output reg  [7:0] out_cb
);
    localparam [7:0] TARGET_LUMA_U8 = TARGET_LUMA[7:0];
    localparam signed [15:0] DETAIL_GAIN_S = DETAIL_GAIN;
    localparam signed [15:0] LIFT_GAIN_S   = LIFT_GAIN;

    function [11:0] log2_q8;
        input [8:0] value;
        integer index;
        reg [3:0] msb_index;
        reg [8:0] base_value;
        reg [16:0] fraction_value;
        reg [16:0] fraction_shifted;
        reg [11:0] integer_term;
        begin
            msb_index        = 4'd0;
            base_value       = 9'd0;
            fraction_value   = 17'd0;
            fraction_shifted = 17'd0;
            integer_term     = 12'd0;
            log2_q8          = 12'd0;

            if (value > 9'd1) begin
                for (index = 0; index < 9; index = index + 1) begin
                    if (value[index]) begin
                        msb_index = index[3:0];
                    end
                end
                base_value       = 9'd1 << msb_index;
                fraction_value   = (value - base_value) << 8;
                fraction_shifted = fraction_value >> msb_index;
                integer_term     = msb_index;
                log2_q8          = (integer_term << 8) +
                                   fraction_shifted[11:0];
            end
        end
    endfunction

    function [7:0] clamp_u8_signed;
        input signed [31:0] value;
        begin
            if (value < 32'sd0) begin
                clamp_u8_signed = 8'd0;
            end else if (value > 32'sd255) begin
                clamp_u8_signed = 8'd255;
            end else begin
                clamp_u8_signed = value[7:0];
            end
        end
    endfunction

    // The line taps match the active shader implementation and map to the
    // eLinx/Altera RAM-backed altshift_taps primitive instead of LUT registers.
    wire [15:0] line_taps_w;
    wire [7:0] tap0_w = in_y;
    wire [7:0] tap1_w = line_taps_w[7:0];
    wire [7:0] tap2_w = line_taps_w[15:8];

    reg [7:0] window_r [0:2][0:1];
    reg [1:0] row_count_r;
    reg [15:0] col_count_r;
    reg [1:0] row_count_eff_r;
    reg [15:0] col_count_eff_r;
    reg [10:0] row_sum0_comb;
    reg [10:0] row_sum1_comb;
    reg [10:0] row_sum2_comb;
    reg [15:0] weighted_sum_comb;
    reg [7:0] blur_comb;
    integer row_index;
    integer col_index;

    reg       blur_valid_r;
    reg [7:0] blur_luma_r;
    reg       align1_valid_r;
    reg       align1_sof_r;
    reg       align1_eol_r;
    reg [7:0] align1_y_r;
    reg [7:0] align1_cr_r;
    reg [7:0] align1_cb_r;

    reg        stage2_valid_r;
    reg        stage2_sof_r;
    reg        stage2_eol_r;
    reg [7:0]  stage2_y_r;
    reg [7:0]  stage2_cr_r;
    reg [7:0]  stage2_cb_r;
    reg [7:0]  stage2_blur_r;
    reg [11:0] stage2_log_y_r;
    reg [11:0] stage2_log_blur_r;

    wire [11:0] log_y_comb_w = log2_q8({1'b0, align1_y_r} + 9'd1);
    wire [11:0] log_blur_comb_w =
        log2_q8({1'b0, blur_luma_r} + 9'd1);

    reg signed [12:0] detail_term_comb;
    reg signed [15:0] illumination_lift_comb;
    reg signed [31:0] detail_scaled_comb;
    reg signed [31:0] lift_scaled_comb;
    reg signed [31:0] enhanced_accum_comb;
    reg signed [31:0] enhanced_luma_comb;
    reg [7:0] enhanced_y_comb;

    altshift_taps #(
        .intended_device_family("Stratix"),
        .lpm_hint              ("RAM_BLOCK_TYPE=M4K"),
        .lpm_type              ("altshift_taps"),
        .number_of_taps        (2),
        .tap_distance          (IMAGE_WIDTH),
        .width                 (8),
        .power_up_state        ("CLEARED")
    ) line_delay_inst (
        .aclr    (1'b0),
        .clken   (in_valid),
        .clock   (clk),
        .shiftin (in_y),
        .shiftout(),
        .taps    (line_taps_w)
    );

    always @* begin
        row_count_eff_r = in_sof ? 2'd0 : row_count_r;
        col_count_eff_r = in_sof ? 16'd0 : col_count_r;
        row_sum0_comb = tap0_w + (window_r[0][0] << 1) +
                        window_r[0][1];
        row_sum1_comb = (tap1_w << 1) +
                        (window_r[1][0] << 2) +
                        (window_r[1][1] << 1);
        row_sum2_comb = tap2_w + (window_r[2][0] << 1) +
                        window_r[2][1];
        weighted_sum_comb = row_sum0_comb + row_sum1_comb + row_sum2_comb;
        blur_comb = weighted_sum_comb[7:4];
        if ((row_count_eff_r < 2'd2) || (col_count_eff_r < 16'd2)) begin
            blur_comb = in_y;
        end
    end

    always @* begin
        detail_term_comb = $signed({1'b0, stage2_log_y_r}) -
                           $signed({1'b0, stage2_log_blur_r});
        if (stage2_blur_r < TARGET_LUMA_U8) begin
            illumination_lift_comb =
                $signed({1'b0, TARGET_LUMA_U8}) -
                $signed({1'b0, stage2_blur_r});
        end else begin
            illumination_lift_comb = 16'sd0;
        end

        detail_scaled_comb = detail_term_comb * DETAIL_GAIN_S;
        lift_scaled_comb = (illumination_lift_comb * LIFT_GAIN_S) <<< 8;
        enhanced_accum_comb = $signed({1'b0, stage2_y_r, 8'd0}) +
                              detail_scaled_comb + lift_scaled_comb;
        enhanced_luma_comb = enhanced_accum_comb >>> 8;
        enhanced_y_comb = clamp_u8_signed(enhanced_luma_comb);
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            row_count_r   <= 2'd0;
            col_count_r   <= 16'd0;
            for (row_index = 0; row_index < 3; row_index = row_index + 1) begin
                for (col_index = 0; col_index < 2; col_index = col_index + 1) begin
                    window_r[row_index][col_index] <= 8'd0;
                end
            end
            blur_valid_r  <= 1'b0;
            blur_luma_r   <= 8'd0;
            align1_valid_r <= 1'b0;
            align1_sof_r   <= 1'b0;
            align1_eol_r   <= 1'b0;
            align1_y_r     <= 8'd0;
            align1_cr_r    <= 8'd0;
            align1_cb_r    <= 8'd0;
        end else begin
            blur_valid_r   <= in_valid;
            align1_valid_r <= in_valid;
            align1_sof_r   <= in_valid && in_sof;
            align1_eol_r   <= in_valid && in_eol;

            if (in_valid) begin
                blur_luma_r <= blur_comb;
                align1_y_r  <= in_y;
                align1_cr_r <= in_cr;
                align1_cb_r <= in_cb;

                for (row_index = 0; row_index < 3; row_index = row_index + 1) begin
                    for (col_index = 1; col_index > 0; col_index = col_index - 1) begin
                        window_r[row_index][col_index] <=
                            window_r[row_index][col_index-1];
                    end
                end
                window_r[0][0] <= tap0_w;
                window_r[1][0] <= tap1_w;
                window_r[2][0] <= tap2_w;

                if (in_sof) begin
                    row_count_r <= 2'd0;
                    col_count_r <= in_eol ? 16'd0 : 16'd1;
                end else if (in_eol) begin
                    col_count_r <= 16'd0;
                    if (row_count_r < 2'd2) begin
                        row_count_r <= row_count_r + 2'd1;
                    end
                end else begin
                    col_count_r <= col_count_r + 16'd1;
                end
            end
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            stage2_valid_r    <= 1'b0;
            stage2_sof_r      <= 1'b0;
            stage2_eol_r      <= 1'b0;
            stage2_y_r        <= 8'd0;
            stage2_cr_r       <= 8'd0;
            stage2_cb_r       <= 8'd0;
            stage2_blur_r     <= 8'd0;
            stage2_log_y_r    <= 12'd0;
            stage2_log_blur_r <= 12'd0;
        end else begin
            stage2_valid_r <= blur_valid_r && align1_valid_r;
            stage2_sof_r   <= blur_valid_r && align1_valid_r && align1_sof_r;
            stage2_eol_r   <= blur_valid_r && align1_valid_r && align1_eol_r;
            if (blur_valid_r && align1_valid_r) begin
                stage2_y_r        <= align1_y_r;
                stage2_cr_r       <= align1_cr_r;
                stage2_cb_r       <= align1_cb_r;
                stage2_blur_r     <= blur_luma_r;
                stage2_log_y_r    <= log_y_comb_w;
                stage2_log_blur_r <= log_blur_comb_w;
            end
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            out_valid <= 1'b0;
            out_sof   <= 1'b0;
            out_eol   <= 1'b0;
            out_y     <= 8'd0;
            out_cr    <= 8'd0;
            out_cb    <= 8'd0;
        end else begin
            out_valid <= stage2_valid_r;
            out_sof   <= stage2_valid_r && stage2_sof_r;
            out_eol   <= stage2_valid_r && stage2_eol_r;
            if (stage2_valid_r) begin
                out_y  <= enhanced_y_comb;
                out_cr <= stage2_cr_r;
                out_cb <= stage2_cb_r;
            end
        end
    end
endmodule
