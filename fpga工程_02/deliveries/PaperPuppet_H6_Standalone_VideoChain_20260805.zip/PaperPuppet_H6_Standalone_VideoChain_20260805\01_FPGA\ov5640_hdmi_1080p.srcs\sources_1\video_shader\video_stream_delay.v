// Module Function:
//   Delays a complete HDMI-style timing/RGB stream by a fixed clock count.
//   This gives the shader and bypass branches identical output timing.
module video_stream_delay #(
    parameter integer LATENCY = 13
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        video_hs_i,
    input  wire        video_vs_i,
    input  wire        video_de_i,
    input  wire [23:0] video_rgb_i,
    output wire        video_hs_o,
    output wire        video_vs_o,
    output wire        video_de_o,
    output wire [23:0] video_rgb_o
);
    (* altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *)
    reg [LATENCY-1:0] hs_pipe_r;
    (* altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *)
    reg [LATENCY-1:0] vs_pipe_r;
    (* altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *)
    reg [LATENCY-1:0] de_pipe_r;
    (* altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *)
    reg [23:0] rgb_pipe_r [0:LATENCY-1];

    integer index;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            hs_pipe_r <= {LATENCY{1'b1}};
            vs_pipe_r <= {LATENCY{1'b1}};
            de_pipe_r <= {LATENCY{1'b0}};
            for (index = 0; index < LATENCY; index = index + 1) begin
                rgb_pipe_r[index] <= 24'd0;
            end
        end else begin
            hs_pipe_r[0] <= video_hs_i;
            vs_pipe_r[0] <= video_vs_i;
            de_pipe_r[0] <= video_de_i;
            rgb_pipe_r[0] <= video_rgb_i;
            for (index = 1; index < LATENCY; index = index + 1) begin
                hs_pipe_r[index] <= hs_pipe_r[index-1];
                vs_pipe_r[index] <= vs_pipe_r[index-1];
                de_pipe_r[index] <= de_pipe_r[index-1];
                rgb_pipe_r[index] <= rgb_pipe_r[index-1];
            end
        end
    end

    assign video_hs_o  = hs_pipe_r[LATENCY-1];
    assign video_vs_o  = vs_pipe_r[LATENCY-1];
    assign video_de_o  = de_pipe_r[LATENCY-1];
    assign video_rgb_o = rgb_pipe_r[LATENCY-1];
endmodule
