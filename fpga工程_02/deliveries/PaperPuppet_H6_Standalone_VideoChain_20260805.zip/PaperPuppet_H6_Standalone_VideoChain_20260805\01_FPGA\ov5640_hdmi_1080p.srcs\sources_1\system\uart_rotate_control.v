// ============================================================================
// Module Function:
//   UART register-control wrapper for live rotation angle commands and status responses.
// ============================================================================
`timescale 1ns / 1ps

module uart_rotate_control #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD   = 115200
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        uart_rxd_i,
    output wire        uart_txd_o,
    input  wire [15:0] heartbeat_i,
    input  wire [15:0] status_reg_i,
    input  wire [15:0] rotate_active_angle_i,
    input  wire [15:0] rotate_status_i,
    input  wire [15:0] rotate_debug0_i,
    input  wire [15:0] rotate_debug1_i,
    output wire [15:0] rotate_angle_deg_o,
    output wire        rotate_cfg_toggle_o
);

wire [7:0] rx_data_w;
wire       rx_valid_w;
wire [7:0] tx_data_w;
wire       tx_valid_w;
wire       tx_busy_w;
wire       tx_ready_w;

wire [15:0] unused_mode_w;
wire [15:0] unused_algo_enable_w;
wire [15:0] unused_brightness_gain_w;
wire [15:0] unused_gamma_sel_w;
wire [15:0] unused_scale_sel_w;
wire [15:0] unused_rotate_sel_w;
wire [15:0] unused_edge_sel_w;
wire [15:0] unused_osd_sel_w;
wire [15:0] unused_cam_cmd_w;
wire [15:0] unused_cam_reg_addr_w;
wire [15:0] unused_cam_wr_data_w;

assign tx_ready_w = ~tx_busy_w;

uart_rx #(
    .CLK_HZ (CLK_HZ),
    .BAUD   (BAUD)
) u_uart_rx (
    .clk          (clk),
    .rst_n        (rst_n),
    .rx_i         (uart_rxd_i),
    .data_o       (rx_data_w),
    .data_valid_o (rx_valid_w)
);

uart_ctrl_regs u_uart_ctrl_regs (
    .clk                  (clk),
    .rst_n                (rst_n),
    .rx_data_i            (rx_data_w),
    .rx_valid_i           (rx_valid_w),
    .tx_data_o            (tx_data_w),
    .tx_valid_o           (tx_valid_w),
    .tx_ready_i           (tx_ready_w),
    .mode_o               (unused_mode_w),
    .algo_enable_o        (unused_algo_enable_w),
    .brightness_gain_o    (unused_brightness_gain_w),
    .gamma_sel_o          (unused_gamma_sel_w),
    .scale_sel_o          (unused_scale_sel_w),
    .rotate_sel_o         (unused_rotate_sel_w),
    .rotate_angle_deg_o   (rotate_angle_deg_o),
    .rotate_cfg_toggle_o  (rotate_cfg_toggle_o),
    .edge_sel_o           (unused_edge_sel_w),
    .osd_sel_o            (unused_osd_sel_w),
    .cam_cmd_o            (unused_cam_cmd_w),
    .cam_reg_addr_o       (unused_cam_reg_addr_w),
    .cam_wr_data_o        (unused_cam_wr_data_w),
    .status_reg_i         (status_reg_i),
    .fps_counter_i        (16'd0),
    .heartbeat_i          (heartbeat_i),
    .rotate_active_angle_i(rotate_active_angle_i),
    .rotate_status_i      (rotate_status_i),
    .rotate_debug0_i      (rotate_debug0_i),
    .rotate_debug1_i      (rotate_debug1_i),
    .cam_rd_data_i        (16'd0),
    .cam_status_i         (16'd0),
    .cam_frame_count_i    (16'd0),
    .cam_line_count_i     (16'd0),
    .cam_last_pixel_i     (16'd0),
    .cam_error_count_i    (16'd0)
);

uart_tx #(
    .CLK_HZ (CLK_HZ),
    .BAUD   (BAUD)
) u_uart_tx (
    .clk          (clk),
    .rst_n        (rst_n),
    .data_i       (tx_data_w),
    .data_valid_i (tx_valid_w & tx_ready_w),
    .tx_o         (uart_txd_o),
    .busy_o       (tx_busy_w)
);

endmodule
