`timescale 1ns / 1ps

module black_frame_coarse_detector #(
    parameter integer IMAGE_WIDTH = 1280,
    parameter integer IMAGE_HEIGHT = 720,
    parameter integer X_WIDTH = 12,
    parameter integer Y_WIDTH = 12,
    parameter integer BIN_SHIFT = 4,
    parameter integer Y_BINS = 45,
    parameter [7:0] DARK_MAX = 8'd80,
    parameter [15:0] ROW_BIN_MIN_DARK = 16'd300,
    parameter [15:0] ROW_BIN_MAX_DARK = 16'hffff,
    parameter [X_WIDTH-1:0] EDGE_MARGIN = 12'd24,
    parameter [X_WIDTH-1:0] SIDE_TOLERANCE = 12'd24,
    parameter [15:0] MIN_SIDE_ROWS = 16'd48,
    parameter [X_WIDTH-1:0] MIN_FRAME_WIDTH = 12'd300,
    parameter [Y_WIDTH-1:0] MIN_FRAME_HEIGHT = 12'd180,
    parameter [15:0] MIN_LINE_BAND_HEIGHT = 16'd2,
    parameter [15:0] MAX_LINE_BAND_HEIGHT = 16'd32
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 sof,
    input  wire                 eof,
    input  wire                 pixel_valid,
    input  wire [X_WIDTH-1:0]   pixel_x,
    input  wire [Y_WIDTH-1:0]   pixel_y,
    input  wire [7:0]           pixel_r,
    input  wire [7:0]           pixel_g,
    input  wire [7:0]           pixel_b,
    output reg                  frame_valid,
    output reg [X_WIDTH-1:0]    left_x,
    output reg [X_WIDTH-1:0]    right_x,
    output reg [Y_WIDTH-1:0]    top_y,
    output reg [Y_WIDTH-1:0]    bottom_y,
    output reg                  candidate_valid,
    output reg [X_WIDTH-1:0]    candidate_left_x,
    output reg [X_WIDTH-1:0]    candidate_right_x,
    output reg [Y_WIDTH-1:0]    candidate_top_y,
    output reg [Y_WIDTH-1:0]    candidate_bottom_y,
    output reg                  left_side_valid,
    output reg                  right_side_valid
);

    wire is_dark;
    wire line_boundary;
    wire [15:0] line_final_run_count_wire;
    wire [X_WIDTH-1:0] line_final_run_start_wire;
    wire [X_WIDTH-1:0] line_final_run_end_wire;
    wire line_final_run_is_current_wire;
    wire line_run_interior_wire;
    wire line_candidate_valid_wire;
    wire left_side_pixel_wire;
    wire right_side_pixel_wire;
    wire left_side_topology_valid_wire;
    wire right_side_topology_valid_wire;
    wire [17:0] left_side_rows_x4_wire;
    wire [17:0] right_side_rows_x4_wire;
    wire band_valid_wire;
    wire band_contiguous_wire;

    reg line_active_reg;
    reg [Y_WIDTH-1:0] line_y_reg;
    reg [15:0] line_run_count_reg;
    reg [X_WIDTH-1:0] line_run_start_reg;
    reg [X_WIDTH-1:0] line_run_end_reg;
    reg [15:0] line_best_run_count_reg;
    reg [X_WIDTH-1:0] line_best_run_start_reg;
    reg [X_WIDTH-1:0] line_best_run_end_reg;

    reg frame_line_found_reg;
    reg [X_WIDTH-1:0] frame_left_acc_reg;
    reg [X_WIDTH-1:0] frame_right_acc_reg;
    reg [Y_WIDTH-1:0] frame_top_acc_reg;
    reg [Y_WIDTH-1:0] frame_bottom_acc_reg;
    reg line_left_side_seen_reg;
    reg line_right_side_seen_reg;
    reg [15:0] frame_left_side_rows_reg;
    reg [15:0] frame_right_side_rows_reg;
    reg band_active_reg;
    reg [X_WIDTH-1:0] band_left_reg;
    reg [X_WIDTH-1:0] band_right_reg;
    reg [Y_WIDTH-1:0] band_start_y_reg;
    reg [Y_WIDTH-1:0] band_end_y_reg;
    reg [15:0] band_height_reg;

    wire [X_WIDTH:0] frame_width_wire;
    wire [Y_WIDTH:0] frame_height_wire;
    localparam [X_WIDTH-1:0] RIGHT_EDGE_LIMIT = IMAGE_WIDTH - 1 - EDGE_MARGIN;

    assign is_dark =
        pixel_valid &&
        (pixel_r <= DARK_MAX) &&
        (pixel_g <= DARK_MAX) &&
        (pixel_b <= DARK_MAX);
    assign line_boundary = pixel_valid && line_active_reg && (pixel_y != line_y_reg);
    assign frame_width_wire = {1'b0, frame_right_acc_reg} - {1'b0, frame_left_acc_reg} + 13'd1;
    assign frame_height_wire = {1'b0, frame_bottom_acc_reg} - {1'b0, frame_top_acc_reg} + 13'd1;
    assign line_run_interior_wire =
        (line_run_start_reg > EDGE_MARGIN) &&
        (line_run_end_reg < RIGHT_EDGE_LIMIT);
    assign line_final_run_is_current_wire =
        line_run_interior_wire &&
        (line_run_count_reg > line_best_run_count_reg);
    assign line_final_run_count_wire = line_final_run_is_current_wire ?
                                       line_run_count_reg : line_best_run_count_reg;
    assign line_final_run_start_wire = line_final_run_is_current_wire ?
                                       line_run_start_reg : line_best_run_start_reg;
    assign line_final_run_end_wire = line_final_run_is_current_wire ?
                                     line_run_end_reg : line_best_run_end_reg;
    assign line_candidate_valid_wire =
        (line_final_run_count_wire >= ROW_BIN_MIN_DARK) &&
        (line_final_run_count_wire <= ROW_BIN_MAX_DARK);
    assign left_side_pixel_wire =
        frame_line_found_reg &&
        is_dark &&
        (({1'b0, pixel_x} + {1'b0, SIDE_TOLERANCE}) >= {1'b0, frame_left_acc_reg}) &&
        ({1'b0, pixel_x} <= ({1'b0, frame_left_acc_reg} + {1'b0, SIDE_TOLERANCE}));
    assign right_side_pixel_wire =
        frame_line_found_reg &&
        is_dark &&
        (({1'b0, pixel_x} + {1'b0, SIDE_TOLERANCE}) >= {1'b0, frame_right_acc_reg}) &&
        ({1'b0, pixel_x} <= ({1'b0, frame_right_acc_reg} + {1'b0, SIDE_TOLERANCE}));
    assign left_side_rows_x4_wire = {2'b00, frame_left_side_rows_reg} << 2;
    assign right_side_rows_x4_wire = {2'b00, frame_right_side_rows_reg} << 2;
    assign left_side_topology_valid_wire =
        (frame_left_side_rows_reg >= MIN_SIDE_ROWS) &&
        (left_side_rows_x4_wire >= {5'b00000, frame_height_wire});
    assign right_side_topology_valid_wire =
        (frame_right_side_rows_reg >= MIN_SIDE_ROWS) &&
        (right_side_rows_x4_wire >= {5'b00000, frame_height_wire});
    assign band_valid_wire =
        band_active_reg &&
        (band_height_reg >= MIN_LINE_BAND_HEIGHT) &&
        (band_height_reg <= MAX_LINE_BAND_HEIGHT);
    assign band_contiguous_wire =
        band_active_reg &&
        ({1'b0, line_y_reg} <= ({1'b0, band_end_y_reg} + 13'd1));

    always @(posedge clk or negedge rst_n) begin
            if (!rst_n) begin
                line_active_reg <= 1'b0;
                line_y_reg <= {Y_WIDTH{1'b0}};
                line_run_count_reg <= 16'd0;
                line_run_start_reg <= {X_WIDTH{1'b0}};
                line_run_end_reg <= {X_WIDTH{1'b0}};
                line_best_run_count_reg <= 16'd0;
                line_best_run_start_reg <= {X_WIDTH{1'b0}};
                line_best_run_end_reg <= {X_WIDTH{1'b0}};
                frame_line_found_reg <= 1'b0;
            frame_left_acc_reg <= {X_WIDTH{1'b1}};
            frame_right_acc_reg <= {X_WIDTH{1'b0}};
            frame_top_acc_reg <= {Y_WIDTH{1'b0}};
            frame_bottom_acc_reg <= {Y_WIDTH{1'b0}};
            line_left_side_seen_reg <= 1'b0;
            line_right_side_seen_reg <= 1'b0;
            frame_left_side_rows_reg <= 16'd0;
            frame_right_side_rows_reg <= 16'd0;
            band_active_reg <= 1'b0;
            band_left_reg <= {X_WIDTH{1'b0}};
            band_right_reg <= {X_WIDTH{1'b0}};
            band_start_y_reg <= {Y_WIDTH{1'b0}};
            band_end_y_reg <= {Y_WIDTH{1'b0}};
            band_height_reg <= 16'd0;
            frame_valid <= 1'b0;
            left_x <= {X_WIDTH{1'b0}};
            right_x <= {X_WIDTH{1'b0}};
            top_y <= {Y_WIDTH{1'b0}};
            bottom_y <= {Y_WIDTH{1'b0}};
            candidate_valid <= 1'b0;
            candidate_left_x <= {X_WIDTH{1'b0}};
            candidate_right_x <= {X_WIDTH{1'b0}};
            candidate_top_y <= {Y_WIDTH{1'b0}};
            candidate_bottom_y <= {Y_WIDTH{1'b0}};
            left_side_valid <= 1'b0;
            right_side_valid <= 1'b0;
        end else begin
            if (sof) begin
                line_active_reg <= 1'b0;
                line_y_reg <= {Y_WIDTH{1'b0}};
                line_run_count_reg <= 16'd0;
                line_run_start_reg <= {X_WIDTH{1'b0}};
                line_run_end_reg <= {X_WIDTH{1'b0}};
                line_best_run_count_reg <= 16'd0;
                line_best_run_start_reg <= {X_WIDTH{1'b0}};
                line_best_run_end_reg <= {X_WIDTH{1'b0}};
                frame_line_found_reg <= 1'b0;
                frame_left_acc_reg <= {X_WIDTH{1'b1}};
                frame_right_acc_reg <= {X_WIDTH{1'b0}};
                frame_top_acc_reg <= {Y_WIDTH{1'b0}};
                frame_bottom_acc_reg <= {Y_WIDTH{1'b0}};
                line_left_side_seen_reg <= 1'b0;
                line_right_side_seen_reg <= 1'b0;
                frame_left_side_rows_reg <= 16'd0;
                frame_right_side_rows_reg <= 16'd0;
                band_active_reg <= 1'b0;
                band_left_reg <= {X_WIDTH{1'b0}};
                band_right_reg <= {X_WIDTH{1'b0}};
                band_start_y_reg <= {Y_WIDTH{1'b0}};
                band_end_y_reg <= {Y_WIDTH{1'b0}};
                band_height_reg <= 16'd0;
            end else if (pixel_valid) begin
                if (line_boundary) begin
                    if (frame_line_found_reg && line_left_side_seen_reg) begin
                        if (frame_left_side_rows_reg != 16'hffff) begin
                            frame_left_side_rows_reg <= frame_left_side_rows_reg + 16'd1;
                        end
                    end
                    if (frame_line_found_reg && line_right_side_seen_reg) begin
                        if (frame_right_side_rows_reg != 16'hffff) begin
                            frame_right_side_rows_reg <= frame_right_side_rows_reg + 16'd1;
                        end
                    end

                    if (line_candidate_valid_wire) begin
                        if (band_active_reg && band_contiguous_wire) begin
                            if (line_final_run_start_wire < band_left_reg) begin
                                band_left_reg <= line_final_run_start_wire;
                            end
                            if (line_final_run_end_wire > band_right_reg) begin
                                band_right_reg <= line_final_run_end_wire;
                            end
                            band_end_y_reg <= line_y_reg;
                            if (band_height_reg != 16'hffff) begin
                                band_height_reg <= band_height_reg + 16'd1;
                            end
                        end else begin
                            if (band_active_reg && band_valid_wire) begin
                                if (!frame_line_found_reg) begin
                                    frame_top_acc_reg <= band_start_y_reg;
                                    frame_left_acc_reg <= band_left_reg;
                                    frame_right_acc_reg <= band_right_reg;
                                end else begin
                                    if (band_left_reg < frame_left_acc_reg) begin
                                        frame_left_acc_reg <= band_left_reg;
                                    end
                                    if (band_right_reg > frame_right_acc_reg) begin
                                        frame_right_acc_reg <= band_right_reg;
                                    end
                                end
                                frame_bottom_acc_reg <= band_end_y_reg;
                                frame_line_found_reg <= 1'b1;
                            end
                            band_active_reg <= 1'b1;
                            band_left_reg <= line_final_run_start_wire;
                            band_right_reg <= line_final_run_end_wire;
                            band_start_y_reg <= line_y_reg;
                            band_end_y_reg <= line_y_reg;
                            band_height_reg <= 16'd1;
                        end
                    end else if (band_active_reg) begin
                        if (band_valid_wire) begin
                            if (!frame_line_found_reg) begin
                                frame_top_acc_reg <= band_start_y_reg;
                                frame_left_acc_reg <= band_left_reg;
                                frame_right_acc_reg <= band_right_reg;
                            end else begin
                                if (band_left_reg < frame_left_acc_reg) begin
                                    frame_left_acc_reg <= band_left_reg;
                                end
                                if (band_right_reg > frame_right_acc_reg) begin
                                    frame_right_acc_reg <= band_right_reg;
                                end
                            end
                            frame_bottom_acc_reg <= band_end_y_reg;
                            frame_line_found_reg <= 1'b1;
                        end
                        band_active_reg <= 1'b0;
                        band_left_reg <= {X_WIDTH{1'b0}};
                        band_right_reg <= {X_WIDTH{1'b0}};
                        band_start_y_reg <= {Y_WIDTH{1'b0}};
                        band_end_y_reg <= {Y_WIDTH{1'b0}};
                        band_height_reg <= 16'd0;
                    end

                    line_y_reg <= pixel_y;
                    line_active_reg <= 1'b1;
                    line_run_count_reg <= is_dark ? 16'd1 : 16'd0;
                    line_run_start_reg <= is_dark ? pixel_x : {X_WIDTH{1'b0}};
                    line_run_end_reg <= is_dark ? pixel_x : {X_WIDTH{1'b0}};
                    line_best_run_count_reg <= 16'd0;
                    line_best_run_start_reg <= {X_WIDTH{1'b0}};
                    line_best_run_end_reg <= {X_WIDTH{1'b0}};
                    line_left_side_seen_reg <= left_side_pixel_wire;
                    line_right_side_seen_reg <= right_side_pixel_wire;
                end else begin
                    if (!line_active_reg) begin
                        line_y_reg <= pixel_y;
                        line_active_reg <= 1'b1;
                        line_run_count_reg <= is_dark ? 16'd1 : 16'd0;
                        line_run_start_reg <= is_dark ? pixel_x : {X_WIDTH{1'b0}};
                        line_run_end_reg <= is_dark ? pixel_x : {X_WIDTH{1'b0}};
                        line_best_run_count_reg <= 16'd0;
                        line_best_run_start_reg <= {X_WIDTH{1'b0}};
                        line_best_run_end_reg <= {X_WIDTH{1'b0}};
                        line_left_side_seen_reg <= left_side_pixel_wire;
                        line_right_side_seen_reg <= right_side_pixel_wire;
                    end else if (is_dark) begin
                        if (left_side_pixel_wire) begin
                            line_left_side_seen_reg <= 1'b1;
                        end
                        if (right_side_pixel_wire) begin
                            line_right_side_seen_reg <= 1'b1;
                        end
                        if (line_run_count_reg == 16'd0) begin
                            line_run_count_reg <= 16'd1;
                            line_run_start_reg <= pixel_x;
                            line_run_end_reg <= pixel_x;
                        end else begin
                            if (line_run_count_reg != 16'hffff) begin
                                line_run_count_reg <= line_run_count_reg + 16'd1;
                            end
                            line_run_end_reg <= pixel_x;
                        end
                    end else begin
                        if (
                            line_run_interior_wire &&
                            (line_run_count_reg > line_best_run_count_reg)
                        ) begin
                            line_best_run_count_reg <= line_run_count_reg;
                            line_best_run_start_reg <= line_run_start_reg;
                            line_best_run_end_reg <= line_run_end_reg;
                        end
                        line_run_count_reg <= 16'd0;
                        line_run_start_reg <= {X_WIDTH{1'b0}};
                        line_run_end_reg <= {X_WIDTH{1'b0}};
                    end
                end
            end

            if (eof) begin
                if (
                    frame_line_found_reg &&
                    (frame_right_acc_reg > frame_left_acc_reg) &&
                    (frame_bottom_acc_reg > frame_top_acc_reg) &&
                    (frame_width_wire >= {1'b0, MIN_FRAME_WIDTH}) &&
                    (frame_height_wire >= {1'b0, MIN_FRAME_HEIGHT})
                ) begin
                    candidate_valid <= 1'b1;
                    candidate_left_x <= frame_left_acc_reg;
                    candidate_right_x <= frame_right_acc_reg;
                    candidate_top_y <= frame_top_acc_reg;
                    candidate_bottom_y <= frame_bottom_acc_reg;
                    left_side_valid <= left_side_topology_valid_wire;
                    right_side_valid <= right_side_topology_valid_wire;
                    if (left_side_topology_valid_wire && right_side_topology_valid_wire) begin
                        frame_valid <= 1'b1;
                        left_x <= frame_left_acc_reg;
                        right_x <= frame_right_acc_reg;
                        top_y <= frame_top_acc_reg;
                        bottom_y <= frame_bottom_acc_reg;
                    end else begin
                        frame_valid <= 1'b0;
                    end
                end else begin
                    frame_valid <= 1'b0;
                    candidate_valid <= 1'b0;
                    candidate_left_x <= {X_WIDTH{1'b0}};
                    candidate_right_x <= {X_WIDTH{1'b0}};
                    candidate_top_y <= {Y_WIDTH{1'b0}};
                    candidate_bottom_y <= {Y_WIDTH{1'b0}};
                    left_side_valid <= 1'b0;
                    right_side_valid <= 1'b0;
                end
            end
        end
    end

endmodule
