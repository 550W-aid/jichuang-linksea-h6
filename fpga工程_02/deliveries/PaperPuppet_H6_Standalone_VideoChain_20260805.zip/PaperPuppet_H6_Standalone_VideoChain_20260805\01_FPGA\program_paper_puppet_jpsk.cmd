@echo off
setlocal EnableExtensions
set "PROGRAMMER=D:\eLinx3.0\bin\shell\bin\Programmer_core.exe"
set "PROGRAM_TCL=%~dp0program_paper_puppet_jpsk.tcl"
set "PROGRAM_LOG=%~dp0program_paper_puppet_last.log"

if not exist "%PROGRAMMER%" (
    echo Missing eLinx programmer: %PROGRAMMER%
    exit /b 2
)

"%PROGRAMMER%" -silence -f "%PROGRAM_TCL%" > "%PROGRAM_LOG%" 2>&1
set "PROGRAM_EXIT=%ERRORLEVEL%"
type "%PROGRAM_LOG%"
exit /b %PROGRAM_EXIT%
