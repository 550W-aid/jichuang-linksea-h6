// ============================================================================
// Module Function:
//   Pipelined coordinate mapper that converts output preview coordinates into rotated source coordinates.
// ============================================================================
`timescale 1ns / 1ps

module rotate_coordinate_map #(
    parameter integer IMAGE_W = 1024,
    parameter integer IMAGE_H = 768,
    parameter integer FORCE_RAW_COPY = 0
) (
    input  wire               clk,
    input  wire               rst_n,
    input  wire               cfg_valid,
    output wire               cfg_ready,
    input  wire [8:0]         cfg_angle_deg,
    input  wire               request_valid,
    input  wire               request_sof,
    input  wire [15:0]        out_x,
    input  wire [15:0]        out_y,
    output wire [8:0]         active_angle_deg,
    output wire signed [31:0] src_x,
    output wire signed [31:0] src_y,
    output wire               src_inside,
    output wire               src_valid
);

    localparam integer X_CENTER = IMAGE_W / 2;
    localparam integer Y_CENTER = IMAGE_H / 2;
    localparam signed [16:0] X_CENTER_S17 = X_CENTER;
    localparam signed [16:0] Y_CENTER_S17 = Y_CENTER;
    localparam signed [31:0] X_CENTER_S32 = X_CENTER;
    localparam signed [31:0] Y_CENTER_S32 = Y_CENTER;

    reg [8:0]         active_angle_q;
    reg signed [9:0]  sin_active_q;
    reg signed [9:0]  cos_active_q;

    reg               stage0_valid_q;
    reg               stage0_raw_copy_q;
    reg [15:0]        stage0_out_x_q;
    reg [15:0]        stage0_out_y_q;
    reg signed [9:0]  stage0_sin_q;
    reg signed [9:0]  stage0_cos_q;

    reg               stage1_valid_q;
    reg               stage1_raw_copy_q;
    reg [15:0]        stage1_out_x_q;
    reg [15:0]        stage1_out_y_q;
    reg signed [16:0] stage1_x_centered_q;
    reg signed [16:0] stage1_y_centered_q;
    reg signed [9:0]  stage1_sin_q;
    reg signed [9:0]  stage1_cos_q;

    reg               stage2_valid_q;
    reg               stage2_raw_copy_q;
    reg [15:0]        stage2_out_x_q;
    reg [15:0]        stage2_out_y_q;
    reg signed [9:0]  stage2_sin_q;
    reg signed [9:0]  stage2_cos_q;
    reg signed [31:0] stage2_x_cos_q;
    reg signed [31:0] stage2_y_sin_q;
    reg signed [31:0] stage2_x_sin_q;
    reg signed [31:0] stage2_y_cos_q;

    reg               stage3_valid_q;
    reg               stage3_raw_copy_q;
    reg [15:0]        stage3_out_x_q;
    reg [15:0]        stage3_out_y_q;
    reg signed [31:0] stage3_x_rotate_q;
    reg signed [31:0] stage3_y_rotate_q;

    reg               stage4_valid_q;
    reg signed [31:0] stage4_src_x_q;
    reg signed [31:0] stage4_src_y_q;
    reg               stage4_src_inside_q;

    wire signed [9:0] sin_cfg_w;
    wire signed [9:0] cos_cfg_w;
    wire signed [16:0] stage1_x_centered_w;
    wire signed [16:0] stage1_y_centered_w;
    wire signed [31:0] stage2_x_cos_w;
    wire signed [31:0] stage2_y_sin_w;
    wire signed [31:0] stage2_x_sin_w;
    wire signed [31:0] stage2_y_cos_w;
    wire signed [31:0] stage3_x_center_corr_w;
    wire signed [31:0] stage3_y_center_corr_w;
    wire signed [31:0] stage3_x_acc_w;
    wire signed [31:0] stage3_y_acc_w;
    wire signed [31:0] stage3_x_rotate_w;
    wire signed [31:0] stage3_y_rotate_w;
    wire signed [31:0] stage4_calc_src_x_w;
    wire signed [31:0] stage4_calc_src_y_w;

    assign cfg_ready        = 1'b1;
    assign active_angle_deg = active_angle_q;
    assign src_valid        = stage4_valid_q;
    assign src_x            = stage4_src_x_q;
    assign src_y            = stage4_src_y_q;
    assign src_inside       = stage4_src_inside_q;

    assign stage1_x_centered_w = $signed({1'b0, stage0_out_x_q}) - X_CENTER_S17;
    assign stage1_y_centered_w = Y_CENTER_S17 - $signed({1'b0, stage0_out_y_q});

    assign stage2_x_cos_w = $signed(stage1_x_centered_q) * $signed(stage1_cos_q);
    assign stage2_y_sin_w = $signed(stage1_y_centered_q) * $signed(stage1_sin_q);
    assign stage2_x_sin_w = $signed(stage1_x_centered_q) * $signed(stage1_sin_q);
    assign stage2_y_cos_w = $signed(stage1_y_centered_q) * $signed(stage1_cos_q);

    // Map pixel centers instead of pixel corners:
    // src_x correction = 0.5 * (cos + sin - 1)
    // src_y correction = 0.5 * (sin - cos + 1)
    assign stage3_x_center_corr_w =
        (($signed({{22{stage2_cos_q[9]}}, stage2_cos_q}) +
          $signed({{22{stage2_sin_q[9]}}, stage2_sin_q}) - 32'sd256) >>> 1);
    assign stage3_y_center_corr_w =
        (($signed({{22{stage2_sin_q[9]}}, stage2_sin_q}) -
          $signed({{22{stage2_cos_q[9]}}, stage2_cos_q}) + 32'sd256) >>> 1);

    assign stage3_x_acc_w    = (stage2_x_cos_q - stage2_y_sin_q) + stage3_x_center_corr_w + 32'sd128;
    assign stage3_y_acc_w    = (stage2_x_sin_q + stage2_y_cos_q) + stage3_y_center_corr_w + 32'sd128;
    assign stage3_x_rotate_w = stage3_x_acc_w >>> 8;
    assign stage3_y_rotate_w = stage3_y_acc_w >>> 8;
    assign stage4_calc_src_x_w = stage3_raw_copy_q ?
                                 $signed({1'b0, stage3_out_x_q}) :
                                 (stage3_x_rotate_q + X_CENTER_S32);
    assign stage4_calc_src_y_w = stage3_raw_copy_q ?
                                 $signed({1'b0, stage3_out_y_q}) :
                                 (Y_CENTER_S32 - stage3_y_rotate_q);

    rotate_trig_lut u_rotate_trig_lut (
        .clk       (clk),
        .rst_n     (rst_n),
        .cfg_valid (cfg_valid),
        .angle_deg (cfg_angle_deg),
        .sin_value (sin_cfg_w),
        .cos_value (cos_cfg_w)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            active_angle_q        <= 9'd0;
            sin_active_q          <= 10'sd0;
            cos_active_q          <= 10'sd256;
            stage0_valid_q        <= 1'b0;
            stage0_raw_copy_q     <= 1'b0;
            stage0_out_x_q        <= 16'd0;
            stage0_out_y_q        <= 16'd0;
            stage0_sin_q          <= 10'sd0;
            stage0_cos_q          <= 10'sd256;
            stage1_valid_q        <= 1'b0;
            stage1_raw_copy_q     <= 1'b0;
            stage1_out_x_q        <= 16'd0;
            stage1_out_y_q        <= 16'd0;
            stage1_x_centered_q   <= 17'sd0;
            stage1_y_centered_q   <= 17'sd0;
            stage1_sin_q          <= 10'sd0;
            stage1_cos_q          <= 10'sd256;
            stage2_valid_q        <= 1'b0;
            stage2_raw_copy_q     <= 1'b0;
            stage2_out_x_q        <= 16'd0;
            stage2_out_y_q        <= 16'd0;
            stage2_sin_q          <= 10'sd0;
            stage2_cos_q          <= 10'sd256;
            stage2_x_cos_q        <= 32'sd0;
            stage2_y_sin_q        <= 32'sd0;
            stage2_x_sin_q        <= 32'sd0;
            stage2_y_cos_q        <= 32'sd0;
            stage3_valid_q        <= 1'b0;
            stage3_raw_copy_q     <= 1'b0;
            stage3_out_x_q        <= 16'd0;
            stage3_out_y_q        <= 16'd0;
            stage3_x_rotate_q     <= 32'sd0;
            stage3_y_rotate_q     <= 32'sd0;
            stage4_valid_q        <= 1'b0;
            stage4_src_x_q        <= 32'sd0;
            stage4_src_y_q        <= 32'sd0;
            stage4_src_inside_q   <= 1'b0;
        end else begin
            if (cfg_valid) begin
                active_angle_q <= cfg_angle_deg;
            end
            sin_active_q <= sin_cfg_w;
            cos_active_q <= cos_cfg_w;

            stage0_valid_q <= request_valid;
            if (request_valid) begin
                stage0_raw_copy_q <= (FORCE_RAW_COPY != 0);
                stage0_out_x_q    <= out_x;
                stage0_out_y_q    <= out_y;
                stage0_sin_q      <= sin_active_q;
                stage0_cos_q      <= cos_active_q;
            end

            stage1_valid_q      <= stage0_valid_q;
            stage1_raw_copy_q   <= stage0_raw_copy_q;
            stage1_out_x_q      <= stage0_out_x_q;
            stage1_out_y_q      <= stage0_out_y_q;
            stage1_x_centered_q <= stage1_x_centered_w;
            stage1_y_centered_q <= stage1_y_centered_w;
            stage1_sin_q        <= stage0_sin_q;
            stage1_cos_q        <= stage0_cos_q;

            stage2_valid_q    <= stage1_valid_q;
            stage2_raw_copy_q <= stage1_raw_copy_q;
            stage2_out_x_q    <= stage1_out_x_q;
            stage2_out_y_q    <= stage1_out_y_q;
            stage2_sin_q      <= stage1_sin_q;
            stage2_cos_q      <= stage1_cos_q;
            stage2_x_cos_q    <= stage2_x_cos_w;
            stage2_y_sin_q    <= stage2_y_sin_w;
            stage2_x_sin_q    <= stage2_x_sin_w;
            stage2_y_cos_q    <= stage2_y_cos_w;

            stage3_valid_q    <= stage2_valid_q;
            stage3_raw_copy_q <= stage2_raw_copy_q;
            stage3_out_x_q    <= stage2_out_x_q;
            stage3_out_y_q    <= stage2_out_y_q;
            stage3_x_rotate_q <= stage3_x_rotate_w;
            stage3_y_rotate_q <= stage3_y_rotate_w;

            stage4_valid_q      <= stage3_valid_q;
            stage4_src_x_q      <= stage4_calc_src_x_w;
            stage4_src_y_q      <= stage4_calc_src_y_w;
            stage4_src_inside_q <= stage3_valid_q &&
                                   (stage4_calc_src_x_w >= 0) &&
                                   (stage4_calc_src_x_w < IMAGE_W) &&
                                   (stage4_calc_src_y_w >= 0) &&
                                   (stage4_calc_src_y_w < IMAGE_H);
        end
    end

endmodule
