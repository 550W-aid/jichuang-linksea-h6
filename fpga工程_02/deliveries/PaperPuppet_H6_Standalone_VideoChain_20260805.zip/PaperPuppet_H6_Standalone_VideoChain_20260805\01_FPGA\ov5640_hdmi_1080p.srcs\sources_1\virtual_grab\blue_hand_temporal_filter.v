`timescale 1ns / 1ps

module blue_hand_temporal_filter #(
    parameter integer X_WIDTH = 12,
    parameter integer Y_WIDTH = 12,
    parameter integer COUNT_W = 24,
    parameter integer HOLD_FRAMES = 15
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 frame_tick,
    input  wire                 candidate_valid,
    input  wire [X_WIDTH-1:0]   candidate_x,
    input  wire [Y_WIDTH-1:0]   candidate_y,
    input  wire [COUNT_W-1:0]   candidate_pixel_count,
    input  wire [X_WIDTH-1:0]   candidate_min_x,
    input  wire [X_WIDTH-1:0]   candidate_max_x,
    input  wire [Y_WIDTH-1:0]   candidate_min_y,
    input  wire [Y_WIDTH-1:0]   candidate_max_y,
    output reg                  track_valid,
    output reg  [X_WIDTH-1:0]   track_x,
    output reg  [Y_WIDTH-1:0]   track_y,
    output reg  [COUNT_W-1:0]   track_pixel_count,
    output reg  [X_WIDTH-1:0]   track_min_x,
    output reg  [X_WIDTH-1:0]   track_max_x,
    output reg  [Y_WIDTH-1:0]   track_min_y,
    output reg  [Y_WIDTH-1:0]   track_max_y
);

    reg [7:0] miss_count_reg;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            track_valid <= 1'b0;
            track_x <= {X_WIDTH{1'b0}};
            track_y <= {Y_WIDTH{1'b0}};
            track_pixel_count <= {COUNT_W{1'b0}};
            track_min_x <= {X_WIDTH{1'b0}};
            track_max_x <= {X_WIDTH{1'b0}};
            track_min_y <= {Y_WIDTH{1'b0}};
            track_max_y <= {Y_WIDTH{1'b0}};
            miss_count_reg <= 8'd0;
        end else if (frame_tick) begin
            if (candidate_valid) begin
                track_valid <= 1'b1;
                track_x <= candidate_x;
                track_y <= candidate_y;
                track_pixel_count <= candidate_pixel_count;
                track_min_x <= candidate_min_x;
                track_max_x <= candidate_max_x;
                track_min_y <= candidate_min_y;
                track_max_y <= candidate_max_y;
                miss_count_reg <= 8'd0;
            end else if (track_valid) begin
                if ((HOLD_FRAMES <= 1) ||
                    (miss_count_reg >= (HOLD_FRAMES - 1))) begin
                    track_valid <= 1'b0;
                    track_x <= {X_WIDTH{1'b0}};
                    track_y <= {Y_WIDTH{1'b0}};
                    track_pixel_count <= {COUNT_W{1'b0}};
                    track_min_x <= {X_WIDTH{1'b0}};
                    track_max_x <= {X_WIDTH{1'b0}};
                    track_min_y <= {Y_WIDTH{1'b0}};
                    track_max_y <= {Y_WIDTH{1'b0}};
                    miss_count_reg <= 8'd0;
                end else begin
                    miss_count_reg <= miss_count_reg + 8'd1;
                end
            end else begin
                miss_count_reg <= 8'd0;
            end
        end
    end

endmodule
