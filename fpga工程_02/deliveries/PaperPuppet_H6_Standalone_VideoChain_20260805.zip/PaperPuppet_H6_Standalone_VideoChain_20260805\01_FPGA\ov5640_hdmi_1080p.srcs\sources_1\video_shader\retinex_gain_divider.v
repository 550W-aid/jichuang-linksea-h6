// Module Function:
//   Quantizes enhanced/original luma into a five-level Q8 gain. Threshold
//   comparisons replace the original reciprocal ROM and 16x16 multiplier,
//   and a true three-stage pipeline limits fanout while preserving the
//   1.00x to 1.50x range.
module retinex_gain_divider #(
    parameter integer IP_LATENCY = 3
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        in_valid,
    input  wire [15:0] numerator,
    input  wire [7:0]  denominator,
    output wire        out_valid,
    output wire [15:0] quotient_q8
);
    reg stage0_valid_r;
    reg [7:0] stage0_delta_r;
    reg [7:0] stage0_orig_r;

    reg stage1_valid_r;
    reg [12:0] stage1_delta_x32_r;
    reg [10:0] stage1_orig_x1_r;
    reg [10:0] stage1_orig_x3_r;
    reg [10:0] stage1_orig_x5_r;
    reg [10:0] stage1_orig_x7_r;

    reg stage2_valid_r;
    reg [15:0] stage2_scale_q8_r;

    reg [7:0] luma_enh_comb;
    reg [7:0] luma_orig_comb;
    reg [7:0] luma_delta_comb;
    reg [12:0] delta_x32_comb;
    reg [10:0] orig_x1_comb;
    reg [10:0] orig_x3_comb;
    reg [10:0] orig_x5_comb;
    reg [10:0] orig_x7_comb;
    reg [15:0] scale_q8_comb;

    always @* begin
        luma_enh_comb   = numerator[15:8];
        luma_orig_comb  = (denominator <= 8'd1) ? 8'd1 : denominator;
        luma_delta_comb = (luma_enh_comb > luma_orig_comb) ?
                          (luma_enh_comb - luma_orig_comb) : 8'd0;
    end

    always @* begin
        delta_x32_comb = {stage0_delta_r, 5'd0};
        orig_x1_comb   = {3'd0, stage0_orig_r};
        orig_x3_comb   = {3'd0, stage0_orig_r} +
                         ({3'd0, stage0_orig_r} << 1);
        orig_x5_comb   = {3'd0, stage0_orig_r} +
                         ({3'd0, stage0_orig_r} << 2);
        orig_x7_comb   = ({3'd0, stage0_orig_r} << 3) -
                         {3'd0, stage0_orig_r};
    end

    always @* begin
        scale_q8_comb   = 16'd256;
        if (stage1_delta_x32_r >= stage1_orig_x7_r) begin
            scale_q8_comb = 16'd384;
        end else if (stage1_delta_x32_r >= stage1_orig_x5_r) begin
            scale_q8_comb = 16'd352;
        end else if (stage1_delta_x32_r >= stage1_orig_x3_r) begin
            scale_q8_comb = 16'd320;
        end else if (stage1_delta_x32_r >= stage1_orig_x1_r) begin
            scale_q8_comb = 16'd288;
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            stage0_valid_r      <= 1'b0;
            stage0_delta_r      <= 8'd0;
            stage0_orig_r       <= 8'd1;
            stage1_valid_r      <= 1'b0;
            stage1_delta_x32_r  <= 13'd0;
            stage1_orig_x1_r    <= 11'd1;
            stage1_orig_x3_r    <= 11'd3;
            stage1_orig_x5_r    <= 11'd5;
            stage1_orig_x7_r    <= 11'd7;
            stage2_valid_r      <= 1'b0;
            stage2_scale_q8_r   <= 16'd256;
        end else begin
            stage0_valid_r <= in_valid;
            if (in_valid) begin
                stage0_delta_r <= luma_delta_comb;
                stage0_orig_r  <= luma_orig_comb;
            end

            stage1_valid_r <= stage0_valid_r;
            if (stage0_valid_r) begin
                stage1_delta_x32_r <= delta_x32_comb;
                stage1_orig_x1_r   <= orig_x1_comb;
                stage1_orig_x3_r   <= orig_x3_comb;
                stage1_orig_x5_r   <= orig_x5_comb;
                stage1_orig_x7_r   <= orig_x7_comb;
            end

            stage2_valid_r <= stage1_valid_r;
            if (stage1_valid_r) begin
                stage2_scale_q8_r <= scale_q8_comb;
            end
        end
    end

    assign out_valid   = stage2_valid_r;
    assign quotient_q8 = stage2_scale_q8_r;

    // The project integration fixes this compatibility parameter at three;
    // keeping it in the interface avoids changing the surrounding wrappers.
    wire unused_ip_latency_w = (IP_LATENCY != 3);
endmodule
