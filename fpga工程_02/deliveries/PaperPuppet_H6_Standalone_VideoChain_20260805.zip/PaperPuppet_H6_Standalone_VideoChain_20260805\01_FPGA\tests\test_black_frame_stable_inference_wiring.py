from pathlib import Path
import re
import unittest


RTL = (
    Path(__file__).resolve().parents[1]
    / "ov5640_hdmi_1080p.srcs"
    / "sources_1"
    / "virtual_grab"
    / "unified_virtual_grab_feature.v"
)


class BlackFrameStableInferenceWiringTest(unittest.TestCase):
    def test_tracker_uses_green_anchor_geometry_not_partial_black_band(self) -> None:
        source = RTL.read_text(encoding="utf-8")

        self.assertRegex(source, r"\.green_anchor_valid\s*\(green_anchor_valid_w\)")
        self.assertRegex(source, r"green_anchor_width_w\s*>=\s*13'd96")
        self.assertRegex(source, r"green_anchor_width_w\s*<=\s*13'd320")
        self.assertRegex(source, r"green_anchor_height_w\s*>=\s*13'd32")
        self.assertRegex(source, r"green_anchor_height_w\s*<=\s*13'd220")
        self.assertRegex(source, r"\.inferred_valid\s*\(frame_inferred_valid_w\)")
        self.assertNotRegex(source, r"\.inferred_valid\s*\(frame_candidate_valid_w\)")


if __name__ == "__main__":
    unittest.main()
