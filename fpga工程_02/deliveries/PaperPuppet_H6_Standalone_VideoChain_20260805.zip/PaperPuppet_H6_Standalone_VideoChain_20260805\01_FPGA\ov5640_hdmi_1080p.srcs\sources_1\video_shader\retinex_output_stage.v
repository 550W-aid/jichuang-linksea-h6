// Module Function:
//   Applies quantized Retinex gain and a monotonic per-channel shadow curve,
//   then blends in eight strength steps and saturates aligned RGB888 pixels.
//   The pointwise curve preserves dark color ratios without line state.
module retinex_output_stage #(
    parameter SCALE_MAX_Q8 = 16'd384,
    parameter EDGE_GAIN    = 1,
    parameter SHADOW_TARGET = 192,
    parameter SHADOW_LOW_KNEE = 64,
    parameter MUL_LATENCY  = 2
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        in_valid,
    input  wire        in_sof,
    input  wire        in_eol,
    input  wire [7:0]  in_r,
    input  wire [7:0]  in_g,
    input  wire [7:0]  in_b,
    input  wire [7:0]  in_luma_orig,
    input  wire [7:0]  in_blur,
    input  wire [7:0]  in_lowlight_level,
    input  wire [15:0] scale_q8_i,
    output reg         out_valid,
    output reg         out_sof,
    output reg         out_eol,
    output reg [7:0]   out_r,
    output reg [7:0]   out_g,
    output reg [7:0]   out_b
);
    localparam signed [15:0] EDGE_GAIN_S = EDGE_GAIN;

    function [9:0] apply_gain_shift;
        input [7:0] value;
        input [15:0] scale_q8;
        reg [9:0] base;
        begin
            base = {2'd0, value};
            if (scale_q8 <= 16'd256) begin
                apply_gain_shift = base;
            end else if (scale_q8 <= 16'd288) begin
                apply_gain_shift = base + (value >> 3);
            end else if (scale_q8 <= 16'd320) begin
                apply_gain_shift = base + (value >> 2);
            end else if (scale_q8 <= 16'd352) begin
                apply_gain_shift = base + (value >> 2) + (value >> 3);
            end else begin
                apply_gain_shift = base + (value >> 1);
            end
        end
    endfunction

    function [7:0] clamp_u8_from_wide;
        input signed [17:0] value;
        begin
            if (value < 0) begin
                clamp_u8_from_wide = 8'd0;
            end else if (value > 18'sd255) begin
                clamp_u8_from_wide = 8'd255;
            end else begin
                clamp_u8_from_wide = value[7:0];
            end
        end
    endfunction

    function [8:0] apply_shadow_curve;
        input [7:0] value;
        begin
            if (value < SHADOW_LOW_KNEE[7:0]) begin
                apply_shadow_curve = {1'b0, value} << 1;
            end else if (value < SHADOW_TARGET[7:0]) begin
                apply_shadow_curve = ({1'b0, value} >> 1) +
                                     ({1'b0, SHADOW_TARGET[7:0]} >> 1);
            end else begin
                apply_shadow_curve = {1'b0, value};
            end
        end
    endfunction

    reg [15:0] scale_limited_comb;
    reg signed [9:0] edge_delta_comb;
    reg signed [15:0] edge_boost_comb;
    reg [9:0] scaled_r_comb;
    reg [9:0] scaled_g_comb;
    reg [9:0] scaled_b_comb;
    reg [8:0] shadow_r_comb;
    reg [8:0] shadow_g_comb;
    reg [8:0] shadow_b_comb;
    reg signed [17:0] tone_r_comb;
    reg signed [17:0] tone_g_comb;
    reg signed [17:0] tone_b_comb;
    reg signed [17:0] retinex_r_comb;
    reg signed [17:0] retinex_g_comb;
    reg signed [17:0] retinex_b_comb;
    reg signed [17:0] enhanced_r_comb;
    reg signed [17:0] enhanced_g_comb;
    reg signed [17:0] enhanced_b_comb;

    reg stage0_valid_r;
    reg stage0_sof_r;
    reg stage0_eol_r;
    reg [7:0] stage0_base_r_r;
    reg [7:0] stage0_base_g_r;
    reg [7:0] stage0_base_b_r;
    reg [7:0] stage0_level_r;
    reg signed [17:0] stage0_enh_r_r;
    reg signed [17:0] stage0_enh_g_r;
    reg signed [17:0] stage0_enh_b_r;

    reg signed [17:0] delta_r_comb;
    reg signed [17:0] delta_g_comb;
    reg signed [17:0] delta_b_comb;
    reg signed [17:0] blend_r_comb;
    reg signed [17:0] blend_g_comb;
    reg signed [17:0] blend_b_comb;
    reg [3:0] blend_step_comb;

    reg stage1_valid_r;
    reg stage1_sof_r;
    reg stage1_eol_r;
    reg [7:0] stage1_base_r_r;
    reg [7:0] stage1_base_g_r;
    reg [7:0] stage1_base_b_r;
    reg signed [17:0] stage1_delta_r_r;
    reg signed [17:0] stage1_delta_g_r;
    reg signed [17:0] stage1_delta_b_r;
    reg [3:0] stage1_step_r;

    reg stage2_valid_r;
    reg stage2_sof_r;
    reg stage2_eol_r;
    reg signed [17:0] stage2_r_r;
    reg signed [17:0] stage2_g_r;
    reg signed [17:0] stage2_b_r;

    always @* begin
        scale_limited_comb = (scale_q8_i > SCALE_MAX_Q8) ?
                             SCALE_MAX_Q8 : scale_q8_i;
        edge_delta_comb = $signed({1'b0, in_luma_orig}) -
                          $signed({1'b0, in_blur});
        edge_boost_comb = edge_delta_comb * EDGE_GAIN_S;
        scaled_r_comb = apply_gain_shift(in_r, scale_limited_comb);
        scaled_g_comb = apply_gain_shift(in_g, scale_limited_comb);
        scaled_b_comb = apply_gain_shift(in_b, scale_limited_comb);
        shadow_r_comb = apply_shadow_curve(in_r);
        shadow_g_comb = apply_shadow_curve(in_g);
        shadow_b_comb = apply_shadow_curve(in_b);
        tone_r_comb = $signed({9'd0, shadow_r_comb});
        tone_g_comb = $signed({9'd0, shadow_g_comb});
        tone_b_comb = $signed({9'd0, shadow_b_comb});
        retinex_r_comb = $signed({1'b0, scaled_r_comb}) + edge_boost_comb;
        retinex_g_comb = $signed({1'b0, scaled_g_comb}) + edge_boost_comb;
        retinex_b_comb = $signed({1'b0, scaled_b_comb}) + edge_boost_comb;
        enhanced_r_comb = (retinex_r_comb > tone_r_comb) ?
                          retinex_r_comb : tone_r_comb;
        enhanced_g_comb = (retinex_g_comb > tone_g_comb) ?
                          retinex_g_comb : tone_g_comb;
        enhanced_b_comb = (retinex_b_comb > tone_b_comb) ?
                          retinex_b_comb : tone_b_comb;
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            stage0_valid_r <= 1'b0;
            stage0_sof_r   <= 1'b0;
            stage0_eol_r   <= 1'b0;
        end else begin
            stage0_valid_r <= in_valid;
            stage0_sof_r   <= in_sof;
            stage0_eol_r   <= in_eol;
            if (in_valid) begin
                stage0_base_r_r <= in_r;
                stage0_base_g_r <= in_g;
                stage0_base_b_r <= in_b;
                stage0_level_r  <= in_lowlight_level;
                stage0_enh_r_r  <= enhanced_r_comb;
                stage0_enh_g_r  <= enhanced_g_comb;
                stage0_enh_b_r  <= enhanced_b_comb;
            end
        end
    end

    always @* begin
        delta_r_comb = stage0_enh_r_r - $signed({10'd0, stage0_base_r_r});
        delta_g_comb = stage0_enh_g_r - $signed({10'd0, stage0_base_g_r});
        delta_b_comb = stage0_enh_b_r - $signed({10'd0, stage0_base_b_r});
        blend_step_comb = (stage0_level_r == 8'd0) ? 4'd0 :
                          ({1'b0, stage0_level_r[7:5]} + 4'd1);
    end

    always @* begin
        case (stage1_step_r)
            4'd0: begin
                blend_r_comb = $signed({10'd0, stage1_base_r_r});
                blend_g_comb = $signed({10'd0, stage1_base_g_r});
                blend_b_comb = $signed({10'd0, stage1_base_b_r});
            end
            4'd1: begin
                blend_r_comb = $signed({10'd0, stage1_base_r_r}) + (stage1_delta_r_r >>> 3);
                blend_g_comb = $signed({10'd0, stage1_base_g_r}) + (stage1_delta_g_r >>> 3);
                blend_b_comb = $signed({10'd0, stage1_base_b_r}) + (stage1_delta_b_r >>> 3);
            end
            4'd2: begin
                blend_r_comb = $signed({10'd0, stage1_base_r_r}) + (stage1_delta_r_r >>> 2);
                blend_g_comb = $signed({10'd0, stage1_base_g_r}) + (stage1_delta_g_r >>> 2);
                blend_b_comb = $signed({10'd0, stage1_base_b_r}) + (stage1_delta_b_r >>> 2);
            end
            4'd3: begin
                blend_r_comb = $signed({10'd0, stage1_base_r_r}) +
                               (stage1_delta_r_r >>> 2) + (stage1_delta_r_r >>> 3);
                blend_g_comb = $signed({10'd0, stage1_base_g_r}) +
                               (stage1_delta_g_r >>> 2) + (stage1_delta_g_r >>> 3);
                blend_b_comb = $signed({10'd0, stage1_base_b_r}) +
                               (stage1_delta_b_r >>> 2) + (stage1_delta_b_r >>> 3);
            end
            4'd4: begin
                blend_r_comb = $signed({10'd0, stage1_base_r_r}) + (stage1_delta_r_r >>> 1);
                blend_g_comb = $signed({10'd0, stage1_base_g_r}) + (stage1_delta_g_r >>> 1);
                blend_b_comb = $signed({10'd0, stage1_base_b_r}) + (stage1_delta_b_r >>> 1);
            end
            4'd5: begin
                blend_r_comb = $signed({10'd0, stage1_base_r_r}) +
                               (stage1_delta_r_r >>> 1) + (stage1_delta_r_r >>> 3);
                blend_g_comb = $signed({10'd0, stage1_base_g_r}) +
                               (stage1_delta_g_r >>> 1) + (stage1_delta_g_r >>> 3);
                blend_b_comb = $signed({10'd0, stage1_base_b_r}) +
                               (stage1_delta_b_r >>> 1) + (stage1_delta_b_r >>> 3);
            end
            4'd6: begin
                blend_r_comb = $signed({10'd0, stage1_base_r_r}) +
                               (stage1_delta_r_r >>> 1) + (stage1_delta_r_r >>> 2);
                blend_g_comb = $signed({10'd0, stage1_base_g_r}) +
                               (stage1_delta_g_r >>> 1) + (stage1_delta_g_r >>> 2);
                blend_b_comb = $signed({10'd0, stage1_base_b_r}) +
                               (stage1_delta_b_r >>> 1) + (stage1_delta_b_r >>> 2);
            end
            4'd7: begin
                blend_r_comb = $signed({10'd0, stage1_base_r_r}) +
                               stage1_delta_r_r - (stage1_delta_r_r >>> 3);
                blend_g_comb = $signed({10'd0, stage1_base_g_r}) +
                               stage1_delta_g_r - (stage1_delta_g_r >>> 3);
                blend_b_comb = $signed({10'd0, stage1_base_b_r}) +
                               stage1_delta_b_r - (stage1_delta_b_r >>> 3);
            end
            default: begin
                blend_r_comb = $signed({10'd0, stage1_base_r_r}) + stage1_delta_r_r;
                blend_g_comb = $signed({10'd0, stage1_base_g_r}) + stage1_delta_g_r;
                blend_b_comb = $signed({10'd0, stage1_base_b_r}) + stage1_delta_b_r;
            end
        endcase
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            stage1_valid_r <= 1'b0;
            stage1_sof_r   <= 1'b0;
            stage1_eol_r   <= 1'b0;
        end else begin
            stage1_valid_r <= stage0_valid_r;
            stage1_sof_r   <= stage0_sof_r;
            stage1_eol_r   <= stage0_eol_r;
            if (stage0_valid_r) begin
                stage1_base_r_r  <= stage0_base_r_r;
                stage1_base_g_r  <= stage0_base_g_r;
                stage1_base_b_r  <= stage0_base_b_r;
                stage1_delta_r_r <= delta_r_comb;
                stage1_delta_g_r <= delta_g_comb;
                stage1_delta_b_r <= delta_b_comb;
                stage1_step_r    <= blend_step_comb;
            end
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            stage2_valid_r <= 1'b0;
            stage2_sof_r   <= 1'b0;
            stage2_eol_r   <= 1'b0;
        end else begin
            stage2_valid_r <= stage1_valid_r;
            stage2_sof_r   <= stage1_sof_r;
            stage2_eol_r   <= stage1_eol_r;
            if (stage1_valid_r) begin
                stage2_r_r <= blend_r_comb;
                stage2_g_r <= blend_g_comb;
                stage2_b_r <= blend_b_comb;
            end
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            out_valid <= 1'b0;
            out_sof   <= 1'b0;
            out_eol   <= 1'b0;
        end else begin
            out_valid <= stage2_valid_r;
            out_sof   <= stage2_sof_r;
            out_eol   <= stage2_eol_r;
            if (stage2_valid_r) begin
                out_r <= clamp_u8_from_wide(stage2_r_r);
                out_g <= clamp_u8_from_wide(stage2_g_r);
                out_b <= clamp_u8_from_wide(stage2_b_r);
            end
        end
    end

    wire unused_mul_latency_w = (MUL_LATENCY != 0);
endmodule
