﻿set scriptDir [file dirname [file normalize [info script]]]
set projectDir [file normalize [file join $scriptDir ".."]]
cd "D:/eLinx3.0/bin/shell/bin"
set projectName ov5640_hdmi_1080p
set ImpleName imple_1
set vecname $projectName

set_global_assignment -name TOP_LEVEL_ENTITY TOP1
set_global_assignment -name DESIGN_PATH $projectDir
set_global_assignment -name PROJECT_NAME $projectName
set_global_assignment -name DEVICE_SERIES eHiChip6
set_global_assignment -name DEVICE_NAME EQ6HL130

load_pb_ver $projectDir/$projectName.runs/$ImpleName/$vecname.ver.pb
load_time_model ../Infrastructure/psk_intern/eHiChip6/EQ6HL130/

if {[catch {deserialize_timing_graph $projectDir/$projectName.runs/$ImpleName/$vecname.tbg.pb} err]} {
    puts "DESERIALIZE_GRAPH_ERROR=$err"
    exit 1
}
if {[catch {deserialize_timing_delay $projectDir/$projectName.runs/$ImpleName/$vecname} err]} {
    puts "DESERIALIZE_DELAY_ERROR=$err"
    exit 1
}
if {[catch {do_timing_analysis} err]} {
    puts "TIMING_ANALYSIS_ERROR=$err"
    exit 1
}
if {[catch {set report_result [print_timing_report $projectDir/$projectName.runs/$ImpleName/$vecname.tan.rpt]} err]} {
    puts "PRINT_REPORT_ERROR=$err"
    exit 1
}

puts "PRINT_REPORT_RESULT=$report_result"
puts "TIMING_REPORT_OK"
free_timing_graph
exit 0

