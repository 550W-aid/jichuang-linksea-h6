// ============================================================================
// Module Function:
//   Captures the PHY GMII receive bus at the center of its source-synchronous
//   data eye so RXD and RX_CTL reach protocol logic as an aligned byte.
// ============================================================================
module gmii_rx_input_capture (
    input  wire       rx_clk_i,
    input  wire       rx_ctl_i,
    input  wire [7:0] rx_data_i,
    output wire       rx_ctl_o,
    output wire [7:0] rx_data_o
);

(* preserve, noprune, altera_attribute = "-name DONT_MERGE_REGISTER ON; -name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *)
reg       rx_ctl_r;
(* preserve, noprune, altera_attribute = "-name DONT_MERGE_REGISTER ON; -name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *)
reg [7:0] rx_data_r;
(* preserve, noprune, altera_attribute = "-name DONT_MERGE_REGISTER ON; -name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *)
reg       rx_ctl_aligned_r;
(* preserve, noprune, altera_attribute = "-name DONT_MERGE_REGISTER ON; -name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *)
reg [7:0] rx_data_aligned_r;

assign rx_ctl_o  = rx_ctl_aligned_r;
assign rx_data_o = rx_data_aligned_r;

// The PHY changes its GMII outputs around the rising edge. Sampling on the
// falling edge moves the input register to the middle of the valid byte eye;
// the next rising edge then gives downstream logic half a cycle to capture it.
// No reset is needed because the PHY remains in hardware reset for 20 ms.
always @(negedge rx_clk_i) begin
    rx_ctl_r  <= rx_ctl_i;
    rx_data_r <= rx_data_i;
end

// Isolate the half-cycle input path from downstream fanout. Only these nine
// local registers consume the falling-edge sample; all protocol logic receives
// the aligned rising-edge copy and therefore has a full cycle for processing.
always @(posedge rx_clk_i) begin
    rx_ctl_aligned_r  <= rx_ctl_r;
    rx_data_aligned_r <= rx_data_r;
end

endmodule
