// ============================================================================
// Module Function:
//   Merged system core: Ethernet video/image receive path, dual-SDRAM frame buffering, HDMI output, diagnostics, and rotate overlay hookup.
// ============================================================================
`timescale 1ns/1ps

module eth_video_rotate_system
(
    input  wire        sys_clk,
    input  wire        sys_rst_n,
    input  wire        key2_n,
    input  wire        key3_n,
    input  wire        key4_n,
    input  wire        ov5640_pclk,
    input  wire        ov5640_vsync,
    input  wire        ov5640_href,
    input  wire [7:0]  ov5640_data,
    output wire        ov5640_rst_n,
    output wire        ov5640_pwdn,
    output wire        sccb_scl,
    inout  wire        sccb_sda,
    input  wire        eth_rxc,
    input  wire        eth_rx_ctl,
    input  wire        eth_txc,
    input  wire [7:0]  eth_rxd,
    output wire        eth_tx_ctl,
    output wire [7:0]  eth_txd,
    output wire        GTX_CLK,
    output wire        eth_rst_n,
    output wire        eth_tx_er,
    inout  wire        eth_mdio,
    output wire        eth_mdc,
    output wire        sdram1_clk,
    output wire        sdram1_cke,
    output wire        sdram1_cs_n,
    output wire        sdram1_ras_n,
    output wire        sdram1_cas_n,
    output wire        sdram1_we_n,
    output wire [1:0]  sdram1_ba,
    output wire [12:0] sdram1addr,
    inout  wire [15:0] sdram1_dq,
    output wire        sdram2_clk,
    output wire        sdram2_cke,
    output wire        sdram2_cs_n,
    output wire        sdram2_ras_n,
    output wire        sdram2_cas_n,
    output wire        sdram2_we_n,
    output wire [1:0]  sdram2_ba,
    output wire [12:0] sdram2addr,
    inout  wire [15:0] sdram2_dq,
    output wire        ddc_scl,
    inout  wire        ddc_sda,
    output wire        hdmi_out_clk,
    output wire        hdmi_out_hsync,
    output wire        hdmi_out_vsync,
    output wire [23:0] hdmi_out_rgb,
    output wire        hdmi_out_de,
    output wire        hdmi_reset_n,
    output wire        ov5640_xclk,
    input  wire        uart_rxd,
    output wire        uart_txd,
    output wire        uart1_txd,
    input  wire [7:0]  fsmc_addr,
    inout  wire [15:0] fsmc_data,
    input  wire        fsmc_cs_n,
    input  wire        fsmc_rd_n,
    input  wire        fsmc_wr_n,
    output wire        fsmc_int,
    output wire        led1,
    output wire        led2,
    output wire        led3,
    output wire        led4
);

`ifdef ETH_REF_ONLY_TOP

wire        clk_125m_refonly_w;
wire        clk_125m_tx_shift_refonly_w;
wire        pll1_locked_refonly_w;
wire [1:0]  eth_speed_led_refonly_w;
wire        eth_rx_pkt_seen_sys_w;
wire [7:0]  eth_tx_clk_mon_sys_w;
wire [15:0] eth_rx_last_len_sys_w;
wire [7:0]  eth_rx_last_data_sys_w;
wire [7:0]  eth_dbg_rx_pkt_cnt_w;
wire [7:0]  eth_dbg_raw_rx_cnt_w;
wire [31:0] eth_arp_dbg_counts_sys_w;
wire [31:0] eth_arp_des_ip_sys_w;
wire [95:0] eth_raw_rx_head_sys_w;
wire [95:0] eth_raw_tx_head_sys_w;
wire        eth_tx_ctl_udp_sys_w;
wire        dbg_arp_tx_en_sys_w;
wire [47:0] eth_arp_des_mac_sys_w;

reg  [7:0]  eth_dbg_rx_pkt_cnt_d_r;
reg  [15:0] uart_len_latched_r;
reg         uart_msg_pending_r;
reg  [3:0]  uart_msg_idx_r;
reg  [1:0]  uart_state_r;
reg  [7:0]  uart_data_r;
reg         uart_valid_r;
wire        uart_busy_w;

localparam [1:0] UART_ST_IDLE = 2'd0;
localparam [1:0] UART_ST_BUSY = 2'd1;
localparam [1:0] UART_ST_WAIT = 2'd2;

function [7:0] refonly_hex_ascii;
    input [3:0] value;
    begin
        refonly_hex_ascii = (value < 4'd10) ? (8'h30 + value) :
                            (8'h41 + value - 4'd10);
    end
endfunction

function [7:0] refonly_uart_byte;
    input [3:0] index;
    input [15:0] length;
    begin
        case (index)
            4'd0: refonly_uart_byte = "R";
            4'd1: refonly_uart_byte = "X";
            4'd2: refonly_uart_byte = "=";
            4'd3: refonly_uart_byte = refonly_hex_ascii(length[15:12]);
            4'd4: refonly_uart_byte = refonly_hex_ascii(length[11:8]);
            4'd5: refonly_uart_byte = refonly_hex_ascii(length[7:4]);
            4'd6: refonly_uart_byte = refonly_hex_ascii(length[3:0]);
            4'd7: refonly_uart_byte = 8'h0d;
            default: refonly_uart_byte = 8'h0a;
        endcase
    end
endfunction

clk_hdmi_1080p clk_eth_refonly_125m_inst(
    .areset (1'b0),
    .inclk0 (sys_clk),
    .c0     (clk_125m_refonly_w),
    .c1     (clk_125m_tx_shift_refonly_w),
    .locked (pll1_locked_refonly_w)
);

eth_board_bringup #(
    .BOARD_VIDEO_ONLY       (1'b0),
    .ENABLE_UDP_DIAG_TX     (1'b0),
    .UDP_LOOPBACK_MAX_BYTES (16'd1472)
) eth_board_bringup_refonly_inst (
    .sys_clk                (sys_clk),
    .sys_rst_n              (sys_rst_n),
    .clk_125MHz             (clk_125m_refonly_w),
    .clk_125MHz_tx_shift    (clk_125m_tx_shift_refonly_w),
    .eth_rxc                (eth_rxc),
    .eth_rx_ctl             (eth_rx_ctl),
    .eth_txc                (eth_txc),
    .eth_rxd                (eth_rxd),
    .eth_tx_ctl             (eth_tx_ctl),
    .eth_txd                (eth_txd),
    .GTX_CLK                (GTX_CLK),
    .eth_rst_n              (eth_rst_n),
    .eth_tx_er              (eth_tx_er),
    .touch_key              (key2_n),
    .i_Key_GBCR             (key3_n),
    .i_Key_ANAR             (key4_n),
    .eth_mdio               (eth_mdio),
    .eth_mdc                (eth_mdc),
    .EthSpeedLED            (eth_speed_led_refonly_w),
    .eth_rx_pkt_seen_sys_d1 (eth_rx_pkt_seen_sys_w),
    .eth_tx_clk_mon_sys_d1  (eth_tx_clk_mon_sys_w),
    .eth_rx_last_len_sys_d1 (eth_rx_last_len_sys_w),
    .eth_rx_last_data_sys_d1(eth_rx_last_data_sys_w),
    .eth_dbg_rx_pkt_cnt     (eth_dbg_rx_pkt_cnt_w),
    .eth_dbg_raw_rx_cnt     (eth_dbg_raw_rx_cnt_w),
    .eth_arp_dbg_counts_sys_d1(eth_arp_dbg_counts_sys_w),
    .eth_arp_des_ip_sys_d1  (eth_arp_des_ip_sys_w),
    .eth_raw_rx_head_sys_d1 (eth_raw_rx_head_sys_w),
    .eth_raw_tx_head_sys_d1 (eth_raw_tx_head_sys_w),
    .eth_tx_ctl_udp_sys_d1  (eth_tx_ctl_udp_sys_w),
    .dbg_arp_tx_en_sys_d1   (dbg_arp_tx_en_sys_w),
    .eth_arp_des_mac_sys_d1 (eth_arp_des_mac_sys_w)
);

uart_tx #(
    .CLK_HZ (50_000_000),
    .BAUD   (115200)
) uart_tx_refonly_inst (
    .clk          (sys_clk),
    .rst_n        (sys_rst_n),
    .data_i       (uart_data_r),
    .data_valid_i (uart_valid_r),
    .tx_o         (uart_txd),
    .busy_o       (uart_busy_w)
);

always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        eth_dbg_rx_pkt_cnt_d_r <= 8'd0;
        uart_len_latched_r     <= 16'd0;
        uart_msg_pending_r     <= 1'b0;
        uart_msg_idx_r         <= 4'd0;
        uart_state_r           <= UART_ST_IDLE;
        uart_data_r            <= 8'd0;
        uart_valid_r           <= 1'b0;
    end else begin
        eth_dbg_rx_pkt_cnt_d_r <= eth_dbg_rx_pkt_cnt_w;
        uart_valid_r <= 1'b0;

        if (eth_dbg_rx_pkt_cnt_w != eth_dbg_rx_pkt_cnt_d_r) begin
            uart_len_latched_r <= eth_rx_last_len_sys_w;
            uart_msg_pending_r <= 1'b1;
            uart_msg_idx_r     <= 4'd0;
        end

        case (uart_state_r)
            UART_ST_IDLE: begin
                if (uart_msg_pending_r && !uart_busy_w) begin
                    uart_data_r  <= refonly_uart_byte(uart_msg_idx_r, uart_len_latched_r);
                    uart_valid_r <= 1'b1;
                    uart_state_r <= UART_ST_BUSY;
                end
            end
            UART_ST_BUSY: begin
                if (uart_busy_w) begin
                    uart_state_r <= UART_ST_WAIT;
                end
            end
            default: begin
                if (!uart_busy_w) begin
                    if (uart_msg_idx_r == 4'd8) begin
                        uart_msg_pending_r <= 1'b0;
                        uart_msg_idx_r     <= 4'd0;
                    end else begin
                        uart_msg_idx_r <= uart_msg_idx_r + 4'd1;
                    end
                    uart_state_r <= UART_ST_IDLE;
                end
            end
        endcase
    end
end

assign uart1_txd = uart_txd;

assign ov5640_rst_n = 1'b0;
assign ov5640_pwdn  = 1'b1;
assign sccb_scl     = 1'b1;
assign sccb_sda     = 1'bz;
assign ov5640_xclk  = 1'b0;

assign sdram1_clk   = 1'b0;
assign sdram1_cke   = 1'b0;
assign sdram1_cs_n  = 1'b1;
assign sdram1_ras_n = 1'b1;
assign sdram1_cas_n = 1'b1;
assign sdram1_we_n  = 1'b1;
assign sdram1_ba    = 2'b00;
assign sdram1addr   = 13'd0;
assign sdram1_dq    = 16'hzzzz;

assign sdram2_clk   = 1'b0;
assign sdram2_cke   = 1'b0;
assign sdram2_cs_n  = 1'b1;
assign sdram2_ras_n = 1'b1;
assign sdram2_cas_n = 1'b1;
assign sdram2_we_n  = 1'b1;
assign sdram2_ba    = 2'b00;
assign sdram2addr   = 13'd0;
assign sdram2_dq    = 16'hzzzz;

assign ddc_scl        = 1'b1;
assign ddc_sda        = 1'bz;
assign hdmi_out_clk   = 1'b0;
assign hdmi_out_hsync = 1'b0;
assign hdmi_out_vsync = 1'b0;
assign hdmi_out_rgb   = 24'd0;
assign hdmi_out_de    = 1'b0;
assign hdmi_reset_n   = 1'b0;

// LEDs are low-active: on means the corresponding diagnostic bit is true.
assign led1 = ~pll1_locked_refonly_w;
assign led2 = ~eth_rx_pkt_seen_sys_w;
assign led3 = ~eth_dbg_rx_pkt_cnt_w[0];
assign led4 = ~eth_arp_dbg_counts_sys_w[0];

`else

localparam [23:0] H_PIXEL = 24'd1280;
localparam [23:0] V_PIXEL = 24'd720;
localparam [23:0] FRAME_WORDS = H_PIXEL * V_PIXEL;
localparam [23:0] HALF_FRAME_WORDS = H_PIXEL * (V_PIXEL >> 1);
// Use smaller bursts so read/write arbitration can interleave more often
// under camera traffic instead of blocking on long 512-word transfers.
localparam [9:0]  SDRAM_BURST = 10'd128;
localparam [1:0]  ALGORITHM_IDLE         = 2'd0;
localparam [1:0]  ALGORITHM_ROTATE       = 2'd1;
localparam [1:0]  ALGORITHM_VIRTUAL_GRAB = 2'd2;
localparam [1:0]  ALGORITHM_SHADER       = 2'd3;
localparam        PCLK_FRAME_PIXEL_DIAG_EN = 1'b0;
// Keep per-pixel camera diagnostics off in the stable image; the frame-seen
// latch below remains active, but the wide PCLK counters are timing-expensive.
localparam        PCLK_DIAG_COUNTERS_EN    = 1'b0;
localparam        PCLK_WR_COUNT_DIAG_EN    = 1'b0;
// Diagnostic build: route the compact Ethernet status stream to the CH340
// main UART (COM18). Set to 0 after PHY/ARP board bring-up is complete.
localparam        ETH_SERIAL_DIAG_MODE      = 1'b0;
localparam        COLORBAR_TEST             = 1'b0;
localparam        CAM_PCLK_POLARITY_TEST    = 1'b0;
localparam        CAM_PCLK_SLOW_TEST        = 1'b0;
localparam [1:0]  NEW480_STREAM_MODE        = 2'd0; // default camera display uses odd/even-line dual SDRAM
localparam        NEW480_STREAM_EN          = (NEW480_STREAM_MODE != 2'd0);
localparam        NEW480_SINGLE_SDRAM_EN    = (NEW480_STREAM_MODE == 2'd1);
localparam        NEW480_HALF_LINE_EN       = (NEW480_STREAM_MODE == 2'd2);
localparam        HALF_LINE_TRIPLE_BUFFER_EN = NEW480_HALF_LINE_EN;
localparam [11:0] H_HALF_PIXEL              = 12'd640;
localparam        FPGA_COLORBAR_TEST_EN     = COLORBAR_TEST;
localparam [23:0] HDMI_DBG_PERIOD_CYCLES   = 24'd12_500_000;
localparam [23:0] SLOT0_B_ADDR = 24'd0;
localparam [23:0] SLOT0_E_ADDR = HALF_FRAME_WORDS;
localparam [23:0] SLOT1_B_ADDR = HALF_FRAME_WORDS;
localparam [23:0] SLOT1_E_ADDR = HALF_FRAME_WORDS + HALF_FRAME_WORDS;
localparam [23:0] SLOT2_B_ADDR = HALF_FRAME_WORDS + HALF_FRAME_WORDS;
localparam [23:0] SLOT2_E_ADDR = HALF_FRAME_WORDS + HALF_FRAME_WORDS + HALF_FRAME_WORDS;
// Prime each read FIFO close to full so HDMI is less exposed to SDRAM jitter.
localparam [10:0] RD_FIFO_PRIME_WM = 11'd1792;
localparam [10:0] RD_FIFO_READ_GUARD_WM = 11'd2;
localparam [10:0] WR_COMMIT_SAFE_WM = {1'b0, SDRAM_BURST};
localparam [3:0]  BUF_RST_STRETCH = 4'd8;
localparam [12:0] CAM_COMMIT_DELAY = 13'd4095;
localparam [12:0] WR_COMMIT_GRACE_CYCLES = 13'd2047;

function [23:0] slot_b_addr_fn;
    input [1:0] slot_i;
    begin
        case (slot_i)
            2'd0:    slot_b_addr_fn = SLOT0_B_ADDR;
            2'd1:    slot_b_addr_fn = SLOT1_B_ADDR;
            default: slot_b_addr_fn = SLOT2_B_ADDR;
        endcase
    end
endfunction

function [23:0] slot_e_addr_fn;
    input [1:0] slot_i;
    begin
        case (slot_i)
            2'd0:    slot_e_addr_fn = SLOT0_E_ADDR;
            2'd1:    slot_e_addr_fn = SLOT1_E_ADDR;
            default: slot_e_addr_fn = SLOT2_E_ADDR;
        endcase
    end
endfunction

wire        clk_100m;
wire        clk_100m_shift;
wire        sys_clk2;
wire        clk_24m;
wire        clk_25m;
wire        clk_125m;
wire        clk_125m_tx_shift;
wire        hdmi_clk_74m25_direct;
wire        pll1_locked;
wire        pll_eth_locked;
wire        pll_hdmi_locked;
wire        core_rst_n;
wire        hdmi_rst_n;
wire        hdmi_pix_clk;

wire        cfg_done;
wire        wr_en;
wire [15:0] wr_data;
wire [15:0] rd_data0_w;
wire [15:0] rd_data1_w;
wire [10:0] rd_fifo_num0_w;
wire [10:0] rd_fifo_num1_w;
wire [10:0] rd_fifo_rd_num0_w;
wire [10:0] rd_fifo_rd_num1_w;
wire [10:0] wr_fifo_num0_w;
wire [10:0] wr_fifo_num1_w;
wire        sdram1_init_done;
wire        sdram2_init_done;
wire        hdmi_cfg_done;
wire        hdmi_init_error;
wire        hdmi_cfg_scl_w;
wire        hdmi_sda_oe_w;
wire        hdmi_sda_i_w;
wire        hdmi_reset_ctrl_w;
wire        hdmi_dbg_lo_scl_w;
wire        hdmi_dbg_lo_sda_oe_w;
wire        hdmi_dbg_lo_busy_w;
wire        hdmi_dbg_lo_done_w;
wire        hdmi_dbg_lo_ack_ok_w;
wire        hdmi_dbg_lo_nack_w;
wire        hdmi_dbg_lo_timeout_w;
wire [7:0]  hdmi_dbg_lo_rd_data_w;
wire        hdmi_dbg_hi_scl_w;
wire        hdmi_dbg_hi_sda_oe_w;
wire        hdmi_dbg_hi_busy_w;
wire        hdmi_dbg_hi_done_w;
wire        hdmi_dbg_hi_ack_ok_w;
wire        hdmi_dbg_hi_nack_w;
wire        hdmi_dbg_hi_timeout_w;
wire [7:0]  hdmi_dbg_hi_rd_data_w;
wire        rd_en_w;
wire [11:0] pixel_xpos_w;
wire [11:0] pixel_ypos_w;
wire        video_hs_w;
wire        video_vs_w;
wire        video_de_w;
wire [15:0] video_rgb_w;
wire [15:0] video_pixel_data_w;
wire [23:0] video_rgb888_w;
wire [23:0] fpga_colorbar_rgb_w;
wire        video_hs_raw_w;
wire        video_vs_raw_w;
wire        video_de_raw_w;
wire [23:0] hdmi_rgb_raw_w;
wire [15:0] video_rgb565_raw_w;
wire        video_hs_rotate_w;
wire        video_vs_rotate_w;
wire        video_de_rotate_w;
wire [23:0] hdmi_rgb_rotate_w;
wire        rotate_preview_active_w;
wire        video_hs_out_path_w;
wire        video_vs_out_path_w;
wire        video_de_out_path_w;
wire [23:0] hdmi_rgb_out_path_w;
wire        video_hs_shader_path_w;
wire        video_vs_shader_path_w;
wire        video_de_shader_path_w;
wire [23:0] hdmi_rgb_shader_path_w;
wire        shader_active_hdmi_w;
wire        video_hs_fusion_path_w;
wire        video_vs_fusion_path_w;
wire        video_de_fusion_path_w;
wire [23:0] hdmi_rgb_fusion_path_w;
wire        video_hs_effect_path_w;
wire        video_vs_effect_path_w;
wire        video_de_effect_path_w;
wire [23:0] hdmi_rgb_effect_path_w;
wire [23:0] hdmi_rgb_puppet_path_w;
wire        puppet_enable_hdmi_w;
wire        puppet_target_valid_w;
wire [11:0] puppet_target_center_x_w;
wire [11:0] puppet_target_center_y_w;
wire        fusion_active_hdmi_w;
wire        fusion_lut_ready_hdmi_w;
wire        fusion_output_select_hdmi_w;
wire        first_video_wait_hdmi_w;
wire        cam_dbg_ack_w;
wire        cam_dbg_busy_w;
wire        cam_dbg_done_w;
wire        cam_dbg_timeout_w;
wire [15:0] cam_dbg_addr_w;
wire [7:0]  cam_dbg_data_w;
wire [2:0]  cam_dbg_state_w;
wire [3:0]  cam_dbg_index_w;
reg  [25:0] led_heartbeat_r;

wire        sys_init_done_w;
wire        wr_req0_w;
wire        wr_req1_w;
wire        rd_req0_w;
wire        rd_req1_w;
wire        rd_req0_need_w;
wire        rd_req1_need_w;
wire        rd_req0_empty_need_w;
wire        rd_req1_empty_need_w;
wire        rd_req0_guard_w;
wire        rd_req1_guard_w;
wire        rd_pixel_valid_guard_w;
wire        rd_underflow_toggle_hdmi_w;
wire        rd_underflow_event_100_w;
wire        cam_frame_pulse_100_w;
wire        cam_valid_frame_pulse_100_w;
wire        hdmi_frame_pulse_100_w;
wire        cam_commit_w;
wire        cam_frame_done_w;
wire        hdmi_swap_w;
wire        wr_en_gated_pclk_w;
wire        cam_stream_active_pclk_w;
wire        wr_req_pclk_w;
wire        cam_write_bank_sel_pclk_w;
wire        selected_rd_empty_w;
wire [10:0] selected_rd_fifo_num_w;
wire [10:0] selected_rd_fifo_num_sys_w;
wire [10:0] selected_rd_fifo_num_hdmi_w;
wire [15:0] selected_rd_data_100_w;
wire        display_right_sel_w;
wire        rd_fifo_prime_ok_w;
wire        rd_fifo_prime_ok_sys_w;
wire        rd_fifo0_empty_hdmi_w;
wire        rd_fifo1_empty_hdmi_w;
wire        wr_fifos_below_burst_w;
wire        commit_grace_expired_w;
wire [10:0] diag_slot_state_w;
wire        sdram1_read_valid_w;
wire        sdram2_read_valid_w;
wire [23:0] sdram1_wr_b_addr_w;
wire [23:0] sdram1_wr_e_addr_w;
wire [23:0] sdram1_rd_b_addr_w;
wire [23:0] sdram1_rd_e_addr_w;
wire [23:0] sdram2_wr_b_addr_w;
wire [23:0] sdram2_wr_e_addr_w;
wire [23:0] sdram2_rd_b_addr_w;
wire [23:0] sdram2_rd_e_addr_w;
wire        uart_diag_tx_w;
wire        uart_rx_len_tx_w;
wire        uart_rotate_txd_w;
wire        virtual_grab_uart_txd_w;
wire [1:0]  algorithm_mode_w;
wire        ethernet_source_mode_w;
wire [7:0]  lowlight_level_w;
wire        shader_cfg_toggle_w;
wire        virtual_grab_mode_w;
wire        rotate_mode_w;
wire        shader_mode_w;
wire        fusion_mode_w;
wire [9:0]  shader_control_hdmi_w;
wire        shader_control_hdmi_pulse_w;
wire        shader_control_cdc_busy_w;
wire        ETH_VIDEO_TEST_EN;
wire [23:0] virtual_grab_hdmi_rgb_w;
wire [15:0] rotate_angle_deg_w;
wire        rotate_cfg_toggle_w;
wire [15:0] rotate_active_angle_w;
wire [15:0] rotate_status_w;
wire [15:0] rotate_debug0_w;
wire [15:0] rotate_debug1_w;
wire [15:0] rotate_status_reg_w;

wire        eth_core_rst_n_w;
wire        eth_rx_rec_en_w;
wire [7:0]  eth_rx_rec_data_w;
wire [15:0] eth_rx_rec_byte_num_w;
wire        eth_rx_rec_pkt_done_w;
wire        eth_udp_rx_done_sys_w;
wire [15:0] eth_udp_rx_byte_num_sys_w;
wire [1:0]  eth_speed_led_w;
wire        eth_rx_pkt_seen_sys_w;
wire [7:0]  eth_tx_clk_mon_sys_w;
wire [15:0] eth_rx_last_len_sys_w;
wire [7:0]  eth_rx_last_data_sys_w;
wire [7:0]  eth_dbg_rx_pkt_cnt_w;
wire [7:0]  eth_dbg_raw_rx_cnt_w;
wire [31:0] eth_arp_dbg_counts_sys_w;
wire [31:0] eth_arp_des_ip_sys_w;
wire [95:0] eth_raw_rx_head_sys_w;
wire [95:0] eth_raw_tx_head_sys_w;
wire        eth_tx_ctl_udp_sys_w;
wire        dbg_arp_tx_en_sys_w;
wire [47:0] eth_arp_des_mac_sys_w;
wire        eth_video_wr_req0_w;
wire        eth_video_wr_req1_w;
wire [15:0] eth_video_wr_data_w;
wire        eth_video_frame_done_toggle_w;
wire        eth_video_frame_abort_toggle_w;
wire        eth_video_packet_seen_toggle_w;
wire [15:0] eth_video_good_packets_w;
wire [15:0] eth_video_bad_packets_w;
wire [15:0] eth_video_frame_count_w;
wire [10:0] eth_video_last_line_w;
wire        eth_video_last_half_w;
wire [1:0]  eth_video_last_chunk_w;
wire [15:0] eth_video_last_words_w;
wire [7:0]  eth_video_last_frame_id_w;
wire        eth_video_active_w;
wire        eth_frame_done_pulse_100_w;
wire        eth_frame_abort_pulse_100_w;
wire        source_frame_pulse_100_w;
wire        sdram_wr_req0_w;
wire        sdram_wr_req1_w;
wire [15:0] sdram_wr_data0_w;
wire [15:0] sdram_wr_data1_w;
wire [15:0] eth_sdram_fifo0_q_w;
wire [15:0] eth_sdram_fifo1_q_w;
wire [10:0] eth_sdram_fifo0_usedw_w;
wire [10:0] eth_sdram_fifo1_usedw_w;
wire        eth_sdram_fifo0_empty_w;
wire        eth_sdram_fifo1_empty_w;
wire        eth_sdram_fifo0_rdreq_w;
wire        eth_sdram_fifo1_rdreq_w;
wire        eth_sdram_fifo0_valid_pclk_w;
wire        eth_sdram_fifo1_valid_pclk_w;
wire        eth_sdram_bridge_drained_pclk_w;
wire        eth_wr_reset_sync_w;

reg  [1:0]  wr_slot_r;
reg  [1:0]  source_mode_pclk_sync_r;
reg  [1:0]  source_mode_hdmi_sync_r;
reg  [1:0]  eth_mode_100_sync_r;
reg         eth_mode_100_d_r;
reg         eth_sdram_fifo0_rdreq_d_pclk_r;
reg         eth_sdram_fifo1_rdreq_d_pclk_r;
reg         eth_sdram_bridge_drained_meta_100_r;
reg         eth_sdram_bridge_drained_100_r;
reg  [1:0]  rd_slot_r;
reg  [1:0]  pending_slot_r;
reg         pending_valid_r;
reg         cam_capture_started_r;
reg         frame_ready_r;
reg         display_enable_r;
reg         rd_recover_pending_r;
reg [15:0]  display_frame_counter_r;
reg [3:0]   wr_rst_cnt_r;
reg [3:0]   rd_rst_cnt_r;
reg [12:0]  cam_commit_delay_r;
reg         cam_commit_ready_r;
reg [12:0]  commit_wait_cnt_r;
reg [3:0]   capture_resume_cnt_r;
reg         commit_wait_r;
reg         capture_pause_sys_r;
reg [15:0]  cam_frame_counter_r;
reg [15:0]  hdmi_frame_counter_r;
reg [15:0]  cam_commit_counter_r;
reg [15:0]  frame_swap_counter_r;
reg [15:0]  rd_underflow_counter_r;
reg [10:0]  rd_fifo0_min_r;
reg [10:0]  rd_fifo1_min_r;
reg [15:0]  rd_underflow_counter_hdmi_r;
reg [15:0]  rd_underflow_counter_meta_r;
reg [10:0]  rd_fifo0_min_hdmi_r;
reg [10:0]  rd_fifo1_min_hdmi_r;
reg [10:0]  rd_fifo0_min_meta_r;
reg [10:0]  rd_fifo1_min_meta_r;
reg [10:0]  rd_fifo0_usedw_meta_r;
reg [10:0]  rd_fifo0_usedw_sys_r;
reg [10:0]  rd_fifo1_usedw_meta_r;
reg [10:0]  rd_fifo1_usedw_sys_r;
reg [10:0]  selected_rd_fifo_num_sys_r;
reg         frame_ready_hdmi_meta_r;
reg         frame_ready_hdmi_sys_r;

(* preserve, altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg frame_ready_meta_hdmi_r;
(* preserve, altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg frame_ready_sync_hdmi_r;
reg         video_started_hdmi_r;
reg         hdmi_hsync_d1_r;
reg         hdmi_hsync_d2_r;
reg         hdmi_hsync_d3_r;
reg         hdmi_vsync_d1_r;
reg         hdmi_vsync_d2_r;
reg         hdmi_vsync_d3_r;
reg         hdmi_de_d1_r;
reg         hdmi_de_d2_r;
reg         hdmi_de_d3_r;
reg [23:0]  hdmi_rgb_d1_r;
reg [23:0]  hdmi_rgb_d2_r;
reg [23:0]  hdmi_rgb_d3_r;
reg [1:0]   display_right_pipe_hdmi_r;

reg         cam_frame_toggle_pclk_r;
reg [1:0]   cam_frame_toggle_100_r;
reg         cam_valid_frame_toggle_pclk_r;
reg [1:0]   cam_valid_frame_toggle_100_r;
reg         hdmi_frame_toggle_hdmi_r;
reg [1:0]   hdmi_frame_toggle_100_r;

(* preserve *) reg ov5640_vsync_io_pclk_r;
reg         ov5640_vsync_d_pclk_r;
reg         ov5640_vsync_dd_pclk_r;
reg         ov5640_href_d_pclk_r;
reg         ov5640_href_dd_pclk_r;
reg  [1:0]  cam_raw_x_mod3_pclk_r;
reg  [1:0]  cam_raw_y_mod3_pclk_r;
reg         capture_pause_sync_d_pclk_r;
reg         cam_line_odd_pclk_r;
reg [11:0]  cam_pixel_x_pclk_r;
reg         capture_resume_wait_pclk_r;
reg         capture_active_pclk_r;
reg         wr_en_pipe_pclk_r;
reg [15:0]  wr_data_pipe_pclk_r;
reg         wr_line_odd_pipe_pclk_r;
reg         capture_pause_meta_pclk_r;
reg         capture_pause_sync_pclk_r;
reg         video_vs_d_hdmi_r;
reg         frame_seen_pclk_r;
reg         frame_pixels_seen_pclk_r;
reg         frame_pixels_seen_last_pclk_r;
reg         frame_href_seen_pclk_r;
reg [12:0]  raw_line_pixels_pclk_r;
reg [12:0]  raw_line_pixels_last_pclk_r;
reg [11:0]  raw_frame_lines_pclk_r;
reg [11:0]  raw_frame_lines_last_pclk_r;
reg [20:0]  raw_frame_pixels_pclk_r;
reg [20:0]  raw_frame_pixels_last_pclk_r;
reg [15:0]  cam_last_pixel_pclk_r;
reg [15:0]  cam_last_pixel_frame_pclk_r;
reg [15:0]  wr_req0_count_pclk_r;
reg [15:0]  wr_req1_count_pclk_r;
reg [15:0]  display_sample_hdmi_r;
reg         display_sample_arm_hdmi_r;
reg [15:0]  rd_req0_count_hdmi_r;
reg [15:0]  rd_req1_count_hdmi_r;
reg [15:0]  rd_fifo0_empty_count_hdmi_r;
reg [15:0]  rd_fifo1_empty_count_hdmi_r;
reg         rd_req0_empty_d_hdmi_r;
reg         rd_req1_empty_d_hdmi_r;
reg         rd_req0_empty_event_hdmi_r;
reg         rd_req1_empty_event_hdmi_r;
reg [15:0]  left_pixel_sample_hdmi_r;
reg [15:0]  right_pixel_sample_hdmi_r;

reg [15:0]  raw_line_pixels_meta_r;
reg [15:0]  raw_line_pixels_sys_r;
reg [15:0]  raw_frame_lines_meta_r;
reg [15:0]  raw_frame_lines_sys_r;
reg [20:0]  raw_frame_pixels_meta_r;
reg [20:0]  raw_frame_pixels_sys_r;
reg [15:0]  cam_last_pixel_meta_r;
reg [15:0]  cam_last_pixel_sys_r;
reg         frame_pixels_seen_meta_r;
reg         frame_pixels_seen_sys_r;
reg         cam_data_seen_r;
reg         cfg_done_meta_r;
reg         cfg_done_sys_r;
reg         hdmi_cfg_done_meta_r;
reg         hdmi_cfg_done_sys_r;
reg [15:0]  cam_dbg_addr_meta_r;
reg [15:0]  cam_dbg_addr_sys_r;
reg [7:0]   cam_dbg_data_meta_r;
reg [7:0]   cam_dbg_data_sys_r;
reg         cam_dbg_ack_meta_r;
reg         cam_dbg_ack_sys_r;
reg         cam_dbg_busy_meta_r;
reg         cam_dbg_busy_sys_r;
reg         cam_dbg_done_meta_r;
reg         cam_dbg_done_sys_r;
reg         cam_dbg_timeout_meta_r;
reg         cam_dbg_timeout_sys_r;
reg [2:0]   cam_dbg_state_meta_r;
reg [2:0]   cam_dbg_state_sys_r;
reg [3:0]   cam_dbg_index_meta_r;
reg [3:0]   cam_dbg_index_sys_r;
reg [15:0]  rd_data0_meta_r;
reg [15:0]  rd_data0_sys_r;
reg [15:0]  rd_data1_meta_r;
reg [15:0]  rd_data1_sys_r;
reg [15:0]  wr_req0_count_meta_r;
reg [15:0]  wr_req0_count_sys_r;
reg [15:0]  wr_req1_count_meta_r;
reg [15:0]  wr_req1_count_sys_r;
reg [15:0]  rd_req0_count_meta_r;
reg [15:0]  rd_req0_count_sys_r;
reg [15:0]  rd_req1_count_meta_r;
reg [15:0]  rd_req1_count_sys_r;
reg [15:0]  rd_fifo0_empty_count_meta_r;
reg [15:0]  rd_fifo0_empty_count_sys_r;
reg [15:0]  rd_fifo1_empty_count_meta_r;
reg [15:0]  rd_fifo1_empty_count_sys_r;
reg [15:0]  left_pixel_meta_r;
reg [15:0]  left_pixel_sys_r;
reg [15:0]  right_pixel_meta_r;
reg [15:0]  right_pixel_sys_r;
reg [1:0]   eth_frame_done_100_r;
reg [1:0]   eth_frame_abort_100_r;
reg [1:0]   rd_underflow_toggle_100_r;
reg [2:0]   wr_rst_eth_sync_r;
reg         eth_udp_rx_done_sys_r;
reg [15:0]  eth_udp_rx_byte_num_sys_r;
reg [7:0]   eth_dbg_rx_pkt_cnt_d_r;
reg [15:0]  eth_good_packets_meta_r;
reg [15:0]  eth_good_packets_sys_r;
reg [15:0]  eth_bad_packets_meta_r;
reg [15:0]  eth_bad_packets_sys_r;
reg [15:0]  eth_frame_count_meta_r;
reg [15:0]  eth_frame_count_sys_r;
reg [10:0]  eth_last_line_meta_r;
reg [10:0]  eth_last_line_sys_r;
reg         eth_last_half_meta_r;
reg         eth_last_half_sys_r;
reg [1:0]   eth_last_chunk_meta_r;
reg [1:0]   eth_last_chunk_sys_r;
reg [15:0]  eth_last_words_meta_r;
reg [15:0]  eth_last_words_sys_r;
reg [7:0]   eth_last_frame_id_meta_r;
reg [7:0]   eth_last_frame_id_sys_r;
reg         eth_active_meta_r;
reg         eth_active_sys_r;
reg         eth_packet_seen_meta_r;
reg         eth_packet_seen_sys_r;
reg         hdmi_dbg_start_r;
reg         hdmi_dbg_req_sent_r;
reg         hdmi_dbg_done_latched_r;
reg         hdmi_dbg_ack_ok_r;
reg         hdmi_dbg_nack_r;
reg         hdmi_dbg_timeout_r;
reg [7:0]   hdmi_dbg_rd_data_r;
reg [1:0]   hdmi_dbg_reg_sel_r;
reg [15:0]  hdmi_dbg_last_addr_r;
reg [23:0]  hdmi_dbg_wait_count_r;

wire [15:0] hdmi_dbg_reg_addr_w =
    (hdmi_dbg_reg_sel_r == 2'd0) ? 16'h000A :
    (hdmi_dbg_reg_sel_r == 2'd1) ? 16'h000B :
                                   16'h0088;
wire        hdmi_dbg_sel_hi_w    = hdmi_dbg_reg_addr_w[7];
wire        hdmi_dbg_busy_w      = hdmi_dbg_sel_hi_w ? hdmi_dbg_hi_busy_w    : hdmi_dbg_lo_busy_w;
wire        hdmi_dbg_done_w      = hdmi_dbg_sel_hi_w ? hdmi_dbg_hi_done_w    : hdmi_dbg_lo_done_w;
wire        hdmi_dbg_ack_ok_w    = hdmi_dbg_sel_hi_w ? hdmi_dbg_hi_ack_ok_w  : hdmi_dbg_lo_ack_ok_w;
wire        hdmi_dbg_nack_w      = hdmi_dbg_sel_hi_w ? hdmi_dbg_hi_nack_w    : hdmi_dbg_lo_nack_w;
wire        hdmi_dbg_timeout_w   = hdmi_dbg_sel_hi_w ? hdmi_dbg_hi_timeout_w : hdmi_dbg_lo_timeout_w;
wire [7:0]  hdmi_dbg_rd_data_w   = hdmi_dbg_sel_hi_w ? hdmi_dbg_hi_rd_data_w : hdmi_dbg_lo_rd_data_w;
wire        wr_rst_w             = (wr_rst_cnt_r != 4'd0);
wire        rd_rst_w             = (rd_rst_cnt_r != 4'd0);
assign eth_wr_reset_sync_w       = wr_rst_eth_sync_r[2];
wire        cam_commit_ready_w   = cam_commit_ready_r;
wire        eth_mode_changed_100_w = ETH_VIDEO_TEST_EN ^ eth_mode_100_d_r;
wire [1:0]  rd_slot_after_swap_w = hdmi_swap_w ? pending_slot_r : rd_slot_r;
wire [1:0]  next_wr_slot_w =
    ((rd_slot_after_swap_w != 2'd0) && (wr_slot_r != 2'd0)) ? 2'd0 :
    ((rd_slot_after_swap_w != 2'd1) && (wr_slot_r != 2'd1)) ? 2'd1 :
                                                              2'd2;

assign core_rst_n       = sys_rst_n & pll1_locked;
// The PHY reset counter itself runs from clk_125m. If that clock is absent it
// cannot release reset; avoiding a hard dependency on the Fast-PLL lock flag
// also prevents a false-low lock indication from permanently disabling PHY.
assign eth_core_rst_n_w = core_rst_n;
assign pll_hdmi_locked  = pll1_locked;
assign hdmi_rst_n       = core_rst_n;
assign hdmi_pix_clk     = hdmi_clk_74m25_direct;
assign hdmi_out_clk     = hdmi_pix_clk;
assign hdmi_sda_i_w     = ddc_sda;
assign ddc_scl          = hdmi_cfg_scl_w;
assign hdmi_reset_n     = hdmi_reset_ctrl_w;
assign sys_init_done_w  = sdram1_init_done & sdram2_init_done & hdmi_cfg_done &
                          (ETH_VIDEO_TEST_EN ? 1'b1 : cfg_done);
assign ov5640_rst_n     = 1'b1;
assign ov5640_pwdn      = 1'b0;
assign ov5640_xclk      = clk_24m;
assign eth_udp_rx_done_sys_w     = eth_udp_rx_done_sys_r;
assign eth_udp_rx_byte_num_sys_w = eth_udp_rx_byte_num_sys_r;
assign virtual_grab_mode_w = (algorithm_mode_w == ALGORITHM_VIRTUAL_GRAB);
assign rotate_mode_w       = (algorithm_mode_w == ALGORITHM_ROTATE);
assign shader_mode_w       = (algorithm_mode_w == ALGORITHM_SHADER);
// The HDMI-side effect pipeline is shared by camera and Ethernet frames.
// Source selection must not suppress a valid multi-exposure request.
assign fusion_output_select_hdmi_w = fusion_active_hdmi_w;
assign video_hs_effect_path_w = fusion_output_select_hdmi_w ?
                                video_hs_fusion_path_w :
                                video_hs_shader_path_w;
assign video_vs_effect_path_w = fusion_output_select_hdmi_w ?
                                video_vs_fusion_path_w :
                                video_vs_shader_path_w;
assign video_de_effect_path_w = fusion_output_select_hdmi_w ?
                                video_de_fusion_path_w :
                                video_de_shader_path_w;
assign hdmi_rgb_effect_path_w = fusion_output_select_hdmi_w ?
                                hdmi_rgb_fusion_path_w :
                                hdmi_rgb_shader_path_w;

paper_puppet_h6_overlay paper_puppet_h6_overlay_inst (
    .clk             (hdmi_pix_clk),
    .rst_n           (hdmi_rst_n),
    .key_n           (key2_n),
    .hsync_i         (video_hs_effect_path_w),
    .vsync_i         (video_vs_effect_path_w),
    .de_i            (video_de_effect_path_w),
    .x_i             (pixel_xpos_w),
    .y_i             (pixel_ypos_w),
    .rgb_i           (hdmi_rgb_effect_path_w),
    .rgb_o           (hdmi_rgb_puppet_path_w),
    .puppet_enable   (puppet_enable_hdmi_w),
    .target_valid    (puppet_target_valid_w),
    .target_center_x (puppet_target_center_x_w),
    .target_center_y (puppet_target_center_y_w)
);
assign uart_txd         = ETH_SERIAL_DIAG_MODE ? uart_rx_len_tx_w :
                          (virtual_grab_mode_w ? virtual_grab_uart_txd_w : uart_rotate_txd_w);
assign uart1_txd        = uart_diag_tx_w;
assign ETH_VIDEO_TEST_EN = eth_mode_100_sync_r[1];
assign led1             = pll1_locked;
assign led2             = sdram1_init_done & sdram2_init_done;
assign led3             = cfg_done_sys_r;
assign led4             = HALF_LINE_TRIPLE_BUFFER_EN ? frame_ready_r :
                          (NEW480_STREAM_EN ? sys_init_done_w : frame_ready_r);
assign rotate_status_reg_w = {12'd0, frame_ready_hdmi_sys_r, frame_ready_r, cfg_done_sys_r, 1'b1};

assign video_rgb888_w = {
    video_rgb_w[15:11], video_rgb_w[15:13],
    video_rgb_w[10:5],  video_rgb_w[10:9],
    video_rgb_w[4:0],   video_rgb_w[4:2]
};
assign video_rgb565_raw_w = {
    hdmi_rgb_raw_w[23:19],
    hdmi_rgb_raw_w[15:10],
    hdmi_rgb_raw_w[7:3]
};
assign fpga_colorbar_rgb_w =
    (pixel_xpos_w < 12'd160)  ? 24'hFFFFFF :
    (pixel_xpos_w < 12'd320)  ? 24'hFFFF00 :
    (pixel_xpos_w < 12'd480)  ? 24'h00FFFF :
    (pixel_xpos_w < 12'd640)  ? 24'h00FF00 :
    (pixel_xpos_w < 12'd800)  ? 24'hFF00FF :
    (pixel_xpos_w < 12'd960)  ? 24'hFF0000 :
    (pixel_xpos_w < 12'd1120) ? 24'h0000FF :
                                24'h000000;
// Match the proven 480p board path first: feed the SiI9134 with the raw
// low-active syncs from the timing generator and let the transmitter decide
// how to packetize the HDMI output timing.
assign video_hs_raw_w = video_hs_w;
assign video_vs_raw_w = video_vs_w;
assign first_video_wait_hdmi_w = HALF_LINE_TRIPLE_BUFFER_EN & ~video_started_hdmi_r;
assign video_de_raw_w = video_de_w;
assign hdmi_rgb_raw_w = video_de_raw_w ?
                        ((FPGA_COLORBAR_TEST_EN ||
                          (NEW480_STREAM_EN && selected_rd_empty_w) ||
                          first_video_wait_hdmi_w) ?
                         fpga_colorbar_rgb_w : video_rgb888_w) :
                        24'd0;
assign video_hs_out_path_w = (rotate_mode_w && rotate_preview_active_w) ? video_hs_rotate_w : video_hs_raw_w;
assign video_vs_out_path_w = (rotate_mode_w && rotate_preview_active_w) ? video_vs_rotate_w : video_vs_raw_w;
assign video_de_out_path_w = (rotate_mode_w && rotate_preview_active_w) ? video_de_rotate_w : video_de_raw_w;
assign hdmi_rgb_out_path_w = virtual_grab_mode_w ? virtual_grab_hdmi_rgb_w :
                             ((rotate_mode_w && rotate_preview_active_w) ? hdmi_rgb_rotate_w : hdmi_rgb_raw_w);

assign sdram1_wr_b_addr_w = HALF_LINE_TRIPLE_BUFFER_EN ? slot_b_addr_fn(wr_slot_r) :
                            (NEW480_STREAM_EN ? 24'd0 : slot_b_addr_fn(wr_slot_r));
assign sdram1_wr_e_addr_w = NEW480_SINGLE_SDRAM_EN ? FRAME_WORDS :
                            (HALF_LINE_TRIPLE_BUFFER_EN ? slot_e_addr_fn(wr_slot_r) :
                            (NEW480_HALF_LINE_EN ? HALF_FRAME_WORDS : slot_e_addr_fn(wr_slot_r)));
assign sdram2_wr_b_addr_w = HALF_LINE_TRIPLE_BUFFER_EN ? slot_b_addr_fn(wr_slot_r) :
                            (NEW480_STREAM_EN ? 24'd0 : slot_b_addr_fn(wr_slot_r));
assign sdram2_wr_e_addr_w = HALF_LINE_TRIPLE_BUFFER_EN ? slot_e_addr_fn(wr_slot_r) :
                            (NEW480_HALF_LINE_EN ? HALF_FRAME_WORDS : slot_e_addr_fn(wr_slot_r));

assign sdram1_rd_b_addr_w = HALF_LINE_TRIPLE_BUFFER_EN ? slot_b_addr_fn(rd_slot_r) :
                            (NEW480_STREAM_EN ? 24'd0 : slot_b_addr_fn(rd_slot_r));
assign sdram1_rd_e_addr_w = NEW480_SINGLE_SDRAM_EN ? FRAME_WORDS :
                            (HALF_LINE_TRIPLE_BUFFER_EN ? slot_e_addr_fn(rd_slot_r) :
                            (NEW480_HALF_LINE_EN ? HALF_FRAME_WORDS : slot_e_addr_fn(rd_slot_r)));
assign sdram2_rd_b_addr_w = HALF_LINE_TRIPLE_BUFFER_EN ? slot_b_addr_fn(rd_slot_r) :
                            (NEW480_STREAM_EN ? 24'd0 : slot_b_addr_fn(rd_slot_r));
assign sdram2_rd_e_addr_w = HALF_LINE_TRIPLE_BUFFER_EN ? slot_e_addr_fn(rd_slot_r) :
                            (NEW480_HALF_LINE_EN ? HALF_FRAME_WORDS : slot_e_addr_fn(rd_slot_r));

assign display_right_sel_w = display_right_pipe_hdmi_r[1];
assign video_pixel_data_w = (source_mode_hdmi_sync_r[1] && !rd_pixel_valid_guard_w) ? 16'd0 :
                            (NEW480_SINGLE_SDRAM_EN ? rd_data0_w :
                            (NEW480_HALF_LINE_EN ? (display_right_sel_w ? rd_data1_w : rd_data0_w) :
                            (frame_ready_sync_hdmi_r ?
                            (pixel_ypos_w[0] ? rd_data1_w : rd_data0_w) :
                            16'd0)));

assign cam_stream_active_pclk_w = wr_en & capture_active_pclk_r &
                                  ~capture_pause_sync_pclk_r;
assign wr_en_gated_pclk_w = cam_stream_active_pclk_w &
                            (cam_raw_x_mod3_pclk_r != 2'd2) &
                            (cam_raw_y_mod3_pclk_r != 2'd2) &
                            ~capture_resume_wait_pclk_r;
assign wr_req_pclk_w = wr_en_pipe_pclk_r;
assign cam_write_bank_sel_pclk_w = wr_line_odd_pipe_pclk_r;
assign wr_req0_w = wr_req_pclk_w & (NEW480_SINGLE_SDRAM_EN ? 1'b1 : ~cam_write_bank_sel_pclk_w);
assign wr_req1_w = wr_req_pclk_w & (NEW480_SINGLE_SDRAM_EN ? 1'b0 :  cam_write_bank_sel_pclk_w);
assign eth_sdram_fifo0_rdreq_w = ~eth_sdram_fifo0_empty_w;
assign eth_sdram_fifo1_rdreq_w = ~eth_sdram_fifo1_empty_w;
assign eth_sdram_fifo0_valid_pclk_w = eth_sdram_fifo0_rdreq_d_pclk_r &&
                                       source_mode_pclk_sync_r[1];
assign eth_sdram_fifo1_valid_pclk_w = eth_sdram_fifo1_rdreq_d_pclk_r &&
                                       source_mode_pclk_sync_r[1];
assign eth_sdram_bridge_drained_pclk_w =
    eth_sdram_fifo0_empty_w &&
    eth_sdram_fifo1_empty_w &&
    !eth_sdram_fifo0_rdreq_d_pclk_r &&
    !eth_sdram_fifo1_rdreq_d_pclk_r;
assign sdram_wr_req0_w = source_mode_pclk_sync_r[1] ? eth_sdram_fifo0_valid_pclk_w : wr_req0_w;
assign sdram_wr_req1_w = source_mode_pclk_sync_r[1] ? eth_sdram_fifo1_valid_pclk_w : wr_req1_w;
assign sdram_wr_data0_w = source_mode_pclk_sync_r[1] ? eth_sdram_fifo0_q_w : wr_data_pipe_pclk_r;
assign sdram_wr_data1_w = source_mode_pclk_sync_r[1] ? eth_sdram_fifo1_q_w : wr_data_pipe_pclk_r;
assign rd_req0_need_w = FPGA_COLORBAR_TEST_EN ? 1'b0 :
                        (NEW480_SINGLE_SDRAM_EN ? (rd_en_w & frame_ready_sync_hdmi_r) :
                        (NEW480_HALF_LINE_EN ? (rd_en_w & (pixel_xpos_w < H_HALF_PIXEL) &
                                                (!HALF_LINE_TRIPLE_BUFFER_EN || frame_ready_sync_hdmi_r)) :
                        (frame_ready_sync_hdmi_r & ~pixel_ypos_w[0] & rd_en_w)));
assign rd_req1_need_w = FPGA_COLORBAR_TEST_EN ? 1'b0 :
                        (NEW480_SINGLE_SDRAM_EN ? 1'b0 :
                        (NEW480_HALF_LINE_EN ? (rd_en_w & (pixel_xpos_w >= H_HALF_PIXEL) &
                                                (!HALF_LINE_TRIPLE_BUFFER_EN || frame_ready_sync_hdmi_r)) :
                        (frame_ready_sync_hdmi_r &  pixel_ypos_w[0] & rd_en_w)));
assign rd_fifo0_empty_hdmi_w = (rd_fifo_rd_num0_w == 11'd0);
assign rd_fifo1_empty_hdmi_w = (rd_fifo_rd_num1_w == 11'd0);
assign rd_req0_empty_need_w = rd_req0_need_w & rd_fifo0_empty_hdmi_w;
assign rd_req1_empty_need_w = rd_req1_need_w & rd_fifo1_empty_hdmi_w;

hdmi_read_underflow_guard #(
    .GUARD_WORDS (RD_FIFO_READ_GUARD_WM)
) hdmi_read_underflow_guard_inst (
    .clk                (hdmi_pix_clk),
    .rst_n              (hdmi_rst_n),
    .frame_active_i     (frame_ready_sync_hdmi_r & source_mode_hdmi_sync_r[1]),
    .rd_req0_need_i     (rd_req0_need_w),
    .rd_req1_need_i     (rd_req1_need_w),
    .fifo0_words_i      (rd_fifo_rd_num0_w),
    .fifo1_words_i      (rd_fifo_rd_num1_w),
    .rd_req0_o          (rd_req0_guard_w),
    .rd_req1_o          (rd_req1_guard_w),
    .pixel_valid_o      (rd_pixel_valid_guard_w),
    .underflow_active_o (),
    .underflow_toggle_o (rd_underflow_toggle_hdmi_w)
);

assign rd_req0_w = source_mode_hdmi_sync_r[1] ? rd_req0_guard_w : rd_req0_need_w;
assign rd_req1_w = source_mode_hdmi_sync_r[1] ? rd_req1_guard_w : rd_req1_need_w;

assign cam_frame_pulse_100_w = cam_frame_toggle_100_r[1] ^ cam_frame_toggle_100_r[0];
assign cam_valid_frame_pulse_100_w = cam_valid_frame_toggle_100_r[1] ^
                                      cam_valid_frame_toggle_100_r[0];
assign hdmi_frame_pulse_100_w = FPGA_COLORBAR_TEST_EN ? 1'b0 :
                                (hdmi_frame_toggle_100_r[1] ^ hdmi_frame_toggle_100_r[0]);
assign rd_underflow_event_100_w = rd_underflow_toggle_100_r[1] ^
                                  rd_underflow_toggle_100_r[0];
assign eth_frame_done_pulse_100_w = eth_frame_done_100_r[1] ^ eth_frame_done_100_r[0];
assign eth_frame_abort_pulse_100_w = eth_frame_abort_100_r[1] ^ eth_frame_abort_100_r[0];
assign source_frame_pulse_100_w = ETH_VIDEO_TEST_EN ? eth_frame_done_pulse_100_w :
                                  cam_valid_frame_pulse_100_w;
assign cam_frame_done_w = ETH_VIDEO_TEST_EN ? eth_frame_done_pulse_100_w :
                          ((HALF_LINE_TRIPLE_BUFFER_EN || !NEW480_STREAM_EN) &
                           cam_valid_frame_pulse_100_w & cam_capture_started_r);
assign wr_fifos_below_burst_w = (wr_fifo_num0_w < WR_COMMIT_SAFE_WM) &&
                                (wr_fifo_num1_w < WR_COMMIT_SAFE_WM);
assign commit_grace_expired_w = (commit_wait_cnt_r >= WR_COMMIT_GRACE_CYCLES);
assign cam_commit_w = commit_wait_r && cam_commit_ready_w &&
                      (ETH_VIDEO_TEST_EN ?
                       (eth_sdram_bridge_drained_100_r &&
                        commit_grace_expired_w &&
                        (wr_fifo_num0_w == 11'd0) &&
                        (wr_fifo_num1_w == 11'd0)) :
                       (wr_fifos_below_burst_w || commit_grace_expired_w));
assign hdmi_swap_w = (HALF_LINE_TRIPLE_BUFFER_EN || !NEW480_STREAM_EN) &
                     hdmi_frame_pulse_100_w & pending_valid_r & cam_commit_ready_w;

assign selected_rd_fifo_num_sys_w = NEW480_SINGLE_SDRAM_EN ? rd_fifo_num0_w :
                                    ((rd_fifo_num0_w < rd_fifo_num1_w) ? rd_fifo_num0_w : rd_fifo_num1_w);
assign selected_rd_fifo_num_hdmi_w = NEW480_SINGLE_SDRAM_EN ? rd_fifo_rd_num0_w :
                                     ((rd_fifo_rd_num0_w < rd_fifo_rd_num1_w) ? rd_fifo_rd_num0_w : rd_fifo_rd_num1_w);
assign selected_rd_fifo_num_w = selected_rd_fifo_num_sys_r;
assign selected_rd_empty_w = (selected_rd_fifo_num_sys_r == 11'd0);
assign selected_rd_data_100_w = rd_data0_sys_r;
assign rd_fifo_prime_ok_w = (selected_rd_fifo_num_hdmi_w >= RD_FIFO_PRIME_WM);
assign rd_fifo_prime_ok_sys_w = (selected_rd_fifo_num_sys_r >= RD_FIFO_PRIME_WM);
assign diag_slot_state_w = {
    pending_valid_r,
    wr_rst_w,
    rd_rst_w,
    wr_slot_r,
    rd_slot_r,
    pending_slot_r,
    display_enable_r,
    frame_ready_r
};
assign sdram1_read_valid_w = FPGA_COLORBAR_TEST_EN ? 1'b0 :
                             (HALF_LINE_TRIPLE_BUFFER_EN ? (frame_ready_r & ~rd_rst_w) :
                             (NEW480_STREAM_EN ? (sdram1_init_done & ~rd_rst_w) :
                             (frame_ready_r & ~rd_rst_w)));
assign sdram2_read_valid_w = FPGA_COLORBAR_TEST_EN ? 1'b0 :
                             (HALF_LINE_TRIPLE_BUFFER_EN ? (frame_ready_r & ~rd_rst_w) :
                             (NEW480_STREAM_EN ? (NEW480_HALF_LINE_EN & sdram2_init_done & ~rd_rst_w) :
                             (frame_ready_r & ~rd_rst_w)));

assign hdmi_out_hsync = FPGA_COLORBAR_TEST_EN ? video_hs_raw_w : hdmi_hsync_d3_r;
assign hdmi_out_vsync = FPGA_COLORBAR_TEST_EN ? video_vs_raw_w : hdmi_vsync_d3_r;
assign hdmi_out_de    = FPGA_COLORBAR_TEST_EN ? video_de_raw_w : hdmi_de_d3_r;
assign hdmi_out_rgb   = FPGA_COLORBAR_TEST_EN ? hdmi_rgb_raw_w : hdmi_rgb_d3_r;

always @(posedge sys_clk) begin
    led_heartbeat_r <= led_heartbeat_r + 26'd1;
end

wire [15:0] debug_error_w;
assign debug_error_w = {
    8'd0,
    hdmi_swap_w,
    cam_commit_w,
    pll_hdmi_locked,
    hdmi_frame_pulse_100_w,
    cam_frame_pulse_100_w,
    cam_capture_started_r,
    pending_valid_r,
    (~frame_ready_r)
};

always @(posedge sys_clk or negedge core_rst_n) begin
    if (!core_rst_n) begin
        hdmi_dbg_start_r        <= 1'b0;
        hdmi_dbg_req_sent_r     <= 1'b0;
        hdmi_dbg_done_latched_r <= 1'b0;
        hdmi_dbg_ack_ok_r       <= 1'b0;
        hdmi_dbg_nack_r         <= 1'b0;
        hdmi_dbg_timeout_r      <= 1'b0;
        hdmi_dbg_rd_data_r      <= 8'd0;
        hdmi_dbg_reg_sel_r      <= 2'd0;
        hdmi_dbg_last_addr_r    <= 16'h000A;
        hdmi_dbg_wait_count_r   <= 24'd0;
    end else begin
        hdmi_dbg_start_r <= 1'b0;

        if (!FPGA_COLORBAR_TEST_EN || !hdmi_cfg_done_sys_r) begin
            hdmi_dbg_req_sent_r     <= 1'b0;
            hdmi_dbg_done_latched_r <= 1'b0;
            hdmi_dbg_ack_ok_r       <= 1'b0;
            hdmi_dbg_nack_r         <= 1'b0;
            hdmi_dbg_timeout_r      <= 1'b0;
            hdmi_dbg_rd_data_r      <= 8'd0;
            hdmi_dbg_reg_sel_r      <= 2'd0;
            hdmi_dbg_last_addr_r    <= 16'h000A;
            hdmi_dbg_wait_count_r   <= 24'd0;
        end else if (!hdmi_dbg_req_sent_r && !hdmi_dbg_busy_w) begin
            if (hdmi_dbg_wait_count_r == HDMI_DBG_PERIOD_CYCLES - 1'b1) begin
                hdmi_dbg_start_r     <= 1'b1;
                hdmi_dbg_req_sent_r  <= 1'b1;
                hdmi_dbg_last_addr_r <= hdmi_dbg_reg_addr_w;
                hdmi_dbg_wait_count_r <= 24'd0;
            end else begin
                hdmi_dbg_wait_count_r <= hdmi_dbg_wait_count_r + 1'b1;
            end
        end

        if (hdmi_dbg_done_w) begin
            hdmi_dbg_req_sent_r     <= 1'b0;
            hdmi_dbg_wait_count_r   <= 24'd0;
            hdmi_dbg_done_latched_r <= 1'b1;
            hdmi_dbg_ack_ok_r       <= hdmi_dbg_ack_ok_w;
            hdmi_dbg_nack_r         <= hdmi_dbg_nack_w;
            hdmi_dbg_timeout_r      <= hdmi_dbg_timeout_w;
            hdmi_dbg_rd_data_r      <= hdmi_dbg_rd_data_w;
            hdmi_dbg_reg_sel_r      <= (hdmi_dbg_reg_sel_r == 2'd2) ? 2'd0 : (hdmi_dbg_reg_sel_r + 1'b1);
        end
    end
end

clk_gen clk_gen_inst(
    .areset (~sys_rst_n),
    .inclk0 (sys_clk),
    .c0     (clk_100m),
    .c1     (clk_100m_shift),
    .c2     (clk_25m),
    .c3     (clk_24m),
    .c4     (hdmi_clk_74m25_direct),
    .c5     (),
    .locked (pll1_locked)
);

// ARP board diagnostic: use the PHY's proven 125 MHz receive clock for the
// transmit state machine, output registers, and forwarded GTX clock. This
// removes the auxiliary TX PLL that remained unlocked on hardware.
assign clk_125m          = eth_rxc;
assign clk_125m_tx_shift = eth_rxc;
assign pll_eth_locked    = 1'b1;

eth_board_bringup #(
    .BOARD_VIDEO_ONLY       (1'b0),
    .ENABLE_UDP_DIAG_TX     (1'b0),
    .UDP_LOOPBACK_MAX_BYTES (16'd1472)
) eth_board_bringup_inst (
    .sys_clk                (sys_clk),
    .sys_rst_n              (eth_core_rst_n_w),
    .clk_125MHz             (clk_125m),
    .clk_125MHz_tx_shift    (clk_125m_tx_shift),
    .eth_rxc                (eth_rxc),
    .eth_rx_ctl             (eth_rx_ctl),
    .eth_txc                (eth_txc),
    .eth_rxd                (eth_rxd),
    .eth_tx_ctl             (eth_tx_ctl),
    .eth_txd                (eth_txd),
    .GTX_CLK                (GTX_CLK),
    .eth_rst_n              (eth_rst_n),
    .eth_tx_er              (eth_tx_er),
    .touch_key              (key2_n),
    .i_Key_GBCR             (key3_n),
    .i_Key_ANAR             (key4_n),
    .eth_mdio               (eth_mdio),
    .eth_mdc                (eth_mdc),
    .EthSpeedLED            (eth_speed_led_w),
    .eth_rx_rec_en_o        (eth_rx_rec_en_w),
    .eth_rx_rec_data_o      (eth_rx_rec_data_w),
    .eth_rx_rec_byte_num_o  (eth_rx_rec_byte_num_w),
    .eth_rx_rec_pkt_done_o  (eth_rx_rec_pkt_done_w),
    .eth_rx_pkt_seen_sys_d1 (eth_rx_pkt_seen_sys_w),
    .eth_tx_clk_mon_sys_d1  (eth_tx_clk_mon_sys_w),
    .eth_rx_last_len_sys_d1 (eth_rx_last_len_sys_w),
    .eth_rx_last_data_sys_d1(eth_rx_last_data_sys_w),
    .eth_dbg_rx_pkt_cnt     (eth_dbg_rx_pkt_cnt_w),
    .eth_dbg_raw_rx_cnt     (eth_dbg_raw_rx_cnt_w),
    .eth_arp_dbg_counts_sys_d1(eth_arp_dbg_counts_sys_w),
    .eth_arp_des_ip_sys_d1  (eth_arp_des_ip_sys_w),
    .eth_raw_rx_head_sys_d1 (eth_raw_rx_head_sys_w),
    .eth_raw_tx_head_sys_d1 (eth_raw_tx_head_sys_w),
    .eth_tx_ctl_udp_sys_d1  (eth_tx_ctl_udp_sys_w),
    .dbg_arp_tx_en_sys_d1   (dbg_arp_tx_en_sys_w),
    .eth_arp_des_mac_sys_d1 (eth_arp_des_mac_sys_w)
);

eth_video_rx_to_sdram #(
    .HALF_PIXELS            (11'd640),
    .FRAME_LINES            (11'd720),
    .CHUNK_PIXELS           (11'd320),
    .CHUNKS_PER_HALF        (2'd2),
    .ALLOW_PACKET_DUPLICATES (1'b1),
    .RETRY_BAD_PACKET        (1'b1)
) eth_video_rx_to_sdram_inst (
    .eth_clk                (eth_rxc),
    .wr_clk_i               (clk_100m),
    .rst_n                  (eth_core_rst_n_w),
    .rec_en_i               (eth_rx_rec_en_w),
    .rec_data_i             (eth_rx_rec_data_w),
    .rec_byte_num_i         (eth_rx_rec_byte_num_w),
    .wr_reset_i             (eth_wr_reset_sync_w),
    .wr_reset_wr_i          (wr_rst_w),
    .wr_req0_o              (eth_video_wr_req0_w),
    .wr_req1_o              (eth_video_wr_req1_w),
    .wr_data_o              (eth_video_wr_data_w),
    .frame_done_toggle_o    (eth_video_frame_done_toggle_w),
    .frame_abort_toggle_o   (eth_video_frame_abort_toggle_w),
    .packet_seen_toggle_o   (eth_video_packet_seen_toggle_w),
    .good_packet_count_o    (eth_video_good_packets_w),
    .bad_packet_count_o     (eth_video_bad_packets_w),
    .frame_count_o          (eth_video_frame_count_w),
    .last_line_o            (eth_video_last_line_w),
    .last_half_o            (eth_video_last_half_w),
    .last_chunk_o           (eth_video_last_chunk_w),
    .last_words_o           (eth_video_last_words_w),
    .last_frame_id_o        (eth_video_last_frame_id_w),
    .active_o               (eth_video_active_w)
);

always @(posedge sys_clk or negedge core_rst_n) begin
    if (!core_rst_n) begin
        eth_dbg_rx_pkt_cnt_d_r    <= 8'd0;
        eth_udp_rx_done_sys_r     <= 1'b0;
        eth_udp_rx_byte_num_sys_r <= 16'd0;
    end else begin
        eth_dbg_rx_pkt_cnt_d_r <= eth_dbg_rx_pkt_cnt_w;
        eth_udp_rx_done_sys_r  <= (eth_dbg_rx_pkt_cnt_w != eth_dbg_rx_pkt_cnt_d_r);
        if (eth_dbg_rx_pkt_cnt_w != eth_dbg_rx_pkt_cnt_d_r) begin
            eth_udp_rx_byte_num_sys_r <= eth_rx_last_len_sys_w;
        end
    end
end

ov5640_top #(
    .CLK_FREQ (26'd25_000_000),
    .CAM_PCLK_POLARITY_TEST (CAM_PCLK_POLARITY_TEST),
    .CAM_PCLK_SLOW_TEST     (CAM_PCLK_SLOW_TEST)
) ov5640_top_inst (
    .sys_clk         (clk_25m),
    .sys_rst_n       (core_rst_n),
    .sys_init_done   (sys_init_done_w),
    .ov5640_pclk     (ov5640_pclk),
    .ov5640_href     (ov5640_href),
    .ov5640_vsync    (ov5640_vsync),
    .ov5640_data     (ov5640_data),
    .cfg_done        (cfg_done),
    .sccb_scl        (sccb_scl),
    .sccb_sda        (sccb_sda),
    .ov5640_wr_en    (wr_en),
    .ov5640_data_out (wr_data),
    .dbg_rd_addr_o   (cam_dbg_addr_w),
    .dbg_rd_data_o   (cam_dbg_data_w),
    .dbg_rd_ack_o    (cam_dbg_ack_w),
    .dbg_rd_busy_o   (cam_dbg_busy_w),
    .dbg_rd_done_o   (cam_dbg_done_w),
    .dbg_rd_timeout_o(cam_dbg_timeout_w),
    .dbg_rd_state_o  (cam_dbg_state_w),
    .dbg_rd_index_o  (cam_dbg_index_w)
);

// Match the board-verified native 720p SiI9134 initialization path.
assign hdmi_reset_ctrl_w = sys_rst_n;

sil9134_dri #(
    .BIT_CTRL (1'b0),
    .CLK_FREQ (27'd50_000_000),
    .I2C_FREQ (18'd250_000)
) hdmi_ctrl_inst (
    .clk           (sys_clk),
    .rst_n         (sys_rst_n),
    .hdmi_cfg_done (hdmi_cfg_done),
    .hdmi_cfg_scl  (hdmi_cfg_scl_w),
    .hdmi_cfg_sda  (ddc_sda)
);

sccb_master #(
    .CLK_HZ         (50_000_000),
    .BUS_HZ         (100_000),
    .SENSOR_ADDR    (7'h39),
    .REG_ADDR_BYTES (1)
) hdmi_dbg_rd_lo_master_inst (
    .clk            (sys_clk),
    .rst_n          (core_rst_n),
    .start_i        (hdmi_dbg_start_r & ~hdmi_dbg_sel_hi_w),
    .read_i         (1'b1),
    .reg_addr_i     (hdmi_dbg_reg_addr_w),
    .wr_data_i      (8'h00),
    .rd_data_o      (hdmi_dbg_lo_rd_data_w),
    .busy_o         (hdmi_dbg_lo_busy_w),
    .done_o         (hdmi_dbg_lo_done_w),
    .ack_ok_o       (hdmi_dbg_lo_ack_ok_w),
    .nack_o         (hdmi_dbg_lo_nack_w),
    .timeout_o      (hdmi_dbg_lo_timeout_w),
    .sccb_scl_o     (hdmi_dbg_lo_scl_w),
    .sccb_sda_oe_o  (hdmi_dbg_lo_sda_oe_w),
    .sccb_sda_i     (hdmi_sda_i_w)
);

sccb_master #(
    .CLK_HZ         (50_000_000),
    .BUS_HZ         (100_000),
    .SENSOR_ADDR    (7'h3B),
    .REG_ADDR_BYTES (1)
) hdmi_dbg_rd_hi_master_inst (
    .clk            (sys_clk),
    .rst_n          (core_rst_n),
    .start_i        (hdmi_dbg_start_r & hdmi_dbg_sel_hi_w),
    .read_i         (1'b1),
    .reg_addr_i     (hdmi_dbg_reg_addr_w),
    .wr_data_i      (8'h00),
    .rd_data_o      (hdmi_dbg_hi_rd_data_w),
    .busy_o         (hdmi_dbg_hi_busy_w),
    .done_o         (hdmi_dbg_hi_done_w),
    .ack_ok_o       (hdmi_dbg_hi_ack_ok_w),
    .nack_o         (hdmi_dbg_hi_nack_w),
    .timeout_o      (hdmi_dbg_hi_timeout_w),
    .sccb_scl_o     (hdmi_dbg_hi_scl_w),
    .sccb_sda_oe_o  (hdmi_dbg_hi_sda_oe_w),
    .sccb_sda_i     (hdmi_sda_i_w)
);

fifo_data #(
    .LPM_NUMWORDS(2048),
    .LPM_WIDTHU(11)
) eth_sdram_fifo0_inst (
    .aclr(~core_rst_n || wr_rst_w),
    .rdclk(ov5640_pclk),
    .wrclk(clk_100m),
    .data(eth_video_wr_data_w),
    .rdreq(eth_sdram_fifo0_rdreq_w),
    .wrreq(eth_video_wr_req0_w),
    .rdempty(eth_sdram_fifo0_empty_w),
    .rdusedw(eth_sdram_fifo0_usedw_w),
    .wrusedw(),
    .q(eth_sdram_fifo0_q_w)
);

fifo_data #(
    .LPM_NUMWORDS(2048),
    .LPM_WIDTHU(11)
) eth_sdram_fifo1_inst (
    .aclr(~core_rst_n || wr_rst_w),
    .rdclk(ov5640_pclk),
    .wrclk(clk_100m),
    .data(eth_video_wr_data_w),
    .rdreq(eth_sdram_fifo1_rdreq_w),
    .wrreq(eth_video_wr_req1_w),
    .rdempty(eth_sdram_fifo1_empty_w),
    .rdusedw(eth_sdram_fifo1_usedw_w),
    .wrusedw(),
    .q(eth_sdram_fifo1_q_w)
);

sdram_top #(
    .LINE_WORDS      (H_PIXEL)
) sdram1_top_inst(
    .sys_clk         (clk_100m),
    .clk_out         (clk_100m),
    .sys_rst_n       (core_rst_n),
    .wr_fifo_wr_clk  (ov5640_pclk),
    .wr_fifo_wr_req  (sdram_wr_req0_w),
    .wr_fifo_wr_data (sdram_wr_data0_w),
    .sdram_wr_b_addr (sdram1_wr_b_addr_w),
    .sdram_wr_e_addr (sdram1_wr_e_addr_w),
    .wr_burst_len    (SDRAM_BURST),
    .wr_rst          (wr_rst_w),
    .rd_fifo_rd_clk  (hdmi_pix_clk),
    .rd_fifo_rd_req  (rd_req0_w),
    .rd_fifo_rd_data (rd_data0_w),
    .rd_fifo_num     (rd_fifo_num0_w),
    .rd_fifo_rd_num  (rd_fifo_rd_num0_w),
    .wr_fifo_num_o   (wr_fifo_num0_w),
    .sdram_rd_b_addr (sdram1_rd_b_addr_w),
    .sdram_rd_e_addr (sdram1_rd_e_addr_w),
    .rd_burst_len    (SDRAM_BURST),
    .rd_rst          (rd_rst_w),
    .read_valid      (sdram1_read_valid_w),
    .rd_flip_v       (1'b0),
    .pingpang_en     (1'b0),
    .init_end        (sdram1_init_done),
    .sdram_clk       (sdram1_clk),
    .sdram_cke       (sdram1_cke),
    .sdram_cs_n      (sdram1_cs_n),
    .sdram_ras_n     (sdram1_ras_n),
    .sdram_cas_n     (sdram1_cas_n),
    .sdram_we_n      (sdram1_we_n),
    .sdram_ba        (sdram1_ba),
    .sdram_addr      (sdram1addr),
    .sdram_dq        (sdram1_dq)
);

sdram_top #(
    .LINE_WORDS      (H_PIXEL)
) sdram2_top_inst(
    .sys_clk         (clk_100m),
    .clk_out         (clk_100m),
    .sys_rst_n       (core_rst_n),
    .wr_fifo_wr_clk  (ov5640_pclk),
    .wr_fifo_wr_req  (sdram_wr_req1_w),
    .wr_fifo_wr_data (sdram_wr_data1_w),
    .sdram_wr_b_addr (sdram2_wr_b_addr_w),
    .sdram_wr_e_addr (sdram2_wr_e_addr_w),
    .wr_burst_len    (SDRAM_BURST),
    .wr_rst          (wr_rst_w),
    .rd_fifo_rd_clk  (hdmi_pix_clk),
    .rd_fifo_rd_req  (rd_req1_w),
    .rd_fifo_rd_data (rd_data1_w),
    .rd_fifo_num     (rd_fifo_num1_w),
    .rd_fifo_rd_num  (rd_fifo_rd_num1_w),
    .wr_fifo_num_o   (wr_fifo_num1_w),
    .sdram_rd_b_addr (sdram2_rd_b_addr_w),
    .sdram_rd_e_addr (sdram2_rd_e_addr_w),
    .rd_burst_len    (SDRAM_BURST),
    .rd_rst          (rd_rst_w),
    .read_valid      (sdram2_read_valid_w),
    .rd_flip_v       (1'b0),
    .pingpang_en     (1'b0),
    .init_end        (sdram2_init_done),
    .sdram_clk       (sdram2_clk),
    .sdram_cke       (sdram2_cke),
    .sdram_cs_n      (sdram2_cs_n),
    .sdram_ras_n     (sdram2_ras_n),
    .sdram_cas_n     (sdram2_cas_n),
    .sdram_we_n      (sdram2_we_n),
    .sdram_ba        (sdram2_ba),
    .sdram_addr      (sdram2addr),
    .sdram_dq        (sdram2_dq)
);

video_driver video_driver_inst(
    .pixel_clk  (hdmi_pix_clk),
    .sys_rst_n  (hdmi_rst_n),
    .video_hs   (video_hs_w),
    .video_vs   (video_vs_w),
    .video_de   (video_de_w),
    .video_rgb  (video_rgb_w),
    .data_req   (rd_en_w),
    .pixel_xpos (pixel_xpos_w),
    .pixel_ypos (pixel_ypos_w),
    .pixel_data (video_pixel_data_w)
);

unified_uart_mode_router #(
    .CLK_FREQ_HZ(50000000),
    .UART_BPS(115200)
) unified_uart_mode_router_inst (
    .clk(sys_clk),
    .rst_n(core_rst_n),
    .uart_rxd(uart_rxd),
    .eth_activity_i(eth_active_sys_r),
    .algorithm_mode_o(algorithm_mode_w),
    .ethernet_source_mode_o(ethernet_source_mode_w),
    .lowlight_level_o(lowlight_level_w),
    .shader_cfg_toggle_o(shader_cfg_toggle_w),
    .fusion_mode_o(fusion_mode_w)
);

cdc_word_toggle #(
    .WIDTH(10)
) shader_control_cdc_inst (
    .src_clk_i         (sys_clk),
    .src_rst_n_i       (core_rst_n),
    .src_data_i        ({fusion_mode_w, shader_mode_w, lowlight_level_w}),
    .src_send_toggle_i (shader_cfg_toggle_w),
    .src_busy_o        (shader_control_cdc_busy_w),
    .dst_clk_i         (hdmi_pix_clk),
    .dst_rst_n_i       (hdmi_rst_n),
    .dst_data_o        (shader_control_hdmi_w),
    .dst_pulse_o       (shader_control_hdmi_pulse_w)
);

unified_virtual_grab_feature #(
    .IMAGE_WIDTH(1280),
    .IMAGE_HEIGHT(720)
) virtual_grab_feature_inst (
    .sys_clk             (sys_clk),
    .rst_n               (core_rst_n),
    .camera_pclk         (ov5640_pclk),
    .camera_frame_start_i(ov5640_vsync_d_pclk_r & ~ov5640_vsync_dd_pclk_r),
    .camera_pixel_valid_i(wr_en_pipe_pclk_r),
    .camera_rgb565_i     (wr_data_pipe_pclk_r),
    .uart_rxd            (uart_rxd),
    .uart_txd            (virtual_grab_uart_txd_w),
    .fsmc_addr           (fsmc_addr),
    .fsmc_data           (fsmc_data),
    .fsmc_cs_n           (fsmc_cs_n),
    .fsmc_rd_n           (fsmc_rd_n),
    .fsmc_wr_n           (fsmc_wr_n),
    .fsmc_int            (fsmc_int),
    .grab_btn_raw        (~key3_n),
    .release_btn_raw     (~key4_n),
    .hdmi_pix_clk        (hdmi_pix_clk),
    .hdmi_rst_n          (hdmi_rst_n),
    .hdmi_x_i            (pixel_xpos_w),
    .hdmi_y_i            (pixel_ypos_w),
    .hdmi_de_i           (video_de_raw_w),
    .hdmi_rgb_i          (hdmi_rgb_raw_w),
    .hdmi_rgb_o          (virtual_grab_hdmi_rgb_w)
);

// The independent paper-puppet candidate intentionally omits the rotation
// preview framebuffer. Keep the legacy interface as an explicit pass-through.
assign rotate_active_angle_w  = 16'd0;
assign rotate_status_w        = 16'd0;
assign rotate_debug0_w        = 16'd0;
assign rotate_debug1_w        = 16'd0;
assign video_hs_rotate_w      = video_hs_raw_w;
assign video_vs_rotate_w      = video_vs_raw_w;
assign video_de_rotate_w      = video_de_raw_w;
assign hdmi_rgb_rotate_w      = hdmi_rgb_raw_w;
assign rotate_preview_active_w = 1'b0;

video_shader_path #(
    .IMAGE_WIDTH    (1280),
    .DETAIL_GAIN    (4),
    .LIFT_GAIN      (1),
    .TARGET_LUMA    (64),
    .SCALE_MAX_Q8   (384),
    .EDGE_GAIN      (0),
    .SPATIAL_DETAIL_EN(0),
    .SHADOW_TARGET  (192),
    .SHADOW_LOW_KNEE(64),
    .CORE_LATENCY  (13)
) video_shader_path_inst (
    .pix_clk              (hdmi_pix_clk),
    .pix_rst_n            (hdmi_rst_n),
    .shader_cfg_valid_i   (shader_control_hdmi_pulse_w),
    .shader_enable_i      (shader_control_hdmi_w[8] &&
                           !shader_control_hdmi_w[9]),
    .lowlight_level_i     (shader_control_hdmi_w[7:0]),
    .video_hs_i           (video_hs_out_path_w),
    .video_vs_i           (video_vs_out_path_w),
    .video_de_i           (video_de_out_path_w),
    .video_rgb_i          (hdmi_rgb_out_path_w),
    .video_hs_o           (video_hs_shader_path_w),
    .video_vs_o           (video_vs_shader_path_w),
    .video_de_o           (video_de_shader_path_w),
    .video_rgb_o          (hdmi_rgb_shader_path_w),
    .shader_active_o      (shader_active_hdmi_w)
);

multi_exposure_video_path #(
    .IMAGE_WIDTH       (1280),
    .IMAGE_HEIGHT      (720),
    .CONVERSION_LATENCY(7),
    .OUTPUT_LATENCY    (13)
) multi_exposure_video_path_inst (
    .pix_clk             (hdmi_pix_clk),
    .pix_rst_n           (hdmi_rst_n),
    .fusion_cfg_valid_i  (shader_control_hdmi_pulse_w),
    .fusion_enable_i     (shader_control_hdmi_w[9]),
    .video_hs_i          (video_hs_out_path_w),
    .video_vs_i          (video_vs_out_path_w),
    .video_de_i          (video_de_out_path_w),
    .video_rgb_i         (hdmi_rgb_out_path_w),
    .video_hs_o          (video_hs_fusion_path_w),
    .video_vs_o          (video_vs_fusion_path_w),
    .video_de_o          (video_de_fusion_path_w),
    .video_rgb_o         (hdmi_rgb_fusion_path_w),
    .fusion_active_o     (fusion_active_hdmi_w),
    .fusion_lut_ready_o  (fusion_lut_ready_hdmi_w)
);

uart_diag_mux #(
    .CLK_HZ (50_000_000),
    .BAUD   (115200),
    .CHAR_GAP_CYCLES (4000),
    .ENABLE_PERIODIC_STATUS (1'b1)
) uart_diag_mux_inst (
    .clk                    (sys_clk),
    .rst_n                  (core_rst_n),
    .hdmi_init_done_i       (hdmi_cfg_done_sys_r),
    .cam_init_done_i        (cfg_done_sys_r),
    .cam_data_active_i      (cam_data_seen_r),
    .display_camera_i       (1'b1),
    .fb_frame_ready_i       (frame_ready_r),
    .sdram_init_done_i      (sdram1_init_done & sdram2_init_done),
    .sdram_rd_empty_i       (selected_rd_empty_w),
    .sdram_rd_usedw_i       (selected_rd_fifo_num_w),
    .sdram_wr_usedw_i       (diag_slot_state_w),
    .sdram_underflow_count_i(rd_underflow_counter_r),
    .frame_counter_i        (display_frame_counter_r),
    .line_counter_i         (raw_frame_lines_sys_r),
    .error_count_i          (debug_error_w),
    .cam_commit_count_i     (cam_commit_counter_r),
    .hdmi_frame_count_i     (hdmi_frame_counter_r),
    .frame_swap_count_i     (frame_swap_counter_r),
    .rd_fifo0_min_i         (rd_fifo0_min_r),
    .rd_fifo1_min_i         (rd_fifo1_min_r),
    .rd_fifo0_usedw_i       (rd_fifo0_usedw_sys_r),
    .rd_fifo1_usedw_i       (rd_fifo1_usedw_sys_r),
    .wr_req0_count_i        (wr_req0_count_sys_r),
    .wr_req1_count_i        (wr_req1_count_sys_r),
    .rd_req0_count_i        (rd_req0_count_sys_r),
    .rd_req1_count_i        (rd_req1_count_sys_r),
    .rd_fifo0_empty_count_i (rd_fifo0_empty_count_sys_r),
    .rd_fifo1_empty_count_i (rd_fifo1_empty_count_sys_r),
    .left_pixel_i           (left_pixel_sys_r),
    .right_pixel_i          (right_pixel_sys_r),
    .slot_state_i           (diag_slot_state_w),
    .debug_line_pixels_i    (raw_line_pixels_sys_r),
    .debug_frame_lines_i    (raw_frame_lines_sys_r),
    .cam_last_pixel_i       (cam_last_pixel_sys_r),
    .cam_dbg_frame_pixels_i (raw_frame_pixels_sys_r[19:0]),
    .cam_dbg_frame_lines_i  (raw_frame_lines_sys_r),
    .cam_dbg_line_pixels_i  (raw_line_pixels_sys_r),
    .cam_raw_hi_i           (cam_last_pixel_sys_r[15:8]),
    .cam_raw_lo_i           (cam_last_pixel_sys_r[7:0]),
    .fb_last_pixel_i        (selected_rd_data_100_w),
    .display_pixel_i        (selected_rd_data_100_w),
    .cam_dbg_addr_i         (FPGA_COLORBAR_TEST_EN ? hdmi_dbg_last_addr_r : cam_dbg_addr_sys_r),
    .cam_dbg_data_i         (FPGA_COLORBAR_TEST_EN ? hdmi_dbg_rd_data_r : cam_dbg_data_sys_r),
    .cam_dbg_ack_i          (FPGA_COLORBAR_TEST_EN ? hdmi_dbg_ack_ok_r : cam_dbg_ack_sys_r),
    .cam_busy_i             (FPGA_COLORBAR_TEST_EN ? hdmi_dbg_busy_w : cam_dbg_busy_sys_r),
    .cam_done_i             (FPGA_COLORBAR_TEST_EN ? hdmi_dbg_done_latched_r : cam_dbg_done_sys_r),
    .cam_ack_ok_i           (FPGA_COLORBAR_TEST_EN ? hdmi_dbg_ack_ok_r : cam_dbg_ack_sys_r),
    .cam_nack_i             (FPGA_COLORBAR_TEST_EN ? hdmi_dbg_nack_r : 1'b0),
    .cam_timeout_i          (FPGA_COLORBAR_TEST_EN ? hdmi_dbg_timeout_r : cam_dbg_timeout_sys_r),
    .cam_dbg_state_i        (FPGA_COLORBAR_TEST_EN ? {hdmi_dbg_done_latched_r, hdmi_dbg_ack_ok_r, hdmi_dbg_busy_w} : cam_dbg_state_sys_r),
    .cam_dbg_index_i        (FPGA_COLORBAR_TEST_EN ? 4'h8 : cam_dbg_index_sys_r),
    .zoom_level_i           (8'd0),
    .pan_x_i                (8'd128),
    .pan_y_i                (8'd128),
    .low_light_enable_i     (1'b0),
    .low_light_offset_i     (9'd0),
    .eth_rx_seen_i          (eth_packet_seen_sys_r),
    .eth_good_packets_i     (eth_good_packets_sys_r),
    .eth_bad_packets_i      (eth_bad_packets_sys_r),
    .eth_frame_count_i      (eth_frame_count_sys_r),
    .eth_last_line_i        (eth_last_line_sys_r),
    .eth_last_half_i        (eth_last_half_sys_r),
    .eth_last_chunk_i       (eth_last_chunk_sys_r),
    .eth_last_words_i       (eth_last_words_sys_r),
    .eth_last_frame_id_i    (eth_last_frame_id_sys_r),
    .eth_active_i           (eth_active_sys_r),
    .eth_rx_done_i          (1'b0),
    .eth_rx_byte_num_i      (eth_udp_rx_byte_num_sys_w),
    .eth_raw_count_i        (eth_dbg_raw_rx_cnt_w),
    .eth_pkt_count_i        (eth_dbg_rx_pkt_cnt_w),
    .eth_last_len_i         (eth_rx_last_len_sys_w),
    .eth_arp_counts_i       (eth_arp_dbg_counts_sys_w),
    .uart_tx_o              (uart_diag_tx_w)
);

eth_lite_status_uart #(
    .CLK_HZ (50_000_000),
    .BAUD   (115200),
    .PERIOD_CYCLES (25_000_000)
) eth_lite_status_uart_inst (
    .clk          (sys_clk),
    .rst_n        (core_rst_n),
    .raw_count_i  (eth_dbg_raw_rx_cnt_w),
    .pkt_count_i  (eth_dbg_rx_pkt_cnt_w),
    .last_len_i   (eth_rx_last_len_sys_w),
    .raw_head_i   (eth_raw_rx_head_sys_w),
    .raw_tx_head_i(eth_raw_tx_head_sys_w),
    .arp_counts_i (eth_arp_dbg_counts_sys_w),
    .phy_reset_n_i(eth_rst_n),
    .pll_locked_i (pll_eth_locked),
    .link_speed_i (eth_speed_led_w),
    .tx_clk_mon_i (eth_tx_clk_mon_sys_w),
    .uart_tx_o    (uart_rx_len_tx_w)
);

uart_rotate_control #(
    .CLK_HZ (50_000_000),
    .BAUD   (115200)
) uart_rotate_control_inst (
    .clk                  (sys_clk),
    .rst_n                (core_rst_n),
    .uart_rxd_i           (uart_rxd),
    .uart_txd_o           (uart_rotate_txd_w),
    .heartbeat_i          (led_heartbeat_r[25:10]),
    .status_reg_i         (rotate_status_reg_w),
    .rotate_active_angle_i(rotate_active_angle_w),
    .rotate_status_i      (rotate_status_w),
    .rotate_debug0_i      (rotate_debug0_w),
    .rotate_debug1_i      (rotate_debug1_w),
    .rotate_angle_deg_o   (rotate_angle_deg_w),
    .rotate_cfg_toggle_o  (rotate_cfg_toggle_w)
);

always @(posedge eth_rxc or negedge eth_core_rst_n_w) begin
    if (!eth_core_rst_n_w) begin
        wr_rst_eth_sync_r <= 3'b111;
    end else begin
        wr_rst_eth_sync_r <= {wr_rst_eth_sync_r[1:0], wr_rst_w};
    end
end

always @(posedge hdmi_pix_clk or negedge hdmi_rst_n) begin
    if (!hdmi_rst_n) begin
        frame_ready_meta_hdmi_r <= 1'b0;
        frame_ready_sync_hdmi_r <= 1'b0;
        video_vs_d_hdmi_r <= 1'b0;
        hdmi_frame_toggle_hdmi_r <= 1'b0;
        display_sample_hdmi_r <= 16'd0;
        display_sample_arm_hdmi_r <= 1'b1;
        rd_req0_count_hdmi_r <= 16'd0;
        rd_req1_count_hdmi_r <= 16'd0;
        rd_fifo0_empty_count_hdmi_r <= 16'd0;
        rd_fifo1_empty_count_hdmi_r <= 16'd0;
        rd_underflow_counter_hdmi_r <= 16'd0;
        rd_fifo0_min_hdmi_r <= 11'h7ff;
        rd_fifo1_min_hdmi_r <= 11'h7ff;
        rd_req0_empty_d_hdmi_r <= 1'b0;
        rd_req1_empty_d_hdmi_r <= 1'b0;
        rd_req0_empty_event_hdmi_r <= 1'b0;
        rd_req1_empty_event_hdmi_r <= 1'b0;
        left_pixel_sample_hdmi_r <= 16'd0;
        right_pixel_sample_hdmi_r <= 16'd0;
        video_started_hdmi_r <= 1'b0;
        source_mode_hdmi_sync_r <= 2'b00;
    end else begin
        source_mode_hdmi_sync_r <= {source_mode_hdmi_sync_r[0], ethernet_source_mode_w};
        frame_ready_meta_hdmi_r <= display_enable_r;
        frame_ready_sync_hdmi_r <= frame_ready_meta_hdmi_r;
        rd_req0_empty_d_hdmi_r <= rd_req0_empty_need_w;
        rd_req1_empty_d_hdmi_r <= rd_req1_empty_need_w;
        rd_req0_empty_event_hdmi_r <= rd_req0_empty_need_w && !rd_req0_empty_d_hdmi_r;
        rd_req1_empty_event_hdmi_r <= rd_req1_empty_need_w && !rd_req1_empty_d_hdmi_r;
        if (rd_req0_w) begin
            rd_req0_count_hdmi_r <= rd_req0_count_hdmi_r + 16'd1;
        end
        if (rd_req1_w) begin
            rd_req1_count_hdmi_r <= rd_req1_count_hdmi_r + 16'd1;
        end
        if (rd_req0_empty_event_hdmi_r) begin
            rd_fifo0_empty_count_hdmi_r <= rd_fifo0_empty_count_hdmi_r + 16'd1;
            rd_underflow_counter_hdmi_r <= rd_underflow_counter_hdmi_r + 16'd1;
        end
        if (rd_req1_empty_event_hdmi_r) begin
            rd_fifo1_empty_count_hdmi_r <= rd_fifo1_empty_count_hdmi_r + 16'd1;
            rd_underflow_counter_hdmi_r <= rd_underflow_counter_hdmi_r + 16'd1;
        end
        if (!frame_ready_sync_hdmi_r) begin
            rd_fifo0_min_hdmi_r <= 11'h7ff;
            rd_fifo1_min_hdmi_r <= 11'h7ff;
        end else if (video_de_w) begin
            if (rd_fifo_rd_num0_w < rd_fifo0_min_hdmi_r) begin
                rd_fifo0_min_hdmi_r <= rd_fifo_rd_num0_w;
            end
            if (rd_fifo_rd_num1_w < rd_fifo1_min_hdmi_r) begin
                rd_fifo1_min_hdmi_r <= rd_fifo_rd_num1_w;
            end
        end
        if (video_de_w && (pixel_xpos_w < H_HALF_PIXEL)) begin
            left_pixel_sample_hdmi_r <= rd_data0_w;
        end
        if (video_de_w && (pixel_xpos_w >= H_HALF_PIXEL)) begin
            right_pixel_sample_hdmi_r <= rd_data1_w;
        end
        if (FPGA_COLORBAR_TEST_EN) begin
            video_started_hdmi_r <= 1'b0;
        end else if (frame_ready_sync_hdmi_r && video_de_w) begin
            video_started_hdmi_r <= 1'b1;
        end
        if (FPGA_COLORBAR_TEST_EN) begin
            video_vs_d_hdmi_r <= 1'b0;
            hdmi_frame_toggle_hdmi_r <= 1'b0;
            display_sample_arm_hdmi_r <= 1'b1;
        end else begin
            video_vs_d_hdmi_r <= video_vs_w;
            if (!video_vs_d_hdmi_r && video_vs_w) begin
                hdmi_frame_toggle_hdmi_r <= ~hdmi_frame_toggle_hdmi_r;
                display_sample_arm_hdmi_r <= 1'b1;
            end
            if (display_sample_arm_hdmi_r && frame_ready_sync_hdmi_r && video_de_w) begin
                display_sample_hdmi_r <= video_pixel_data_w;
                display_sample_arm_hdmi_r <= 1'b0;
            end
        end
    end
end

always @(posedge hdmi_pix_clk or negedge hdmi_rst_n) begin
    if (!hdmi_rst_n) begin
        hdmi_hsync_d1_r <= 1'b1;
        hdmi_hsync_d2_r <= 1'b1;
        hdmi_hsync_d3_r <= 1'b1;
        hdmi_vsync_d1_r <= 1'b1;
        hdmi_vsync_d2_r <= 1'b1;
        hdmi_vsync_d3_r <= 1'b1;
        hdmi_de_d1_r    <= 1'b0;
        hdmi_de_d2_r    <= 1'b0;
        hdmi_de_d3_r    <= 1'b0;
        hdmi_rgb_d1_r   <= 24'd0;
        hdmi_rgb_d2_r   <= 24'd0;
        hdmi_rgb_d3_r   <= 24'd0;
        display_right_pipe_hdmi_r <= 2'b00;
    end else begin
        display_right_pipe_hdmi_r <= {display_right_pipe_hdmi_r[0], (pixel_xpos_w >= H_HALF_PIXEL)};
        hdmi_hsync_d1_r <= video_hs_effect_path_w;
        hdmi_hsync_d2_r <= hdmi_hsync_d1_r;
        hdmi_hsync_d3_r <= hdmi_hsync_d2_r;
        hdmi_vsync_d1_r <= video_vs_effect_path_w;
        hdmi_vsync_d2_r <= hdmi_vsync_d1_r;
        hdmi_vsync_d3_r <= hdmi_vsync_d2_r;
        hdmi_de_d1_r    <= video_de_effect_path_w;
        hdmi_de_d2_r    <= hdmi_de_d1_r;
        hdmi_de_d3_r    <= hdmi_de_d2_r;
        hdmi_rgb_d1_r   <= hdmi_rgb_puppet_path_w;
        hdmi_rgb_d2_r   <= hdmi_rgb_d1_r;
        hdmi_rgb_d3_r   <= hdmi_rgb_d2_r;
    end
end

// Dedicated first-stage camera sync capture. Keeping this register separate
// from the large pixel-control process gives the placer a simple IO-local path.
always @(posedge ov5640_pclk or negedge core_rst_n) begin
    if (!core_rst_n) begin
        ov5640_vsync_io_pclk_r <= 1'b0;
    end else begin
        ov5640_vsync_io_pclk_r <= ov5640_vsync;
    end
end

always @(posedge ov5640_pclk or negedge core_rst_n) begin
    if (!core_rst_n) begin
        source_mode_pclk_sync_r <= 2'b00;
        ov5640_vsync_d_pclk_r <= 1'b0;
        ov5640_vsync_dd_pclk_r <= 1'b0;
        ov5640_href_d_pclk_r <= 1'b0;
        ov5640_href_dd_pclk_r <= 1'b0;
        cam_raw_x_mod3_pclk_r <= 2'd0;
        cam_raw_y_mod3_pclk_r <= 2'd0;
        capture_resume_wait_pclk_r <= 1'b1;
        capture_active_pclk_r <= 1'b0;
        wr_en_pipe_pclk_r <= 1'b0;
        wr_data_pipe_pclk_r <= 16'd0;
        wr_line_odd_pipe_pclk_r <= 1'b0;
        capture_pause_meta_pclk_r <= 1'b0;
        capture_pause_sync_pclk_r <= 1'b0;
        capture_pause_sync_d_pclk_r <= 1'b0;
        cam_line_odd_pclk_r <= 1'b0;
        cam_pixel_x_pclk_r <= 12'd0;
        cam_frame_toggle_pclk_r <= 1'b0;
        cam_valid_frame_toggle_pclk_r <= 1'b0;
        frame_seen_pclk_r <= 1'b0;
        frame_pixels_seen_pclk_r <= 1'b0;
        frame_pixels_seen_last_pclk_r <= 1'b0;
        frame_href_seen_pclk_r <= 1'b0;
        raw_line_pixels_pclk_r <= 13'd0;
        raw_line_pixels_last_pclk_r <= 13'd0;
        raw_frame_lines_pclk_r <= 12'd0;
        raw_frame_lines_last_pclk_r <= 12'd0;
        raw_frame_pixels_pclk_r <= 21'd0;
        raw_frame_pixels_last_pclk_r <= 21'd0;
        cam_last_pixel_pclk_r <= 16'd0;
        cam_last_pixel_frame_pclk_r <= 16'd0;
        wr_req0_count_pclk_r <= 16'd0;
        wr_req1_count_pclk_r <= 16'd0;
    end else begin
        source_mode_pclk_sync_r <= {source_mode_pclk_sync_r[0], ethernet_source_mode_w};
        ov5640_vsync_d_pclk_r  <= ov5640_vsync_io_pclk_r;
        ov5640_vsync_dd_pclk_r <= ov5640_vsync_d_pclk_r;
        ov5640_href_d_pclk_r   <= ov5640_href;
        ov5640_href_dd_pclk_r  <= ov5640_href_d_pclk_r;
        capture_pause_meta_pclk_r <= capture_pause_sys_r;
        capture_pause_sync_pclk_r <= capture_pause_meta_pclk_r;
        capture_pause_sync_d_pclk_r <= capture_pause_sync_pclk_r;
        wr_en_pipe_pclk_r      <= wr_en_gated_pclk_w;
        wr_data_pipe_pclk_r    <= wr_data;
        wr_line_odd_pipe_pclk_r <= cam_line_odd_pclk_r;
        if (ov5640_href) begin
            frame_href_seen_pclk_r <= 1'b1;
        end
        if (!PCLK_WR_COUNT_DIAG_EN) begin
            wr_req0_count_pclk_r <= 16'd0;
            wr_req1_count_pclk_r <= 16'd0;
        end

        if (capture_resume_wait_pclk_r && capture_active_pclk_r &&
            !capture_pause_sync_pclk_r && !frame_href_seen_pclk_r) begin
            capture_resume_wait_pclk_r <= 1'b0;
        end

        if (!ov5640_vsync_dd_pclk_r && ov5640_vsync_d_pclk_r) begin
            if (capture_resume_wait_pclk_r && !capture_pause_sync_pclk_r) begin
                capture_active_pclk_r <= 1'b1;
                capture_resume_wait_pclk_r <= 1'b0;
            end
            cam_raw_x_mod3_pclk_r <= 2'd0;
            cam_raw_y_mod3_pclk_r <= 2'd0;
            cam_line_odd_pclk_r <= 1'b0;
            cam_pixel_x_pclk_r <= 12'd0;
            cam_frame_toggle_pclk_r <= ~cam_frame_toggle_pclk_r;
            if (frame_pixels_seen_pclk_r) begin
                cam_valid_frame_toggle_pclk_r <= ~cam_valid_frame_toggle_pclk_r;
            end
            frame_pixels_seen_last_pclk_r <= frame_pixels_seen_pclk_r;
            frame_pixels_seen_pclk_r <= 1'b0;
            frame_href_seen_pclk_r <= 1'b0;
            if (PCLK_DIAG_COUNTERS_EN) begin
                if (frame_seen_pclk_r) begin
                    raw_frame_lines_last_pclk_r  <= raw_frame_lines_pclk_r;
                    raw_frame_pixels_last_pclk_r <= raw_frame_pixels_pclk_r;
                    cam_last_pixel_frame_pclk_r  <= cam_last_pixel_pclk_r;
                end
                frame_seen_pclk_r      <= 1'b1;
                raw_line_pixels_pclk_r      <= 13'd0;
                raw_frame_lines_pclk_r <= 12'd0;
                raw_frame_pixels_pclk_r <= 21'd0;
            end else begin
                frame_seen_pclk_r <= 1'b0;
                raw_line_pixels_pclk_r <= 13'd0;
                raw_line_pixels_last_pclk_r <= 13'd0;
                raw_frame_lines_pclk_r <= 12'd0;
                raw_frame_lines_last_pclk_r <= 12'd0;
                raw_frame_pixels_pclk_r <= 21'd0;
                raw_frame_pixels_last_pclk_r <= 21'd0;
                cam_last_pixel_pclk_r <= 16'd0;
                cam_last_pixel_frame_pclk_r <= 16'd0;
            end
        end else if (!capture_pause_sync_d_pclk_r && capture_pause_sync_pclk_r) begin
            capture_resume_wait_pclk_r <= 1'b1;
        end else if (ov5640_href_dd_pclk_r && !ov5640_href_d_pclk_r) begin
            cam_raw_x_mod3_pclk_r <= 2'd0;
            cam_raw_y_mod3_pclk_r <= (cam_raw_y_mod3_pclk_r == 2'd2) ? 2'd0 :
                                     (cam_raw_y_mod3_pclk_r + 2'd1);
            if (NEW480_STREAM_EN) begin
                cam_line_odd_pclk_r <= 1'b0;
            end else if (cam_raw_y_mod3_pclk_r != 2'd2) begin
                cam_line_odd_pclk_r <= ~cam_line_odd_pclk_r;
            end
            cam_pixel_x_pclk_r <= 12'd0;
            if (PCLK_DIAG_COUNTERS_EN && (raw_line_pixels_pclk_r != 13'd0)) begin
                raw_line_pixels_last_pclk_r <= raw_line_pixels_pclk_r;
                raw_frame_lines_pclk_r      <= raw_frame_lines_pclk_r + 12'd1;
                raw_line_pixels_pclk_r      <= 13'd0;
            end
        end else begin
            if (cam_stream_active_pclk_w) begin
                cam_raw_x_mod3_pclk_r <= (cam_raw_x_mod3_pclk_r == 2'd2) ? 2'd0 :
                                         (cam_raw_x_mod3_pclk_r + 2'd1);
            end
            if (wr_req_pclk_w) begin
                if (PCLK_WR_COUNT_DIAG_EN) begin
                    if (wr_req0_w) begin
                        wr_req0_count_pclk_r <= wr_req0_count_pclk_r + 16'd1;
                    end
                    if (wr_req1_w) begin
                        wr_req1_count_pclk_r <= wr_req1_count_pclk_r + 16'd1;
                    end
                end
                if (NEW480_STREAM_EN) begin
                    cam_line_odd_pclk_r <= NEW480_HALF_LINE_EN ?
                                           (cam_pixel_x_pclk_r >= (H_HALF_PIXEL - 12'd1)) :
                                           1'b0;
                    cam_pixel_x_pclk_r <= (cam_pixel_x_pclk_r == 12'd1279) ?
                                          12'd0 : (cam_pixel_x_pclk_r + 12'd1);
                end else begin
                    cam_pixel_x_pclk_r <= (cam_pixel_x_pclk_r == 12'd1279) ?
                                          12'd0 : (cam_pixel_x_pclk_r + 12'd1);
                end
                frame_pixels_seen_pclk_r <= 1'b1;
                if (PCLK_DIAG_COUNTERS_EN) begin
                    raw_line_pixels_pclk_r <= raw_line_pixels_pclk_r + 13'd1;
                    if (PCLK_FRAME_PIXEL_DIAG_EN) begin
                        raw_frame_pixels_pclk_r <= raw_frame_pixels_pclk_r + 21'd1;
                    end
                    cam_last_pixel_pclk_r <= wr_data_pipe_pclk_r;
                end
            end
            if (!PCLK_DIAG_COUNTERS_EN) begin
                frame_seen_pclk_r <= 1'b0;
                raw_line_pixels_pclk_r <= 13'd0;
                raw_line_pixels_last_pclk_r <= 13'd0;
                raw_frame_lines_pclk_r <= 12'd0;
                raw_frame_lines_last_pclk_r <= 12'd0;
                raw_frame_pixels_pclk_r <= 21'd0;
                raw_frame_pixels_last_pclk_r <= 21'd0;
                cam_last_pixel_pclk_r <= 16'd0;
                cam_last_pixel_frame_pclk_r <= 16'd0;
            end
        end
    end
end

always @(posedge ov5640_pclk or negedge core_rst_n) begin
    if (!core_rst_n) begin
        eth_sdram_fifo0_rdreq_d_pclk_r <= 1'b0;
        eth_sdram_fifo1_rdreq_d_pclk_r <= 1'b0;
    end else begin
        eth_sdram_fifo0_rdreq_d_pclk_r <= eth_sdram_fifo0_rdreq_w;
        eth_sdram_fifo1_rdreq_d_pclk_r <= eth_sdram_fifo1_rdreq_w;
    end
end

always @(posedge clk_100m or negedge core_rst_n) begin
    if (!core_rst_n) begin
        eth_sdram_bridge_drained_meta_100_r <= 1'b0;
        eth_sdram_bridge_drained_100_r <= 1'b0;
    end else begin
        eth_sdram_bridge_drained_meta_100_r <= eth_sdram_bridge_drained_pclk_w;
        eth_sdram_bridge_drained_100_r <= eth_sdram_bridge_drained_meta_100_r;
    end
end

always @(posedge clk_100m or negedge core_rst_n) begin
    if (!core_rst_n) begin
        eth_mode_100_sync_r <= 2'b00;
        eth_mode_100_d_r <= 1'b0;
        cam_frame_toggle_100_r <= 2'b00;
        cam_valid_frame_toggle_100_r <= 2'b00;
        hdmi_frame_toggle_100_r <= 2'b00;
        wr_slot_r <= 2'd1;
        rd_slot_r <= 2'd0;
        pending_slot_r <= 2'd2;
        pending_valid_r <= 1'b0;
        cam_capture_started_r <= 1'b0;
        frame_ready_r <= 1'b0;
        display_enable_r <= 1'b0;
        rd_recover_pending_r <= 1'b0;
        display_frame_counter_r <= 16'd0;
        wr_rst_cnt_r <= BUF_RST_STRETCH;
        rd_rst_cnt_r <= BUF_RST_STRETCH;
        cam_commit_delay_r <= 13'd0;
        cam_commit_ready_r <= 1'b1;
        commit_wait_cnt_r <= 13'd0;
        capture_resume_cnt_r <= 4'd0;
        commit_wait_r <= 1'b0;
        capture_pause_sys_r <= 1'b0;
        cam_frame_counter_r <= 16'd0;
        hdmi_frame_counter_r <= 16'd0;
        cam_commit_counter_r <= 16'd0;
        frame_swap_counter_r <= 16'd0;
        rd_underflow_counter_r <= 16'd0;
        rd_fifo0_min_r <= 11'h7ff;
        rd_fifo1_min_r <= 11'h7ff;
        rd_underflow_counter_meta_r <= 16'd0;
        rd_fifo0_min_meta_r <= 11'h7ff;
        rd_fifo1_min_meta_r <= 11'h7ff;
        rd_fifo0_usedw_meta_r <= 11'd0;
        rd_fifo0_usedw_sys_r <= 11'd0;
        rd_fifo1_usedw_meta_r <= 11'd0;
        rd_fifo1_usedw_sys_r <= 11'd0;
        selected_rd_fifo_num_sys_r <= 11'd0;
        frame_ready_hdmi_meta_r <= 1'b0;
        frame_ready_hdmi_sys_r <= 1'b0;

        raw_line_pixels_meta_r <= 16'd0;
        raw_line_pixels_sys_r  <= 16'd0;
        raw_frame_lines_meta_r <= 16'd0;
        raw_frame_lines_sys_r  <= 16'd0;
        raw_frame_pixels_meta_r <= 21'd0;
        raw_frame_pixels_sys_r  <= 21'd0;
        cam_last_pixel_meta_r <= 16'd0;
        cam_last_pixel_sys_r  <= 16'd0;
        frame_pixels_seen_meta_r <= 1'b0;
        frame_pixels_seen_sys_r  <= 1'b0;
        cam_data_seen_r <= 1'b0;
        cfg_done_meta_r <= 1'b0;
        cfg_done_sys_r  <= 1'b0;
        hdmi_cfg_done_meta_r <= 1'b0;
        hdmi_cfg_done_sys_r  <= 1'b0;
        cam_dbg_addr_meta_r <= 16'd0;
        cam_dbg_addr_sys_r  <= 16'd0;
        cam_dbg_data_meta_r <= 8'd0;
        cam_dbg_data_sys_r  <= 8'd0;
        cam_dbg_ack_meta_r  <= 1'b0;
        cam_dbg_ack_sys_r   <= 1'b0;
        cam_dbg_busy_meta_r <= 1'b0;
        cam_dbg_busy_sys_r  <= 1'b0;
        cam_dbg_done_meta_r <= 1'b0;
        cam_dbg_done_sys_r  <= 1'b0;
        cam_dbg_timeout_meta_r <= 1'b0;
        cam_dbg_timeout_sys_r  <= 1'b0;
        cam_dbg_state_meta_r <= 3'd0;
        cam_dbg_state_sys_r  <= 3'd0;
        cam_dbg_index_meta_r <= 4'd0;
        cam_dbg_index_sys_r  <= 4'd0;
        rd_data0_meta_r <= 16'd0;
        rd_data0_sys_r  <= 16'd0;
        rd_data1_meta_r <= 16'd0;
        rd_data1_sys_r  <= 16'd0;
        wr_req0_count_meta_r <= 16'd0;
        wr_req0_count_sys_r  <= 16'd0;
        wr_req1_count_meta_r <= 16'd0;
        wr_req1_count_sys_r  <= 16'd0;
        rd_req0_count_meta_r <= 16'd0;
        rd_req0_count_sys_r  <= 16'd0;
        rd_req1_count_meta_r <= 16'd0;
        rd_req1_count_sys_r  <= 16'd0;
        rd_fifo0_empty_count_meta_r <= 16'd0;
        rd_fifo0_empty_count_sys_r  <= 16'd0;
        rd_fifo1_empty_count_meta_r <= 16'd0;
        rd_fifo1_empty_count_sys_r  <= 16'd0;
        left_pixel_meta_r <= 16'd0;
        left_pixel_sys_r  <= 16'd0;
        right_pixel_meta_r <= 16'd0;
        right_pixel_sys_r  <= 16'd0;
        eth_frame_done_100_r <= 2'b00;
        eth_frame_abort_100_r <= 2'b00;
        rd_underflow_toggle_100_r <= 2'b00;
        eth_good_packets_meta_r <= 16'd0;
        eth_good_packets_sys_r  <= 16'd0;
        eth_bad_packets_meta_r <= 16'd0;
        eth_bad_packets_sys_r  <= 16'd0;
        eth_frame_count_meta_r <= 16'd0;
        eth_frame_count_sys_r  <= 16'd0;
        eth_last_line_meta_r <= 11'd0;
        eth_last_line_sys_r  <= 11'd0;
        eth_last_half_meta_r <= 1'b0;
        eth_last_half_sys_r  <= 1'b0;
        eth_last_chunk_meta_r <= 2'd0;
        eth_last_chunk_sys_r  <= 2'd0;
        eth_last_words_meta_r <= 16'd0;
        eth_last_words_sys_r  <= 16'd0;
        eth_last_frame_id_meta_r <= 8'd0;
        eth_last_frame_id_sys_r  <= 8'd0;
        eth_active_meta_r <= 1'b0;
        eth_active_sys_r  <= 1'b0;
        eth_packet_seen_meta_r <= 1'b0;
        eth_packet_seen_sys_r  <= 1'b0;
    end else begin
        eth_mode_100_sync_r <= {eth_mode_100_sync_r[0], ethernet_source_mode_w};
        eth_mode_100_d_r <= ETH_VIDEO_TEST_EN;
        cam_frame_toggle_100_r  <= {cam_frame_toggle_100_r[0], cam_frame_toggle_pclk_r};
        cam_valid_frame_toggle_100_r <= {cam_valid_frame_toggle_100_r[0],
                                         cam_valid_frame_toggle_pclk_r};
        hdmi_frame_toggle_100_r <= {hdmi_frame_toggle_100_r[0], hdmi_frame_toggle_hdmi_r};
        eth_frame_done_100_r    <= {eth_frame_done_100_r[0], eth_video_frame_done_toggle_w};
        eth_frame_abort_100_r   <= {eth_frame_abort_100_r[0], eth_video_frame_abort_toggle_w};
        rd_underflow_toggle_100_r <= {rd_underflow_toggle_100_r[0],
                                      rd_underflow_toggle_hdmi_w};
        if (wr_rst_cnt_r != 4'd0) begin
            wr_rst_cnt_r <= wr_rst_cnt_r - 4'd1;
        end
        if (rd_rst_cnt_r != 4'd0) begin
            rd_rst_cnt_r <= rd_rst_cnt_r - 4'd1;
        end
        if (cam_commit_delay_r != 13'd0) begin
            cam_commit_delay_r <= cam_commit_delay_r - 13'd1;
            if (cam_commit_delay_r == 13'd1) begin
                cam_commit_ready_r <= 1'b1;
            end
        end
        if (commit_wait_r && !commit_grace_expired_w) begin
            commit_wait_cnt_r <= commit_wait_cnt_r + 13'd1;
        end
        if (capture_resume_cnt_r != 4'd0) begin
            capture_resume_cnt_r <= capture_resume_cnt_r - 4'd1;
            if (capture_resume_cnt_r == 4'd1) begin
                capture_pause_sys_r <= 1'b0;
            end
        end
        rd_underflow_counter_meta_r <= rd_underflow_counter_hdmi_r;
        rd_underflow_counter_r <= rd_underflow_counter_meta_r;
        rd_fifo0_min_meta_r <= rd_fifo0_min_hdmi_r;
        rd_fifo0_min_r <= rd_fifo0_min_meta_r;
        rd_fifo1_min_meta_r <= rd_fifo1_min_hdmi_r;
        rd_fifo1_min_r <= rd_fifo1_min_meta_r;
        rd_fifo0_usedw_meta_r <= rd_fifo_num0_w;
        rd_fifo0_usedw_sys_r <= rd_fifo0_usedw_meta_r;
        rd_fifo1_usedw_meta_r <= rd_fifo_num1_w;
        rd_fifo1_usedw_sys_r <= rd_fifo1_usedw_meta_r;
        selected_rd_fifo_num_sys_r <= selected_rd_fifo_num_sys_w;
        frame_ready_hdmi_meta_r <= frame_ready_sync_hdmi_r;
        frame_ready_hdmi_sys_r <= frame_ready_hdmi_meta_r;

        if (source_frame_pulse_100_w) begin
            cam_frame_counter_r <= cam_frame_counter_r + 16'd1;
        end
        if (hdmi_frame_pulse_100_w) begin
            hdmi_frame_counter_r <= hdmi_frame_counter_r + 16'd1;
        end

        raw_line_pixels_meta_r <= {3'd0, raw_line_pixels_last_pclk_r};
        raw_line_pixels_sys_r  <= raw_line_pixels_meta_r;
        raw_frame_lines_meta_r <= {4'd0, raw_frame_lines_last_pclk_r};
        raw_frame_lines_sys_r  <= raw_frame_lines_meta_r;
        raw_frame_pixels_meta_r <= raw_frame_pixels_last_pclk_r;
        raw_frame_pixels_sys_r  <= raw_frame_pixels_meta_r;
        cam_last_pixel_meta_r <= cam_last_pixel_frame_pclk_r;
        cam_last_pixel_sys_r  <= cam_last_pixel_meta_r;
        frame_pixels_seen_meta_r <= frame_pixels_seen_last_pclk_r;
        frame_pixels_seen_sys_r  <= frame_pixels_seen_meta_r;
        if (ETH_VIDEO_TEST_EN && (eth_frame_count_sys_r != 16'd0)) begin
            cam_data_seen_r <= 1'b1;
        end else if (frame_pixels_seen_sys_r) begin
            cam_data_seen_r <= 1'b1;
        end
        cfg_done_meta_r <= cfg_done;
        cfg_done_sys_r  <= cfg_done_meta_r;
        hdmi_cfg_done_meta_r <= hdmi_cfg_done;
        hdmi_cfg_done_sys_r  <= hdmi_cfg_done_meta_r;
        cam_dbg_addr_meta_r <= cam_dbg_addr_w;
        cam_dbg_addr_sys_r  <= cam_dbg_addr_meta_r;
        cam_dbg_data_meta_r <= cam_dbg_data_w;
        cam_dbg_data_sys_r  <= cam_dbg_data_meta_r;
        cam_dbg_ack_meta_r  <= cam_dbg_ack_w;
        cam_dbg_ack_sys_r   <= cam_dbg_ack_meta_r;
        cam_dbg_busy_meta_r <= cam_dbg_busy_w;
        cam_dbg_busy_sys_r  <= cam_dbg_busy_meta_r;
        cam_dbg_done_meta_r <= cam_dbg_done_w;
        cam_dbg_done_sys_r  <= cam_dbg_done_meta_r;
        cam_dbg_timeout_meta_r <= cam_dbg_timeout_w;
        cam_dbg_timeout_sys_r  <= cam_dbg_timeout_meta_r;
        cam_dbg_state_meta_r <= cam_dbg_state_w;
        cam_dbg_state_sys_r  <= cam_dbg_state_meta_r;
        cam_dbg_index_meta_r <= cam_dbg_index_w;
        cam_dbg_index_sys_r  <= cam_dbg_index_meta_r;
        rd_data0_meta_r <= display_sample_hdmi_r;
        rd_data0_sys_r  <= rd_data0_meta_r;
        rd_data1_meta_r <= 16'd0;
        rd_data1_sys_r  <= rd_data1_meta_r;
        wr_req0_count_meta_r <= wr_req0_count_pclk_r;
        wr_req0_count_sys_r  <= wr_req0_count_meta_r;
        wr_req1_count_meta_r <= wr_req1_count_pclk_r;
        wr_req1_count_sys_r  <= wr_req1_count_meta_r;
        rd_req0_count_meta_r <= rd_req0_count_hdmi_r;
        rd_req0_count_sys_r  <= rd_req0_count_meta_r;
        rd_req1_count_meta_r <= rd_req1_count_hdmi_r;
        rd_req1_count_sys_r  <= rd_req1_count_meta_r;
        rd_fifo0_empty_count_meta_r <= rd_fifo0_empty_count_hdmi_r;
        rd_fifo0_empty_count_sys_r  <= rd_fifo0_empty_count_meta_r;
        rd_fifo1_empty_count_meta_r <= rd_fifo1_empty_count_hdmi_r;
        rd_fifo1_empty_count_sys_r  <= rd_fifo1_empty_count_meta_r;
        left_pixel_meta_r <= left_pixel_sample_hdmi_r;
        left_pixel_sys_r  <= left_pixel_meta_r;
        right_pixel_meta_r <= right_pixel_sample_hdmi_r;
        right_pixel_sys_r  <= right_pixel_meta_r;
        eth_good_packets_meta_r <= eth_video_good_packets_w;
        eth_good_packets_sys_r  <= eth_good_packets_meta_r;
        eth_bad_packets_meta_r  <= eth_video_bad_packets_w;
        eth_bad_packets_sys_r   <= eth_bad_packets_meta_r;
        eth_frame_count_meta_r  <= eth_video_frame_count_w;
        eth_frame_count_sys_r   <= eth_frame_count_meta_r;
        eth_last_line_meta_r    <= eth_video_last_line_w;
        eth_last_line_sys_r     <= eth_last_line_meta_r;
        eth_last_half_meta_r    <= eth_video_last_half_w;
        eth_last_half_sys_r     <= eth_last_half_meta_r;
        eth_last_chunk_meta_r   <= eth_video_last_chunk_w;
        eth_last_chunk_sys_r    <= eth_last_chunk_meta_r;
        eth_last_words_meta_r   <= eth_video_last_words_w;
        eth_last_words_sys_r    <= eth_last_words_meta_r;
        eth_last_frame_id_meta_r <= eth_video_last_frame_id_w;
        eth_last_frame_id_sys_r  <= eth_last_frame_id_meta_r;
        eth_active_meta_r       <= eth_video_active_w;
        eth_active_sys_r        <= eth_active_meta_r;
        eth_packet_seen_meta_r  <= eth_video_packet_seen_toggle_w;
        eth_packet_seen_sys_r   <= eth_packet_seen_meta_r;

        if (source_frame_pulse_100_w) begin
            cam_capture_started_r <= 1'b1;
        end

        if (eth_mode_changed_100_w) begin
            wr_rst_cnt_r <= BUF_RST_STRETCH;
            pending_valid_r <= 1'b0;
            rd_recover_pending_r <= 1'b0;
            commit_wait_r <= 1'b0;
            commit_wait_cnt_r <= 13'd0;
            cam_commit_delay_r <= 13'd0;
            cam_commit_ready_r <= 1'b1;
            capture_pause_sys_r <= 1'b0;
            capture_resume_cnt_r <= 4'd0;
            cam_capture_started_r <= 1'b0;
        end

        // A missing, duplicated, or reordered UDP packet invalidates the
        // current write slot. Flush only the Ethernet write pipeline; the
        // last complete read slot remains visible on HDMI.
        if (ETH_VIDEO_TEST_EN && eth_frame_abort_pulse_100_w &&
            !eth_mode_changed_100_w) begin
            wr_rst_cnt_r <= BUF_RST_STRETCH;
            commit_wait_r <= 1'b0;
            commit_wait_cnt_r <= 13'd0;
            cam_commit_delay_r <= 13'd0;
            cam_commit_ready_r <= 1'b1;
            capture_pause_sys_r <= 1'b0;
            capture_resume_cnt_r <= 4'd0;
        end

        if (cam_frame_done_w && !commit_wait_r && !eth_mode_changed_100_w) begin
            commit_wait_r <= 1'b1;
            commit_wait_cnt_r <= 13'd0;
            capture_pause_sys_r <= 1'b1;
            capture_resume_cnt_r <= 4'd0;
        end

        if (ETH_VIDEO_TEST_EN && rd_underflow_event_100_w) begin
            rd_recover_pending_r <= 1'b1;
        end

        // Ethernet recovers only at an HDMI frame boundary; camera mode keeps
        // the stable baseline's immediate empty-FIFO recovery behavior.
        if (ETH_VIDEO_TEST_EN && hdmi_frame_pulse_100_w && rd_recover_pending_r) begin
            display_enable_r <= 1'b0;
            rd_rst_cnt_r <= BUF_RST_STRETCH;
            rd_recover_pending_r <= 1'b0;
        end else if (!ETH_VIDEO_TEST_EN && display_enable_r &&
            (rd_rst_cnt_r == 4'd0) && selected_rd_empty_w) begin
            display_enable_r <= 1'b0;
            rd_rst_cnt_r <= BUF_RST_STRETCH;
        end else if (frame_ready_r && !display_enable_r &&
            (rd_rst_cnt_r == 4'd0) &&
            rd_fifo_prime_ok_sys_w) begin
            display_enable_r <= 1'b1;
        end

        if (hdmi_swap_w) begin
            rd_slot_r <= pending_slot_r;
            frame_ready_r <= 1'b1;
            display_enable_r <= 1'b0;
            rd_recover_pending_r <= 1'b0;
            display_frame_counter_r <= display_frame_counter_r + 16'd1;
            frame_swap_counter_r <= frame_swap_counter_r + 16'd1;
            pending_valid_r <= 1'b0;
            rd_rst_cnt_r <= BUF_RST_STRETCH;
        end

        if (cam_commit_w) begin
            pending_slot_r <= wr_slot_r;
            pending_valid_r <= 1'b1;
            wr_slot_r <= next_wr_slot_w;
            wr_rst_cnt_r <= BUF_RST_STRETCH;
            commit_wait_r <= 1'b0;
            commit_wait_cnt_r <= 13'd0;
            capture_resume_cnt_r <= BUF_RST_STRETCH;
            cam_commit_delay_r <= CAM_COMMIT_DELAY;
            cam_commit_ready_r <= 1'b0;
            cam_commit_counter_r <= cam_commit_counter_r + 16'd1;
        end
end
end

`endif

endmodule

