// ============================================================================
// Module Function:
//   RGMII receive interface that converts PHY DDR receive signals into byte stream data.
// ============================================================================
module rgmii_rx(
    //以太网RGMII接口
    input              rgmii_rxc   , //RGMII接收时钟
    input              rgmii_rx_ctl, //RGMII接收数据控制信号
    input       [3:0]  rgmii_rxd   , //RGMII接收数据    

    //以太网GMII接口
    output          gmii_rx_clk , //GMII接收时钟
    output          gmii_rx_dv  , //GMII接收数据有效信号
    output  reg [7:0]  gmii_rxd    ,  //GMII接收数据   
    output  reg        arp_rx_clk_flag
    );   

//wire define    
//wire  [1:0]  gmii_rxdv_t;        //两位GMII接收有效信号 

//*****************************************************
//**                    main code
//*****************************************************
localparam rgmii_rx_ctl_d_size = 4;
reg [rgmii_rx_ctl_d_size:0] rgmii_rx_ctl_d;
reg arp_rx_clk_flag_d;

assign gmii_rx_clk = rgmii_rxc;
assign gmii_rx_dv = rgmii_rx_ctl_d[0] | rgmii_rx_ctl_d[rgmii_rx_ctl_d_size];//gmii_rxdv_t[0] & gmii_rxdv_t[1];
// assign arp_rx_clk_flag = gmii_rx_clk;

always @(posedge rgmii_rxc) rgmii_rx_ctl_d<={rgmii_rx_ctl_d[rgmii_rx_ctl_d_size-1:0],rgmii_rx_ctl};

// always @(posedge rgmii_rxc) gmii_rx_dv<=rgmii_rx_ctl_d;
always @(posedge rgmii_rxc) begin
    if(rgmii_rx_ctl || gmii_rx_dv) arp_rx_clk_flag_d<=~arp_rx_clk_flag_d;
    else arp_rx_clk_flag_d<=1'b0;
end
always @(posedge rgmii_rxc) arp_rx_clk_flag<=arp_rx_clk_flag_d;
always @(posedge rgmii_rxc)begin
    gmii_rxd<={rgmii_rxd,gmii_rxd[7:4]};
end

endmodule