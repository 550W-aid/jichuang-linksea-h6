`timescale 1ns/1ps

// Frame-based direct multi-exposure fusion for a continuous RGB888 HDMI stream.
// The first completed frame builds a luma LUT; following frames use the most
// recently completed LUT. The fixed output latency matches video_shader_path.
module multi_exposure_video_path #(
    parameter integer IMAGE_WIDTH       = 1280,
    parameter integer IMAGE_HEIGHT      = 720,
    parameter integer CONVERSION_LATENCY = 7,
    parameter integer OUTPUT_LATENCY     = 13
) (
    input  wire        pix_clk,
    input  wire        pix_rst_n,
    input  wire        fusion_cfg_valid_i,
    input  wire        fusion_enable_i,
    input  wire        video_hs_i,
    input  wire        video_vs_i,
    input  wire        video_de_i,
    input  wire [23:0] video_rgb_i,
    output wire        video_hs_o,
    output wire        video_vs_o,
    output wire        video_de_o,
    output wire [23:0] video_rgb_o,
    output wire        fusion_active_o,
    output wire        fusion_lut_ready_o
);
    localparam integer EXTRA_LATENCY = OUTPUT_LATENCY - CONVERSION_LATENCY;

    reg fusion_enable_pending_r;
    reg fusion_enable_active_r;
    reg [10:0] pixel_x_r;
    reg [9:0]  pixel_y_r;
    reg        frame_sof_pending_r;

    wire stream_sof_w;
    wire stream_eol_w;
    wire stream_eof_w;
    wire stream_s_ready_w;
    wire stream_m_valid_w;
    wire [23:0] stream_m_data_w;
    wire stream_m_keep_w;
    wire stream_m_sof_w;
    wire stream_m_eol_w;
    wire stream_m_eof_w;

    wire timing_hs_w;
    wire timing_vs_w;
    wire timing_de_w;
    wire [23:0] timing_rgb_w;
    wire fusion_de_aligned_w;
    wire [23:0] fusion_rgb_aligned_w;

    assign stream_sof_w = video_de_i && frame_sof_pending_r &&
                          (pixel_x_r == 11'd0) && (pixel_y_r == 10'd0);
    assign stream_eol_w = video_de_i &&
                          (pixel_x_r == IMAGE_WIDTH - 1);
    assign stream_eof_w = stream_eol_w &&
                          (pixel_y_r == IMAGE_HEIGHT - 1);

    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n) begin
            fusion_enable_pending_r <= 1'b0;
            fusion_enable_active_r  <= 1'b0;
            pixel_x_r               <= 11'd0;
            pixel_y_r               <= 10'd0;
            frame_sof_pending_r     <= 1'b1;
        end else begin
            if (fusion_cfg_valid_i) begin
                fusion_enable_pending_r <= fusion_enable_i;
            end

            // 720p VS is active low. Commit mode changes only in vertical
            // blanking so the selected path cannot change within a frame.
            if (!video_vs_i) begin
                fusion_enable_active_r <= fusion_cfg_valid_i ?
                                          fusion_enable_i :
                                          fusion_enable_pending_r;
                pixel_x_r           <= 11'd0;
                pixel_y_r           <= 10'd0;
                frame_sof_pending_r <= 1'b1;
            end else if (video_de_i) begin
                if (frame_sof_pending_r) begin
                    frame_sof_pending_r <= 1'b0;
                end
                if (stream_eol_w) begin
                    pixel_x_r <= 11'd0;
                    if (pixel_y_r == IMAGE_HEIGHT - 1) begin
                        pixel_y_r <= 10'd0;
                    end else begin
                        pixel_y_r <= pixel_y_r + 10'd1;
                    end
                end else begin
                    pixel_x_r <= pixel_x_r + 11'd1;
                end
            end
        end
    end

    darkness_enhance_rgb888_stream_std #(
        .MAX_LANES (1),
        .GAMMA_MODE(2'd1),
        .FUSION_EN (1'b1)
    ) fusion_stream_inst (
        .clk                     (pix_clk),
        .rst_n                   (pix_rst_n),
        .s_valid                 (video_de_i),
        .s_ready                 (stream_s_ready_w),
        .s_data                  (video_rgb_i),
        .s_keep                  (1'b1),
        .s_sof                   (stream_sof_w),
        .s_eol                   (stream_eol_w),
        .s_eof                   (stream_eof_w),
        .cfg_valid               (1'b1),
        .cfg_ready               (),
        .cfg_brightness_offset   (9'sd0),
        .active_brightness_offset(),
        .m_valid                 (stream_m_valid_w),
        .m_ready                 (1'b1),
        .m_data                  (stream_m_data_w),
        .m_keep                  (stream_m_keep_w),
        .m_sof                   (stream_m_sof_w),
        .m_eol                   (stream_m_eol_w),
        .m_eof                   (stream_m_eof_w),
        .fusion_lut_ready_o      (fusion_lut_ready_o)
    );

    video_stream_delay #(
        .LATENCY(OUTPUT_LATENCY)
    ) timing_delay_inst (
        .clk        (pix_clk),
        .rst_n      (pix_rst_n),
        .video_hs_i (video_hs_i),
        .video_vs_i (video_vs_i),
        .video_de_i (video_de_i),
        .video_rgb_i(video_rgb_i),
        .video_hs_o (timing_hs_w),
        .video_vs_o (timing_vs_w),
        .video_de_o (timing_de_w),
        .video_rgb_o(timing_rgb_w)
    );

    video_stream_delay #(
        .LATENCY(EXTRA_LATENCY)
    ) fusion_alignment_delay_inst (
        .clk        (pix_clk),
        .rst_n      (pix_rst_n),
        .video_hs_i (1'b1),
        .video_vs_i (1'b1),
        .video_de_i (stream_m_valid_w),
        .video_rgb_i(stream_m_data_w),
        .video_hs_o (),
        .video_vs_o (),
        .video_de_o (fusion_de_aligned_w),
        .video_rgb_o(fusion_rgb_aligned_w)
    );

    assign video_hs_o       = timing_hs_w;
    assign video_vs_o       = timing_vs_w;
    assign video_de_o       = timing_de_w;
    assign video_rgb_o      = fusion_enable_active_r ?
                              fusion_rgb_aligned_w : timing_rgb_w;
    assign fusion_active_o  = fusion_enable_active_r;

    // synthesis translate_off
    initial begin
        if (OUTPUT_LATENCY <= CONVERSION_LATENCY) begin
            $display("ASSERTION FAILED: OUTPUT_LATENCY must exceed CONVERSION_LATENCY");
            $stop;
        end
    end

    always @(posedge pix_clk) begin
        if (pix_rst_n && video_de_i && !stream_s_ready_w) begin
            $display("ASSERTION FAILED: fusion stream applied backpressure");
            $stop;
        end
        if (pix_rst_n && (fusion_de_aligned_w !== timing_de_w)) begin
            $display("ASSERTION FAILED: fusion RGB and HDMI DE are not aligned time=%0t fusion=%b de=%b",
                     $time, fusion_de_aligned_w, timing_de_w);
            $stop;
        end
        if (pix_rst_n && stream_m_valid_w && !stream_m_keep_w) begin
            $display("ASSERTION FAILED: fusion output valid without keep");
            $stop;
        end
        if (pix_rst_n && stream_m_sof_w && !stream_m_valid_w) begin
            $display("ASSERTION FAILED: fusion SOF without valid");
            $stop;
        end
        if (pix_rst_n && stream_m_eol_w && !stream_m_valid_w) begin
            $display("ASSERTION FAILED: fusion EOL without valid");
            $stop;
        end
        if (pix_rst_n && stream_m_eof_w && !stream_m_valid_w) begin
            $display("ASSERTION FAILED: fusion EOF without valid");
            $stop;
        end
    end
    // synthesis translate_on
endmodule
