// Module Function:
//   Fixed-rate RGB888 valid/ready compatibility wrapper for New_shader. The
//   datapath is not backpressure-capable, so s_ready is permanently asserted.
module retinex_rgb888_stream_top #(
    parameter IMAGE_WIDTH = 1280,
    parameter [7:0] LOWLIGHT_LEVEL = 8'hff,
    parameter CORE_LATENCY = 13
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        s_valid,
    output wire        s_ready,
    input  wire [23:0] s_data,
    input  wire        s_keep,
    input  wire        s_sof,
    input  wire        s_eol,
    input  wire        s_eof,
    output wire        m_valid,
    input  wire        m_ready,
    output wire [23:0] m_data,
    output wire        m_keep,
    output wire        m_sof,
    output wire        m_eol,
    output wire        m_eof
);
    wire core_valid_w;
    wire core_sof_w;
    wire core_eol_w;
    wire [7:0] core_r_w;
    wire [7:0] core_g_w;
    wire [7:0] core_b_w;
    wire eof_valid_w;
    wire eof_sof_w;
    wire eof_eol_w;
    wire eof_data_w;
    wire stream_valid_w = s_valid && s_keep;

    assign s_ready = 1'b1;
    assign m_valid = core_valid_w;
    assign m_data  = {core_r_w, core_g_w, core_b_w};
    assign m_keep  = core_valid_w;
    assign m_sof   = core_sof_w;
    assign m_eol   = core_eol_w;
    assign m_eof   = eof_valid_w && eof_data_w;

    retinex_core #(
        .IMAGE_WIDTH(IMAGE_WIDTH)
    ) retinex_core_inst (
        .clk             (clk),
        .rst_n           (rst_n),
        .lowlight_level_i(LOWLIGHT_LEVEL),
        .in_valid        (stream_valid_w),
        .in_sof          (s_sof),
        .in_eol          (s_eol),
        .in_r            (s_data[23:16]),
        .in_g            (s_data[15:8]),
        .in_b            (s_data[7:0]),
        .out_valid       (core_valid_w),
        .out_sof         (core_sof_w),
        .out_eol         (core_eol_w),
        .out_r           (core_r_w),
        .out_g           (core_g_w),
        .out_b           (core_b_w)
    );

    retinex_stream_delay #(
        .DATA_WIDTH(1),
        .LATENCY(CORE_LATENCY)
    ) eof_delay_inst (
        .clk      (clk),
        .rst_n    (rst_n),
        .in_valid (stream_valid_w),
        .in_sof   (s_sof),
        .in_eol   (s_eol),
        .in_data  (s_eof),
        .out_valid(eof_valid_w),
        .out_sof  (eof_sof_w),
        .out_eol  (eof_eol_w),
        .out_data (eof_data_w)
    );

    wire unused_m_ready_w = m_ready;
    wire unused_eof_sidebands_w = eof_sof_w ^ eof_eol_w;
endmodule
