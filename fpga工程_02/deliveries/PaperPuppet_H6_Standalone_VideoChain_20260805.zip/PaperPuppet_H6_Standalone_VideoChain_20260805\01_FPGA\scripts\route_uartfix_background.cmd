@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "F:\codex\merge_20260722\Unified_480x270_VGrab_Gimbal_Work\01_FPGA\scripts\run_ov5640_hdmi_1080p_helper_flow.ps1" -Action compile -BoardTestOnly
exit /b %ERRORLEVEL%
