﻿param(
    [ValidateSet('doctor', 'compile', 'sta', 'bitgen', 'program', 'report', 'all')]
    [string]$Action = 'doctor',
    [switch]$ForceSynthesis,
    [switch]$AllowGmiiTimingWarnings,
    [switch]$BoardTestOnly
)

$ErrorActionPreference = 'Stop'

$projectName = 'ov5640_hdmi_1080p'
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$projectFile = Join-Path $projectRoot "$projectName.epr"
$runRoot = Join-Path $projectRoot "$projectName.runs/imple_1"
$synthRoot = Join-Path $projectRoot "$projectName.runs/synth_1"
$helperLogDir = Join-Path $projectRoot 'release_logs'
$readSdcRouteScript = Join-Path $PSScriptRoot 'route_with_read_sdc.tcl'
$nativeImplementation = 'D:/eLinx3.0/bin/shell/bin/Implementation.exe'
$gmiiTimingChecker = Join-Path $PSScriptRoot 'check_gmii_output_timing.py'
$gmiiInputTimingChecker = Join-Path $PSScriptRoot 'check_gmii_input_capture_timing.py'
$gmiiTxPhasePs = 0
$script:LastRouteLog = $null
$noValidObjectPattern = 'No valid object\(s\)' # Matches native text: No valid object(s)
$releaseFmaxMHz = @{
    'sys_clk' = 50.0
    'ov5640_pclk' = 84.0
    'hdmi_pix' = 74.25
}
$helperCandidates = @(
    'D:/Work/Git/jichuang-linksea-h6_main/elinx-helper',
    'F:/codex/jichuang-linksea-h6_main_elinx-helper/elinx-helper',
    (Join-Path (Split-Path $projectRoot -Parent) 'jichuang-linksea-h6_main_elinx-helper/elinx-helper')
)
$helperRoot = $helperCandidates |
    Where-Object { Test-Path -LiteralPath (Join-Path $_ 'elinx-compile.cmd') } |
    Select-Object -First 1

New-Item -ItemType Directory -Force -Path $helperLogDir | Out-Null
$env:ELINX_HELPER_LOG_DIR = $helperLogDir
$env:PATH = "$PSScriptRoot;$env:PATH"

function Assert-RequiredPaths {
    if (-not $helperRoot) {
        throw 'Shared eLinx helper was not found.'
    }
    foreach ($required in @($projectFile, $readSdcRouteScript, $nativeImplementation, $gmiiTimingChecker, $gmiiInputTimingChecker)) {
        if (-not (Test-Path -LiteralPath $required)) {
            throw "Required build input was not found: $required"
        }
    }
}

function Get-HelperLogPath {
    param([string]$ScriptName)

    $actionName = [IO.Path]::GetFileNameWithoutExtension($ScriptName) -replace '^elinx-', ''
    Join-Path $helperLogDir "$actionName-$projectName.log"
}

function Assert-HelperLogClean {
    param([string]$ScriptName)

    $logPath = Get-HelperLogPath $ScriptName
    if (-not (Test-Path -LiteralPath $logPath)) {
        throw "$ScriptName did not produce helper log: $logPath"
    }
    $logItem = Get-Item -LiteralPath $logPath
    if ($logItem.Length -le 0) {
        throw "Log is empty for $ScriptName`: $logPath"
    }
    $logText = Get-Content -LiteralPath $logPath -Raw
    foreach ($pattern in @(
        'ECP file NOT accordance',
        'Load ECP Error',
        '\[ERROR\]',
        'Fatal Error',
        'Traceback',
        'failed with exit code',
        ' was unsuccessful'
    )) {
        if ($logText -match $pattern) {
            throw "$ScriptName helper log contains release-blocking error pattern '$pattern': $logPath"
        }
    }
}

function Sync-ImplementationConstraints {
    $synthPsf = Join-Path $synthRoot "$projectName.run.psf"
    $implePsf = Join-Path $runRoot "$projectName.run.psf"
    if (-not (Test-Path -LiteralPath $synthPsf)) {
        throw "Missing synthesis constraint snapshot: $synthPsf"
    }
    New-Item -ItemType Directory -Force -Path $runRoot | Out-Null
    Copy-Item -LiteralPath $synthPsf -Destination $implePsf -Force
    if ((Get-Item -LiteralPath $implePsf).Length -le 0) {
        throw "Implementation constraint snapshot is empty: $implePsf"
    }
}

function Test-SynthesisCurrent {
    $artifacts = @(
        (Join-Path $synthRoot "$projectName`_eHiChip6.ecp"),
        (Join-Path $synthRoot "$projectName.ver.pb"),
        (Join-Path $synthRoot "$projectName.run.psf")
    )
    foreach ($artifact in $artifacts) {
        if (-not (Test-Path -LiteralPath $artifact)) {
            return $false
        }
    }
    $artifactFloor = ($artifacts | ForEach-Object { Get-Item -LiteralPath $_ } |
        Sort-Object LastWriteTime | Select-Object -First 1).LastWriteTime
    $inputs = @(
        (Get-Item -LiteralPath $projectFile),
        (Get-Item -LiteralPath (Join-Path $projectRoot "$projectName.qsf")),
        (Get-Item -LiteralPath (Join-Path $projectRoot "$projectName.sdc"))
    )
    $inputs += Get-ChildItem -LiteralPath (Join-Path $projectRoot "$projectName.srcs") -Recurse -File |
        Where-Object { $_.Extension -in @('.v', '.sv', '.vhd', '.vhdl', '.edc') }
    return -not ($inputs | Where-Object { $_.LastWriteTime -gt $artifactFloor.AddSeconds(2) })
}

function Invoke-SynthesisIfNeeded {
    if (-not $ForceSynthesis -and (Test-SynthesisCurrent)) {
        Write-Host 'Synthesis checkpoint is current; running implementation only.'
        return
    }
    Invoke-Helper 'elinx-synth.cmd'
    Assert-HelperLogClean 'elinx-synth.cmd'
}

function Invoke-Helper {
    param([string]$ScriptName)

    $scriptPath = Join-Path $helperRoot $ScriptName
    $previousCompatSynth = [Environment]::GetEnvironmentVariable('ELINX_FORCE_COMPAT_SYNTH', 'Process')
    try {
        if ($ScriptName -eq 'elinx-synth.cmd') {
            # Native synthesis always rejects this FIFO-based design. The
            # helper's supported compat path produces the release checkpoint.
            $env:ELINX_FORCE_COMPAT_SYNTH = '1'
        }
        & $env:ComSpec /d /c "`"$scriptPath`"" $projectFile
        $helperExitCode = $LASTEXITCODE
    }
    finally {
        if ($null -eq $previousCompatSynth) {
            Remove-Item Env:ELINX_FORCE_COMPAT_SYNTH -ErrorAction SilentlyContinue
        }
        else {
            $env:ELINX_FORCE_COMPAT_SYNTH = $previousCompatSynth
        }
    }
    if ($helperExitCode -ne 0) {
        throw "$ScriptName failed with exit code $helperExitCode"
    }
}

function Invoke-ReadSdcRoute {
    $logPath = Join-Path $projectRoot ("audit_route_{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
    $output = & $nativeImplementation -silence -f $readSdcRouteScript 2>&1
    $exitCode = $LASTEXITCODE
    $output | Set-Content -LiteralPath $logPath -Encoding UTF8
    $output
    $script:LastRouteLog = $logPath
    if ($exitCode -ne 0) {
        throw "SDC-aware route failed with exit code $exitCode. Log: $logPath"
    }
    Assert-RouteLogClean $logPath
}

function Assert-RouteLogClean {
    param([string]$RouteLogPath)

    if (-not $RouteLogPath) {
        return
    }
    if (-not (Test-Path -LiteralPath $RouteLogPath)) {
        throw "Missing SDC-aware route log: $RouteLogPath"
    }
    $text = Get-Content -LiteralPath $RouteLogPath -Raw
    foreach ($pattern in @('ECP file NOT accordance', 'Load ECP Error', $noValidObjectPattern, 'invalid command', 'illegal value', '\[ERROR\]', 'Fatal Error')) {
        if ($text -match $pattern) {
            throw "SDC-aware route log contains release-blocking error pattern '$pattern': $RouteLogPath"
        }
    }
    $wnsMatch = [regex]::Match($text, 'WNS:\s*([-0-9.]+)\s*ns\s*WHS:\s*([-0-9.]+)\s*ns\s*TNS:\s*([-0-9.]+)\s*ns\s*THS:\s*([-0-9.]+)\s*ns')
    if (-not $BoardTestOnly -and $wnsMatch.Success) {
        $labels = @('WNS', 'WHS', 'TNS', 'THS')
        for ($i = 1; $i -le 4; $i++) {
            $value = [double]$wnsMatch.Groups[$i].Value
            if ($value -lt 0.0) {
                throw "Timing gate failed in route log: $($labels[$i - 1])=$value. Log: $RouteLogPath"
            }
        }
    }
}

function Assert-ImplementationLogClean {
    $implementationLogPath = Join-Path $runRoot "$projectName.edi"
    if (-not (Test-Path -LiteralPath $implementationLogPath)) {
        throw "Missing implementation log: $implementationLogPath"
    }
    $text = Get-Content -LiteralPath $implementationLogPath -Raw
    foreach ($pattern in @(
        'ECP file NOT accordance',
        'Load ECP Error',
        $noValidObjectPattern,
        'invalid command',
        'illegal value',
        '\[ERROR\]',
        'Fatal Error'
    )) {
        if ($text -match $pattern) {
            throw "Implementation log contains release-blocking error pattern '$pattern': $implementationLogPath"
        }
    }
}

function Assert-ReportFresh {
    param($Since)

    $required = @(
        (Join-Path $runRoot "$projectName.slack.rpt"),
        (Join-Path $runRoot "$projectName`_route_status.rpt"),
        (Join-Path $runRoot "$projectName`_eHiChip6_EQ6HL130.ecp"),
        (Join-Path $runRoot "$projectName.ver.pb"),
        (Join-Path $runRoot "$projectName.tan.pb")
    )
    foreach ($path in $required) {
        if (-not (Test-Path -LiteralPath $path)) {
            throw "Missing release report/artifact: $path"
        }
        if ($Since -and ((Get-Item -LiteralPath $path).LastWriteTime -lt $Since.AddSeconds(-2))) {
            throw "Release report/artifact is stale: $path"
        }
    }

    $synthEcp = Join-Path $synthRoot "$projectName`_eHiChip6.ecp"
    $impleEcp = Join-Path $runRoot "$projectName`_eHiChip6_EQ6HL130.ecp"
    if ((Test-Path -LiteralPath $synthEcp) -and (Test-Path -LiteralPath $impleEcp)) {
        $synthTime = (Get-Item -LiteralPath $synthEcp).LastWriteTime
        $impleTime = (Get-Item -LiteralPath $impleEcp).LastWriteTime
        if ($impleTime -lt $synthTime.AddSeconds(-2)) {
            throw "Implementation checkpoint is older than synthesis checkpoint; rerun route before release."
        }
    }
}

function Assert-RouteStatusClean {
    $routeStatusPath = Join-Path $runRoot "$projectName`_route_status.rpt"
    $text = Get-Content -LiteralPath $routeStatusPath -Raw
    $match = [regex]::Match($text, '# of nets with routing error\D+(\d+)')
    if (-not $match.Success) {
        throw "Could not parse route error count: $routeStatusPath"
    }
    $routeErrors = [int]$match.Groups[1].Value
    if ($routeErrors -ne 0) {
        throw "Route status gate failed: routing error count is $routeErrors"
    }
}

function Assert-GmiiOutputTiming {
    $timingDb = Join-Path $runRoot "$projectName.tan.pb"
    if (-not (Test-Path -LiteralPath $timingDb)) {
        throw "Missing post-route timing database: $timingDb"
    }
    $python = (Get-Command python -ErrorAction Stop).Source
    & $python $gmiiTimingChecker --db $timingDb --phase-ps $gmiiTxPhasePs
    if ($LASTEXITCODE -ne 0) {
        throw "GMII setup/hold release gate failed with exit code $LASTEXITCODE"
    }
}

function Assert-GmiiInputCaptureTiming {
    $timingDb = Join-Path $runRoot "$projectName.tan.pb"
    if (-not (Test-Path -LiteralPath $timingDb)) {
        throw "Missing post-route timing database: $timingDb"
    }
    $python = (Get-Command python -ErrorAction Stop).Source
    & $python $gmiiInputTimingChecker --db $timingDb
    if ($LASTEXITCODE -ne 0) {
        throw "GMII RX capture timing gate failed with exit code $LASTEXITCODE"
    }
}

function Get-ClockAlias {
    param([string]$ClockName)

    if ($ClockName -eq 'sys_clk') {
        return 'sys_clk'
    }
    if ($ClockName -eq 'ov5640_pclk') {
        return 'ov5640_pclk'
    }
    if (($ClockName -like '*clk_gen:clk_gen_inst*') -and ($ClockName -like '*_clk4*')) {
        return 'hdmi_pix'
    }
    return $null
}

function Assert-TimingGate {
    $slackPath = Join-Path $runRoot "$projectName.slack.rpt"
    $text = Get-Content -LiteralPath $slackPath -Raw
    $seen = @{}

    foreach ($line in ($text -split "`r?`n")) {
        $clockMatch = [regex]::Match(
            $line,
            '^clock name:(.+?)\s+Fmax:([0-9.]+)\s+sync_slack:([-0-9.]+|N/A)\s+async_slack:([-0-9.]+|N/A)'
        )
        if ($clockMatch.Success) {
            $clockName = $clockMatch.Groups[1].Value.Trim()
            $fmax = [double]$clockMatch.Groups[2].Value
            $syncSlack = $clockMatch.Groups[3].Value
            $asyncSlack = $clockMatch.Groups[4].Value
            foreach ($slack in @($syncSlack, $asyncSlack)) {
                if ($slack -ne 'N/A' -and ([double]$slack) -lt 0.0) {
                    throw "Timing gate failed for $clockName`: slack=$slack. Report: $slackPath"
                }
            }
            $alias = Get-ClockAlias $clockName
            if ($alias) {
                $seen[$alias] = $true
                if ($fmax -lt $releaseFmaxMHz[$alias]) {
                    throw "Fmax gate failed for $alias`: $fmax MHz < $($releaseFmaxMHz[$alias]) MHz. Report: $slackPath"
                }
            }
            continue
        }

        $summaryMatch = [regex]::Match($line, 'all_path_min_slack:([-0-9.]+)\s+all_route_min_slack:([-0-9.]+)')
        if ($summaryMatch.Success) {
            $allPath = [double]$summaryMatch.Groups[1].Value
            $allRoute = [double]$summaryMatch.Groups[2].Value
            # all_route_min_slack includes raw routes that SDC intentionally
            # marks false-path. Gate effective timed paths and per-clock slack;
            # Assert-RouteLogClean separately gates official WNS/WHS/TNS/THS.
            if ($allPath -lt 0.0) {
                throw "Timing gate failed: all_path_min_slack=$allPath all_route_min_slack=$allRoute. Report: $slackPath"
            }
        }
    }

    foreach ($requiredClock in $releaseFmaxMHz.Keys) {
        if (-not $seen.ContainsKey($requiredClock)) {
            throw "Timing gate could not find required clock '$requiredClock' in $slackPath"
        }
    }
}

function Assert-BitgenArtifactFresh {
    param($Since)

    $jpsk = Join-Path $runRoot "$projectName.jpsk"
    if (-not (Test-Path -LiteralPath $jpsk)) {
        throw "Bitgen did not produce JPSK: $jpsk"
    }
    if ($Since -and ((Get-Item -LiteralPath $jpsk).LastWriteTime -lt $Since.AddSeconds(-2))) {
        throw "JPSK artifact is stale: $jpsk"
    }
}

function Assert-ReleaseGate {
    param($Since, [string]$RouteLogPath)

    Assert-ReportFresh $Since
    Assert-RouteStatusClean
    Assert-TimingGate
    try {
        Assert-GmiiInputCaptureTiming
    }
    catch {
        if (-not $AllowGmiiTimingWarnings) {
            throw
        }
        Write-Warning "ARP diagnostic build: GMII RX board-timing estimate did not pass: $($_.Exception.Message)"
    }
    try {
        Assert-GmiiOutputTiming
    }
    catch {
        if (-not $AllowGmiiTimingWarnings) {
            throw
        }
        Write-Warning "ARP diagnostic build: GMII TX board-timing estimate did not pass: $($_.Exception.Message)"
    }
    Assert-ImplementationLogClean
    Assert-RouteLogClean $RouteLogPath
}

function Show-Reports {
    Get-Content -LiteralPath (Join-Path $runRoot "$projectName.slack.rpt")
    Get-Content -LiteralPath (Join-Path $runRoot "$projectName`_route_status.rpt")
}

Assert-RequiredPaths

switch ($Action) {
    'doctor' {
        Write-Host "Project: $projectFile"
        Write-Host "Helper:  $helperRoot"
        Write-Host "eLinx:   $nativeImplementation"
    }
    'compile' {
        $started = Get-Date
        Invoke-SynthesisIfNeeded
        Sync-ImplementationConstraints
        Invoke-ReadSdcRoute
        Assert-ReleaseGate $started $script:LastRouteLog
    }
    'sta' {
        Invoke-Helper 'elinx-sta.cmd'
        Assert-HelperLogClean 'elinx-sta.cmd'
        Assert-ReleaseGate $null $null
        Show-Reports
    }
    'bitgen' {
        if (-not $BoardTestOnly) {
            Assert-ReleaseGate $null $null
        }
        $started = Get-Date
        Invoke-Helper 'elinx-bitgen.cmd'
        Assert-HelperLogClean 'elinx-bitgen.cmd'
        Assert-BitgenArtifactFresh $started
    }
    'program' {
        & (Join-Path $projectRoot 'program_unified_jpsk.cmd')
        if ($LASTEXITCODE -ne 0) {
            throw "Programming failed with exit code $LASTEXITCODE"
        }
    }
    'report' {
        Show-Reports
        Assert-ReleaseGate $null $null
    }
    'all' {
        $started = Get-Date
        Invoke-SynthesisIfNeeded
        Sync-ImplementationConstraints
        Invoke-ReadSdcRoute
        if (-not $BoardTestOnly) {
            Assert-ReleaseGate $started $script:LastRouteLog
        }
        $bitgenStarted = Get-Date
        Invoke-Helper 'elinx-bitgen.cmd'
        Assert-HelperLogClean 'elinx-bitgen.cmd'
        Assert-BitgenArtifactFresh $bitgenStarted
        Show-Reports
    }
}

