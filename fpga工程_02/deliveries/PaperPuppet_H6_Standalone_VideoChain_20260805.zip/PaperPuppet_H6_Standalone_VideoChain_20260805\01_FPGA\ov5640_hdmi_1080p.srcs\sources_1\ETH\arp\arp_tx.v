// ============================================================================
// Module Function:
//   ARP packet transmit formatter.
// ============================================================================
module arp_tx(
    input               clk,
    input               rst_n,
    input               arp_tx_en,
    input               arp_tx_type,
    input      [47:0]   des_mac,
    input      [31:0]   des_ip,
    input      [31:0]   crc_zero_next,
    output reg          tx_done,
    output reg          gmii_tx_en,
    output reg [7:0]    gmii_txd,
    output reg          crc_en,
    output reg          crc_clr
);

parameter BOARD_MAC = 48'h00_11_22_33_44_55;
parameter BOARD_IP  = {8'd192, 8'd168, 8'd1, 8'd10};
parameter DES_MAC   = 48'hff_ff_ff_ff_ff_ff;
parameter DES_IP    = {8'd192, 8'd168, 8'd1, 8'd102};

localparam ETH_TYPE      = 16'h0806;
localparam HD_TYPE       = 16'h0001;
localparam PROTOCOL_TYPE = 16'h0800;
localparam [6:0] PREAMBLE_LAST_INDEX = 7'd7;
localparam [6:0] ETH_LAST_INDEX      = 7'd21;
localparam [6:0] ARP_LAST_INDEX      = 7'd49;
localparam [6:0] PAD_LAST_INDEX      = 7'd67;
localparam [6:0] FRAME_LAST_INDEX    = 7'd71;

reg         tx_en_d0;
reg         tx_en_d1;
reg         tx_en_d2;
reg         active_r;
reg [6:0]   byte_index_r;
reg [63:0]  preamble_shift;
reg [111:0] eth_head_shift;
reg [223:0] arp_data_shift;
reg [31:0]  fcs_shift;

wire        pos_tx_en;
wire [47:0] target_mac;
wire [31:0] target_ip;
wire [31:0] fcs_word_next;

function [7:0] fcs_byte;
    input [7:0] crc_byte;
    begin
        fcs_byte = {~crc_byte[0], ~crc_byte[1], ~crc_byte[2], ~crc_byte[3],
                    ~crc_byte[4], ~crc_byte[5], ~crc_byte[6], ~crc_byte[7]};
    end
endfunction

assign pos_tx_en    = (~tx_en_d2) & tx_en_d1;
assign target_mac   = (des_mac != 48'd0) ? des_mac : DES_MAC;
assign target_ip    = (des_ip  != 32'd0) ? des_ip  : DES_IP;
assign fcs_word_next = {
    fcs_byte(crc_zero_next[31:24]),
    fcs_byte(crc_zero_next[23:16]),
    fcs_byte(crc_zero_next[15:8]),
    fcs_byte(crc_zero_next[7:0])
};

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        tx_en_d0 <= 1'b0;
        tx_en_d1 <= 1'b0;
        tx_en_d2 <= 1'b0;
    end
    else begin
        tx_en_d0 <= arp_tx_en;
        tx_en_d1 <= tx_en_d0;
        tx_en_d2 <= tx_en_d1;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        active_r            <= 1'b0;
        byte_index_r        <= 7'd0;
        preamble_shift      <= 64'd0;
        eth_head_shift      <= 112'd0;
        arp_data_shift      <= 224'd0;
        fcs_shift           <= 32'd0;
        tx_done             <= 1'b0;
        gmii_tx_en          <= 1'b0;
        gmii_txd            <= 8'd0;
        crc_en              <= 1'b0;
        crc_clr             <= 1'b0;
    end
    else begin
        tx_done    <= 1'b0;
        gmii_tx_en <= 1'b0;
        gmii_txd   <= 8'd0;
        crc_en     <= 1'b0;
        crc_clr    <= 1'b0;

        if(!active_r) begin
            if(pos_tx_en) begin
                active_r       <= 1'b1;
                byte_index_r   <= 7'd0;
                preamble_shift <= 64'h55_55_55_55_55_55_55_d5;
                eth_head_shift <= {target_mac, BOARD_MAC, ETH_TYPE};
                arp_data_shift <= {
                    HD_TYPE,
                    PROTOCOL_TYPE,
                    8'h06,
                    8'h04,
                    8'h00,
                    arp_tx_type ? 8'h02 : 8'h01,
                    BOARD_MAC,
                    BOARD_IP,
                    target_mac,
                    target_ip
                };
                fcs_shift <= 32'd0;
                crc_clr   <= 1'b1;
            end
        end
        else begin
            gmii_tx_en <= 1'b1;

            if(byte_index_r <= PREAMBLE_LAST_INDEX) begin
                gmii_txd      <= preamble_shift[63:56];
                preamble_shift <= {preamble_shift[55:0], 8'd0};
            end
            else if(byte_index_r <= ETH_LAST_INDEX) begin
                gmii_txd      <= eth_head_shift[111:104];
                eth_head_shift <= {eth_head_shift[103:0], 8'd0};
                crc_en        <= 1'b1;
            end
            else if(byte_index_r <= ARP_LAST_INDEX) begin
                gmii_txd      <= arp_data_shift[223:216];
                arp_data_shift <= {arp_data_shift[215:0], 8'd0};
                crc_en        <= 1'b1;
            end
            else if(byte_index_r <= PAD_LAST_INDEX) begin
                gmii_txd <= 8'd0;
                crc_en   <= 1'b1;
            end
            else if(byte_index_r == (PAD_LAST_INDEX + 7'd1)) begin
                // crc_zero_next includes the final padding byte currently on
                // gmii_txd, so capture and emit the first FCS byte together.
                gmii_txd <= fcs_word_next[31:24];
                fcs_shift <= {fcs_word_next[23:0], 8'd0};
            end
            else begin
                gmii_txd  <= fcs_shift[31:24];
                fcs_shift <= {fcs_shift[23:0], 8'd0};
            end

            if(byte_index_r == FRAME_LAST_INDEX) begin
                active_r     <= 1'b0;
                byte_index_r <= 7'd0;
                fcs_shift    <= 32'd0;
                tx_done      <= 1'b1;
                crc_clr      <= 1'b1;
            end
            else begin
                byte_index_r <= byte_index_r + 7'd1;
            end
        end
    end
end

endmodule
