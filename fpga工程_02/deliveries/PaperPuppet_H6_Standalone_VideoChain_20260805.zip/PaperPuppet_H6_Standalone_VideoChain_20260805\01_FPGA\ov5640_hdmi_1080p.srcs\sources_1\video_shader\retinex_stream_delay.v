// Module Function:
//   Fixed-cycle payload and valid/SOF/EOL delay used to align arithmetic
//   pipeline branches inside the Retinex processing path.
module retinex_stream_delay #(
    parameter DATA_WIDTH = 8,
    parameter LATENCY    = 1
) (
    clk,
    rst_n,
    in_valid,
    in_sof,
    in_eol,
    in_data,
    out_valid,
    out_sof,
    out_eol,
    out_data
);

    input clk;
    input rst_n;
    input in_valid;
    input in_sof;
    input in_eol;
    input [DATA_WIDTH-1:0] in_data;
    output out_valid;
    output out_sof;
    output out_eol;
    output [DATA_WIDTH-1:0] out_data;

    reg [LATENCY-1:0] valid_pipe_r;
    reg [LATENCY-1:0] sof_pipe_r;
    reg [LATENCY-1:0] eol_pipe_r;
    reg [DATA_WIDTH-1:0] data_pipe_r [0:LATENCY-1];
    integer i;

    always @(posedge clk) begin
        if (!rst_n) begin
            valid_pipe_r <= {LATENCY{1'b0}};
            sof_pipe_r   <= {LATENCY{1'b0}};
            eol_pipe_r   <= {LATENCY{1'b0}};
            for (i = 0; i < LATENCY; i = i + 1) begin
                data_pipe_r[i] <= {DATA_WIDTH{1'b0}};
            end
        end else begin
            valid_pipe_r[0] <= in_valid;
            sof_pipe_r[0]   <= in_sof;
            eol_pipe_r[0]   <= in_eol;
            if (in_valid) begin
                data_pipe_r[0] <= in_data;
            end

            for (i = 1; i < LATENCY; i = i + 1) begin
                valid_pipe_r[i] <= valid_pipe_r[i-1];
                sof_pipe_r[i]   <= sof_pipe_r[i-1];
                eol_pipe_r[i]   <= eol_pipe_r[i-1];
                if (valid_pipe_r[i-1]) begin
                    data_pipe_r[i] <= data_pipe_r[i-1];
                end
            end
        end
    end

    assign out_valid = valid_pipe_r[LATENCY-1];
    assign out_sof   = sof_pipe_r[LATENCY-1];
    assign out_eol   = eol_pipe_r[LATENCY-1];
    assign out_data  = data_pipe_r[LATENCY-1];

endmodule
