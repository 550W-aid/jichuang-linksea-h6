`timescale 1ns / 1ps

module luma_direct_fusion_lut #(
    parameter integer HIST_COUNTER_WIDTH = 22
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       pixel_valid,
    input  wire [7:0] pixel_luma,
    input  wire       pixel_eof,
    output wire [7:0] fused_luma,
    output reg        lut_ready
);

    localparam [3:0] ST_COLLECT      = 4'd0;
    localparam [3:0] ST_FIND_INIT    = 4'd1;
    localparam [3:0] ST_FIND_PRIME   = 4'd2;
    localparam [3:0] ST_FIND_SCAN    = 4'd3;
    localparam [3:0] ST_HE_INIT      = 4'd4;
    localparam [3:0] ST_HE_PRIME     = 4'd5;
    localparam [3:0] ST_HE_SCAN      = 4'd6;
    localparam [3:0] ST_HE_WAIT      = 4'd7;
    localparam [3:0] ST_FUSE_LOOKUP  = 4'd8;
    localparam [3:0] ST_FUSE_SCORE   = 4'd9;
    localparam [3:0] ST_FUSE_LAUNCH  = 4'd10;
    localparam [3:0] ST_FUSE_WAIT    = 4'd11;
    localparam [3:0] ST_CLEAR_HIST   = 4'd12;
    localparam [3:0] ST_FUSE_PRODUCT = 4'd13;
    localparam [3:0] ST_FIND_PRIME2  = 4'd14;
    localparam [3:0] ST_HE_PRIME2    = 4'd15;

    reg [3:0] state_r;
    reg [7:0] lut_index_r;
    reg [HIST_COUNTER_WIDTH-1:0] histogram [0:255];
    reg [7:0] he_lut [0:255];
    reg [7:0] fused_lut_bank0 [0:255];
    reg [7:0] fused_lut_bank1 [0:255];
    reg       active_bank_r;
    reg [7:0] fused_bank0_read_r;
    reg [7:0] fused_bank1_read_r;
    reg [7:0] original_pixel_read_r;
    reg       lookup_active_bank_r;
    reg       lookup_lut_ready_r;

    reg [HIST_COUNTER_WIDTH-1:0] frame_pixel_count_r;
    reg [HIST_COUNTER_WIDTH-1:0] frame_pixels_r;
    reg [7:0]                    hist_read_address_r;
    reg [HIST_COUNTER_WIDTH-1:0] hist_read_data_r;
    reg [HIST_COUNTER_WIDTH-1:0] hist_scan_data_r;
    reg                          hist_pending_valid_r;
    reg [7:0]                    hist_pending_address_r;
    reg                          hist_pending_eof_r;
    reg                          hist_last_write_valid_r;
    reg [7:0]                    hist_last_write_address_r;
    reg [HIST_COUNTER_WIDTH-1:0] hist_last_write_data_r;
    reg [HIST_COUNTER_WIDTH-1:0] cdf_r;
    reg [HIST_COUNTER_WIDTH-1:0] cdf_min_r;
    reg                          cdf_min_found_r;
    reg [8:0]                    nonzero_bins_r;
    reg                          identity_he_r;

    reg [7:0] fuse_y_original_r;
    reg [7:0] fuse_y_gamma_r;
    reg [7:0] fuse_y_he_r;
    reg [7:0] fuse_score_original_r;
    reg [7:0] fuse_score_gamma_r;
    reg [7:0] fuse_score_he_r;
    reg [11:0] fuse_denominator_r;
    reg [18:0] fuse_scaled_product_original_r;
    reg [16:0] fuse_scaled_product_gamma_r;
    reg [15:0] fuse_product_he_r;

    reg        divider_start_r;
    reg [28:0] divider_numerator_r;
    reg [21:0] divider_denominator_r;
    wire       divider_busy_w;
    wire       divider_done_w;
    wire [28:0] divider_quotient_w;

    wire [7:0] hist_read_address_w;
    wire [HIST_COUNTER_WIDTH-1:0] histogram_incremented_w;
    wire [HIST_COUNTER_WIDTH-1:0] histogram_current_w;
    wire [HIST_COUNTER_WIDTH:0] cdf_sum_w;
    wire [HIST_COUNTER_WIDTH-1:0] he_denominator_w;
    wire [HIST_COUNTER_WIDTH-1:0] he_delta_w;
    wire [29:0] he_scaled_w;
    wire [28:0] he_rounded_numerator_w;

    wire [7:0] gamma_index_w;
    wire [7:0] shadow_weight_index_w;
    wire [10:0] fusion_weight_original_w;
    wire [8:0] fusion_weight_gamma_w;
    wire [7:0] fusion_weight_he_w;
    wire [11:0] fusion_denominator_w;
    wire [15:0] fusion_product_original_w;
    wire [15:0] fusion_product_gamma_w;
    wire [15:0] fusion_product_he_w;
    wire [18:0] fusion_scaled_product_original_w;
    wire [16:0] fusion_scaled_product_gamma_w;
    wire [19:0] fusion_numerator_w;
    wire [20:0] fusion_rounded_numerator_w;

    function [15:0] multiply_u8;
        input [7:0] operand_a;
        input [7:0] operand_b;
        begin
            multiply_u8 = operand_a * operand_b;
        end
    endfunction

    function [29:0] multiply_u22_u8;
        input [21:0] operand_a;
        input [7:0]  operand_b;
        begin
            multiply_u22_u8 = operand_a * operand_b;
        end
    endfunction

    assign hist_read_address_w = ((state_r == ST_COLLECT) && pixel_valid) ?
                                 pixel_luma : hist_read_address_r;
    assign histogram_incremented_w =
        ((hist_last_write_valid_r &&
          (hist_last_write_address_r == hist_pending_address_r)) ?
         hist_last_write_data_r : hist_read_data_r) + 1'b1;
    assign histogram_current_w = hist_scan_data_r;
    assign cdf_sum_w = {1'b0, cdf_r} + {1'b0, histogram_current_w};
    assign he_denominator_w = frame_pixels_r - cdf_min_r;
    assign he_delta_w = cdf_sum_w[HIST_COUNTER_WIDTH-1:0] - cdf_min_r;
    assign he_scaled_w = multiply_u22_u8(he_delta_w[21:0], 8'd255);
    assign he_rounded_numerator_w =
        he_scaled_w[28:0] + {{8{1'b0}}, he_denominator_w[21:1]};

    assign fusion_weight_original_w = {3'd0, fuse_score_original_r};
    assign fusion_weight_gamma_w = {1'b0, fuse_score_gamma_r};
    assign fusion_weight_he_w = 8'd0;
    assign fusion_denominator_w =
        {1'b0, fusion_weight_original_w} +
        {3'b000, fusion_weight_gamma_w} +
        {4'b0000, fusion_weight_he_w};
    assign fusion_product_original_w =
        multiply_u8(fuse_score_original_r, fuse_y_original_r);
    assign fusion_product_gamma_w =
        multiply_u8(fuse_score_gamma_r, fuse_y_gamma_r);
    assign fusion_product_he_w =
        multiply_u8(fuse_score_he_r, fuse_y_he_r);
    assign fusion_scaled_product_original_w =
        {3'd0, fusion_product_original_w};
    assign fusion_scaled_product_gamma_w = {1'b0, fusion_product_gamma_w};
    assign fusion_numerator_w =
        {1'b0, fuse_scaled_product_original_r} +
        {3'b000, fuse_scaled_product_gamma_r} +
        {4'b0000, fuse_product_he_r};
    assign fusion_rounded_numerator_w =
        {1'b0, fusion_numerator_w} + {{9{1'b0}}, fuse_denominator_r[11:1]};

    assign fused_luma = lookup_lut_ready_r ?
                        (lookup_active_bank_r ?
                         fused_bank1_read_r : fused_bank0_read_r) :
                        original_pixel_read_r;

    luma_fusion_static_luts u_index_luts (
        .address    (lut_index_r),
        .gamma_value(gamma_index_w),
        .score_value(),
        .shadow_weight(shadow_weight_index_w)
    );

    unsigned_divider_29_22 u_divider (
        .clk        (clk),
        .rst_n      (rst_n),
        .start      (divider_start_r),
        .numerator  (divider_numerator_r),
        .denominator(divider_denominator_r),
        .busy       (divider_busy_w),
        .done       (divider_done_w),
        .quotient   (divider_quotient_w)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_r                  <= ST_CLEAR_HIST;
            lut_index_r              <= 8'd0;
            active_bank_r            <= 1'b0;
            fused_bank0_read_r       <= 8'd0;
            fused_bank1_read_r       <= 8'd0;
            original_pixel_read_r    <= 8'd0;
            lookup_active_bank_r     <= 1'b0;
            lookup_lut_ready_r       <= 1'b0;
            lut_ready                <= 1'b0;
            frame_pixel_count_r      <= {HIST_COUNTER_WIDTH{1'b0}};
            frame_pixels_r           <= {HIST_COUNTER_WIDTH{1'b0}};
            hist_read_address_r      <= 8'd0;
            hist_read_data_r         <= {HIST_COUNTER_WIDTH{1'b0}};
            hist_scan_data_r         <= {HIST_COUNTER_WIDTH{1'b0}};
            hist_pending_valid_r     <= 1'b0;
            hist_pending_address_r   <= 8'd0;
            hist_pending_eof_r       <= 1'b0;
            hist_last_write_valid_r  <= 1'b0;
            hist_last_write_address_r <= 8'd0;
            hist_last_write_data_r   <= {HIST_COUNTER_WIDTH{1'b0}};
            cdf_r                    <= {HIST_COUNTER_WIDTH{1'b0}};
            cdf_min_r                <= {HIST_COUNTER_WIDTH{1'b0}};
            cdf_min_found_r          <= 1'b0;
            nonzero_bins_r           <= 9'd0;
            identity_he_r            <= 1'b0;
            fuse_y_original_r        <= 8'd0;
            fuse_y_gamma_r           <= 8'd0;
            fuse_y_he_r              <= 8'd0;
            fuse_score_original_r    <= 8'd0;
            fuse_score_gamma_r       <= 8'd0;
            fuse_score_he_r          <= 8'd0;
            fuse_denominator_r       <= 12'd0;
            fuse_scaled_product_original_r <= 19'd0;
            fuse_scaled_product_gamma_r <= 17'd0;
            fuse_product_he_r        <= 16'd0;
            divider_start_r          <= 1'b0;
            divider_numerator_r      <= 29'd0;
            divider_denominator_r    <= 22'd1;
        end else begin
            divider_start_r <= 1'b0;
            if (state_r != ST_HE_WAIT) begin
                hist_read_data_r <= histogram[hist_read_address_w];
                hist_scan_data_r <= hist_read_data_r;
            end
            if (pixel_valid) begin
                fused_bank0_read_r   <= fused_lut_bank0[pixel_luma];
                fused_bank1_read_r   <= fused_lut_bank1[pixel_luma];
                original_pixel_read_r <= pixel_luma;
                lookup_active_bank_r <= active_bank_r;
                lookup_lut_ready_r   <= lut_ready;
            end

            case (state_r)
                ST_COLLECT: begin
                    if (hist_pending_valid_r) begin
                        histogram[hist_pending_address_r] <= histogram_incremented_w;
                        hist_last_write_valid_r           <= 1'b1;
                        hist_last_write_address_r         <= hist_pending_address_r;
                        hist_last_write_data_r            <= histogram_incremented_w;
                        hist_pending_valid_r              <= 1'b0;
                        if (hist_pending_eof_r) begin
                            frame_pixels_r <= frame_pixel_count_r;
                            state_r        <= ST_FIND_INIT;
                        end
                    end
                    if (pixel_valid &&
                        !(hist_pending_valid_r && hist_pending_eof_r)) begin
                        hist_pending_valid_r   <= 1'b1;
                        hist_pending_address_r <= pixel_luma;
                        hist_pending_eof_r     <= pixel_eof;
                        frame_pixel_count_r    <= frame_pixel_count_r + 1'b1;
                    end
                end

                ST_FIND_INIT: begin
                    lut_index_r       <= 8'd0;
                    cdf_r             <= {HIST_COUNTER_WIDTH{1'b0}};
                    cdf_min_r         <= {HIST_COUNTER_WIDTH{1'b0}};
                    cdf_min_found_r   <= 1'b0;
                    nonzero_bins_r    <= 9'd0;
                    identity_he_r     <= 1'b0;
                    hist_read_address_r <= 8'd0;
                    state_r           <= ST_FIND_PRIME;
                end

                ST_FIND_PRIME: begin
                    hist_read_address_r <= 8'd1;
                    state_r             <= ST_FIND_PRIME2;
                end

                ST_FIND_PRIME2: begin
                    hist_read_address_r <= 8'd2;
                    state_r             <= ST_FIND_SCAN;
                end

                ST_FIND_SCAN: begin
                    cdf_r <= cdf_sum_w[HIST_COUNTER_WIDTH-1:0];
                    if (histogram_current_w != {HIST_COUNTER_WIDTH{1'b0}}) begin
                        nonzero_bins_r <= nonzero_bins_r + 1'b1;
                        if (!cdf_min_found_r) begin
                            cdf_min_r       <= cdf_sum_w[HIST_COUNTER_WIDTH-1:0];
                            cdf_min_found_r <= 1'b1;
                        end
                    end

                    if (lut_index_r == 8'hFF) begin
                        if ((nonzero_bins_r +
                             ((histogram_current_w != {HIST_COUNTER_WIDTH{1'b0}}) ?
                              9'd1 : 9'd0)) <= 9'd1) begin
                            identity_he_r <= 1'b1;
                        end
                        state_r <= ST_HE_INIT;
                    end else begin
                        lut_index_r <= lut_index_r + 1'b1;
                        if (lut_index_r < 8'hFD) begin
                            hist_read_address_r <= lut_index_r + 8'd3;
                        end
                    end
                end

                ST_HE_INIT: begin
                    lut_index_r <= 8'd0;
                    cdf_r       <= {HIST_COUNTER_WIDTH{1'b0}};
                    hist_read_address_r <= 8'd0;
                    state_r     <= ST_HE_PRIME;
                end

                ST_HE_PRIME: begin
                    hist_read_address_r <= 8'd1;
                    state_r             <= ST_HE_PRIME2;
                end

                ST_HE_PRIME2: begin
                    hist_read_address_r <= 8'd2;
                    state_r             <= ST_HE_SCAN;
                end

                ST_HE_SCAN: begin
                    cdf_r <= cdf_sum_w[HIST_COUNTER_WIDTH-1:0];
                    if (identity_he_r) begin
                        he_lut[lut_index_r] <= lut_index_r;
                        if (lut_index_r == 8'hFF) begin
                            lut_index_r <= 8'd0;
                            state_r     <= ST_FUSE_LOOKUP;
                        end else begin
                            lut_index_r <= lut_index_r + 1'b1;
                            if (lut_index_r < 8'hFD) begin
                                hist_read_address_r <= lut_index_r + 8'd3;
                            end
                        end
                    end else if (cdf_sum_w[HIST_COUNTER_WIDTH-1:0] <= cdf_min_r) begin
                        he_lut[lut_index_r] <= 8'd0;
                        if (lut_index_r == 8'hFF) begin
                            lut_index_r <= 8'd0;
                            state_r     <= ST_FUSE_LOOKUP;
                        end else begin
                            lut_index_r <= lut_index_r + 1'b1;
                            if (lut_index_r < 8'hFD) begin
                                hist_read_address_r <= lut_index_r + 8'd3;
                            end
                        end
                    end else begin
                        divider_numerator_r   <= he_rounded_numerator_w;
                        divider_denominator_r <= {{(22-HIST_COUNTER_WIDTH){1'b0}},
                                                  he_denominator_w};
                        divider_start_r       <= 1'b1;
                        state_r               <= ST_HE_WAIT;
                    end
                end

                ST_HE_WAIT: begin
                    if (divider_done_w) begin
                        he_lut[lut_index_r] <=
                            (divider_quotient_w > 29'd255) ?
                            8'hFF : divider_quotient_w[7:0];
                        if (lut_index_r == 8'hFF) begin
                            lut_index_r <= 8'd0;
                            state_r     <= ST_FUSE_LOOKUP;
                        end else begin
                            lut_index_r <= lut_index_r + 1'b1;
                            if (lut_index_r < 8'hFD) begin
                                hist_read_address_r <= lut_index_r + 8'd3;
                            end
                            state_r     <= ST_HE_SCAN;
                        end
                    end
                end

                ST_FUSE_LOOKUP: begin
                    fuse_y_original_r <= lut_index_r;
                    fuse_y_gamma_r    <= gamma_index_w;
                    fuse_y_he_r       <= he_lut[lut_index_r];
                    state_r           <= ST_FUSE_SCORE;
                end

                ST_FUSE_SCORE: begin
                    fuse_score_original_r <= 8'd255 - shadow_weight_index_w;
                    fuse_score_gamma_r    <= shadow_weight_index_w;
                    fuse_score_he_r       <= 8'd0;
                    state_r               <= ST_FUSE_PRODUCT;
                end

                ST_FUSE_PRODUCT: begin
                    fuse_denominator_r <= fusion_denominator_w;
                    fuse_scaled_product_original_r <=
                        fusion_scaled_product_original_w;
                    fuse_scaled_product_gamma_r <=
                        fusion_scaled_product_gamma_w;
                    fuse_product_he_r <= fusion_product_he_w;
                    state_r               <= ST_FUSE_LAUNCH;
                end

                ST_FUSE_LAUNCH: begin
                    if (fuse_denominator_r == 12'd0) begin
                        if (active_bank_r) begin
                            fused_lut_bank0[lut_index_r] <= fuse_y_gamma_r;
                        end else begin
                            fused_lut_bank1[lut_index_r] <= fuse_y_gamma_r;
                        end
                        if (lut_index_r == 8'hFF) begin
                            active_bank_r <= ~active_bank_r;
                            lut_ready     <= 1'b1;
                            lut_index_r   <= 8'd0;
                            state_r       <= ST_CLEAR_HIST;
                        end else begin
                            lut_index_r <= lut_index_r + 1'b1;
                            state_r     <= ST_FUSE_LOOKUP;
                        end
                    end else begin
                        divider_numerator_r   <= {{8{1'b0}}, fusion_rounded_numerator_w};
                        divider_denominator_r <= {10'd0, fuse_denominator_r};
                        divider_start_r       <= 1'b1;
                        state_r               <= ST_FUSE_WAIT;
                    end
                end

                ST_FUSE_WAIT: begin
                    if (divider_done_w) begin
                        if (active_bank_r) begin
                            fused_lut_bank0[lut_index_r] <=
                                (divider_quotient_w > 29'd255) ?
                                8'hFF : divider_quotient_w[7:0];
                        end else begin
                            fused_lut_bank1[lut_index_r] <=
                                (divider_quotient_w > 29'd255) ?
                                8'hFF : divider_quotient_w[7:0];
                        end
                        if (lut_index_r == 8'hFF) begin
                            active_bank_r <= ~active_bank_r;
                            lut_ready     <= 1'b1;
                            lut_index_r   <= 8'd0;
                            state_r       <= ST_CLEAR_HIST;
                        end else begin
                            lut_index_r <= lut_index_r + 1'b1;
                            state_r     <= ST_FUSE_LOOKUP;
                        end
                    end
                end

                ST_CLEAR_HIST: begin
                    histogram[lut_index_r] <= {HIST_COUNTER_WIDTH{1'b0}};
                    if (lut_index_r == 8'hFF) begin
                        lut_index_r         <= 8'd0;
                        frame_pixel_count_r <= {HIST_COUNTER_WIDTH{1'b0}};
                        hist_pending_valid_r <= 1'b0;
                        hist_pending_eof_r   <= 1'b0;
                        hist_last_write_valid_r <= 1'b0;
                        state_r             <= ST_COLLECT;
                    end else begin
                        lut_index_r <= lut_index_r + 1'b1;
                    end
                end

                default: begin
                    lut_index_r <= 8'd0;
                    state_r     <= ST_CLEAR_HIST;
                end
            endcase
        end
    end

endmodule


module unsigned_divider_29_22 (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start,
    input  wire [28:0] numerator,
    input  wire [21:0] denominator,
    output reg         busy,
    output reg         done,
    output reg  [28:0] quotient
);

    reg [28:0] dividend_r;
    reg [28:0] quotient_r;
    reg [22:0] remainder_r;
    reg [21:0] denominator_r;
    reg [5:0]  bit_count_r;

    wire [22:0] shifted_remainder_w;
    wire        subtract_w;
    wire [22:0] next_remainder_w;
    wire [28:0] next_quotient_w;

    assign shifted_remainder_w = {remainder_r[21:0], dividend_r[28]};
    assign subtract_w = shifted_remainder_w >= {1'b0, denominator_r};
    assign next_remainder_w = subtract_w ?
                              (shifted_remainder_w - {1'b0, denominator_r}) :
                              shifted_remainder_w;
    assign next_quotient_w = {quotient_r[27:0], subtract_w};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            busy          <= 1'b0;
            done          <= 1'b0;
            quotient      <= 29'd0;
            dividend_r    <= 29'd0;
            quotient_r    <= 29'd0;
            remainder_r   <= 23'd0;
            denominator_r <= 22'd1;
            bit_count_r   <= 6'd0;
        end else begin
            done <= 1'b0;
            if (start && !busy) begin
                if (denominator == 22'd0) begin
                    quotient <= {29{1'b1}};
                    done     <= 1'b1;
                end else begin
                    busy          <= 1'b1;
                    dividend_r    <= numerator;
                    quotient_r    <= 29'd0;
                    remainder_r   <= 23'd0;
                    denominator_r <= denominator;
                    bit_count_r   <= 6'd29;
                end
            end else if (busy) begin
                dividend_r  <= {dividend_r[27:0], 1'b0};
                quotient_r  <= next_quotient_w;
                remainder_r <= next_remainder_w;
                if (bit_count_r == 6'd1) begin
                    busy        <= 1'b0;
                    done        <= 1'b1;
                    quotient    <= next_quotient_w;
                    bit_count_r <= 6'd0;
                end else begin
                    bit_count_r <= bit_count_r - 1'b1;
                end
            end
        end
    end

endmodule
