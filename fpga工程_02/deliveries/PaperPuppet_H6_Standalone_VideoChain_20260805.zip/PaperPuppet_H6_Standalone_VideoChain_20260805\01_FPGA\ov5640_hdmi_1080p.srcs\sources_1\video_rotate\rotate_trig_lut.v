// ============================================================================
// Module Function:
//   Sine/cosine lookup table for the rotate coordinate mapper.
// ============================================================================
`timescale 1ns / 1ps

module rotate_trig_lut (
    input  wire               clk,
    input  wire               rst_n,
    input  wire               cfg_valid,
    input  wire [8:0]         angle_deg,
    output reg  signed [9:0]  sin_value,
    output reg  signed [9:0]  cos_value
);

    function signed [9:0] quarter_wave_value;
        input [6:0] degrees;
        begin
            case (degrees)
                7'd0:  quarter_wave_value = 10'sd0;
                7'd1:  quarter_wave_value = 10'sd4;
                7'd2:  quarter_wave_value = 10'sd8;
                7'd3:  quarter_wave_value = 10'sd13;
                7'd4:  quarter_wave_value = 10'sd17;
                7'd5:  quarter_wave_value = 10'sd22;
                7'd6:  quarter_wave_value = 10'sd26;
                7'd7:  quarter_wave_value = 10'sd31;
                7'd8:  quarter_wave_value = 10'sd35;
                7'd9:  quarter_wave_value = 10'sd40;
                7'd10: quarter_wave_value = 10'sd44;
                7'd11: quarter_wave_value = 10'sd48;
                7'd12: quarter_wave_value = 10'sd53;
                7'd13: quarter_wave_value = 10'sd57;
                7'd14: quarter_wave_value = 10'sd61;
                7'd15: quarter_wave_value = 10'sd66;
                7'd16: quarter_wave_value = 10'sd70;
                7'd17: quarter_wave_value = 10'sd74;
                7'd18: quarter_wave_value = 10'sd79;
                7'd19: quarter_wave_value = 10'sd83;
                7'd20: quarter_wave_value = 10'sd87;
                7'd21: quarter_wave_value = 10'sd91;
                7'd22: quarter_wave_value = 10'sd95;
                7'd23: quarter_wave_value = 10'sd100;
                7'd24: quarter_wave_value = 10'sd104;
                7'd25: quarter_wave_value = 10'sd108;
                7'd26: quarter_wave_value = 10'sd112;
                7'd27: quarter_wave_value = 10'sd116;
                7'd28: quarter_wave_value = 10'sd120;
                7'd29: quarter_wave_value = 10'sd124;
                7'd30: quarter_wave_value = 10'sd127;
                7'd31: quarter_wave_value = 10'sd131;
                7'd32: quarter_wave_value = 10'sd135;
                7'd33: quarter_wave_value = 10'sd139;
                7'd34: quarter_wave_value = 10'sd143;
                7'd35: quarter_wave_value = 10'sd146;
                7'd36: quarter_wave_value = 10'sd150;
                7'd37: quarter_wave_value = 10'sd154;
                7'd38: quarter_wave_value = 10'sd157;
                7'd39: quarter_wave_value = 10'sd161;
                7'd40: quarter_wave_value = 10'sd164;
                7'd41: quarter_wave_value = 10'sd167;
                7'd42: quarter_wave_value = 10'sd171;
                7'd43: quarter_wave_value = 10'sd174;
                7'd44: quarter_wave_value = 10'sd177;
                7'd45: quarter_wave_value = 10'sd181;
                7'd46: quarter_wave_value = 10'sd184;
                7'd47: quarter_wave_value = 10'sd187;
                7'd48: quarter_wave_value = 10'sd190;
                7'd49: quarter_wave_value = 10'sd193;
                7'd50: quarter_wave_value = 10'sd196;
                7'd51: quarter_wave_value = 10'sd198;
                7'd52: quarter_wave_value = 10'sd201;
                7'd53: quarter_wave_value = 10'sd204;
                7'd54: quarter_wave_value = 10'sd207;
                7'd55: quarter_wave_value = 10'sd209;
                7'd56: quarter_wave_value = 10'sd212;
                7'd57: quarter_wave_value = 10'sd214;
                7'd58: quarter_wave_value = 10'sd217;
                7'd59: quarter_wave_value = 10'sd219;
                7'd60: quarter_wave_value = 10'sd221;
                7'd61: quarter_wave_value = 10'sd223;
                7'd62: quarter_wave_value = 10'sd226;
                7'd63: quarter_wave_value = 10'sd228;
                7'd64: quarter_wave_value = 10'sd230;
                7'd65: quarter_wave_value = 10'sd232;
                7'd66: quarter_wave_value = 10'sd233;
                7'd67: quarter_wave_value = 10'sd235;
                7'd68: quarter_wave_value = 10'sd237;
                7'd69: quarter_wave_value = 10'sd238;
                7'd70: quarter_wave_value = 10'sd240;
                7'd71: quarter_wave_value = 10'sd242;
                7'd72: quarter_wave_value = 10'sd243;
                7'd73: quarter_wave_value = 10'sd244;
                7'd74: quarter_wave_value = 10'sd246;
                7'd75: quarter_wave_value = 10'sd247;
                7'd76: quarter_wave_value = 10'sd248;
                7'd77: quarter_wave_value = 10'sd249;
                7'd78: quarter_wave_value = 10'sd250;
                7'd79: quarter_wave_value = 10'sd251;
                7'd80: quarter_wave_value = 10'sd252;
                7'd81: quarter_wave_value = 10'sd252;
                7'd82: quarter_wave_value = 10'sd253;
                7'd83: quarter_wave_value = 10'sd254;
                7'd84: quarter_wave_value = 10'sd254;
                7'd85: quarter_wave_value = 10'sd255;
                7'd86: quarter_wave_value = 10'sd255;
                7'd87: quarter_wave_value = 10'sd255;
                7'd88: quarter_wave_value = 10'sd255;
                7'd89: quarter_wave_value = 10'sd255;
                7'd90: quarter_wave_value = 10'sd256;
                default: quarter_wave_value = 10'sd0;
            endcase
        end
    endfunction

    reg [8:0] angle_mag_r;
    reg [8:0] sin_angle_full_r;
    reg [8:0] cos_angle_full_r;
    reg [6:0] sin_lookup_angle;
    reg [6:0] cos_lookup_angle;
    reg       cos_neg;
    reg [6:0] sin_lookup_q;
    reg [6:0] cos_lookup_q;
    reg       sin_neg_q;
    reg       cos_neg_q;
    wire signed [9:0] sin_mag_w;
    wire signed [9:0] cos_mag_w;

    assign sin_mag_w = quarter_wave_value(sin_lookup_q);
    assign cos_mag_w = quarter_wave_value(cos_lookup_q);

    always @* begin
        if (angle_deg[8]) begin
            angle_mag_r = (~angle_deg) + 9'd1;
        end else begin
            angle_mag_r = angle_deg;
        end

        if (angle_mag_r > 9'd180) begin
            angle_mag_r = 9'd180;
        end

        sin_angle_full_r = 9'd0;
        cos_angle_full_r = 9'd90;
        sin_lookup_angle = 7'd0;
        cos_lookup_angle = 7'd90;
        cos_neg          = 1'b0;

        if (angle_mag_r <= 9'd90) begin
            sin_angle_full_r = angle_mag_r;
            cos_angle_full_r = 9'd90 - angle_mag_r;
        end else begin
            sin_angle_full_r = 9'd180 - angle_mag_r;
            cos_angle_full_r = angle_mag_r - 9'd90;
            cos_neg          = 1'b1;
        end

        sin_lookup_angle = sin_angle_full_r[6:0];
        cos_lookup_angle = cos_angle_full_r[6:0];
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sin_lookup_q <= 7'd0;
            cos_lookup_q <= 7'd90;
            sin_neg_q    <= 1'b0;
            cos_neg_q    <= 1'b0;
            sin_value    <= 10'sd0;
            cos_value    <= 10'sd256;
        end else begin
            if (cfg_valid) begin
                sin_lookup_q <= sin_lookup_angle;
                cos_lookup_q <= cos_lookup_angle;
                sin_neg_q    <= angle_deg[8];
                cos_neg_q    <= cos_neg;
            end
            sin_value <= sin_neg_q ? -sin_mag_w : sin_mag_w;
            cos_value <= cos_neg_q ? -cos_mag_w : cos_mag_w;
        end
    end

endmodule
