// ============================================================================
// Module Function:
//   Holds the external Ethernet PHY in hardware reset for a programmable
//   number of stable 125 MHz clock cycles after the Ethernet PLL is ready.
// ============================================================================
module eth_phy_reset_ctrl #(
    parameter integer HOLD_CYCLES   = 2_500_000,
    parameter integer COUNTER_WIDTH = 22
)(
    input  wire clk,
    input  wire reset_request_n,
    output reg  phy_reset_n
);

reg [COUNTER_WIDTH-1:0] hold_counter;

always @(posedge clk or negedge reset_request_n) begin
    if(!reset_request_n) begin
        hold_counter <= {COUNTER_WIDTH{1'b0}};
        phy_reset_n  <= 1'b0;
    end
    else if(!phy_reset_n) begin
        if(hold_counter == HOLD_CYCLES - 1) begin
            phy_reset_n <= 1'b1;
        end
        else begin
            hold_counter <= hold_counter + {{(COUNTER_WIDTH-1){1'b0}}, 1'b1};
        end
    end
end

endmodule
