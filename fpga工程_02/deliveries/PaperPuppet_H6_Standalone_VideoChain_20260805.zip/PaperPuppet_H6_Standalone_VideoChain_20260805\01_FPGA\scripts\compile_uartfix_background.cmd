@echo off
setlocal
set "ELINX_FORCE_COMPAT_SYNTH=1"
set "ELINX_HELPER_LOG_DIR=F:\codex\merge_20260722\Unified_480x270_VGrab_Gimbal_Work\01_FPGA\release_logs"
call "F:\codex\jichuang-linksea-h6_main_elinx-helper\elinx-helper\elinx-compile.cmd" "F:\codex\merge_20260722\Unified_480x270_VGrab_Gimbal_Work\01_FPGA\ov5640_hdmi_1080p.epr"
exit /b %ERRORLEVEL%
