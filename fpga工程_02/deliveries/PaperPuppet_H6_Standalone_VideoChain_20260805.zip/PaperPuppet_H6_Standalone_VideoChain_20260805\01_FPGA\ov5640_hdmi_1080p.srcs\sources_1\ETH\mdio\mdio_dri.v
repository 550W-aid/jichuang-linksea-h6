// ============================================================================
// Module Function:
//   Low-level MDIO read/write serial driver.
// ============================================================================
module mdio_dri #(
    parameter PHY_ADDR = 5'b00001,
    parameter CLK_DIV  = 6'd20
)(
    input        clk_50M,
    input        rst_n,
    input  [4:0] i_phy_addr,
    input        i_trig_start,
    input        i_rh_wl,
    input  [4:0] i_reg_addr,
    input [15:0] i_wr_data,
    output reg   o_transmit_done,
    output reg [15:0] o_rd_data,
    output reg   o_rd_ack,
    output reg   dri_clk,
    output reg   o_MDC,
    inout        io_MDIO
);

localparam ST_IDLE    = 6'b00_0001;
localparam ST_PRE     = 6'b00_0010;
localparam ST_START   = 6'b00_0100;
localparam ST_ADDR    = 6'b00_1000;
localparam ST_WR_DATA = 6'b01_0000;
localparam ST_RD_DATA = 6'b10_0000;

reg [1:0]  op_code;
reg [5:0]  clk_cnt;
reg [6:0]  cnt;
reg [5:0]  state;
reg [5:0]  next_state;
reg        mdio_dir;
reg        mdio_out;
reg [15:0] rd_data_t;
reg [15:0] wr_data_t;
reg [4:0]  phy_addr_t;
reg [4:0]  reg_addr_t;
reg        st_done;

wire mdio_in = io_MDIO;

assign io_MDIO = mdio_dir ? mdio_out : 1'bz;

always @(posedge clk_50M) begin
    if(!rst_n) begin
        dri_clk <= 1'b0;
        clk_cnt <= 6'd0;
    end
    else if(clk_cnt == CLK_DIV[5:1] - 1'b1) begin
        clk_cnt <= 6'd0;
        dri_clk <= ~dri_clk;
    end
    else begin
        clk_cnt <= clk_cnt + 1'b1;
    end
end

always @(posedge dri_clk or negedge rst_n) begin
    if(!rst_n)
        o_MDC <= 1'b1;
    else
        o_MDC <= ~cnt[0];
end

always @(posedge dri_clk or negedge rst_n) begin
    if(!rst_n)
        state <= ST_IDLE;
    else
        state <= next_state;
end

always @(*) begin
    if(!rst_n) begin
        next_state = ST_IDLE;
    end
    else begin
        case(state)
            ST_IDLE:    next_state = i_trig_start ? ST_PRE : ST_IDLE;
            ST_PRE:     next_state = st_done ? ST_START : ST_PRE;
            ST_START:   next_state = st_done ? ST_ADDR : ST_START;
            ST_ADDR:    next_state = st_done ? ((op_code == 2'b10) ? ST_RD_DATA : ST_WR_DATA) : ST_ADDR;
            ST_RD_DATA: next_state = st_done ? ST_IDLE : ST_RD_DATA;
            ST_WR_DATA: next_state = st_done ? ST_IDLE : ST_WR_DATA;
            default:    next_state = ST_IDLE;
        endcase
    end
end

always @(posedge dri_clk or negedge rst_n) begin
    if(!rst_n) begin
        cnt <= 7'd0;
        op_code <= 2'b00;
        phy_addr_t <= PHY_ADDR;
        reg_addr_t <= 5'd0;
        wr_data_t <= 16'd0;
        rd_data_t <= 16'd0;
        o_transmit_done <= 1'b0;
        st_done <= 1'b0;
        o_rd_data <= 16'd0;
        o_rd_ack <= 1'b1;
        mdio_dir <= 1'b0;
        mdio_out <= 1'b1;
    end
    else begin
        st_done <= 1'b0;
        cnt <= cnt + 1'b1;
        case(state)
            ST_IDLE: begin
                mdio_out <= 1'b1;
                mdio_dir <= 1'b0;
                o_transmit_done <= 1'b0;
                cnt <= 7'd0;
                if(i_trig_start) begin
                    op_code <= {i_rh_wl, ~i_rh_wl}; // 01 write, 10 read
                    phy_addr_t <= i_phy_addr;
                    reg_addr_t <= i_reg_addr;
                    wr_data_t <= i_wr_data;
                    o_rd_ack <= 1'b1;
                end
            end

            ST_PRE: begin
                mdio_dir <= 1'b1;
                mdio_out <= 1'b1;
                if(cnt == 7'd62)
                    st_done <= 1'b1;
                else if(cnt == 7'd63)
                    cnt <= 7'd0;
            end

            ST_START: begin
                case(cnt)
                    7'd1: mdio_out <= 1'b0;
                    7'd3: mdio_out <= 1'b1;
                    7'd5: mdio_out <= op_code[1];
                    7'd6: st_done <= 1'b1;
                    7'd7: begin
                        mdio_out <= op_code[0];
                        cnt <= 7'd0;
                    end
                    default: ;
                endcase
            end

            ST_ADDR: begin
                case(cnt)
                    7'd1:  mdio_out <= phy_addr_t[4];
                    7'd3:  mdio_out <= phy_addr_t[3];
                    7'd5:  mdio_out <= phy_addr_t[2];
                    7'd7:  mdio_out <= phy_addr_t[1];
                    7'd9:  mdio_out <= phy_addr_t[0];
                    7'd11: mdio_out <= reg_addr_t[4];
                    7'd13: mdio_out <= reg_addr_t[3];
                    7'd15: mdio_out <= reg_addr_t[2];
                    7'd17: mdio_out <= reg_addr_t[1];
                    7'd18: st_done <= 1'b1;
                    7'd19: begin
                        mdio_out <= reg_addr_t[0];
                        cnt <= 7'd0;
                    end
                    default: ;
                endcase
            end

            ST_WR_DATA: begin
                case(cnt)
                    7'd1:  mdio_out <= 1'b1;
                    7'd3:  mdio_out <= 1'b0;
                    7'd5:  mdio_out <= wr_data_t[15];
                    7'd7:  mdio_out <= wr_data_t[14];
                    7'd9:  mdio_out <= wr_data_t[13];
                    7'd11: mdio_out <= wr_data_t[12];
                    7'd13: mdio_out <= wr_data_t[11];
                    7'd15: mdio_out <= wr_data_t[10];
                    7'd17: mdio_out <= wr_data_t[9];
                    7'd19: mdio_out <= wr_data_t[8];
                    7'd21: mdio_out <= wr_data_t[7];
                    7'd23: mdio_out <= wr_data_t[6];
                    7'd25: mdio_out <= wr_data_t[5];
                    7'd27: mdio_out <= wr_data_t[4];
                    7'd29: mdio_out <= wr_data_t[3];
                    7'd31: mdio_out <= wr_data_t[2];
                    7'd33: mdio_out <= wr_data_t[1];
                    7'd35: mdio_out <= wr_data_t[0];
                    7'd37: begin
                        mdio_dir <= 1'b0;
                        mdio_out <= 1'b1;
                    end
                    7'd39: st_done <= 1'b1;
                    7'd40: begin
                        cnt <= 7'd0;
                        o_transmit_done <= 1'b1;
                    end
                    default: ;
                endcase
            end

            ST_RD_DATA: begin
                case(cnt)
                    7'd1: begin
                        mdio_dir <= 1'b0;
                        mdio_out <= 1'b1;
                    end
                    7'd4:  o_rd_ack <= mdio_in;
                    7'd6:  rd_data_t[15] <= mdio_in;
                    7'd8:  rd_data_t[14] <= mdio_in;
                    7'd10: rd_data_t[13] <= mdio_in;
                    7'd12: rd_data_t[12] <= mdio_in;
                    7'd14: rd_data_t[11] <= mdio_in;
                    7'd16: rd_data_t[10] <= mdio_in;
                    7'd18: rd_data_t[9] <= mdio_in;
                    7'd20: rd_data_t[8] <= mdio_in;
                    7'd22: rd_data_t[7] <= mdio_in;
                    7'd24: rd_data_t[6] <= mdio_in;
                    7'd26: rd_data_t[5] <= mdio_in;
                    7'd28: rd_data_t[4] <= mdio_in;
                    7'd30: rd_data_t[3] <= mdio_in;
                    7'd32: rd_data_t[2] <= mdio_in;
                    7'd34: rd_data_t[1] <= mdio_in;
                    7'd36: rd_data_t[0] <= mdio_in;
                    7'd39: st_done <= 1'b1;
                    7'd40: begin
                        o_transmit_done <= 1'b1;
                        o_rd_data <= rd_data_t;
                        rd_data_t <= 16'd0;
                        cnt <= 7'd0;
                    end
                    default: ;
                endcase
            end

            default: begin
                cnt <= 7'd0;
                op_code <= 2'b00;
                phy_addr_t <= PHY_ADDR;
                reg_addr_t <= 5'd0;
                wr_data_t <= 16'd0;
                rd_data_t <= 16'd0;
                o_transmit_done <= 1'b0;
                st_done <= 1'b0;
                o_rd_data <= 16'd0;
                o_rd_ack <= 1'b1;
                mdio_dir <= 1'b0;
                mdio_out <= 1'b1;
            end
        endcase
    end
end

endmodule
