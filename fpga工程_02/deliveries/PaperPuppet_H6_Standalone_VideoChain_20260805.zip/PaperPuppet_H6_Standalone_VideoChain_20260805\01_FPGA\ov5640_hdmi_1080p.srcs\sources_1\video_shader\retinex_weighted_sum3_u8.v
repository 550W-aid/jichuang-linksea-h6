// Module Function:
//   Pipelined 77/150/29 RGB weighted sum used to derive 8-bit video luma.
//   MUL_LATENCY includes the registered three-product sum at the output.
module retinex_weighted_sum3_u8 (
    clk,
    rst_n,
    in_valid,
    in_a,
    in_b,
    in_c,
    coef_a,
    coef_b,
    coef_c,
    out_valid,
    out_sum
);

    parameter MUL_LATENCY = 2;

    input clk;
    input rst_n;
    input in_valid;
    input [7:0] in_a;
    input [7:0] in_b;
    input [7:0] in_c;
    input [7:0] coef_a;
    input [7:0] coef_b;
    input [7:0] coef_c;
    output out_valid;
    output [15:0] out_sum;
    reg [15:0] out_sum;

    localparam integer MULT_IP_LATENCY = MUL_LATENCY - 1;
    reg [MUL_LATENCY-1:0] valid_pipe;
    wire [15:0] mult_a_w;
    wire [15:0] mult_b_w;
    wire [15:0] mult_c_w;
    integer i;

    lpm_mult #(
        .lpm_widtha        (8),
        .lpm_widthb        (8),
        .lpm_widthp        (16),
        .lpm_widths        (1),
        .lpm_representation("UNSIGNED"),
        .lpm_pipeline      (MULT_IP_LATENCY)
    ) u_mult_a (
        .dataa (in_a),
        .datab (coef_a),
        .sum   (1'b0),
        .aclr  (1'b0),
        .clock (clk),
        .clken (1'b1),
        .result(mult_a_w)
    );

    lpm_mult #(
        .lpm_widtha        (8),
        .lpm_widthb        (8),
        .lpm_widthp        (16),
        .lpm_widths        (1),
        .lpm_representation("UNSIGNED"),
        .lpm_pipeline      (MULT_IP_LATENCY)
    ) u_mult_b (
        .dataa (in_b),
        .datab (coef_b),
        .sum   (1'b0),
        .aclr  (1'b0),
        .clock (clk),
        .clken (1'b1),
        .result(mult_b_w)
    );

    lpm_mult #(
        .lpm_widtha        (8),
        .lpm_widthb        (8),
        .lpm_widthp        (16),
        .lpm_widths        (1),
        .lpm_representation("UNSIGNED"),
        .lpm_pipeline      (MULT_IP_LATENCY)
    ) u_mult_c (
        .dataa (in_c),
        .datab (coef_c),
        .sum   (1'b0),
        .aclr  (1'b0),
        .clock (clk),
        .clken (1'b1),
        .result(mult_c_w)
    );

    always @(posedge clk) begin
        if (!rst_n) begin
            valid_pipe <= {MUL_LATENCY{1'b0}};
            out_sum    <= 16'd0;
        end else begin
            valid_pipe[0] <= in_valid;
            for (i = 1; i < MUL_LATENCY; i = i + 1) begin
                valid_pipe[i] <= valid_pipe[i-1];
            end
            out_sum   <= mult_a_w + mult_b_w + mult_c_w;
        end
    end

    assign out_valid = valid_pipe[MUL_LATENCY-1];

endmodule
