// ============================================================================
// Module Function:
//   Vendor FIFO wrapper for video/SDRAM data buffering.
// ============================================================================
// synopsys translate_off
`timescale 1 ps / 1 ps
// synopsys translate_on
module fifo_data #(
	parameter integer LPM_NUMWORDS = 1024,
	parameter integer LPM_WIDTHU = 10
) (
	aclr,
	rdclk,
	wrclk,
	data,
	rdreq,
	wrreq,
	rdempty,
	rdusedw,
	wrusedw,
	q
	);

	input    aclr;
	input    rdclk;
	input    wrclk;
	input    [15:0]    data;
	input    rdreq;
	input    wrreq;
	output    [15:0]    q;
	output    rdempty;
	output    [10:0]    rdusedw;
	output    [10:0]    wrusedw;
	wire      [LPM_WIDTHU-1:0]    rdusedw_i;
	wire      [LPM_WIDTHU-1:0]    wrusedw_i;

generate
	if (LPM_WIDTHU == 11) begin : gen_usedw_passthrough
		assign rdusedw = rdusedw_i;
		assign wrusedw = wrusedw_i;
	end else begin : gen_usedw_extend
		assign rdusedw = {{(11-LPM_WIDTHU){1'b0}}, rdusedw_i};
		assign wrusedw = {{(11-LPM_WIDTHU){1'b0}}, wrusedw_i};
	end
endgenerate

	dcfifo    dcfifo (
		.rdclk (rdclk),
		.wrreq (wrreq),
		.aclr (aclr),
		.data (data),
		.rdreq (rdreq),
		.wrclk (wrclk),
		.wrempty (),
		.wrfull (),
		.q (q),
		.rdempty (rdempty),
		.rdfull (),
		.wrusedw (wrusedw_i),
		.rdusedw (rdusedw_i)
	);

	defparam
		dcfifo.add_ram_output_register = "ON",
		dcfifo.clocks_are_synchronized = "FALSE",
		dcfifo.intended_device_family = "Stratix",
		dcfifo.lpm_hint = "RAM_BLOCK_TYPE=M4K",
		dcfifo.lpm_numwords = LPM_NUMWORDS,
		dcfifo.lpm_showahead = "OFF",
		dcfifo.lpm_type = "dcfifo",
		dcfifo.lpm_width = 16,
		dcfifo.lpm_widthu = LPM_WIDTHU,
		dcfifo.overflow_checking = "ON",
		dcfifo.underflow_checking = "ON",
		dcfifo.use_eab = "ON";
endmodule
