#!/usr/bin/env python3
"""Send test/video chunks to the FPGA UDP video receiver.

Protocol per UDP payload:
  byte 0..1 : 0x45 0x56 ("EV")
  byte 2    : frame id
  byte 3..4 : line number, 0..719, big-endian 11-bit value
  byte 5    : SDRAM bank, equal to line[0]
  byte 6    : ordered chunk index; H2 uses 0..1, other codecs use 0..3
  byte 7    : codec, 1 = raw RGB888, 2 = H2 half-line, 3 = H2 chunk
  byte 8..  : codec payload

The packet is intentionally under a normal 1500-byte Ethernet MTU.
"""

import argparse
import os
import random
import shutil
import socket
import subprocess
import sys
import threading
import time


WIDTH = 1280
HEIGHT = 720
HALF_WIDTH = WIDTH // 2
CHUNK_PIXELS = 320
CHUNKS_PER_HALF = HALF_WIDTH // CHUNK_PIXELS
CHUNKS_PER_LINE = WIDTH // CHUNK_PIXELS
CODEC_RGB888_LITERAL = 1
CODEC_RGB888_H2_LINE = 2
CODEC_RGB888_H2_CHUNK = 3
DEFAULT_PACKET_GAP_US = 20.0

COLORS_RGB565 = [
    0xF800,  # red
    0x07E0,  # green
    0x001F,  # blue
    0xFFE0,  # yellow
    0x07FF,  # cyan
    0xF81F,  # magenta
    0xFFFF,  # white
    0x0000,  # black
]

COLORS_RGB888 = [
    (255, 0, 0),
    (0, 255, 0),
    (0, 0, 255),
    (255, 255, 0),
    (0, 255, 255),
    (255, 0, 255),
    (255, 255, 255),
    (0, 0, 0),
]


def make_rgb888_payload(color, pixels):
    r, g, b = color
    return bytes([r, g, b]) * pixels


def rgb888_chunk_from_frame(frame, line, half, chunk):
    x0 = half * HALF_WIDTH + chunk * CHUNK_PIXELS
    row0 = line * WIDTH * 3
    start = row0 + x0 * 3
    end = start + CHUNK_PIXELS * 3
    return frame[start:end]


def h2_halfline_from_frame(frame, line, segment):
    row0 = line * WIDTH * 3
    start = row0 + segment * HALF_WIDTH * 3
    src = frame[start : start + HALF_WIDTH * 3]
    out = bytearray((HALF_WIDTH // 2) * 3)
    out[0::3] = src[0::6]
    out[1::3] = src[1::6]
    out[2::3] = src[2::6]
    return bytes(out)


def h2_chunk_from_frame(frame, line, half, chunk):
    src = rgb888_chunk_from_frame(frame, line, half, chunk)
    out = bytearray((CHUNK_PIXELS // 2) * 3)
    out[0::3] = src[0::6]
    out[1::3] = src[1::6]
    out[2::3] = src[2::6]
    return bytes(out)


def iter_video_frames(video_path, fps):
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ffmpeg not found on PATH; omit --video to send generated RGB888 test blocks.")

    vf = f"fps={fps},scale={WIDTH}:{HEIGHT}:flags=bicubic"
    cmd = [
        ffmpeg,
        "-hide_banner",
        "-loglevel", "error",
        "-stream_loop", "-1",
        "-i", video_path,
        "-vf", vf,
        "-f", "rawvideo",
        "-pix_fmt", "rgb24",
        "-",
    ]
    frame_bytes = WIDTH * HEIGHT * 3
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    try:
        while True:
            frame = proc.stdout.read(frame_bytes)
            if len(frame) != frame_bytes:
                break
            yield frame
    finally:
        proc.kill()


def serial_reader(port_name, baud):
    try:
        import serial
    except ImportError:
        print("pyserial is not installed; serial monitor disabled.", file=sys.stderr)
        return

    try:
        with serial.Serial(port_name, baudrate=baud, timeout=0.2) as ser:
            print(f"UART monitor opened on {port_name} @ {baud}.")
            while True:
                data = ser.readline()
                if data:
                    print(data.decode(errors="replace").rstrip())
    except Exception as exc:
        print(f"UART monitor stopped: {exc}", file=sys.stderr)


def make_header(frame_id, line, half, chunk, codec):
    return bytes([
        0x45,
        0x56,
        frame_id & 0xFF,
        (line >> 8) & 0x07,
        line & 0xFF,
        half & 0x01,
        chunk & 0x03,
        codec & 0x03,
    ])


def codec_id(codec_name):
    if codec_name == "raw888":
        return CODEC_RGB888_LITERAL
    if codec_name == "h2":
        return CODEC_RGB888_H2_LINE
    if codec_name == "h2chunk":
        return CODEC_RGB888_H2_CHUNK
    raise ValueError(f"unsupported codec {codec_name}")


def create_udp_socket(args):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, args.send_buffer)
    sock.settimeout(args.socket_timeout_ms / 1000.0)
    if args.bind_ip:
        sock.bind((args.bind_ip, 0))
    return sock


def describe_local_route(dst, bind_ip):
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        if bind_ip:
            probe.bind((bind_ip, 0))
        probe.connect(dst)
        return probe.getsockname()
    except OSError as exc:
        return None, f"route probe failed: {exc}"
    finally:
        probe.close()


def send_payload(sock, payload, dst, args):
    attempt = 0
    while True:
        try:
            sock.sendto(payload, dst)
            return sock, attempt
        except OSError as exc:
            attempt += 1
            if attempt > args.max_send_retries:
                raise RuntimeError(
                    f"send failed after {args.max_send_retries} retries: {exc}"
                ) from exc

            delay_s = min(
                (args.retry_backoff_ms / 1000.0) * (2 ** (attempt - 1)),
                args.max_retry_backoff_ms / 1000.0,
            )
            if delay_s > 0:
                delay_s *= random.uniform(0.85, 1.15)
            print(
                f"send error: {exc}; recreating UDP socket and retrying in {delay_s:.3f}s "
                f"({attempt}/{args.max_send_retries})",
                file=sys.stderr,
            )
            try:
                sock.close()
            except OSError:
                pass
            time.sleep(delay_s)
            sock = create_udp_socket(args)


def send_frames(args):
    codec = codec_id(args.codec)
    dst = (args.target_ip, args.port)
    packet_gap = args.packet_gap_us / 1_000_000.0
    frame_period = 0.0 if args.fps <= 0 else 1.0 / args.fps
    frame_id = 0
    video_frames = iter_video_frames(args.video, args.fps) if args.video else None

    sock = create_udp_socket(args)
    recoveries = 0

    print(f"Sending to {args.target_ip}:{args.port}, codec={args.codec}, fps={args.fps}, packet_gap_us={args.packet_gap_us}")
    if args.bind_ip:
        print(f"Bound local UDP source to {args.bind_ip}")
    route_info = describe_local_route(dst, args.bind_ip)
    if isinstance(route_info, tuple) and route_info[0] is not None:
        local_ip, local_port = route_info
        print(f"Local route: {local_ip}:{local_port} -> {args.target_ip}:{args.port}")
    else:
        print(route_info[1], file=sys.stderr)
    if args.video:
        print(f"Video source: {os.path.abspath(args.video)}")
    print("Press Ctrl+C to stop.")

    try:
        while True:
            start = time.perf_counter()
            packets = 0
            frame = next(video_frames) if video_frames else None

            for line in range(HEIGHT):
                band = line // args.band_height
                sdram_bank = line & 1
                segment_count = 2 if codec == CODEC_RGB888_H2_LINE else CHUNKS_PER_LINE
                for segment in range(segment_count):
                    color_idx = (band + segment + frame_id) % len(COLORS_RGB888)
                    half = segment // CHUNKS_PER_HALF
                    chunk = segment % CHUNKS_PER_HALF
                    if frame is not None and codec == CODEC_RGB888_H2_LINE:
                        body = h2_halfline_from_frame(frame, line, segment)
                    elif frame is not None and codec == CODEC_RGB888_H2_CHUNK:
                        body = h2_chunk_from_frame(frame, line, half, chunk)
                    elif frame is not None:
                        body = rgb888_chunk_from_frame(frame, line, half, chunk)
                    else:
                        stored_pixels = CHUNK_PIXELS // 2 if codec == CODEC_RGB888_H2_CHUNK else CHUNK_PIXELS
                        body = make_rgb888_payload(COLORS_RGB888[color_idx], stored_pixels)

                    payload = make_header(frame_id, line, sdram_bank, segment, codec) + body
                    sock, retries = send_payload(sock, payload, dst, args)
                    recoveries += retries
                    packets += 1
                    if packet_gap > 0:
                        time.sleep(packet_gap)

            elapsed = time.perf_counter() - start
            print(
                f"frame={frame_id:02X} packets={packets} send_time={elapsed:.3f}s "
                f"recoveries={recoveries}"
            )
            frame_id = (frame_id + 1) & 0xFF

            if frame_period > elapsed:
                time.sleep(frame_period - elapsed)
    except KeyboardInterrupt:
        print("Stopped.")
    finally:
        sock.close()


def main():
    parser = argparse.ArgumentParser(description="Stream FPGA Ethernet test video.")
    parser.add_argument("--target-ip", default="192.168.1.10", help="FPGA IP address")
    parser.add_argument("--port", type=int, default=5005, help="UDP destination port; FPGA accepts any UDP port")
    parser.add_argument("--fps", type=float, default=2.0, help="Frame rate target; 0 sends as fast as possible")
    parser.add_argument(
        "--packet-gap-us",
        type=float,
        default=DEFAULT_PACKET_GAP_US,
        help="Inter-packet gap in microseconds; a small default reduces burst loss on flaky links",
    )
    parser.add_argument("--codec", choices=["raw888", "h2", "h2chunk"], default="h2", help="Payload codec")
    parser.add_argument("--video", default="", help="Optional MP4/video file; requires ffmpeg on PATH")
    parser.add_argument("--band-height", type=int, default=180, help="Color-block band height in lines")
    parser.add_argument("--send-buffer", type=int, default=4 * 1024 * 1024, help="UDP send buffer size")
    parser.add_argument("--socket-timeout-ms", type=float, default=1000.0, help="Socket timeout for transient NIC stalls")
    parser.add_argument("--bind-ip", default="", help="Optional local source IP to pin traffic to one NIC")
    parser.add_argument("--max-send-retries", type=int, default=8, help="Maximum retries after transient UDP send errors")
    parser.add_argument("--retry-backoff-ms", type=float, default=100.0, help="Initial backoff before recreating the UDP socket")
    parser.add_argument("--max-retry-backoff-ms", type=float, default=2000.0, help="Maximum retry backoff for repeated network errors")
    parser.add_argument("--serial", default="", help="Optional UART port, for example COM7")
    parser.add_argument("--serial-baud", type=int, default=115200, help="UART baud rate")
    args = parser.parse_args()

    if args.packet_gap_us < 0:
        parser.error("--packet-gap-us must be >= 0")
    if args.band_height <= 0:
        parser.error("--band-height must be > 0")
    if args.max_send_retries < 0:
        parser.error("--max-send-retries must be >= 0")
    if args.socket_timeout_ms <= 0:
        parser.error("--socket-timeout-ms must be > 0")
    if args.retry_backoff_ms < 0 or args.max_retry_backoff_ms < 0:
        parser.error("retry backoff values must be >= 0")
    if HEIGHT % args.band_height != 0:
        print("band-height does not need to divide 720, but neat bands are easier to read.")

    if args.serial:
        thread = threading.Thread(target=serial_reader, args=(args.serial, args.serial_baud), daemon=True)
        thread.start()

    send_frames(args)


if __name__ == "__main__":
    main()
