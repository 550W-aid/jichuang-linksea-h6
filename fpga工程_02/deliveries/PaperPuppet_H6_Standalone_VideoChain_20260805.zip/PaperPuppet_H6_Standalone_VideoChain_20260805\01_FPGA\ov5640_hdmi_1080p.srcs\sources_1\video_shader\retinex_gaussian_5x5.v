// Module Function:
//   Uses two RAM-backed line taps and a causal 3x3 weighted window to estimate
//   local illumination. Current-column taps and two registered history columns
//   are combined explicitly; border pixels bypass the incomplete neighborhood.
module retinex_gaussian_5x5 #(
    parameter IMAGE_WIDTH = 1280
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       in_valid,
    input  wire       in_sof,
    input  wire       in_eol,
    input  wire [7:0] in_pixel,
    output reg        out_valid,
    output reg [7:0] out_blur
);
    reg [7:0] win [0:2][0:1];
    reg [1:0] row_count_r;
    reg [11:0] col_count_r;
    reg [1:0] row_count_eff_r;
    reg [11:0] col_count_eff_r;
    reg [10:0] row_sum0;
    reg [10:0] row_sum1;
    reg [10:0] row_sum2;
    reg [15:0] weighted_sum;
    reg [7:0] blur_comb;
    wire [15:0] line_taps_w;
    wire [7:0] tap0_w = in_pixel;
    wire [7:0] tap1_w = line_taps_w[7:0];
    wire [7:0] tap2_w = line_taps_w[15:8];
    integer row_index;
    integer col_index;

    altshift_taps #(
        .intended_device_family("Stratix"),
        .lpm_hint              ("RAM_BLOCK_TYPE=M4K"),
        .lpm_type              ("altshift_taps"),
        .number_of_taps        (2),
        .tap_distance          (IMAGE_WIDTH),
        .width                 (8),
        .power_up_state        ("CLEARED")
    ) line_delay_inst (
        .aclr    (1'b0),
        .clken   (in_valid),
        .clock   (clk),
        .shiftin (in_pixel),
        .shiftout(),
        .taps    (line_taps_w)
    );

    always @* begin
        row_count_eff_r = in_sof ? 2'd0 : row_count_r;
        col_count_eff_r = in_sof ? 12'd0 : col_count_r;
        row_sum0 = {3'd0, tap0_w} + ({3'd0, win[0][0]} << 1) +
                   {3'd0, win[0][1]};
        row_sum1 = ({3'd0, tap1_w} << 1) + ({3'd0, win[1][0]} << 2) +
                   ({3'd0, win[1][1]} << 1);
        row_sum2 = {3'd0, tap2_w} + ({3'd0, win[2][0]} << 1) +
                   {3'd0, win[2][1]};
        weighted_sum = {5'd0, row_sum0} + {5'd0, row_sum1} +
                       {5'd0, row_sum2};
        blur_comb = weighted_sum[11:4];
        if ((row_count_eff_r < 2'd2) || (col_count_eff_r < 12'd2)) begin
            blur_comb = in_pixel;
        end
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            row_count_r    <= 2'd0;
            col_count_r    <= 12'd0;
            out_valid      <= 1'b0;
            out_blur       <= 8'd0;
            for (row_index = 0; row_index < 3; row_index = row_index + 1) begin
                for (col_index = 0; col_index < 2; col_index = col_index + 1) begin
                    win[row_index][col_index] <= 8'd0;
                end
            end
        end else begin
            out_valid <= in_valid;
            if (in_valid) begin
                out_blur <= blur_comb;
                for (row_index = 0; row_index < 3; row_index = row_index + 1) begin
                    for (col_index = 1; col_index > 0; col_index = col_index - 1) begin
                        win[row_index][col_index] <= win[row_index][col_index-1];
                    end
                end
                win[0][0] <= tap0_w;
                win[1][0] <= tap1_w;
                win[2][0] <= tap2_w;

                if (in_sof) begin
                    row_count_r <= 2'd0;
                    col_count_r <= in_eol ? 12'd0 : 12'd1;
                end else if (in_eol) begin
                    col_count_r <= 12'd0;
                    if (row_count_r < 2'd2) begin
                        row_count_r <= row_count_r + 2'd1;
                    end
                end else begin
                    col_count_r <= col_count_r + 12'd1;
                end
            end
        end
    end
endmodule
