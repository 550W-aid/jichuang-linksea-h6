// ============================================================================
// Module Function:
//   Pulse-edge output helper for MDIO/Ethernet control timing.
// ============================================================================
module Posedge_output #(
    parameter reg_width = 3
)(
    input  wire clk,
    input  wire rst_n,
    input  wire i_sig,
    output wire o_rise
);

reg [reg_width-1:0] sig_reg;

assign o_rise = sig_reg[reg_width-2] & ~sig_reg[reg_width-1];

always @(posedge clk) begin
    if (!rst_n) begin
        sig_reg <= {reg_width{1'b0}};
    end else begin
        sig_reg <= {sig_reg[reg_width-2:0], i_sig};
    end
end

endmodule
