// ============================================================================
// Module Function:
//   UART status reporter for Ethernet diagnostics.
// ============================================================================
module eth_status_uart #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD   = 115200
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire [15:0] good_packets_i,
    input  wire [15:0] bad_packets_i,
    input  wire [15:0] frame_count_i,
    input  wire [7:0]  last_frame_id_i,
    input  wire [10:0] last_line_i,
    input  wire        last_half_i,
    input  wire [1:0]  last_chunk_i,
    input  wire [15:0] last_words_i,
    input  wire        active_i,
    output wire        uart_tx_o
);

    localparam [25:0] REPORT_DIV_MAX = CLK_HZ - 1;
    localparam [5:0] REPORT_LEN = 6'd37;

    reg [25:0] report_div_r;
    reg        report_active_r;
    reg [5:0]  report_index_r;
    reg [7:0]  uart_data_r;
    reg        uart_valid_r;

    reg [15:0] good_packets_r;
    reg [15:0] bad_packets_r;
    reg [15:0] frame_count_r;
    reg [7:0]  last_frame_id_r;
    reg [10:0] last_line_r;
    reg        last_half_r;
    reg [1:0]  last_chunk_r;
    reg [15:0] last_words_r;
    reg        active_r;

    wire       uart_busy_w;

    function [7:0] hex_ascii;
        input [3:0] v;
        begin
            hex_ascii = (v < 4'd10) ? (8'h30 + {4'd0, v}) : (8'h41 + {4'd0, v - 4'd10});
        end
    endfunction

    function [7:0] report_byte;
        input [5:0] index;
        begin
            case (index)
                6'd0:  report_byte = "<";
                6'd1:  report_byte = "E";
                6'd2:  report_byte = "p";
                6'd3:  report_byte = hex_ascii(good_packets_r[15:12]);
                6'd4:  report_byte = hex_ascii(good_packets_r[11:8]);
                6'd5:  report_byte = hex_ascii(good_packets_r[7:4]);
                6'd6:  report_byte = hex_ascii(good_packets_r[3:0]);
                6'd7:  report_byte = "q";
                6'd8:  report_byte = hex_ascii(bad_packets_r[15:12]);
                6'd9:  report_byte = hex_ascii(bad_packets_r[11:8]);
                6'd10: report_byte = hex_ascii(bad_packets_r[7:4]);
                6'd11: report_byte = hex_ascii(bad_packets_r[3:0]);
                6'd12: report_byte = "n";
                6'd13: report_byte = hex_ascii(frame_count_r[15:12]);
                6'd14: report_byte = hex_ascii(frame_count_r[11:8]);
                6'd15: report_byte = hex_ascii(frame_count_r[7:4]);
                6'd16: report_byte = hex_ascii(frame_count_r[3:0]);
                6'd17: report_byte = "i";
                6'd18: report_byte = hex_ascii(last_frame_id_r[7:4]);
                6'd19: report_byte = hex_ascii(last_frame_id_r[3:0]);
                6'd20: report_byte = "m";
                6'd21: report_byte = hex_ascii({1'b0, last_line_r[10:8]});
                6'd22: report_byte = hex_ascii(last_line_r[7:4]);
                6'd23: report_byte = hex_ascii(last_line_r[3:0]);
                6'd24: report_byte = last_half_r ? "R" : "L";
                6'd25: report_byte = "c";
                6'd26: report_byte = hex_ascii({2'b00, last_chunk_r});
                6'd27: report_byte = "o";
                6'd28: report_byte = hex_ascii(last_words_r[15:12]);
                6'd29: report_byte = hex_ascii(last_words_r[11:8]);
                6'd30: report_byte = hex_ascii(last_words_r[7:4]);
                6'd31: report_byte = hex_ascii(last_words_r[3:0]);
                6'd32: report_byte = "a";
                6'd33: report_byte = active_r ? "1" : "0";
                6'd34: report_byte = ">";
                6'd35: report_byte = 8'h0D;
                default: report_byte = 8'h0A;
            endcase
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            report_div_r    <= 26'd0;
            report_active_r <= 1'b0;
            report_index_r  <= 6'd0;
            uart_data_r     <= 8'd0;
            uart_valid_r    <= 1'b0;
            good_packets_r  <= 16'd0;
            bad_packets_r   <= 16'd0;
            frame_count_r   <= 16'd0;
            last_frame_id_r <= 8'd0;
            last_line_r     <= 11'd0;
            last_half_r     <= 1'b0;
            last_chunk_r    <= 2'd0;
            last_words_r    <= 16'd0;
            active_r        <= 1'b0;
        end else begin
            uart_valid_r <= 1'b0;

            if (!report_active_r) begin
                if (report_div_r == REPORT_DIV_MAX) begin
                    report_div_r    <= 26'd0;
                    report_active_r <= 1'b1;
                    report_index_r  <= 6'd0;
                    good_packets_r  <= good_packets_i;
                    bad_packets_r   <= bad_packets_i;
                    frame_count_r   <= frame_count_i;
                    last_frame_id_r <= last_frame_id_i;
                    last_line_r     <= last_line_i;
                    last_half_r     <= last_half_i;
                    last_chunk_r    <= last_chunk_i;
                    last_words_r    <= last_words_i;
                    active_r        <= active_i;
                end else begin
                    report_div_r <= report_div_r + 26'd1;
                end
            end else if (!uart_busy_w) begin
                uart_data_r  <= report_byte(report_index_r);
                uart_valid_r <= 1'b1;
                if (report_index_r == REPORT_LEN - 1'b1) begin
                    report_active_r <= 1'b0;
                    report_index_r  <= 6'd0;
                end else begin
                    report_index_r <= report_index_r + 6'd1;
                end
            end
        end
    end

    uart_tx #(
        .CLK_HZ(CLK_HZ),
        .BAUD(BAUD)
    ) u_uart_tx (
        .clk(clk),
        .rst_n(rst_n),
        .data_i(uart_data_r),
        .data_valid_i(uart_valid_r),
        .tx_o(uart_tx_o),
        .busy_o(uart_busy_w)
    );

endmodule
