`timescale 1ns/1ps

// HDMI-domain first-stage paper-puppet detector and procedural overlay.
// The disabled path is a combinational, bit-exact RGB pass-through.
module paper_puppet_h6_overlay #(
    parameter [19:0] DEBOUNCE_COUNT = 20'd742500,
    parameter [19:0] MIN_TARGET_PIXELS = 20'd64
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        key_n,
    input  wire        hsync_i,
    input  wire        vsync_i,
    input  wire        de_i,
    input  wire [11:0] x_i,
    input  wire [11:0] y_i,
    input  wire [23:0] rgb_i,
    output wire [23:0] rgb_o,
    output reg         puppet_enable,
    output reg         target_valid,
    output reg  [11:0] target_center_x,
    output reg  [11:0] target_center_y
);

wire [7:0] red_w   = rgb_i[23:16];
wire [7:0] green_w = rgb_i[15:8];
wire [7:0] blue_w  = rgb_i[7:0];
wire saturated_w = ((red_w > 8'd150) && ({1'b0, red_w} > {1'b0, green_w} + 9'd45) && ({1'b0, red_w} > {1'b0, blue_w} + 9'd45)) ||
                   ((green_w > 8'd150) && ({1'b0, green_w} > {1'b0, red_w} + 9'd45) && ({1'b0, green_w} > {1'b0, blue_w} + 9'd45)) ||
                   ((blue_w > 8'd150) && ({1'b0, blue_w} > {1'b0, red_w} + 9'd45) && ({1'b0, blue_w} > {1'b0, green_w} + 9'd45));

reg key_meta_r;
reg key_sync_r;
reg key_stable_r;
reg [19:0] key_count_r;
reg vsync_d_r;
reg [11:0] min_x_r;
reg [11:0] max_x_r;
reg [11:0] min_y_r;
reg [11:0] max_y_r;
reg [19:0] target_count_r;

wire frame_start_w = vsync_i & ~vsync_d_r;
wire [12:0] center_x_sum_w = {1'b0, min_x_r} + {1'b0, max_x_r};
wire [12:0] center_y_sum_w = {1'b0, min_y_r} + {1'b0, max_y_r};

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        key_meta_r    <= 1'b1;
        key_sync_r    <= 1'b1;
        key_stable_r  <= 1'b1;
        key_count_r   <= 20'd0;
        puppet_enable <= 1'b0;
    end else begin
        key_meta_r <= key_n;
        key_sync_r <= key_meta_r;
        if (key_sync_r == key_stable_r) begin
            key_count_r <= 20'd0;
        end else if (key_count_r >= DEBOUNCE_COUNT - 1'b1) begin
            key_stable_r <= key_sync_r;
            key_count_r  <= 20'd0;
            if (!key_sync_r)
                puppet_enable <= ~puppet_enable;
        end else begin
            key_count_r <= key_count_r + 1'b1;
        end
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        vsync_d_r       <= 1'b0;
        min_x_r         <= 12'hfff;
        max_x_r         <= 12'd0;
        min_y_r         <= 12'hfff;
        max_y_r         <= 12'd0;
        target_count_r  <= 20'd0;
        target_valid    <= 1'b0;
        target_center_x <= 12'd640;
        target_center_y <= 12'd360;
    end else begin
        vsync_d_r <= vsync_i;
        if (frame_start_w) begin
            target_valid <= (target_count_r >= MIN_TARGET_PIXELS);
            if (target_count_r >= MIN_TARGET_PIXELS) begin
                target_center_x <= center_x_sum_w[12:1];
                target_center_y <= center_y_sum_w[12:1];
            end
            min_x_r        <= 12'hfff;
            max_x_r        <= 12'd0;
            min_y_r        <= 12'hfff;
            max_y_r        <= 12'd0;
            target_count_r <= 20'd0;
        end else if (de_i && saturated_w) begin
            if (x_i < min_x_r) min_x_r <= x_i;
            if (x_i > max_x_r) max_x_r <= x_i;
            if (y_i < min_y_r) min_y_r <= y_i;
            if (y_i > max_y_r) max_y_r <= y_i;
            if (target_count_r != 20'hfffff)
                target_count_r <= target_count_r + 1'b1;
        end
    end
end

wire [12:0] x_plus_72_w = {1'b0, x_i} + 13'd72;
wire [12:0] x_plus_66_w = {1'b0, x_i} + 13'd66;
wire [12:0] x_plus_48_w = {1'b0, x_i} + 13'd48;
wire [12:0] x_plus_34_w = {1'b0, x_i} + 13'd34;
wire [12:0] x_plus_28_w = {1'b0, x_i} + 13'd28;
wire [12:0] x_plus_18_w = {1'b0, x_i} + 13'd18;
wire [12:0] x_plus_12_w = {1'b0, x_i} + 13'd12;
wire [12:0] x_plus_10_w = {1'b0, x_i} + 13'd10;
wire [12:0] x_plus_5_w  = {1'b0, x_i} + 13'd5;
wire [12:0] y_plus_88_w = {1'b0, y_i} + 13'd88;
wire [12:0] y_plus_66_w = {1'b0, y_i} + 13'd66;
wire [12:0] y_plus_58_w = {1'b0, y_i} + 13'd58;
wire [12:0] y_plus_54_w = {1'b0, y_i} + 13'd54;
wire [12:0] y_plus_47_w = {1'b0, y_i} + 13'd47;
wire [12:0] y_plus_46_w = {1'b0, y_i} + 13'd46;
wire [12:0] y_plus_41_w = {1'b0, y_i} + 13'd41;
wire [12:0] y_plus_34_w = {1'b0, y_i} + 13'd34;
wire [12:0] y_plus_30_w = {1'b0, y_i} + 13'd30;
wire [12:0] y_plus_22_w = {1'b0, y_i} + 13'd22;
wire [12:0] y_plus_20_w = {1'b0, y_i} + 13'd20;
wire [12:0] cx_w = {1'b0, target_center_x};
wire [12:0] cy_w = {1'b0, target_center_y};

wire staff_w = (x_plus_72_w >= cx_w) && (x_plus_66_w <= cx_w) &&
               (y_plus_88_w >= cy_w) && (y_i <= target_center_y + 12'd74);
wire head_w = (x_plus_28_w >= cx_w) && (x_i <= target_center_x + 12'd28) &&
              (y_plus_66_w >= cy_w) && (y_plus_22_w <= cy_w);
wire ears_w = (x_plus_48_w >= cx_w) && (x_i <= target_center_x + 12'd48) &&
              (y_plus_54_w >= cy_w) && (y_plus_34_w <= cy_w);
wire face_w = (x_plus_18_w >= cx_w) && (x_i <= target_center_x + 12'd18) &&
              (y_plus_58_w >= cy_w) && (y_plus_30_w <= cy_w);
wire body_w = (x_plus_34_w >= cx_w) && (x_i <= target_center_x + 12'd34) &&
              (y_plus_20_w >= cy_w) && (y_i <= target_center_y + 12'd58);
wire belt_w = body_w && (y_i >= target_center_y + 12'd18) && (y_i <= target_center_y + 12'd25);
wire eye_w = ((x_plus_12_w >= cx_w) && (x_plus_5_w <= cx_w) ||
              (x_i >= target_center_x + 12'd5) && (x_i <= target_center_x + 12'd12)) &&
             (y_plus_47_w >= cy_w) && (y_plus_41_w <= cy_w);
wire overlay_w = target_valid && (staff_w || head_w || ears_w || body_w);

wire [23:0] puppet_rgb_w = staff_w ? 24'hD8B020 :
                            eye_w  ? 24'hFFF060 :
                            face_w ? 24'hF0B070 :
                            belt_w ? 24'hFFD020 :
                            head_w ? 24'hC02020 :
                            ears_w ? 24'hB01818 :
                                     24'h901010;

assign rgb_o = (!puppet_enable || !de_i || !overlay_w) ? rgb_i : puppet_rgb_w;

// hsync_i is intentionally present for interface symmetry and debug probing.
wire unused_hsync_w = hsync_i;

endmodule
