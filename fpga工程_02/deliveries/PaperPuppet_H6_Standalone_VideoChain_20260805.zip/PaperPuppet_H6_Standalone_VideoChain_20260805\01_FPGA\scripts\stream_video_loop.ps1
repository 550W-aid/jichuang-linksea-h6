param(
    [string]$Video = "",
    [ValidateSet("h2", "h2chunk", "raw888")]
    [string]$Codec = "h2",
    [ValidateSet("udp", "scapy")]
    [string]$TxMode = "udp",
    [double]$DecodeFps = 30.0,
    [double]$OutputFps = 30.0,
    [double]$PacketGapUs = 0.0,
    [int]$Frames = 0
)

$ErrorActionPreference = "Stop"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$argsList = @(
    (Join-Path $scriptDir "send_eth_video_scapy.py"),
    "--tx-mode", $TxMode,
    "--codec", $Codec,
    "--decode-fps", ([string]$DecodeFps),
    "--output-fps", ([string]$OutputFps),
    "--packet-gap-us", ([string]$PacketGapUs),
    "--frames", ([string]$Frames),
    "--loop"
)

if ($Video -ne "") {
    $argsList += @("--video", $Video)
}

python @argsList
