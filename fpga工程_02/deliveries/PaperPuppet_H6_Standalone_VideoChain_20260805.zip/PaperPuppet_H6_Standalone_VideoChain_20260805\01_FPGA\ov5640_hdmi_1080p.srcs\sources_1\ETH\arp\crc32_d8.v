// ============================================================================
// Module Function:
//   Byte-wide CRC32 generator used by Ethernet frame logic.
// ============================================================================
module crc32_d8(
    input               clk,
    input               rst_n,
    input      [7:0]    data,
    input               crc_en,
    input               crc_clr,
    output reg [31:0]   crc_data,
    output     [31:0]   crc_next,
    output     [31:0]   crc_zero_next
);

function [31:0] crc32_d8_calc;
    input [31:0] crc_value;
    input [7:0]  data_value;
    reg   [7:0]  data_t;
    begin
        data_t = {data_value[0], data_value[1], data_value[2], data_value[3],
                  data_value[4], data_value[5], data_value[6], data_value[7]};

        crc32_d8_calc[0]  = crc_value[24] ^ crc_value[30] ^ data_t[0] ^ data_t[6];
        crc32_d8_calc[1]  = crc_value[24] ^ crc_value[25] ^ crc_value[30] ^ crc_value[31]
                          ^ data_t[0] ^ data_t[1] ^ data_t[6] ^ data_t[7];
        crc32_d8_calc[2]  = crc_value[24] ^ crc_value[25] ^ crc_value[26] ^ crc_value[30]
                          ^ crc_value[31] ^ data_t[0] ^ data_t[1] ^ data_t[2] ^ data_t[6]
                          ^ data_t[7];
        crc32_d8_calc[3]  = crc_value[25] ^ crc_value[26] ^ crc_value[27] ^ crc_value[31]
                          ^ data_t[1] ^ data_t[2] ^ data_t[3] ^ data_t[7];
        crc32_d8_calc[4]  = crc_value[24] ^ crc_value[26] ^ crc_value[27] ^ crc_value[28]
                          ^ crc_value[30] ^ data_t[0] ^ data_t[2] ^ data_t[3] ^ data_t[4]
                          ^ data_t[6];
        crc32_d8_calc[5]  = crc_value[24] ^ crc_value[25] ^ crc_value[27] ^ crc_value[28]
                          ^ crc_value[29] ^ crc_value[30] ^ crc_value[31] ^ data_t[0]
                          ^ data_t[1] ^ data_t[3] ^ data_t[4] ^ data_t[5] ^ data_t[6]
                          ^ data_t[7];
        crc32_d8_calc[6]  = crc_value[25] ^ crc_value[26] ^ crc_value[28] ^ crc_value[29]
                          ^ crc_value[30] ^ crc_value[31] ^ data_t[1] ^ data_t[2] ^ data_t[4]
                          ^ data_t[5] ^ data_t[6] ^ data_t[7];
        crc32_d8_calc[7]  = crc_value[24] ^ crc_value[26] ^ crc_value[27] ^ crc_value[29]
                          ^ crc_value[31] ^ data_t[0] ^ data_t[2] ^ data_t[3] ^ data_t[5]
                          ^ data_t[7];
        crc32_d8_calc[8]  = crc_value[0] ^ crc_value[24] ^ crc_value[25] ^ crc_value[27]
                          ^ crc_value[28] ^ data_t[0] ^ data_t[1] ^ data_t[3] ^ data_t[4];
        crc32_d8_calc[9]  = crc_value[1] ^ crc_value[25] ^ crc_value[26] ^ crc_value[28]
                          ^ crc_value[29] ^ data_t[1] ^ data_t[2] ^ data_t[4] ^ data_t[5];
        crc32_d8_calc[10] = crc_value[2] ^ crc_value[24] ^ crc_value[26] ^ crc_value[27]
                          ^ crc_value[29] ^ data_t[0] ^ data_t[2] ^ data_t[3] ^ data_t[5];
        crc32_d8_calc[11] = crc_value[3] ^ crc_value[24] ^ crc_value[25] ^ crc_value[27]
                          ^ crc_value[28] ^ data_t[0] ^ data_t[1] ^ data_t[3] ^ data_t[4];
        crc32_d8_calc[12] = crc_value[4] ^ crc_value[24] ^ crc_value[25] ^ crc_value[26]
                          ^ crc_value[28] ^ crc_value[29] ^ crc_value[30] ^ data_t[0]
                          ^ data_t[1] ^ data_t[2] ^ data_t[4] ^ data_t[5] ^ data_t[6];
        crc32_d8_calc[13] = crc_value[5] ^ crc_value[25] ^ crc_value[26] ^ crc_value[27]
                          ^ crc_value[29] ^ crc_value[30] ^ crc_value[31] ^ data_t[1]
                          ^ data_t[2] ^ data_t[3] ^ data_t[5] ^ data_t[6] ^ data_t[7];
        crc32_d8_calc[14] = crc_value[6] ^ crc_value[26] ^ crc_value[27] ^ crc_value[28]
                          ^ crc_value[30] ^ crc_value[31] ^ data_t[2] ^ data_t[3] ^ data_t[4]
                          ^ data_t[6] ^ data_t[7];
        crc32_d8_calc[15] = crc_value[7] ^ crc_value[27] ^ crc_value[28] ^ crc_value[29]
                          ^ crc_value[31] ^ data_t[3] ^ data_t[4] ^ data_t[5] ^ data_t[7];
        crc32_d8_calc[16] = crc_value[8] ^ crc_value[24] ^ crc_value[28] ^ crc_value[29]
                          ^ data_t[0] ^ data_t[4] ^ data_t[5];
        crc32_d8_calc[17] = crc_value[9] ^ crc_value[25] ^ crc_value[29] ^ crc_value[30]
                          ^ data_t[1] ^ data_t[5] ^ data_t[6];
        crc32_d8_calc[18] = crc_value[10] ^ crc_value[26] ^ crc_value[30] ^ crc_value[31]
                          ^ data_t[2] ^ data_t[6] ^ data_t[7];
        crc32_d8_calc[19] = crc_value[11] ^ crc_value[27] ^ crc_value[31] ^ data_t[3] ^ data_t[7];
        crc32_d8_calc[20] = crc_value[12] ^ crc_value[28] ^ data_t[4];
        crc32_d8_calc[21] = crc_value[13] ^ crc_value[29] ^ data_t[5];
        crc32_d8_calc[22] = crc_value[14] ^ crc_value[24] ^ data_t[0];
        crc32_d8_calc[23] = crc_value[15] ^ crc_value[24] ^ crc_value[25] ^ crc_value[30]
                          ^ data_t[0] ^ data_t[1] ^ data_t[6];
        crc32_d8_calc[24] = crc_value[16] ^ crc_value[25] ^ crc_value[26] ^ crc_value[31]
                          ^ data_t[1] ^ data_t[2] ^ data_t[7];
        crc32_d8_calc[25] = crc_value[17] ^ crc_value[26] ^ crc_value[27] ^ data_t[2] ^ data_t[3];
        crc32_d8_calc[26] = crc_value[18] ^ crc_value[24] ^ crc_value[27] ^ crc_value[28]
                          ^ crc_value[30] ^ data_t[0] ^ data_t[3] ^ data_t[4] ^ data_t[6];
        crc32_d8_calc[27] = crc_value[19] ^ crc_value[25] ^ crc_value[28] ^ crc_value[29]
                          ^ crc_value[31] ^ data_t[1] ^ data_t[4] ^ data_t[5] ^ data_t[7];
        crc32_d8_calc[28] = crc_value[20] ^ crc_value[26] ^ crc_value[29] ^ crc_value[30]
                          ^ data_t[2] ^ data_t[5] ^ data_t[6];
        crc32_d8_calc[29] = crc_value[21] ^ crc_value[27] ^ crc_value[30] ^ crc_value[31]
                          ^ data_t[3] ^ data_t[6] ^ data_t[7];
        crc32_d8_calc[30] = crc_value[22] ^ crc_value[28] ^ crc_value[31] ^ data_t[4] ^ data_t[7];
        crc32_d8_calc[31] = crc_value[23] ^ crc_value[29] ^ data_t[5];
    end
endfunction

assign crc_next      = crc32_d8_calc(crc_data, data);
assign crc_zero_next = crc32_d8_calc(crc_data, 8'd0);

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        crc_data <= 32'hff_ff_ff_ff;
    else if(crc_clr)
        crc_data <= 32'hff_ff_ff_ff;
    else if(crc_en)
        crc_data <= crc_next;
end

endmodule
