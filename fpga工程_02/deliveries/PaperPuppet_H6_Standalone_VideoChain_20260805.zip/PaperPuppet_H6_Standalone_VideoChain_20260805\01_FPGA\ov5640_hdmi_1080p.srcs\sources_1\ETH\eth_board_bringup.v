// ============================================================================
// Module Function:
//   Board-level Ethernet PHY bring-up and protocol debug wrapper.
// ============================================================================
`timescale 1 ps / 1 ps

module eth_board_bringup #(
    parameter        BOARD_VIDEO_ONLY       = 1'b0,
    parameter        ENABLE_UDP_DIAG_TX     = 1'b0,
    parameter [15:0] UDP_LOOPBACK_MAX_BYTES = 16'd1472,
    parameter integer PHY_RESET_HOLD_CYCLES = 2_500_000,
    parameter integer PHY_RESET_COUNT_WIDTH = 22
)(
    input              sys_clk,
    input              sys_rst_n,
    input              clk_125MHz,
    input              clk_125MHz_tx_shift,

    input              eth_rxc,
    input              eth_rx_ctl,
    input              eth_txc,
    input      [7:0]   eth_rxd,
    output             eth_tx_ctl,
    output     [7:0]   eth_txd,
    output             GTX_CLK,
    output             eth_rst_n,
    output             eth_tx_er,

    input              touch_key,
    input              i_Key_GBCR,
    input              i_Key_ANAR,
    inout              eth_mdio,
    output             eth_mdc,

    output     [1:0]   EthSpeedLED,
    output             eth_rx_rec_en_o,
    output     [7:0]   eth_rx_rec_data_o,
    output     [15:0]  eth_rx_rec_byte_num_o,
    output             eth_rx_rec_pkt_done_o,
    output reg         eth_rx_pkt_seen_sys_d1,
    output reg [7:0]   eth_tx_clk_mon_sys_d1,
    output reg [15:0]  eth_rx_last_len_sys_d1,
    output reg [7:0]   eth_rx_last_data_sys_d1,
    output reg [7:0]   eth_dbg_rx_pkt_cnt,
    output reg [7:0]   eth_dbg_raw_rx_cnt,
    output reg [31:0]  eth_arp_dbg_counts_sys_d1,
    output reg [31:0]  eth_arp_des_ip_sys_d1,
    output reg [95:0]  eth_raw_rx_head_sys_d1,
    output reg [95:0]  eth_raw_tx_head_sys_d1,
    output reg         eth_tx_ctl_udp_sys_d1,
    output reg         dbg_arp_tx_en_sys_d1,
    output reg [47:0]  eth_arp_des_mac_sys_d1
);

    wire        rec_en;
    wire [7:0]  rec_data;
    wire [15:0] rec_byte_num;
    wire        tx_req;
    wire        tx_done;
    reg         udp_tx_start_en;
    reg  [15:0] udp_tx_byte_num;
    reg  [7:0]  udp_tx_data;

    wire        eth_tx_ctl_udp;
    wire [7:0]  eth_txd_udp;
    wire        eth_rst_n_udp;
    wire        eth_phy_rst_n_w;
    wire        eth_rx_ctl_captured_w;
    wire [7:0]  eth_rxd_captured_w;
    (* preserve *)
    reg         eth_tx_ctl_out_r;
    (* preserve *)
    reg  [7:0]  eth_txd_out_r;
    wire        rec_en_udp;
    wire [7:0]  rec_data_udp;
    wire [15:0] rec_byte_num_udp;
    wire        rec_pkt_done_udp;
    wire        tx_req_udp;
    wire        tx_done_udp;
    wire        dbg_arp_req_tx;
    wire        dbg_arp_tx_en;
    wire        dbg_arp_tx_done;
    wire [47:0] dbg_arp_des_mac;
    wire [31:0] dbg_arp_des_ip;

    (* preserve, noprune *) reg        eth_rx_rec_en_d;
    (* preserve, noprune *) reg        eth_rx_pkt_seen;
    (* preserve, noprune *) reg [7:0]  eth_rx_last_data;
    (* preserve, noprune *) reg [15:0] eth_rx_last_len;
    (* preserve, noprune *) reg [7:0]  eth_tx_clk_mon;
    reg         eth_rx_ctl_d;
    reg         eth_raw_rx_toggle_rx;
    reg  [3:0]  eth_raw_byte_idx_rx;
    reg  [7:0]  eth_raw_b0_rx;
    reg  [7:0]  eth_raw_b1_rx;
    reg  [7:0]  eth_raw_b2_rx;
    reg  [7:0]  eth_raw_b3_rx;
    reg  [7:0]  eth_raw_b4_rx;
    reg  [7:0]  eth_raw_b5_rx;
    reg  [7:0]  eth_raw_b6_rx;
    reg  [7:0]  eth_raw_b7_rx;
    reg  [7:0]  eth_raw_b8_rx;
    reg  [7:0]  eth_raw_b9_rx;
    reg  [7:0]  eth_raw_b10_rx;
    reg  [7:0]  eth_raw_b11_rx;
    reg  [95:0] eth_raw_rx_head_snapshot_rx;
    reg         eth_raw_rx_head_toggle_rx;
    reg  [23:0] eth_rx_last_info_snapshot_rx;
    reg         eth_rx_last_info_toggle_rx;
    reg         eth_rx_pkt_toggle_rx;
    reg         udp_reply_toggle_rx;
    reg  [15:0] udp_reply_len_rx;
    reg  [7:0]  udp_reply_last_data_rx;

    reg         udp_reply_toggle_tx_d0;
    reg         udp_reply_toggle_tx_d1;
    reg  [15:0] udp_reply_len_tx_d0;
    reg  [15:0] udp_reply_len_tx_d1;
    reg  [7:0]  udp_reply_last_data_tx_d0;
    reg  [7:0]  udp_reply_last_data_tx_d1;
    reg  [15:0] udp_reply_len_hold;
    reg  [7:0]  udp_reply_last_data_hold;
    reg         udp_tx_pending;
    reg         udp_tx_active;
    reg  [1:0]  udp_tx_byte_idx;
    reg  [26:0] udp_beacon_cnt;
    reg         eth_tx_ctl_udp_d;
    reg         dbg_arp_tx_en_d;
    reg  [4:0]  eth_raw_tx_byte_idx_tx;
    reg  [95:0] eth_raw_tx_head_tx;
    reg         eth_arp_req_toggle_tx;
    reg         eth_arp_en_toggle_tx;
    reg         eth_arp_done_toggle_tx;
    reg         eth_udp_tx_start_toggle_tx;
    reg  [47:0] eth_arp_des_mac_tx;
    reg  [31:0] eth_arp_des_ip_tx;
    reg         eth_tx_launch_toggle_tx;
    reg         eth_tx_done_toggle_tx;
    reg         eth_beacon_toggle_tx;
    reg  [7:0]  eth_last_tx_kind_tx;
    reg  [15:0] eth_last_tx_len_tx;

    reg         eth_rx_pkt_toggle_sys_d0;
    reg         eth_rx_pkt_toggle_sys_d1;
    reg         eth_raw_rx_toggle_sys_d0;
    reg         eth_raw_rx_toggle_sys_d1;
    reg  [7:0]  eth_tx_clk_mon_sys_d0;
    reg         udp_tx_pending_sys_d0;
    reg         udp_tx_pending_sys_d1;
    reg         udp_tx_active_sys_d0;
    reg         udp_tx_active_sys_d1;
    reg         eth_tx_launch_toggle_sys_d0;
    reg         eth_tx_launch_toggle_sys_d1;
    reg         eth_tx_done_toggle_sys_d0;
    reg         eth_tx_done_toggle_sys_d1;
    reg         eth_beacon_toggle_sys_d0;
    reg         eth_beacon_toggle_sys_d1;
    reg         dbg_arp_tx_en_sys_d0;
    reg         eth_tx_ctl_udp_sys_d0;
    reg  [7:0]  eth_last_tx_kind_sys_d0;
    reg  [7:0]  eth_last_tx_kind_sys_d1;
    reg  [15:0] eth_last_tx_len_sys_d0;
    reg  [15:0] eth_last_tx_len_sys_d1;
    reg  [95:0] eth_raw_tx_head_sys_d0;
    reg  [95:0] eth_raw_rx_head_sys_d0;
    reg  [95:0] eth_raw_rx_head_sys_d2;
    reg         eth_raw_rx_head_toggle_sys_d0;
    reg         eth_raw_rx_head_toggle_sys_d1;
    reg         eth_raw_rx_head_toggle_sys_d2;
    wire [23:0] eth_rx_last_info_sys_cdc_w;
    wire        eth_rx_last_info_valid_sys_w;
    wire        eth_rx_last_info_busy_rx_w;
    (* preserve, altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg eth_arp_req_toggle_sys_d0;
    (* preserve, altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg eth_arp_req_toggle_sys_d1;
    (* preserve, altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg eth_arp_en_toggle_sys_d0;
    (* preserve, altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg eth_arp_en_toggle_sys_d1;
    (* preserve, altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg eth_arp_done_toggle_sys_d0;
    (* preserve, altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg eth_arp_done_toggle_sys_d1;
    (* preserve, altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg eth_udp_tx_start_toggle_sys_d0;
    (* preserve, altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg eth_udp_tx_start_toggle_sys_d1;
    reg  [47:0] eth_arp_des_mac_sys_d0;
    reg  [31:0] eth_arp_des_ip_sys_d0;
    reg  [7:0]  eth_dbg_tx_launch_cnt;
    reg  [7:0]  eth_dbg_tx_done_cnt;
    reg  [7:0]  eth_dbg_beacon_cnt;
    wire        rec_pkt_done;

    assign eth_tx_ctl = eth_tx_ctl_out_r;
    assign eth_txd    = eth_txd_out_r;
    assign eth_rst_n  = eth_phy_rst_n_w;
    assign eth_mdc    = 1'b0;
    assign eth_mdio   = 1'bz;
    assign EthSpeedLED = 2'b00;
    assign rec_en     = rec_en_udp;
    assign rec_data   = rec_data_udp;
    assign rec_byte_num = rec_byte_num_udp;
    assign tx_req     = tx_req_udp;
    assign tx_done    = tx_done_udp;
    assign eth_tx_er  = 1'b0;
    assign rec_pkt_done = rec_pkt_done_udp;
    assign eth_rx_rec_en_o = rec_en;
    assign eth_rx_rec_data_o = rec_data;
    assign eth_rx_rec_byte_num_o = rec_byte_num;
    assign eth_rx_rec_pkt_done_o = rec_pkt_done;

    eth_phy_reset_ctrl #(
        .HOLD_CYCLES   (PHY_RESET_HOLD_CYCLES),
        .COUNTER_WIDTH (PHY_RESET_COUNT_WIDTH)
    ) u_eth_phy_reset_ctrl (
        // sys_clk remains available while the PHY is held in reset. At the
        // board's 50 MHz system clock, the default count holds reset for 50 ms.
        .clk             (sys_clk),
        .reset_request_n (sys_rst_n),
        .phy_reset_n     (eth_phy_rst_n_w)
    );

    gmii_rx_input_capture u_gmii_rx_input_capture (
        .rx_clk_i (eth_rxc),
        .rx_ctl_i (eth_rx_ctl),
        .rx_data_i(eth_rxd),
        .rx_ctl_o (eth_rx_ctl_captured_w),
        .rx_data_o(eth_rxd_captured_w)
    );

    // Register the complete GMII bus at the board boundary. The common stage
    // keeps TXD and TX_EN aligned at the board-facing module boundary.
    always @(posedge clk_125MHz or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            eth_tx_ctl_out_r <= 1'b0;
            eth_txd_out_r    <= 8'h00;
        end else begin
            eth_tx_ctl_out_r <= eth_tx_ctl_udp;
            eth_txd_out_r    <= eth_txd_udp;
        end
    end

    generate
        if (!BOARD_VIDEO_ONLY) begin : g_gtx_clk_fwd
            // First board diagnostic uses the original project's unshifted
            // 125 MHz forwarding behavior. clk_125MHz_tx_shift remains in the
            // interface so a later board-measured phase can be reintroduced.
            assign GTX_CLK = clk_125MHz;
        end
        else begin : g_gtx_clk_static
            assign GTX_CLK = 1'b0;
        end
    endgenerate

    generate
        if (!BOARD_VIDEO_ONLY) begin : g_eth_udp_loop
            eth_udp_loop u_eth_udp_loop(
                .sys_clk      (clk_125MHz),
                .sys_rst_n    (sys_rst_n),
                .eth_rxc      (eth_rxc),
                .eth_rx_ctl   (eth_rx_ctl_captured_w),
                .eth_rxd      (eth_rxd_captured_w),
                .eth_txc      (eth_txc),
                .eth_tx_ctl   (eth_tx_ctl_udp),
                .eth_txd      (eth_txd_udp),
                .eth_rst_n    (eth_rst_n_udp),
                .rec_en       (rec_en_udp),
                .rec_data     (rec_data_udp),
                .rec_byte_num (rec_byte_num_udp),
                .rec_pkt_done (rec_pkt_done_udp),
                .tx_req       (tx_req_udp),
                .tx_done      (tx_done_udp),
                .tx_start_en  (udp_tx_start_en),
                .tx_byte_num  (udp_tx_byte_num),
                .tx_data      (udp_tx_data),
                .dbg_arp_req_tx (dbg_arp_req_tx),
                .dbg_arp_tx_en  (dbg_arp_tx_en),
                .dbg_arp_tx_done(dbg_arp_tx_done),
                .dbg_arp_des_mac(dbg_arp_des_mac),
                .dbg_arp_des_ip (dbg_arp_des_ip)
            );
        end
        else begin : g_eth_static
            assign eth_tx_ctl_udp = 1'b0;
            assign eth_txd_udp = 8'h00;
            assign eth_rst_n_udp = sys_rst_n;
            assign rec_en_udp = 1'b0;
            assign rec_data_udp = 8'd0;
            assign rec_byte_num_udp = 16'd0;
            assign rec_pkt_done_udp = 1'b0;
            assign tx_req_udp = 1'b0;
            assign tx_done_udp = 1'b0;
            assign dbg_arp_req_tx = 1'b0;
            assign dbg_arp_tx_en = 1'b0;
            assign dbg_arp_tx_done = 1'b0;
            assign dbg_arp_des_mac = 48'd0;
            assign dbg_arp_des_ip = 32'd0;
        end
    endgenerate

    cdc_word_toggle #(
        .WIDTH(24)
    ) u_rx_last_info_cdc (
        .src_clk_i        (eth_rxc),
        .src_rst_n_i      (sys_rst_n),
        .src_data_i       (eth_rx_last_info_snapshot_rx),
        .src_send_toggle_i(eth_rx_last_info_toggle_rx),
        .src_busy_o       (eth_rx_last_info_busy_rx_w),
        .dst_clk_i        (sys_clk),
        .dst_rst_n_i      (sys_rst_n),
        .dst_data_o       (eth_rx_last_info_sys_cdc_w),
        .dst_pulse_o      (eth_rx_last_info_valid_sys_w)
    );

    always @(posedge eth_rxc or negedge sys_rst_n) begin
        if(!sys_rst_n) begin
            eth_rx_rec_en_d <= 1'b0;
            eth_rx_pkt_seen <= 1'b0;
            eth_rx_last_data <= 8'd0;
            eth_rx_last_len <= 16'd0;
            eth_rx_ctl_d <= 1'b0;
            eth_raw_rx_toggle_rx <= 1'b0;
            eth_raw_byte_idx_rx <= 4'd0;
            eth_raw_b0_rx <= 8'd0;
            eth_raw_b1_rx <= 8'd0;
            eth_raw_b2_rx <= 8'd0;
            eth_raw_b3_rx <= 8'd0;
            eth_raw_b4_rx <= 8'd0;
            eth_raw_b5_rx <= 8'd0;
            eth_raw_b6_rx <= 8'd0;
            eth_raw_b7_rx <= 8'd0;
            eth_raw_b8_rx <= 8'd0;
            eth_raw_b9_rx <= 8'd0;
            eth_raw_b10_rx <= 8'd0;
            eth_raw_b11_rx <= 8'd0;
            eth_raw_rx_head_snapshot_rx <= 96'd0;
            eth_raw_rx_head_toggle_rx <= 1'b0;
            eth_rx_last_info_snapshot_rx <= 24'd0;
            eth_rx_last_info_toggle_rx <= 1'b0;
            eth_rx_pkt_toggle_rx <= 1'b0;
            udp_reply_toggle_rx <= 1'b0;
            udp_reply_len_rx <= 16'd0;
            udp_reply_last_data_rx <= 8'd0;
        end
        else if(BOARD_VIDEO_ONLY) begin
            eth_rx_rec_en_d <= 1'b0;
            eth_rx_pkt_seen <= 1'b0;
            eth_rx_last_data <= 8'd0;
            eth_rx_last_len <= 16'd0;
            eth_rx_ctl_d <= 1'b0;
            eth_raw_rx_toggle_rx <= 1'b0;
            eth_raw_byte_idx_rx <= 4'd0;
            eth_raw_b0_rx <= 8'd0;
            eth_raw_b1_rx <= 8'd0;
            eth_raw_b2_rx <= 8'd0;
            eth_raw_b3_rx <= 8'd0;
            eth_raw_b4_rx <= 8'd0;
            eth_raw_b5_rx <= 8'd0;
            eth_raw_b6_rx <= 8'd0;
            eth_raw_b7_rx <= 8'd0;
            eth_raw_b8_rx <= 8'd0;
            eth_raw_b9_rx <= 8'd0;
            eth_raw_b10_rx <= 8'd0;
            eth_raw_b11_rx <= 8'd0;
            eth_raw_rx_head_snapshot_rx <= 96'd0;
            eth_raw_rx_head_toggle_rx <= 1'b0;
            eth_rx_last_info_snapshot_rx <= 24'd0;
            eth_rx_last_info_toggle_rx <= 1'b0;
            eth_rx_pkt_toggle_rx <= 1'b0;
            udp_reply_toggle_rx <= 1'b0;
            udp_reply_len_rx <= 16'd0;
            udp_reply_last_data_rx <= 8'd0;
        end
        else begin
            eth_rx_ctl_d <= eth_rx_ctl_captured_w;
            eth_rx_rec_en_d <= rec_en;
            if(rec_en) begin
                eth_rx_last_data <= rec_data;
            end

            if(!eth_rx_ctl_d && eth_rx_ctl_captured_w) begin
                eth_raw_rx_toggle_rx <= ~eth_raw_rx_toggle_rx;
                eth_raw_byte_idx_rx <= 4'd1;
                eth_raw_b0_rx <= eth_rxd_captured_w;
            end
            else if(eth_rx_ctl_captured_w && (eth_raw_byte_idx_rx < 4'd12)) begin
                case(eth_raw_byte_idx_rx)
                    4'd1:  eth_raw_b1_rx <= eth_rxd_captured_w;
                    4'd2:  eth_raw_b2_rx <= eth_rxd_captured_w;
                    4'd3:  eth_raw_b3_rx <= eth_rxd_captured_w;
                    4'd4:  eth_raw_b4_rx <= eth_rxd_captured_w;
                    4'd5:  eth_raw_b5_rx <= eth_rxd_captured_w;
                    4'd6:  eth_raw_b6_rx <= eth_rxd_captured_w;
                    4'd7:  eth_raw_b7_rx <= eth_rxd_captured_w;
                    4'd8:  eth_raw_b8_rx <= eth_rxd_captured_w;
                    4'd9:  eth_raw_b9_rx <= eth_rxd_captured_w;
                    4'd10: eth_raw_b10_rx <= eth_rxd_captured_w;
                    4'd11: begin
                        eth_raw_b11_rx <= eth_rxd_captured_w;
                        // Ethernet minimum frame spacing is much longer than
                        // the three sys_clk stages below, so this debug-only
                        // snapshot remains stable throughout its transfer.
                        eth_raw_rx_head_snapshot_rx <= {
                            eth_raw_b0_rx, eth_raw_b1_rx, eth_raw_b2_rx, eth_raw_b3_rx,
                            eth_raw_b4_rx, eth_raw_b5_rx, eth_raw_b6_rx, eth_raw_b7_rx,
                            eth_raw_b8_rx, eth_raw_b9_rx, eth_raw_b10_rx, eth_rxd_captured_w
                        };
                        eth_raw_rx_head_toggle_rx <= ~eth_raw_rx_head_toggle_rx;
                    end
                    default: begin end
                endcase
                eth_raw_byte_idx_rx <= eth_raw_byte_idx_rx + 4'd1;
            end
            else if(!eth_rx_ctl_captured_w) begin
                eth_raw_byte_idx_rx <= 4'd0;
            end

            if(rec_pkt_done) begin
                eth_rx_pkt_seen <= ~eth_rx_pkt_seen;
                eth_rx_last_len <= rec_byte_num;
                eth_rx_pkt_toggle_rx <= ~eth_rx_pkt_toggle_rx;
                if(!eth_rx_last_info_busy_rx_w) begin
                    eth_rx_last_info_snapshot_rx <= {rec_byte_num, eth_rx_last_data};
                    eth_rx_last_info_toggle_rx <= ~eth_rx_last_info_toggle_rx;
                end
                if((rec_byte_num != 16'd0) && (rec_byte_num <= UDP_LOOPBACK_MAX_BYTES)) begin
                    udp_reply_len_rx <= rec_byte_num;
                    udp_reply_last_data_rx <= eth_rx_last_data;
                    udp_reply_toggle_rx <= ~udp_reply_toggle_rx;
                end
            end
        end
    end

    always @(posedge clk_125MHz or negedge sys_rst_n) begin
        if(!sys_rst_n) begin
            eth_tx_clk_mon <= 8'd0;
            udp_reply_toggle_tx_d0 <= 1'b0;
            udp_reply_toggle_tx_d1 <= 1'b0;
            udp_reply_len_tx_d0 <= 16'd0;
            udp_reply_len_tx_d1 <= 16'd0;
            udp_reply_last_data_tx_d0 <= 8'd0;
            udp_reply_last_data_tx_d1 <= 8'd0;
            udp_reply_len_hold <= 16'd0;
            udp_reply_last_data_hold <= 8'd0;
            udp_tx_start_en <= 1'b0;
            udp_tx_byte_num <= 16'd0;
            udp_tx_data <= 8'd0;
            udp_tx_pending <= 1'b0;
            udp_tx_active <= 1'b0;
            udp_tx_byte_idx <= 2'd0;
            udp_beacon_cnt <= 27'd0;
            eth_tx_ctl_udp_d <= 1'b0;
            dbg_arp_tx_en_d <= 1'b0;
            eth_raw_tx_byte_idx_tx <= 5'd0;
            eth_raw_tx_head_tx <= 96'd0;
            eth_arp_req_toggle_tx <= 1'b0;
            eth_arp_en_toggle_tx <= 1'b0;
            eth_arp_done_toggle_tx <= 1'b0;
            eth_udp_tx_start_toggle_tx <= 1'b0;
            eth_arp_des_mac_tx <= 48'd0;
            eth_arp_des_ip_tx <= 32'd0;
            eth_tx_launch_toggle_tx <= 1'b0;
            eth_tx_done_toggle_tx <= 1'b0;
            eth_beacon_toggle_tx <= 1'b0;
            eth_last_tx_kind_tx <= 8'd0;
            eth_last_tx_len_tx <= 16'd0;
        end
        else if(BOARD_VIDEO_ONLY) begin
            eth_tx_clk_mon <= 8'd0;
            udp_reply_toggle_tx_d0 <= 1'b0;
            udp_reply_toggle_tx_d1 <= 1'b0;
            udp_reply_len_tx_d0 <= 16'd0;
            udp_reply_len_tx_d1 <= 16'd0;
            udp_reply_last_data_tx_d0 <= 8'd0;
            udp_reply_last_data_tx_d1 <= 8'd0;
            udp_reply_len_hold <= 16'd0;
            udp_reply_last_data_hold <= 8'd0;
            udp_tx_start_en <= 1'b0;
            udp_tx_byte_num <= 16'd0;
            udp_tx_data <= 8'd0;
            udp_tx_pending <= 1'b0;
            udp_tx_active <= 1'b0;
            udp_tx_byte_idx <= 2'd0;
            udp_beacon_cnt <= 27'd0;
            eth_tx_ctl_udp_d <= 1'b0;
            dbg_arp_tx_en_d <= 1'b0;
            eth_raw_tx_byte_idx_tx <= 5'd0;
            eth_raw_tx_head_tx <= 96'd0;
            eth_arp_req_toggle_tx <= 1'b0;
            eth_arp_en_toggle_tx <= 1'b0;
            eth_arp_done_toggle_tx <= 1'b0;
            eth_udp_tx_start_toggle_tx <= 1'b0;
            eth_arp_des_mac_tx <= 48'd0;
            eth_arp_des_ip_tx <= 32'd0;
            eth_tx_launch_toggle_tx <= 1'b0;
            eth_tx_done_toggle_tx <= 1'b0;
            eth_beacon_toggle_tx <= 1'b0;
            eth_last_tx_kind_tx <= 8'd0;
            eth_last_tx_len_tx <= 16'd0;
        end
        else begin
            eth_tx_clk_mon <= eth_tx_clk_mon + 8'd1;
            udp_reply_toggle_tx_d0 <= udp_reply_toggle_rx;
            udp_reply_toggle_tx_d1 <= udp_reply_toggle_tx_d0;
            udp_reply_len_tx_d0 <= udp_reply_len_rx;
            udp_reply_len_tx_d1 <= udp_reply_len_tx_d0;
            udp_reply_last_data_tx_d0 <= udp_reply_last_data_rx;
            udp_reply_last_data_tx_d1 <= udp_reply_last_data_tx_d0;
            eth_tx_ctl_udp_d <= eth_tx_ctl_udp;
            dbg_arp_tx_en_d <= dbg_arp_tx_en;
            udp_tx_start_en <= 1'b0;

            if(dbg_arp_req_tx)
                eth_arp_req_toggle_tx <= ~eth_arp_req_toggle_tx;

            if(!dbg_arp_tx_en_d && dbg_arp_tx_en) begin
                eth_arp_en_toggle_tx <= ~eth_arp_en_toggle_tx;
                eth_arp_des_mac_tx <= dbg_arp_des_mac;
                eth_arp_des_ip_tx <= dbg_arp_des_ip;
            end

            if(dbg_arp_tx_done)
                eth_arp_done_toggle_tx <= ~eth_arp_done_toggle_tx;

            if(!eth_tx_ctl_udp_d && eth_tx_ctl_udp) begin
                eth_udp_tx_start_toggle_tx <= ~eth_udp_tx_start_toggle_tx;
                eth_raw_tx_byte_idx_tx <= 5'd1;
                eth_raw_tx_head_tx <= 96'd0;
            end
            else if(eth_tx_ctl_udp) begin
                case(eth_raw_tx_byte_idx_tx)
                    5'd8:  eth_raw_tx_head_tx[95:88] <= eth_txd_udp;
                    5'd9:  eth_raw_tx_head_tx[87:80] <= eth_txd_udp;
                    5'd10: eth_raw_tx_head_tx[79:72] <= eth_txd_udp;
                    5'd11: eth_raw_tx_head_tx[71:64] <= eth_txd_udp;
                    5'd12: eth_raw_tx_head_tx[63:56] <= eth_txd_udp;
                    5'd13: eth_raw_tx_head_tx[55:48] <= eth_txd_udp;
                    5'd14: eth_raw_tx_head_tx[47:40] <= eth_txd_udp;
                    5'd15: eth_raw_tx_head_tx[39:32] <= eth_txd_udp;
                    5'd16: eth_raw_tx_head_tx[31:24] <= eth_txd_udp;
                    5'd17: eth_raw_tx_head_tx[23:16] <= eth_txd_udp;
                    5'd18: eth_raw_tx_head_tx[15:8]  <= eth_txd_udp;
                    5'd19: eth_raw_tx_head_tx[7:0]   <= eth_txd_udp;
                    default: begin end
                endcase
                eth_raw_tx_byte_idx_tx <= eth_raw_tx_byte_idx_tx + 5'd1;
            end
            else begin
                eth_raw_tx_byte_idx_tx <= 5'd0;
            end

            if(ENABLE_UDP_DIAG_TX) begin
                if(udp_beacon_cnt == 27'd124999999)
                    udp_beacon_cnt <= 27'd0;
                else
                    udp_beacon_cnt <= udp_beacon_cnt + 27'd1;

                if((udp_reply_toggle_tx_d1 ^ udp_reply_toggle_tx_d0) && !udp_tx_pending && !udp_tx_active) begin
                    udp_reply_len_hold <= udp_reply_len_tx_d1;
                    udp_reply_last_data_hold <= udp_reply_last_data_tx_d1;
                    udp_tx_byte_num <= 16'd4;
                    udp_tx_data <= 8'hE1;
                    udp_tx_byte_idx <= 2'd1;
                    udp_tx_pending <= 1'b1;
                    eth_tx_launch_toggle_tx <= ~eth_tx_launch_toggle_tx;
                    eth_last_tx_kind_tx <= 8'hE1;
                    eth_last_tx_len_tx <= udp_reply_len_tx_d1;
                end
                else if((udp_beacon_cnt == 27'd124999999) && !udp_tx_pending && !udp_tx_active) begin
                    udp_reply_len_hold <= 16'hBEEF;
                    udp_reply_last_data_hold <= 8'hA5;
                    udp_tx_byte_num <= 16'd4;
                    udp_tx_data <= 8'hE2;
                    udp_tx_byte_idx <= 2'd1;
                    udp_tx_pending <= 1'b1;
                    eth_tx_launch_toggle_tx <= ~eth_tx_launch_toggle_tx;
                    eth_beacon_toggle_tx <= ~eth_beacon_toggle_tx;
                    eth_last_tx_kind_tx <= 8'hE2;
                    eth_last_tx_len_tx <= 16'hBEEF;
                end

                if(udp_tx_pending && !udp_tx_active)
                    udp_tx_start_en <= 1'b1;

                if(tx_req) begin
                    udp_tx_start_en <= 1'b0;
                    udp_tx_pending <= 1'b0;
                    udp_tx_active <= 1'b1;
                    case(udp_tx_byte_idx)
                        2'd1: begin
                            udp_tx_data <= udp_reply_len_hold[7:0];
                            udp_tx_byte_idx <= 2'd2;
                        end
                        2'd2: begin
                            udp_tx_data <= udp_reply_len_hold[15:8];
                            udp_tx_byte_idx <= 2'd3;
                        end
                        default: begin
                            udp_tx_data <= udp_reply_last_data_hold;
                            udp_tx_byte_idx <= 2'd0;
                        end
                    endcase
                end

                if(tx_done) begin
                    udp_tx_start_en <= 1'b0;
                    udp_tx_active <= 1'b0;
                    udp_tx_byte_idx <= 2'd0;
                    eth_tx_done_toggle_tx <= ~eth_tx_done_toggle_tx;
                end
            end
            else begin
                udp_beacon_cnt <= 27'd0;
                udp_reply_len_hold <= 16'd0;
                udp_reply_last_data_hold <= 8'd0;
                udp_tx_byte_num <= 16'd0;
                udp_tx_data <= 8'd0;
                udp_tx_pending <= 1'b0;
                udp_tx_active <= 1'b0;
                udp_tx_byte_idx <= 2'd0;
                eth_tx_launch_toggle_tx <= 1'b0;
                eth_tx_done_toggle_tx <= 1'b0;
                eth_beacon_toggle_tx <= 1'b0;
                eth_last_tx_kind_tx <= 8'd0;
                eth_last_tx_len_tx <= 16'd0;
            end
        end
    end

    always @(posedge sys_clk or negedge sys_rst_n) begin
        if(!sys_rst_n) begin
            eth_rx_pkt_toggle_sys_d0 <= 1'b0;
            eth_rx_pkt_toggle_sys_d1 <= 1'b0;
            eth_rx_pkt_seen_sys_d1 <= 1'b0;
            eth_raw_rx_toggle_sys_d0 <= 1'b0;
            eth_raw_rx_toggle_sys_d1 <= 1'b0;
            eth_raw_rx_head_sys_d0 <= 96'd0;
            eth_raw_rx_head_sys_d2 <= 96'd0;
            eth_raw_rx_head_toggle_sys_d0 <= 1'b0;
            eth_raw_rx_head_toggle_sys_d1 <= 1'b0;
            eth_raw_rx_head_toggle_sys_d2 <= 1'b0;
            eth_raw_rx_head_sys_d1 <= 96'd0;
            eth_rx_last_len_sys_d1 <= 16'd0;
            eth_rx_last_data_sys_d1 <= 8'd0;
            eth_tx_clk_mon_sys_d0 <= 8'd0;
            eth_tx_clk_mon_sys_d1 <= 8'd0;
            udp_tx_pending_sys_d0 <= 1'b0;
            udp_tx_pending_sys_d1 <= 1'b0;
            udp_tx_active_sys_d0 <= 1'b0;
            udp_tx_active_sys_d1 <= 1'b0;
            eth_tx_launch_toggle_sys_d0 <= 1'b0;
            eth_tx_launch_toggle_sys_d1 <= 1'b0;
            eth_tx_done_toggle_sys_d0 <= 1'b0;
            eth_tx_done_toggle_sys_d1 <= 1'b0;
            eth_beacon_toggle_sys_d0 <= 1'b0;
            eth_beacon_toggle_sys_d1 <= 1'b0;
            dbg_arp_tx_en_sys_d0 <= 1'b0;
            dbg_arp_tx_en_sys_d1 <= 1'b0;
            eth_tx_ctl_udp_sys_d0 <= 1'b0;
            eth_tx_ctl_udp_sys_d1 <= 1'b0;
            eth_last_tx_kind_sys_d0 <= 8'd0;
            eth_last_tx_kind_sys_d1 <= 8'd0;
            eth_last_tx_len_sys_d0 <= 16'd0;
            eth_last_tx_len_sys_d1 <= 16'd0;
            eth_raw_tx_head_sys_d0 <= 96'd0;
            eth_raw_tx_head_sys_d1 <= 96'd0;
            eth_arp_req_toggle_sys_d0 <= 1'b0;
            eth_arp_req_toggle_sys_d1 <= 1'b0;
            eth_arp_en_toggle_sys_d0 <= 1'b0;
            eth_arp_en_toggle_sys_d1 <= 1'b0;
            eth_arp_done_toggle_sys_d0 <= 1'b0;
            eth_arp_done_toggle_sys_d1 <= 1'b0;
            eth_udp_tx_start_toggle_sys_d0 <= 1'b0;
            eth_udp_tx_start_toggle_sys_d1 <= 1'b0;
            eth_arp_dbg_counts_sys_d1 <= 32'd0;
            eth_arp_des_mac_sys_d0 <= 48'd0;
            eth_arp_des_mac_sys_d1 <= 48'd0;
            eth_arp_des_ip_sys_d0 <= 32'd0;
            eth_arp_des_ip_sys_d1 <= 32'd0;
            eth_dbg_rx_pkt_cnt <= 8'd0;
            eth_dbg_raw_rx_cnt <= 8'd0;
            eth_dbg_tx_launch_cnt <= 8'd0;
            eth_dbg_tx_done_cnt <= 8'd0;
            eth_dbg_beacon_cnt <= 8'd0;
        end
        else if(BOARD_VIDEO_ONLY) begin
            eth_rx_pkt_toggle_sys_d0 <= 1'b0;
            eth_rx_pkt_toggle_sys_d1 <= 1'b0;
            eth_rx_pkt_seen_sys_d1 <= 1'b0;
            eth_raw_rx_toggle_sys_d0 <= 1'b0;
            eth_raw_rx_toggle_sys_d1 <= 1'b0;
            eth_raw_rx_head_sys_d0 <= 96'd0;
            eth_raw_rx_head_sys_d2 <= 96'd0;
            eth_raw_rx_head_toggle_sys_d0 <= 1'b0;
            eth_raw_rx_head_toggle_sys_d1 <= 1'b0;
            eth_raw_rx_head_toggle_sys_d2 <= 1'b0;
            eth_raw_rx_head_sys_d1 <= 96'd0;
            eth_rx_last_len_sys_d1 <= 16'd0;
            eth_rx_last_data_sys_d1 <= 8'd0;
            eth_tx_clk_mon_sys_d0 <= 8'd0;
            eth_tx_clk_mon_sys_d1 <= 8'd0;
            udp_tx_pending_sys_d0 <= 1'b0;
            udp_tx_pending_sys_d1 <= 1'b0;
            udp_tx_active_sys_d0 <= 1'b0;
            udp_tx_active_sys_d1 <= 1'b0;
            eth_tx_launch_toggle_sys_d0 <= 1'b0;
            eth_tx_launch_toggle_sys_d1 <= 1'b0;
            eth_tx_done_toggle_sys_d0 <= 1'b0;
            eth_tx_done_toggle_sys_d1 <= 1'b0;
            eth_beacon_toggle_sys_d0 <= 1'b0;
            eth_beacon_toggle_sys_d1 <= 1'b0;
            dbg_arp_tx_en_sys_d0 <= 1'b0;
            dbg_arp_tx_en_sys_d1 <= 1'b0;
            eth_tx_ctl_udp_sys_d0 <= 1'b0;
            eth_tx_ctl_udp_sys_d1 <= 1'b0;
            eth_last_tx_kind_sys_d0 <= 8'd0;
            eth_last_tx_kind_sys_d1 <= 8'd0;
            eth_last_tx_len_sys_d0 <= 16'd0;
            eth_last_tx_len_sys_d1 <= 16'd0;
            eth_raw_tx_head_sys_d0 <= 96'd0;
            eth_raw_tx_head_sys_d1 <= 96'd0;
            eth_arp_req_toggle_sys_d0 <= 1'b0;
            eth_arp_req_toggle_sys_d1 <= 1'b0;
            eth_arp_en_toggle_sys_d0 <= 1'b0;
            eth_arp_en_toggle_sys_d1 <= 1'b0;
            eth_arp_done_toggle_sys_d0 <= 1'b0;
            eth_arp_done_toggle_sys_d1 <= 1'b0;
            eth_udp_tx_start_toggle_sys_d0 <= 1'b0;
            eth_udp_tx_start_toggle_sys_d1 <= 1'b0;
            eth_arp_dbg_counts_sys_d1 <= 32'd0;
            eth_arp_des_mac_sys_d0 <= 48'd0;
            eth_arp_des_mac_sys_d1 <= 48'd0;
            eth_arp_des_ip_sys_d0 <= 32'd0;
            eth_arp_des_ip_sys_d1 <= 32'd0;
            eth_dbg_rx_pkt_cnt <= 8'd0;
            eth_dbg_raw_rx_cnt <= 8'd0;
            eth_dbg_tx_launch_cnt <= 8'd0;
            eth_dbg_tx_done_cnt <= 8'd0;
            eth_dbg_beacon_cnt <= 8'd0;
        end
        else begin
            eth_rx_pkt_toggle_sys_d0 <= eth_rx_pkt_toggle_rx;
            eth_rx_pkt_toggle_sys_d1 <= eth_rx_pkt_toggle_sys_d0;
            eth_raw_rx_toggle_sys_d0 <= eth_raw_rx_toggle_rx;
            eth_raw_rx_toggle_sys_d1 <= eth_raw_rx_toggle_sys_d0;
            eth_raw_rx_head_sys_d0 <= eth_raw_rx_head_snapshot_rx;
            eth_raw_rx_head_sys_d2 <= eth_raw_rx_head_sys_d0;
            eth_raw_rx_head_toggle_sys_d0 <= eth_raw_rx_head_toggle_rx;
            eth_raw_rx_head_toggle_sys_d1 <= eth_raw_rx_head_toggle_sys_d0;
            eth_raw_rx_head_toggle_sys_d2 <= eth_raw_rx_head_toggle_sys_d1;
            if(eth_raw_rx_head_toggle_sys_d2 ^ eth_raw_rx_head_toggle_sys_d1)
                eth_raw_rx_head_sys_d1 <= eth_raw_rx_head_sys_d2;
            if(eth_rx_last_info_valid_sys_w) begin
                eth_rx_pkt_seen_sys_d1 <= ~eth_rx_pkt_seen_sys_d1;
                eth_rx_last_len_sys_d1 <= eth_rx_last_info_sys_cdc_w[23:8];
                eth_rx_last_data_sys_d1 <= eth_rx_last_info_sys_cdc_w[7:0];
            end
            eth_tx_clk_mon_sys_d0 <= eth_tx_clk_mon;
            eth_tx_clk_mon_sys_d1 <= eth_tx_clk_mon_sys_d0;
            udp_tx_pending_sys_d0 <= udp_tx_pending;
            udp_tx_pending_sys_d1 <= udp_tx_pending_sys_d0;
            udp_tx_active_sys_d0 <= udp_tx_active;
            udp_tx_active_sys_d1 <= udp_tx_active_sys_d0;
            eth_tx_launch_toggle_sys_d0 <= eth_tx_launch_toggle_tx;
            eth_tx_launch_toggle_sys_d1 <= eth_tx_launch_toggle_sys_d0;
            eth_tx_done_toggle_sys_d0 <= eth_tx_done_toggle_tx;
            eth_tx_done_toggle_sys_d1 <= eth_tx_done_toggle_sys_d0;
            eth_beacon_toggle_sys_d0 <= eth_beacon_toggle_tx;
            eth_beacon_toggle_sys_d1 <= eth_beacon_toggle_sys_d0;
            dbg_arp_tx_en_sys_d0 <= dbg_arp_tx_en;
            dbg_arp_tx_en_sys_d1 <= dbg_arp_tx_en_sys_d0;
            eth_tx_ctl_udp_sys_d0 <= eth_tx_ctl_udp;
            eth_tx_ctl_udp_sys_d1 <= eth_tx_ctl_udp_sys_d0;
            eth_last_tx_kind_sys_d0 <= eth_last_tx_kind_tx;
            eth_last_tx_kind_sys_d1 <= eth_last_tx_kind_sys_d0;
            eth_last_tx_len_sys_d0 <= eth_last_tx_len_tx;
            eth_last_tx_len_sys_d1 <= eth_last_tx_len_sys_d0;
            eth_raw_tx_head_sys_d0 <= eth_raw_tx_head_tx;
            eth_raw_tx_head_sys_d1 <= eth_raw_tx_head_sys_d0;
            eth_arp_req_toggle_sys_d0 <= eth_arp_req_toggle_tx;
            eth_arp_req_toggle_sys_d1 <= eth_arp_req_toggle_sys_d0;
            eth_arp_en_toggle_sys_d0 <= eth_arp_en_toggle_tx;
            eth_arp_en_toggle_sys_d1 <= eth_arp_en_toggle_sys_d0;
            eth_arp_done_toggle_sys_d0 <= eth_arp_done_toggle_tx;
            eth_arp_done_toggle_sys_d1 <= eth_arp_done_toggle_sys_d0;
            eth_udp_tx_start_toggle_sys_d0 <= eth_udp_tx_start_toggle_tx;
            eth_udp_tx_start_toggle_sys_d1 <= eth_udp_tx_start_toggle_sys_d0;
            eth_arp_des_mac_sys_d0 <= eth_arp_des_mac_tx;
            eth_arp_des_mac_sys_d1 <= eth_arp_des_mac_sys_d0;
            eth_arp_des_ip_sys_d0 <= eth_arp_des_ip_tx;
            eth_arp_des_ip_sys_d1 <= eth_arp_des_ip_sys_d0;

            if(eth_arp_req_toggle_sys_d1 ^ eth_arp_req_toggle_sys_d0)
                eth_arp_dbg_counts_sys_d1[7:0] <= eth_arp_dbg_counts_sys_d1[7:0] + 8'd1;
            if(eth_arp_en_toggle_sys_d1 ^ eth_arp_en_toggle_sys_d0)
                eth_arp_dbg_counts_sys_d1[15:8] <= eth_arp_dbg_counts_sys_d1[15:8] + 8'd1;
            if(eth_arp_done_toggle_sys_d1 ^ eth_arp_done_toggle_sys_d0)
                eth_arp_dbg_counts_sys_d1[23:16] <= eth_arp_dbg_counts_sys_d1[23:16] + 8'd1;
            if(eth_udp_tx_start_toggle_sys_d1 ^ eth_udp_tx_start_toggle_sys_d0)
                eth_arp_dbg_counts_sys_d1[31:24] <= eth_arp_dbg_counts_sys_d1[31:24] + 8'd1;

            if(eth_rx_pkt_toggle_sys_d1 ^ eth_rx_pkt_toggle_sys_d0)
                eth_dbg_rx_pkt_cnt <= eth_dbg_rx_pkt_cnt + 8'd1;
            if(eth_raw_rx_toggle_sys_d1 ^ eth_raw_rx_toggle_sys_d0)
                eth_dbg_raw_rx_cnt <= eth_dbg_raw_rx_cnt + 8'd1;
            if(eth_tx_launch_toggle_sys_d1 ^ eth_tx_launch_toggle_sys_d0)
                eth_dbg_tx_launch_cnt <= eth_dbg_tx_launch_cnt + 8'd1;
            if(eth_tx_done_toggle_sys_d1 ^ eth_tx_done_toggle_sys_d0)
                eth_dbg_tx_done_cnt <= eth_dbg_tx_done_cnt + 8'd1;
            if(eth_beacon_toggle_sys_d1 ^ eth_beacon_toggle_sys_d0)
                eth_dbg_beacon_cnt <= eth_dbg_beacon_cnt + 8'd1;
        end
    end

endmodule
