`timescale 1ns / 1ps

module black_frame_temporal_tracker #(
    parameter integer X_WIDTH = 12,
    parameter integer LOCK_FRAMES = 4,
    parameter [X_WIDTH-1:0] LOCK_TOLERANCE = 12'd24,
    parameter integer UPDATE_INTERVAL_FRAMES = 15,
    parameter [X_WIDTH-1:0] UPDATE_MAX_DELTA = 12'd32
) (
    input  wire               clk,
    input  wire               rst_n,
    input  wire               relocalize,
    input  wire               frame_tick,
    input  wire               freeze,
    input  wire               direct_valid,
    input  wire [X_WIDTH-1:0] direct_left,
    input  wire [X_WIDTH-1:0] direct_right,
    input  wire [X_WIDTH-1:0] direct_top,
    input  wire [X_WIDTH-1:0] direct_bottom,
    input  wire               inferred_valid,
    input  wire [X_WIDTH-1:0] inferred_left,
    input  wire [X_WIDTH-1:0] inferred_right,
    input  wire [X_WIDTH-1:0] inferred_top,
    input  wire [X_WIDTH-1:0] inferred_bottom,
    output reg                track_valid,
    output reg  [X_WIDTH-1:0] track_left,
    output reg  [X_WIDTH-1:0] track_right,
    output reg  [X_WIDTH-1:0] track_top,
    output reg  [X_WIDTH-1:0] track_bottom
);

    wire candidate_valid;
    wire [X_WIDTH-1:0] candidate_left;
    wire [X_WIDTH-1:0] candidate_right;
    wire [X_WIDTH-1:0] candidate_top;
    wire [X_WIDTH-1:0] candidate_bottom;
    wire [X_WIDTH-1:0] lock_left_delta;
    wire [X_WIDTH-1:0] lock_right_delta;
    wire [X_WIDTH-1:0] lock_top_delta;
    wire [X_WIDTH-1:0] lock_bottom_delta;
    wire [X_WIDTH-1:0] track_left_delta;
    wire [X_WIDTH-1:0] track_right_delta;
    wire [X_WIDTH-1:0] track_top_delta;
    wire [X_WIDTH-1:0] track_bottom_delta;
    wire lock_candidate_close;
    wire track_candidate_close;

    reg [7:0] lock_count_reg;
    reg [7:0] update_count_reg;
    reg [X_WIDTH-1:0] lock_left_reg;
    reg [X_WIDTH-1:0] lock_right_reg;
    reg [X_WIDTH-1:0] lock_top_reg;
    reg [X_WIDTH-1:0] lock_bottom_reg;

    assign candidate_valid = direct_valid | inferred_valid;
    assign candidate_left = direct_valid ? direct_left : inferred_left;
    assign candidate_right = direct_valid ? direct_right : inferred_right;
    assign candidate_top = direct_valid ? direct_top : inferred_top;
    assign candidate_bottom = direct_valid ? direct_bottom : inferred_bottom;

    assign lock_left_delta = (candidate_left >= lock_left_reg) ?
                             (candidate_left - lock_left_reg) :
                             (lock_left_reg - candidate_left);
    assign lock_right_delta = (candidate_right >= lock_right_reg) ?
                              (candidate_right - lock_right_reg) :
                              (lock_right_reg - candidate_right);
    assign lock_top_delta = (candidate_top >= lock_top_reg) ?
                            (candidate_top - lock_top_reg) :
                            (lock_top_reg - candidate_top);
    assign lock_bottom_delta = (candidate_bottom >= lock_bottom_reg) ?
                               (candidate_bottom - lock_bottom_reg) :
                               (lock_bottom_reg - candidate_bottom);
    assign track_left_delta = (candidate_left >= track_left) ?
                              (candidate_left - track_left) :
                              (track_left - candidate_left);
    assign track_right_delta = (candidate_right >= track_right) ?
                               (candidate_right - track_right) :
                               (track_right - candidate_right);
    assign track_top_delta = (candidate_top >= track_top) ?
                             (candidate_top - track_top) :
                             (track_top - candidate_top);
    assign track_bottom_delta = (candidate_bottom >= track_bottom) ?
                                (candidate_bottom - track_bottom) :
                                (track_bottom - candidate_bottom);

    assign lock_candidate_close =
        (lock_left_delta <= LOCK_TOLERANCE) &&
        (lock_right_delta <= LOCK_TOLERANCE) &&
        (lock_top_delta <= LOCK_TOLERANCE) &&
        (lock_bottom_delta <= LOCK_TOLERANCE);
    assign track_candidate_close =
        (track_left_delta <= UPDATE_MAX_DELTA) &&
        (track_right_delta <= UPDATE_MAX_DELTA) &&
        (track_top_delta <= UPDATE_MAX_DELTA) &&
        (track_bottom_delta <= UPDATE_MAX_DELTA);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            track_valid <= 1'b0;
            track_left <= {X_WIDTH{1'b0}};
            track_right <= {X_WIDTH{1'b0}};
            track_top <= {X_WIDTH{1'b0}};
            track_bottom <= {X_WIDTH{1'b0}};
            lock_count_reg <= 8'd0;
            update_count_reg <= 8'd0;
            lock_left_reg <= {X_WIDTH{1'b0}};
            lock_right_reg <= {X_WIDTH{1'b0}};
            lock_top_reg <= {X_WIDTH{1'b0}};
            lock_bottom_reg <= {X_WIDTH{1'b0}};
        end else if (relocalize) begin
            track_valid <= 1'b0;
            track_left <= {X_WIDTH{1'b0}};
            track_right <= {X_WIDTH{1'b0}};
            track_top <= {X_WIDTH{1'b0}};
            track_bottom <= {X_WIDTH{1'b0}};
            lock_count_reg <= 8'd0;
            update_count_reg <= 8'd0;
            lock_left_reg <= {X_WIDTH{1'b0}};
            lock_right_reg <= {X_WIDTH{1'b0}};
            lock_top_reg <= {X_WIDTH{1'b0}};
            lock_bottom_reg <= {X_WIDTH{1'b0}};
        end else if (frame_tick && !freeze) begin
            if (!track_valid) begin
                update_count_reg <= 8'd0;
                if (candidate_valid) begin
                    if (lock_count_reg == 8'd0) begin
                        lock_count_reg <= 8'd1;
                        lock_left_reg <= candidate_left;
                        lock_right_reg <= candidate_right;
                        lock_top_reg <= candidate_top;
                        lock_bottom_reg <= candidate_bottom;
                    end else if (lock_candidate_close) begin
                        lock_left_reg <= ({1'b0, lock_left_reg} +
                                          {1'b0, candidate_left}) >> 1;
                        lock_right_reg <= ({1'b0, lock_right_reg} +
                                           {1'b0, candidate_right}) >> 1;
                        lock_top_reg <= ({1'b0, lock_top_reg} +
                                         {1'b0, candidate_top}) >> 1;
                        lock_bottom_reg <= ({1'b0, lock_bottom_reg} +
                                            {1'b0, candidate_bottom}) >> 1;
                        if (lock_count_reg >= (LOCK_FRAMES - 1)) begin
                            track_valid <= 1'b1;
                            track_left <= ({1'b0, lock_left_reg} +
                                           {1'b0, candidate_left}) >> 1;
                            track_right <= ({1'b0, lock_right_reg} +
                                            {1'b0, candidate_right}) >> 1;
                            track_top <= ({1'b0, lock_top_reg} +
                                          {1'b0, candidate_top}) >> 1;
                            track_bottom <= ({1'b0, lock_bottom_reg} +
                                             {1'b0, candidate_bottom}) >> 1;
                            lock_count_reg <= 8'd0;
                        end else begin
                            lock_count_reg <= lock_count_reg + 8'd1;
                        end
                    end else begin
                        lock_count_reg <= 8'd1;
                        lock_left_reg <= candidate_left;
                        lock_right_reg <= candidate_right;
                        lock_top_reg <= candidate_top;
                        lock_bottom_reg <= candidate_bottom;
                    end
                end else begin
                    lock_count_reg <= 8'd0;
                end
            end else begin
                lock_count_reg <= 8'd0;
                if (update_count_reg >= (UPDATE_INTERVAL_FRAMES - 1)) begin
                    update_count_reg <= 8'd0;
                    if (candidate_valid && track_candidate_close) begin
                        track_left <= ({1'b0, track_left} +
                                       {1'b0, candidate_left}) >> 1;
                        track_right <= ({1'b0, track_right} +
                                        {1'b0, candidate_right}) >> 1;
                        track_top <= ({1'b0, track_top} +
                                      {1'b0, candidate_top}) >> 1;
                        track_bottom <= ({1'b0, track_bottom} +
                                         {1'b0, candidate_bottom}) >> 1;
                    end
                end else begin
                    update_count_reg <= update_count_reg + 8'd1;
                end
            end
        end
    end
endmodule
