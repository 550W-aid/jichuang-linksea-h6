`timescale 1ns / 1ps

// Lightweight target wrapper. The map detector already proves the streaming
// black-border topology; this instance reuses that detector inside the locked
// map ROI for the small calibration target.
module target_rectangle_detector #(
    parameter integer IMAGE_WIDTH = 1280,
    parameter integer IMAGE_HEIGHT = 720,
    parameter integer X_WIDTH = 12,
    parameter integer Y_WIDTH = 12,
    parameter integer MIN_WIDTH_ABS = 24,
    parameter integer MAX_WIDTH_ABS = 384,
    parameter integer MIN_HEIGHT_ABS = 16,
    parameter integer MAX_HEIGHT_ABS = 192,
    parameter integer ROI_GUARD = 48,
    parameter integer ANALYSIS_DEADLINE_CYCLES = 500000
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 sof,
    input  wire                 eof,
    input  wire                 pixel_valid,
    input  wire [X_WIDTH-1:0]   pixel_x,
    input  wire [Y_WIDTH-1:0]   pixel_y,
    input  wire [7:0]           pixel_r,
    input  wire [7:0]           pixel_g,
    input  wire [7:0]           pixel_b,
    input  wire                 scene_roi_valid,
    input  wire [X_WIDTH-1:0]   scene_roi_min_x,
    input  wire [X_WIDTH-1:0]   scene_roi_max_x,
    input  wire [Y_WIDTH-1:0]   scene_roi_min_y,
    input  wire [Y_WIDTH-1:0]   scene_roi_max_y,
    output reg                  result_valid,
    output reg                  target_valid,
    output reg [X_WIDTH-1:0]    target_x,
    output reg [Y_WIDTH-1:0]    target_y,
    output reg [X_WIDTH-1:0]    target_w,
    output reg [Y_WIDTH-1:0]    target_h,
    output reg [31:0]           target_score,
    output reg [3:0]            target_support,
    output reg [15:0]           result_frame_id,
    output reg                  result_roi_valid,
    output reg [X_WIDTH-1:0]    result_roi_left,
    output reg [X_WIDTH-1:0]    result_roi_right,
    output reg [Y_WIDTH-1:0]    result_roi_top,
    output reg [Y_WIDTH-1:0]    result_roi_bottom,
    output reg                  frame_timeout_fault
);

localparam integer MIN_SIDE_ROWS = (MIN_HEIGHT_ABS > 16) ?
                                    (MIN_HEIGHT_ABS / 2) : 8;

wire roi_geometry_valid_w = scene_roi_valid &&
    (scene_roi_max_x >= scene_roi_min_x + (ROI_GUARD * 2) + 2) &&
    (scene_roi_max_y >= scene_roi_min_y + (ROI_GUARD * 2) + 2);
wire target_roi_pixel_valid_w = pixel_valid && roi_geometry_valid_w &&
    (pixel_x >= scene_roi_min_x + ROI_GUARD) &&
    (pixel_x <= scene_roi_max_x - ROI_GUARD) &&
    (pixel_y >= scene_roi_min_y + ROI_GUARD) &&
    (pixel_y <= scene_roi_max_y - ROI_GUARD);

wire coarse_frame_valid_w;
wire [X_WIDTH-1:0] coarse_left_w;
wire [X_WIDTH-1:0] coarse_right_w;
wire [Y_WIDTH-1:0] coarse_top_w;
wire [Y_WIDTH-1:0] coarse_bottom_w;
wire coarse_candidate_valid_w;
wire [X_WIDTH-1:0] coarse_candidate_left_w;
wire [X_WIDTH-1:0] coarse_candidate_right_w;
wire [Y_WIDTH-1:0] coarse_candidate_top_w;
wire [Y_WIDTH-1:0] coarse_candidate_bottom_w;
wire coarse_left_side_valid_w;
wire coarse_right_side_valid_w;

black_frame_coarse_detector #(
    .IMAGE_WIDTH       (IMAGE_WIDTH),
    .IMAGE_HEIGHT      (IMAGE_HEIGHT),
    .X_WIDTH          (X_WIDTH),
    .Y_WIDTH          (Y_WIDTH),
    .DARK_MAX         (8'd96),
    .ROW_BIN_MIN_DARK (MIN_WIDTH_ABS),
    .ROW_BIN_MAX_DARK (MAX_WIDTH_ABS),
    .EDGE_MARGIN      (0),
    .SIDE_TOLERANCE   (12),
    .MIN_SIDE_ROWS    (MIN_SIDE_ROWS),
    .MIN_FRAME_WIDTH  (MIN_WIDTH_ABS),
    .MIN_FRAME_HEIGHT (MIN_HEIGHT_ABS),
    .MIN_LINE_BAND_HEIGHT(1),
    .MAX_LINE_BAND_HEIGHT(16)
) coarse_target_detector_inst (
    .clk                 (clk),
    .rst_n               (rst_n),
    .sof                 (sof),
    .eof                 (eof),
    .pixel_valid         (target_roi_pixel_valid_w),
    .pixel_x             (pixel_x),
    .pixel_y             (pixel_y),
    .pixel_r             (pixel_r),
    .pixel_g             (pixel_g),
    .pixel_b             (pixel_b),
    .frame_valid         (coarse_frame_valid_w),
    .left_x              (coarse_left_w),
    .right_x             (coarse_right_w),
    .top_y               (coarse_top_w),
    .bottom_y            (coarse_bottom_w),
    .candidate_valid     (coarse_candidate_valid_w),
    .candidate_left_x    (coarse_candidate_left_w),
    .candidate_right_x   (coarse_candidate_right_w),
    .candidate_top_y     (coarse_candidate_top_w),
    .candidate_bottom_y  (coarse_candidate_bottom_w),
    .left_side_valid     (coarse_left_side_valid_w),
    .right_side_valid    (coarse_right_side_valid_w)
);

wire [X_WIDTH:0] coarse_width_w =
    {1'b0, coarse_right_w} - {1'b0, coarse_left_w} + 1'b1;
wire [Y_WIDTH:0] coarse_height_w =
    {1'b0, coarse_bottom_w} - {1'b0, coarse_top_w} + 1'b1;
wire [X_WIDTH:0] coarse_center_x_w =
    ({1'b0, coarse_left_w} + {1'b0, coarse_right_w}) >> 1;
wire [Y_WIDTH:0] coarse_center_y_w =
    ({1'b0, coarse_top_w} + {1'b0, coarse_bottom_w}) >> 1;
wire target_geometry_valid_w =
    (coarse_width_w >= MIN_WIDTH_ABS) &&
    (coarse_width_w <= MAX_WIDTH_ABS) &&
    (coarse_height_w >= MIN_HEIGHT_ABS) &&
    (coarse_height_w <= MAX_HEIGHT_ABS) &&
    coarse_left_side_valid_w && coarse_right_side_valid_w;
wire [X_WIDTH+Y_WIDTH+1:0] target_perimeter_w =
    (coarse_width_w + coarse_height_w) << 1;

reg [15:0] frame_id_r;
reg        result_pending_r;
reg        pending_roi_valid_r;
reg [X_WIDTH-1:0] pending_roi_left_r;
reg [X_WIDTH-1:0] pending_roi_right_r;
reg [Y_WIDTH-1:0] pending_roi_top_r;
reg [Y_WIDTH-1:0] pending_roi_bottom_r;
reg [15:0] pending_frame_id_r;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        frame_id_r <= 16'd0;
        result_pending_r <= 1'b0;
        pending_roi_valid_r <= 1'b0;
        pending_roi_left_r <= {X_WIDTH{1'b0}};
        pending_roi_right_r <= {X_WIDTH{1'b0}};
        pending_roi_top_r <= {Y_WIDTH{1'b0}};
        pending_roi_bottom_r <= {Y_WIDTH{1'b0}};
        pending_frame_id_r <= 16'd0;
        result_valid <= 1'b0;
        target_valid <= 1'b0;
        target_x <= {X_WIDTH{1'b1}};
        target_y <= {Y_WIDTH{1'b1}};
        target_w <= {X_WIDTH{1'b0}};
        target_h <= {Y_WIDTH{1'b0}};
        target_score <= 32'd0;
        target_support <= 4'd0;
        result_frame_id <= 16'd0;
        result_roi_valid <= 1'b0;
        result_roi_left <= {X_WIDTH{1'b1}};
        result_roi_right <= {X_WIDTH{1'b1}};
        result_roi_top <= {Y_WIDTH{1'b1}};
        result_roi_bottom <= {Y_WIDTH{1'b1}};
        frame_timeout_fault <= 1'b0;
    end else begin
        result_valid <= 1'b0;
        frame_timeout_fault <= 1'b0;

        if (sof) begin
            pending_roi_valid_r <= roi_geometry_valid_w;
            pending_roi_left_r <= scene_roi_min_x;
            pending_roi_right_r <= scene_roi_max_x;
            pending_roi_top_r <= scene_roi_min_y;
            pending_roi_bottom_r <= scene_roi_max_y;
        end

        if (eof) begin
            pending_frame_id_r <= frame_id_r;
            frame_id_r <= frame_id_r + 16'd1;
            result_pending_r <= 1'b1;
        end else if (result_pending_r) begin
            result_pending_r <= 1'b0;
            result_valid <= 1'b1;
            target_valid <= pending_roi_valid_r && target_geometry_valid_w;
            result_frame_id <= pending_frame_id_r;
            result_roi_valid <= pending_roi_valid_r;
            result_roi_left <= pending_roi_valid_r ? pending_roi_left_r : {X_WIDTH{1'b1}};
            result_roi_right <= pending_roi_valid_r ? pending_roi_right_r : {X_WIDTH{1'b1}};
            result_roi_top <= pending_roi_valid_r ? pending_roi_top_r : {Y_WIDTH{1'b1}};
            result_roi_bottom <= pending_roi_valid_r ? pending_roi_bottom_r : {Y_WIDTH{1'b1}};
            if (pending_roi_valid_r && target_geometry_valid_w) begin
                target_x <= coarse_center_x_w[X_WIDTH-1:0];
                target_y <= coarse_center_y_w[Y_WIDTH-1:0];
                target_w <= coarse_width_w[X_WIDTH-1:0];
                target_h <= coarse_height_w[Y_WIDTH-1:0];
                target_score <= {{(32-(X_WIDTH+Y_WIDTH+2)){1'b0}}, target_perimeter_w};
                target_support <= 4'd11;
            end else begin
                target_x <= {X_WIDTH{1'b1}};
                target_y <= {Y_WIDTH{1'b1}};
                target_w <= {X_WIDTH{1'b0}};
                target_h <= {Y_WIDTH{1'b0}};
                target_score <= 32'd0;
                target_support <= 4'd0;
            end
        end
    end
end

endmodule
