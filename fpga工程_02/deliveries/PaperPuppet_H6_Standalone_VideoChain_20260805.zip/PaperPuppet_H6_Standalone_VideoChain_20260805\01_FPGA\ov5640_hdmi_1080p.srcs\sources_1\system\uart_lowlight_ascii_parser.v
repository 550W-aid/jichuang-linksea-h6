// Module Function:
//   Parses GUI_Merged low-light commands in the form L0\n through L255\n.
//   A completed, clamped level is emitted with a one-clock valid pulse.
`timescale 1ns/1ps

module uart_lowlight_ascii_parser (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       rx_valid_i,
    input  wire [7:0] rx_data_i,
    output reg        level_valid_o,
    output reg  [7:0] level_o
);
    reg       collecting_r;
    reg [1:0] digit_count_r;
    reg [8:0] value_accum_r;

    wire       digit_w = (rx_data_i >= 8'h30) && (rx_data_i <= 8'h39);
    wire [3:0] digit_value_w = rx_data_i[3:0];
    wire       terminator_w = (rx_data_i == 8'h0A) || (rx_data_i == 8'h0D);
    wire [12:0] decimal_next_w = (value_accum_r << 3) +
                                  (value_accum_r << 1) + digit_value_w;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            collecting_r  <= 1'b0;
            digit_count_r <= 2'd0;
            value_accum_r <= 9'd0;
            level_valid_o <= 1'b0;
            level_o       <= 8'd0;
        end else begin
            level_valid_o <= 1'b0;

            if (rx_valid_i) begin
                if (!collecting_r) begin
                    if ((rx_data_i == 8'h4C) || (rx_data_i == 8'h6C)) begin
                        collecting_r  <= 1'b1;
                        digit_count_r <= 2'd0;
                        value_accum_r <= 9'd0;
                    end
                end else if (digit_w && (digit_count_r < 2'd3)) begin
                    digit_count_r <= digit_count_r + 2'd1;
                    value_accum_r <= (decimal_next_w > 13'd255) ?
                                     9'd255 : decimal_next_w[8:0];
                end else if (terminator_w && (digit_count_r != 2'd0)) begin
                    collecting_r  <= 1'b0;
                    digit_count_r <= 2'd0;
                    level_o       <= value_accum_r[7:0];
                    level_valid_o <= 1'b1;
                end else if ((rx_data_i == 8'h4C) || (rx_data_i == 8'h6C)) begin
                    collecting_r  <= 1'b1;
                    digit_count_r <= 2'd0;
                    value_accum_r <= 9'd0;
                end else begin
                    collecting_r  <= 1'b0;
                    digit_count_r <= 2'd0;
                    value_accum_r <= 9'd0;
                end
            end
        end
    end
endmodule
