`timescale 1ns / 1ps

module virtual_grab_uart_tx #(
    parameter integer CLK_FREQ_HZ = 50000000,
    parameter integer UART_BPS    = 115200
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       tx_start,
    input  wire [7:0] tx_data,
    output wire       tx_busy,
    output reg        uart_txd
);

    localparam integer CLKS_PER_BIT = CLK_FREQ_HZ / UART_BPS;

    reg busy_reg;
    reg [15:0] clk_count_reg;
    reg [3:0] bit_index_reg;
    reg [7:0] data_reg;

    assign tx_busy = busy_reg;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            busy_reg      <= 1'b0;
            clk_count_reg <= 16'd0;
            bit_index_reg <= 4'd0;
            data_reg      <= 8'h00;
            uart_txd      <= 1'b1;
        end else begin
            if (!busy_reg) begin
                clk_count_reg <= 16'd0;
                bit_index_reg <= 4'd0;
                uart_txd <= 1'b1;

                if (tx_start) begin
                    busy_reg <= 1'b1;
                    data_reg <= tx_data;
                    uart_txd <= 1'b0;
                end
            end else if (clk_count_reg == CLKS_PER_BIT - 1) begin
                clk_count_reg <= 16'd0;
                bit_index_reg <= bit_index_reg + 4'd1;

                case (bit_index_reg)
                    4'd0: uart_txd <= data_reg[0];
                    4'd1: uart_txd <= data_reg[1];
                    4'd2: uart_txd <= data_reg[2];
                    4'd3: uart_txd <= data_reg[3];
                    4'd4: uart_txd <= data_reg[4];
                    4'd5: uart_txd <= data_reg[5];
                    4'd6: uart_txd <= data_reg[6];
                    4'd7: uart_txd <= data_reg[7];
                    4'd8: uart_txd <= 1'b1;
                    default: begin
                        uart_txd <= 1'b1;
                        busy_reg <= 1'b0;
                    end
                endcase
            end else begin
                clk_count_reg <= clk_count_reg + 16'd1;
            end
        end
    end

endmodule
