// ============================================================================
// Module Function:
//   HDMI pixel-stream rotate overlay that samples a resource-safe BRAM preview and switches between bypass and rotated output.
// ============================================================================
`timescale 1ns / 1ps

module rotate_stream_overlay #(
    parameter integer SRC_FRAME_W = 1280,
    parameter integer SRC_FRAME_H = 720,
    parameter integer PREVIEW_W   = 256,
    parameter integer PREVIEW_H   = 144
) (
    input  wire        sys_clk,
    input  wire        sys_rst_n,
    input  wire [15:0] rotate_angle_deg_sys_i,
    input  wire        rotate_cfg_toggle_sys_i,
    output wire [15:0] rotate_active_angle_sys_o,
    output wire [15:0] rotate_status_sys_o,
    output wire [15:0] rotate_debug0_sys_o,
    output wire [15:0] rotate_debug1_sys_o,

    input  wire        pix_clk,
    input  wire        pix_rst_n,
    input  wire        wr_valid_i,
    input  wire [10:0] wr_x_i,
    input  wire [10:0] wr_y_i,
    input  wire [15:0] wr_rgb565_i,
    input  wire        video_hs_i,
    input  wire        video_vs_i,
    input  wire        video_de_i,
    input  wire [23:0] video_rgb_i,
    input  wire [11:0] pixel_x_i,
    input  wire [11:0] pixel_y_i,
    output wire        video_hs_o,
    output wire        video_vs_o,
    output wire        video_de_o,
    output wire [23:0] video_rgb_o,
    output wire        preview_active_o
);

localparam [1:0] ROTATE_STATE_LIVE = 2'd0;

reg         pending_valid_pix_r;
reg signed [8:0] pending_angle_pix_r;
reg signed [8:0] active_angle_pix_r;

wire signed [8:0] angle_cmd_sys_w;
wire signed [8:0] angle_cmd_pix_w;
wire [15:0]       angle_cmd_pix_word_w;
wire              angle_cmd_valid_pix_w;
wire              angle_cdc_busy_sys_w;
wire              frame_start_pix_w;
wire              active_match_w;
wire [15:0]       angle_cmd_clamped_w;
wire              rotate_expected_active_sys_w;

function signed [8:0] clamp_angle_deg_s9_fn;
    input signed [15:0] angle_in;
    begin
        if (angle_in > 16'sd180) begin
            clamp_angle_deg_s9_fn = 9'sd180;
        end else if (angle_in < -16'sd180) begin
            clamp_angle_deg_s9_fn = -9'sd180;
        end else begin
            clamp_angle_deg_s9_fn = angle_in[8:0];
        end
    end
endfunction

assign angle_cmd_sys_w       = clamp_angle_deg_s9_fn($signed(rotate_angle_deg_sys_i));
assign angle_cmd_pix_w       = clamp_angle_deg_s9_fn($signed(angle_cmd_pix_word_w));
// Commit pending control during vertical sync. This is frame-safe and avoids
// driving the angle-register enables through two wide pixel-coordinate compares.
assign frame_start_pix_w     = ~video_vs_i;
assign angle_cmd_clamped_w   = {{7{angle_cmd_sys_w[8]}}, angle_cmd_sys_w};
assign rotate_expected_active_sys_w = (angle_cmd_sys_w != 9'sd0);
assign rotate_active_angle_sys_o = angle_cmd_clamped_w;
assign active_match_w        = ~angle_cdc_busy_sys_w;
assign rotate_status_sys_o   = {5'd0, rotate_expected_active_sys_w, 1'b1, ROTATE_STATE_LIVE,
                                1'b0, 1'b0, 1'b1, active_match_w,
                                1'b1, (angle_cmd_sys_w != 9'sd0), 1'b1};
assign rotate_debug0_sys_o   = {2'd0, angle_cdc_busy_sys_w, 4'd0, angle_cmd_sys_w};
assign rotate_debug1_sys_o   = {7'd0, angle_cmd_sys_w};

cdc_word_toggle #(
    .WIDTH(16)
) u_rotate_angle_cdc (
    .src_clk_i        (sys_clk),
    .src_rst_n_i      (sys_rst_n),
    .src_data_i       (rotate_angle_deg_sys_i),
    .src_send_toggle_i(rotate_cfg_toggle_sys_i),
    .src_busy_o       (angle_cdc_busy_sys_w),
    .dst_clk_i        (pix_clk),
    .dst_rst_n_i      (pix_rst_n),
    .dst_data_o       (angle_cmd_pix_word_w),
    .dst_pulse_o      (angle_cmd_valid_pix_w)
);

rotate_bram_preview #(
    .SRC_FRAME_W(SRC_FRAME_W),
    .SRC_FRAME_H(SRC_FRAME_H),
    .PREVIEW_W  (PREVIEW_W),
    .PREVIEW_H  (PREVIEW_H)
) u_rotate_bram_preview (
    .wr_clk_i        (pix_clk),
    .wr_rst_n_i      (pix_rst_n),
    .wr_valid_i      (wr_valid_i),
    .wr_x_i          (wr_x_i),
    .wr_y_i          (wr_y_i),
    .wr_data_i       (wr_rgb565_i),
    .rd_clk_i        (pix_clk),
    .rd_rst_n_i      (pix_rst_n),
    .enable_i        (active_angle_pix_r != 9'sd0),
    .angle_deg_i     (active_angle_pix_r),
    .video_hs_i      (video_hs_i),
    .video_vs_i      (video_vs_i),
    .video_de_i      (video_de_i),
    .video_rgb_i     (video_rgb_i),
    .pixel_x_i       (pixel_x_i),
    .pixel_y_i       (pixel_y_i),
    .video_hs_o      (video_hs_o),
    .video_vs_o      (video_vs_o),
    .video_de_o      (video_de_o),
    .video_rgb_o     (video_rgb_o),
    .preview_active_o(preview_active_o)
);

always @(posedge pix_clk or negedge pix_rst_n) begin
    if (!pix_rst_n) begin
        pending_valid_pix_r  <= 1'b0;
        pending_angle_pix_r  <= 9'sd0;
        active_angle_pix_r   <= 9'sd0;
    end else begin
        if (frame_start_pix_w && pending_valid_pix_r) begin
            active_angle_pix_r <= pending_angle_pix_r;
        end

        case ({frame_start_pix_w && pending_valid_pix_r, angle_cmd_valid_pix_w})
            2'b01: begin
                pending_valid_pix_r <= 1'b1;
                pending_angle_pix_r <= angle_cmd_pix_w;
            end
            2'b10: begin
                pending_valid_pix_r <= 1'b0;
            end
            2'b11: begin
                pending_valid_pix_r <= 1'b1;
                pending_angle_pix_r <= angle_cmd_pix_w;
            end
            default: begin
            end
        endcase
    end
end

endmodule
