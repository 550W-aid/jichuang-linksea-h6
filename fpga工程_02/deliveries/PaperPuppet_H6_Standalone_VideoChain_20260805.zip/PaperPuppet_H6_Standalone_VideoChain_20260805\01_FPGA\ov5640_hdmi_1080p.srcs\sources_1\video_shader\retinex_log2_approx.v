// Module Function:
//   Combinational fixed-point base-2 logarithm approximation for 8-bit luma.
module retinex_log2_approx #(
    parameter IN_WIDTH  = 9,
    parameter FRAC_BITS = 8,
    parameter OUT_WIDTH = 12
) (
    din,
    dout
);

    function integer clog2;
        input integer value;
        integer tmp;
        begin
            tmp = value - 1;
            clog2 = 0;
            while (tmp > 0) begin
                tmp = tmp >> 1;
                clog2 = clog2 + 1;
            end
        end
    endfunction

    localparam MSB_BITS = clog2(IN_WIDTH);

    input  [IN_WIDTH-1:0] din;
    output [OUT_WIDTH-1:0] dout;
    reg    [OUT_WIDTH-1:0] dout;
    reg [MSB_BITS-1:0] msb_idx;
    reg [IN_WIDTH-1:0] base_value;
    reg [IN_WIDTH+FRAC_BITS-1:0] frac_value;
    reg [IN_WIDTH+FRAC_BITS-1:0] frac_shifted;
    reg [OUT_WIDTH-1:0] int_term;

    function [MSB_BITS-1:0] find_msb_idx;
        input [IN_WIDTH-1:0] value;
        integer idx;
        begin
            find_msb_idx = {MSB_BITS{1'b0}};
            for (idx = 0; idx < IN_WIDTH; idx = idx + 1) begin
                if (value[idx]) begin
                    find_msb_idx = idx[MSB_BITS-1:0];
                end
            end
        end
    endfunction

    always @* begin
        msb_idx    = {MSB_BITS{1'b0}};
        base_value = {IN_WIDTH{1'b0}};
        frac_value = {(IN_WIDTH+FRAC_BITS){1'b0}};
        frac_shifted = {(IN_WIDTH+FRAC_BITS){1'b0}};
        int_term   = {OUT_WIDTH{1'b0}};
        dout       = {OUT_WIDTH{1'b0}};

        if (din > 1) begin
            msb_idx    = find_msb_idx(din);
            base_value = {{(IN_WIDTH-1){1'b0}}, 1'b1} << msb_idx;
            frac_value = (din - base_value) << FRAC_BITS;
            frac_shifted = frac_value >> msb_idx;
            int_term   = msb_idx;
            dout       = (int_term << FRAC_BITS) + frac_shifted[OUT_WIDTH-1:0];
        end
    end

endmodule
