// ============================================================================
// Module Function:
//   Clock-domain synchronizer for Ethernet receive debug events.
// ============================================================================
module eth_rx_event_sync(
    input  wire        eth_clk,
    input  wire        eth_rst_n,
    input  wire        sys_clk,
    input  wire        sys_rst_n,
    input  wire        rec_en_i,
    input  wire [15:0] rec_byte_num_i,
    output reg         rx_done_pulse_sys_o,
    output reg  [15:0] rx_byte_num_sys_o
);

    reg        rec_en_d_eth;
    reg        rx_done_toggle_eth;
    reg [15:0] rx_byte_num_hold_eth;

    (* preserve, altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg        rx_done_meta_sys;
    (* preserve, altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg        rx_done_sync_sys;
    (* preserve, altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg        rx_done_sync_d_sys;
    (* preserve, altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg [15:0] rx_byte_num_meta_sys;
    (* preserve, altera_attribute = "-name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg [15:0] rx_byte_num_sync_sys;

    always @(posedge eth_clk or negedge eth_rst_n) begin
        if (!eth_rst_n) begin
            rec_en_d_eth         <= 1'b0;
            rx_done_toggle_eth   <= 1'b0;
            rx_byte_num_hold_eth <= 16'd0;
        end else begin
            rec_en_d_eth <= rec_en_i;
            if (rec_en_d_eth && !rec_en_i) begin
                rx_byte_num_hold_eth <= rec_byte_num_i;
                rx_done_toggle_eth   <= ~rx_done_toggle_eth;
            end
        end
    end

    always @(posedge sys_clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            rx_done_meta_sys     <= 1'b0;
            rx_done_sync_sys     <= 1'b0;
            rx_done_sync_d_sys   <= 1'b0;
            rx_byte_num_meta_sys <= 16'd0;
            rx_byte_num_sync_sys <= 16'd0;
            rx_done_pulse_sys_o  <= 1'b0;
            rx_byte_num_sys_o    <= 16'd0;
        end else begin
            rx_done_meta_sys     <= rx_done_toggle_eth;
            rx_done_sync_sys     <= rx_done_meta_sys;
            rx_done_sync_d_sys   <= rx_done_sync_sys;
            rx_byte_num_meta_sys <= rx_byte_num_hold_eth;
            rx_byte_num_sync_sys <= rx_byte_num_meta_sys;

            rx_done_pulse_sys_o <= rx_done_sync_sys ^ rx_done_sync_d_sys;
            if (rx_done_sync_sys ^ rx_done_sync_d_sys) begin
                rx_byte_num_sys_o <= rx_byte_num_sync_sys;
            end
        end
    end

endmodule
