"""Gate post-route GMII setup/hold using the native eLinx timing database."""

from __future__ import annotations

import argparse
import re
import sqlite3
import sys
from pathlib import Path


PERIOD_PS = 8_000.0
PHY_SETUP_PS = 2_000.0
PHY_HOLD_PS = 500.0
MIN_RELEASE_MARGIN_PS = 250.0

EXPECTED_OUTPUTS = ["eth_tx_ctl"] + [f"eth_txd[{bit}]" for bit in range(8)]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", required=True, type=Path)
    phase = parser.add_mutually_exclusive_group(required=True)
    phase.add_argument("--phase-ps", type=float)
    phase.add_argument("--pll-source", type=Path)
    return parser.parse_args()


def read_phase_ps(path: Path) -> float:
    text = path.read_text(encoding="utf-8")
    match = re.search(r'altpll_component\.clk1_phase_shift\s*=\s*"([0-9]+)"', text)
    if not match:
        raise RuntimeError(f"could not read clk1 phase shift from {path}")
    phase_ps = float(match.group(1))
    if not 0.0 <= phase_ps < PERIOD_PS:
        raise RuntimeError(f"clk1 phase must be within one GMII period: {phase_ps} ps")
    return phase_ps


def load_output_paths(connection: sqlite3.Connection, table: str) -> dict[str, sqlite3.Row]:
    rows = connection.execute(
        f"""
        SELECT from_cell_name, to_cell_name, total_delay, clock_skew
        FROM {table}
        WHERE to_cell_name LIKE 'eth_tx%~I/padio'
        """
    ).fetchall()
    result: dict[str, sqlite3.Row] = {}
    for row in rows:
        endpoint = str(row["to_cell_name"]).removesuffix("~I/padio")
        if endpoint not in EXPECTED_OUTPUTS:
            continue
        expected_source = "eth_tx_ctl_out_r" if endpoint == "eth_tx_ctl" else "eth_txd_out_r"
        if expected_source not in str(row["from_cell_name"]):
            raise RuntimeError(f"{endpoint} is not driven by {expected_source}: {row['from_cell_name']}")
        if endpoint in result:
            raise RuntimeError(f"duplicate timing path for {endpoint} in {table}")
        result[endpoint] = row
    missing = sorted(set(EXPECTED_OUTPUTS) - set(result))
    if missing:
        raise RuntimeError(f"missing GMII paths in {table}: {', '.join(missing)}")
    return result


def load_gtx_path(connection: sqlite3.Connection, table: str) -> sqlite3.Row:
    rows = connection.execute(
        f"""
        SELECT from_cell_name, to_cell_name, total_delay
        FROM {table}
        WHERE from_cell_name = 'sys_clk~I/padio'
          AND to_cell_name = 'GTX_CLK~I/padio'
        """
    ).fetchall()
    if len(rows) != 1:
        raise RuntimeError(f"expected one sys_clk-to-GTX_CLK path in {table}, found {len(rows)}")
    return rows[0]


def main() -> int:
    args = parse_args()
    if not args.db.is_file():
        raise RuntimeError(f"timing database was not found: {args.db}")

    phase_ps = args.phase_ps if args.phase_ps is not None else read_phase_ps(args.pll_source)
    if not 0.0 <= phase_ps < PERIOD_PS:
        raise RuntimeError(f"GMII phase must be within one period: {phase_ps} ps")
    connection = sqlite3.connect(args.db)
    connection.row_factory = sqlite3.Row
    try:
        longest = load_output_paths(connection, "elinx_unconstrain_longest_path_report")
        shortest = load_output_paths(connection, "elinx_unconstrain_shortest_path_report")
        gtx_longest = load_gtx_path(connection, "elinx_unconstrain_longest_path_report")
        gtx_shortest = load_gtx_path(connection, "elinx_unconstrain_shortest_path_report")
    finally:
        connection.close()

    max_arrivals: dict[str, float] = {}
    min_arrivals: dict[str, float] = {}
    for endpoint in EXPECTED_OUTPUTS:
        max_row = longest[endpoint]
        min_row = shortest[endpoint]
        launch_max_ps = -float(max_row["clock_skew"]) * 1_000.0
        launch_min_ps = -float(min_row["clock_skew"]) * 1_000.0
        max_arrivals[endpoint] = launch_max_ps + float(max_row["total_delay"])
        min_arrivals[endpoint] = launch_min_ps + float(min_row["total_delay"])

    latest_data_ps = max(max_arrivals.values())
    earliest_data_ps = min(min_arrivals.values())
    gtx_early_ps = float(gtx_shortest["total_delay"])
    gtx_late_ps = float(gtx_longest["total_delay"])

    candidates = []
    for edge_index in range(3):
        sample_early_ps = phase_ps + gtx_early_ps + edge_index * PERIOD_PS
        sample_late_ps = phase_ps + gtx_late_ps + edge_index * PERIOD_PS
        setup_slack_ps = sample_early_ps - latest_data_ps - PHY_SETUP_PS
        hold_slack_ps = PERIOD_PS + earliest_data_ps - sample_late_ps - PHY_HOLD_PS
        candidates.append((min(setup_slack_ps, hold_slack_ps), edge_index, setup_slack_ps, hold_slack_ps))

    _, edge_index, setup_slack_ps, hold_slack_ps = max(candidates)
    print(
        "GMII timing: "
        f"phase={phase_ps / 1000.0:.3f} ns edge={edge_index} "
        f"GTX={gtx_early_ps / 1000.0:.3f}/{gtx_late_ps / 1000.0:.3f} ns "
        f"data={earliest_data_ps / 1000.0:.3f}/{latest_data_ps / 1000.0:.3f} ns "
        f"setup_slack={setup_slack_ps / 1000.0:.3f} ns "
        f"hold_slack={hold_slack_ps / 1000.0:.3f} ns"
    )
    for endpoint in EXPECTED_OUTPUTS:
        print(
            f"  {endpoint}: arrival_min={min_arrivals[endpoint] / 1000.0:.3f} ns "
            f"arrival_max={max_arrivals[endpoint] / 1000.0:.3f} ns"
        )

    failures = []
    if setup_slack_ps < MIN_RELEASE_MARGIN_PS:
        failures.append(f"setup slack {setup_slack_ps / 1000.0:.3f} ns")
    if hold_slack_ps < MIN_RELEASE_MARGIN_PS:
        failures.append(f"hold slack {hold_slack_ps / 1000.0:.3f} ns")
    if failures:
        print(
            "GMII release gate failed: " + ", ".join(failures) +
            f"; required margin is {MIN_RELEASE_MARGIN_PS / 1000.0:.3f} ns",
            file=sys.stderr,
        )
        return 1
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RuntimeError, sqlite3.Error) as exc:
        print(f"GMII timing audit error: {exc}", file=sys.stderr)
        raise SystemExit(2)
