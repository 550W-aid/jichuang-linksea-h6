// ============================================================================
// Module Function:
//   Ethernet protocol controller combining ARP, ICMP, UDP, and RGMII datapaths.
// ============================================================================
module eth_ctrl(
    input              clk,
    input              rst_n,

    input              arp_req,
    output reg         arp_tx_en,
    output             arp_tx_type,
    input              arp_tx_done,
    input              arp_gmii_tx_en,
    input      [7:0]   arp_gmii_txd,

    input              icmp_tx_start_en,
    input              icmp_tx_done,
    input              icmp_gmii_tx_en,
    input      [7:0]   icmp_gmii_txd,
    input              icmp_rec_en,
    input      [7:0]   icmp_rec_data,
    input              icmp_tx_req,
    output     [7:0]   icmp_tx_data,

    input              udp_tx_start_en,
    input              udp_tx_done,
    input              udp_gmii_tx_en,
    input      [7:0]   udp_gmii_txd,
    input      [7:0]   udp_rec_data,
    input              udp_rec_en,
    input              udp_tx_req,
    output     [7:0]   udp_tx_data,

    input      [7:0]   tx_data,
    output             tx_req,
    output reg         rec_en,
    output reg [7:0]   rec_data,

    output reg         gmii_tx_en,
    output reg [7:0]   gmii_txd
);

reg [1:0]  protocol_sw;
reg        icmp_tx_busy;
reg        udp_tx_busy;
reg        icmp_tx_req_d0;
reg        udp_tx_req_d0;
reg [3:0]  arp_tx_en_cnt;

assign arp_tx_type = 1'b1;
assign tx_req      = udp_tx_req ? 1'b1 : icmp_tx_req;
assign icmp_tx_data = icmp_tx_req_d0 ? tx_data : 8'd0;
assign udp_tx_data  = udp_tx_req_d0  ? tx_data : 8'd0;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        icmp_tx_req_d0 <= 1'b0;
        udp_tx_req_d0  <= 1'b0;
    end
    else begin
        icmp_tx_req_d0 <= icmp_tx_req;
        udp_tx_req_d0  <= udp_tx_req;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        rec_en   <= 1'b0;
        rec_data <= 8'd0;
    end
    else if(icmp_rec_en) begin
        rec_en   <= icmp_rec_en;
        rec_data <= icmp_rec_data;
    end
    else if(udp_rec_en) begin
        rec_en   <= udp_rec_en;
        rec_data <= udp_rec_data;
    end
    else begin
        rec_en   <= 1'b0;
        rec_data <= rec_data;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        gmii_tx_en <= 1'b0;
        gmii_txd   <= 8'd0;
    end
    else begin
        case(protocol_sw)
            2'b00: begin
                gmii_tx_en <= arp_gmii_tx_en;
                gmii_txd   <= arp_gmii_txd;
            end
            2'b01: begin
                gmii_tx_en <= udp_gmii_tx_en;
                gmii_txd   <= udp_gmii_txd;
            end
            2'b10: begin
                gmii_tx_en <= icmp_gmii_tx_en;
                gmii_txd   <= icmp_gmii_txd;
            end
            default: begin
                gmii_tx_en <= 1'b0;
                gmii_txd   <= 8'd0;
            end
        endcase
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        icmp_tx_busy <= 1'b0;
    else if(icmp_tx_start_en || icmp_tx_req || icmp_gmii_tx_en)
        icmp_tx_busy <= 1'b1;
    else if(icmp_tx_done)
        icmp_tx_busy <= 1'b0;
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n)
        udp_tx_busy <= 1'b0;
    else if(udp_tx_start_en || udp_tx_req || udp_gmii_tx_en)
        udp_tx_busy <= 1'b1;
    else if(udp_tx_done)
        udp_tx_busy <= 1'b0;
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        protocol_sw   <= 2'b00;
        arp_tx_en     <= 1'b0;
        arp_tx_en_cnt <= 4'd0;
    end
    else begin
        if(arp_tx_en_cnt != 4'd0)
            arp_tx_en_cnt <= arp_tx_en_cnt - 4'd1;

        arp_tx_en <= 1'b0;
        if(arp_tx_en_cnt != 4'd0) begin
            protocol_sw <= 2'b00;
            arp_tx_en   <= 1'b1;
        end
        else if(udp_tx_busy || udp_tx_start_en || udp_tx_req || udp_gmii_tx_en) begin
            protocol_sw <= 2'b01;
        end
        else if(icmp_tx_busy || icmp_tx_start_en || icmp_tx_req || icmp_gmii_tx_en) begin
            protocol_sw <= 2'b10;
        end
        else if(arp_req && (udp_tx_busy == 1'b0) && (icmp_tx_busy == 1'b0)) begin
            protocol_sw   <= 2'b00;
            arp_tx_en     <= 1'b1;
            arp_tx_en_cnt <= 4'd10;
        end
    end
end

endmodule
