set dir [file normalize [file join [file dirname [file normalize [info script]]] ".."]]
cd "D:/eLinx3.0/bin/shell/bin"
set prj ov5640_hdmi_1080p
set topEntity TOP1
set seriesName "eHiChip6"
set deviceName "EQ6HL130"
set packageName "CSG484_H"
set synthName synth_1
set ImpleName imple_1
source "D:/eLinx3.0/bin/shell/bin/run_route_codex_fast.tcl"
run_route $dir $prj $topEntity $seriesName $deviceName $packageName $synthName $ImpleName
exit 0
