`timescale 1ns / 1ps

module virtual_grab_rgb565_stream_adapter #(
    parameter integer IMAGE_WIDTH  = 1280,
    parameter integer IMAGE_HEIGHT = 720,
    parameter integer X_WIDTH      = 12,
    parameter integer Y_WIDTH      = 12
) (
    input  wire                 clk,
    input  wire                 rst_n,
    input  wire                 frame_start,
    input  wire                 pixel_valid_i,
    input  wire [15:0]          pixel_rgb565_i,
    output reg                  sof,
    output reg                  eof,
    output reg                  pixel_valid_o,
    output reg  [X_WIDTH-1:0]   pixel_x,
    output reg  [Y_WIDTH-1:0]   pixel_y,
    output reg  [7:0]           pixel_r,
    output reg  [7:0]           pixel_g,
    output reg  [7:0]           pixel_b
);

    reg [X_WIDTH-1:0] x_count_r;
    reg [Y_WIDTH-1:0] y_count_r;
    reg               frame_seen_r;
    reg               frame_has_pixels_r;
    reg               frame_committed_r;

    wire last_x_w = (x_count_r == (IMAGE_WIDTH - 1));
    wire last_y_w = (y_count_r == (IMAGE_HEIGHT - 1));
    wire last_pixel_w = pixel_valid_i && last_x_w && last_y_w;
    wire boundary_commit_w = frame_start && frame_seen_r && frame_has_pixels_r && !frame_committed_r;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sof <= 1'b0;
            eof <= 1'b0;
            pixel_valid_o <= 1'b0;
            pixel_x <= {X_WIDTH{1'b0}};
            pixel_y <= {Y_WIDTH{1'b0}};
            pixel_r <= 8'd0;
            pixel_g <= 8'd0;
            pixel_b <= 8'd0;
            x_count_r <= {X_WIDTH{1'b0}};
            y_count_r <= {Y_WIDTH{1'b0}};
            frame_seen_r <= 1'b0;
            frame_has_pixels_r <= 1'b0;
            frame_committed_r <= 1'b0;
        end else begin
            sof <= frame_start;
            eof <= last_pixel_w | boundary_commit_w;
            pixel_valid_o <= pixel_valid_i;

            if (frame_start) begin
                x_count_r <= {X_WIDTH{1'b0}};
                y_count_r <= {Y_WIDTH{1'b0}};
                frame_seen_r <= 1'b1;
                frame_has_pixels_r <= 1'b0;
                frame_committed_r <= 1'b0;
            end

            if (pixel_valid_i) begin
                frame_has_pixels_r <= 1'b1;
                pixel_x <= x_count_r;
                pixel_y <= y_count_r;
                pixel_r <= {pixel_rgb565_i[15:11], pixel_rgb565_i[15:13]};
                pixel_g <= {pixel_rgb565_i[10:5], pixel_rgb565_i[10:9]};
                pixel_b <= {pixel_rgb565_i[4:0], pixel_rgb565_i[4:2]};

                if (last_x_w) begin
                    x_count_r <= {X_WIDTH{1'b0}};
                    if (last_y_w) begin
                        y_count_r <= {Y_WIDTH{1'b0}};
                        frame_committed_r <= 1'b1;
                    end else begin
                        y_count_r <= y_count_r + {{(Y_WIDTH-1){1'b0}}, 1'b1};
                    end
                end else begin
                    x_count_r <= x_count_r + {{(X_WIDTH-1){1'b0}}, 1'b1};
                end
            end
        end
    end

endmodule
