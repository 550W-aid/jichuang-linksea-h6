// Module Function:
//   Pipelined Retinex-style RGB888 low-light enhancement core. The RGB data,
//   valid flag, SOF, and EOL sidebands remain aligned through every stage.
//   Spatial detail is optional; the stripe-safe default derives lift only
//   from the current pixel's aligned original luma.
module retinex_core #(
    parameter IMAGE_WIDTH    = 1280,
    parameter DETAIL_GAIN    = 4,
    parameter LIFT_GAIN      = 1,
    parameter TARGET_LUMA    = 64,
    parameter SCALE_MAX_Q8   = 16'd384,
    parameter EDGE_GAIN      = 0,
    parameter SPATIAL_DETAIL_EN = 0,
    parameter SHADOW_TARGET  = 192,
    parameter SHADOW_LOW_KNEE = 64,
    parameter LOG_FRAC_BITS  = 8
) (
    clk,
    rst_n,
    lowlight_level_i,
    in_valid,
    in_sof,
    in_eol,
    in_r,
    in_g,
    in_b,
    out_valid,
    out_sof,
    out_eol,
    out_r,
    out_g,
    out_b
);

    localparam LUMA_MUL_LATENCY = 2;
    localparam LOG_LATENCY      = 1;
    localparam GAIN_DIV_LATENCY = 3;
    localparam GAIN_DATA_ALIGN_LATENCY = GAIN_DIV_LATENCY;

    input clk;
    input rst_n;
    input [7:0] lowlight_level_i;
    input in_valid;
    input in_sof;
    input in_eol;
    input [7:0] in_r;
    input [7:0] in_g;
    input [7:0] in_b;
    output out_valid;
    output out_sof;
    output out_eol;
    output [7:0] out_r;
    output [7:0] out_g;
    output [7:0] out_b;

    function [7:0] clamp_u8_signed;
        input signed [31:0] value;
        begin
            if (value < 0) begin
                clamp_u8_signed = 8'd0;
            end else if (value > 32'sd255) begin
                clamp_u8_signed = 8'd255;
            end else begin
                clamp_u8_signed = value[7:0];
            end
        end
    endfunction

    reg        s0_valid;
    reg        s0_sof;
    reg        s0_eol;
    reg [7:0]  s0_r;
    reg [7:0]  s0_g;
    reg [7:0]  s0_b;
    reg [7:0]  s0_lowlight_level;

    wire        luma_valid;
    wire [15:0] luma_sum;
    wire [7:0]  luma_u8;
    wire        luma_align_valid_w;
    wire        luma_align_sof_w;
    wire        luma_align_eol_w;
    wire [31:0] luma_align_payload_w;
    wire [7:0]  luma_align_r_w;
    wire [7:0]  luma_align_g_w;
    wire [7:0]  luma_align_b_w;
    wire [7:0]  luma_align_lowlight_w;

    reg        s1_sof;
    reg        s1_eol;
    reg [7:0]  s1_r;
    reg [7:0]  s1_g;
    reg [7:0]  s1_b;
    reg [7:0]  s1_luma;
    reg [7:0]  s1_lowlight_level;

    wire       blur_valid;
    wire [7:0] blur_luma;

    reg        s2_valid;
    reg        s2_sof;
    reg        s2_eol;
    reg [7:0]  s2_r;
    reg [7:0]  s2_g;
    reg [7:0]  s2_b;
    reg [7:0]  s2_luma;
    reg [7:0]  s2_blur;
    reg [7:0]  s2_lowlight_level;

    wire [11:0] log_luma;
    wire [11:0] log_blur;
    wire        log_align_valid_w;
    wire        log_align_sof_w;
    wire        log_align_eol_w;
    wire [47:0] log_align_payload_w;
    wire [7:0]  log_align_r_w;
    wire [7:0]  log_align_g_w;
    wire [7:0]  log_align_b_w;
    wire [7:0]  log_align_luma_w;
    wire [7:0]  log_align_blur_w;
    wire [7:0]  log_align_lowlight_w;
    reg signed [12:0] detail_term_comb;
    reg signed [15:0] illum_lift_comb;
    reg signed [31:0] enhanced_accum_comb;
    reg [7:0]  luma_enh_comb;

    reg        s3_valid;
    reg        s3_sof;
    reg        s3_eol;
    reg [7:0]  s3_r;
    reg [7:0]  s3_g;
    reg [7:0]  s3_b;
    reg [7:0]  s3_luma_orig;
    reg [7:0]  s3_luma_enh;
    reg [7:0]  s3_blur;
    reg [7:0]  s3_lowlight_level;

    wire        div_valid;
    wire [15:0] scale_q8_raw;
    wire        div_align_valid_w;
    wire        div_align_sof_w;
    wire        div_align_eol_w;
    wire [47:0] div_align_payload_w;
    wire [7:0]  div_align_r_w;
    wire [7:0]  div_align_g_w;
    wire [7:0]  div_align_b_w;
    wire [7:0]  div_align_luma_orig_w;
    wire [7:0]  div_align_blur_w;
    wire [7:0]  div_align_lowlight_w;

    wire       out_valid_w;
    wire       out_sof_w;
    wire       out_eol_w;
    wire [7:0] out_r_w;
    wire [7:0] out_g_w;
    wire [7:0] out_b_w;

    assign luma_u8 = luma_sum[15:8];

    assign luma_align_r_w         = luma_align_payload_w[31:24];
    assign luma_align_g_w         = luma_align_payload_w[23:16];
    assign luma_align_b_w         = luma_align_payload_w[15:8];
    assign luma_align_lowlight_w  = luma_align_payload_w[7:0];

    assign log_align_r_w          = log_align_payload_w[47:40];
    assign log_align_g_w          = log_align_payload_w[39:32];
    assign log_align_b_w          = log_align_payload_w[31:24];
    assign log_align_luma_w       = log_align_payload_w[23:16];
    assign log_align_blur_w       = log_align_payload_w[15:8];
    assign log_align_lowlight_w   = log_align_payload_w[7:0];

    assign div_align_r_w          = div_align_payload_w[47:40];
    assign div_align_g_w          = div_align_payload_w[39:32];
    assign div_align_b_w          = div_align_payload_w[31:24];
    assign div_align_luma_orig_w  = div_align_payload_w[23:16];
    assign div_align_blur_w       = div_align_payload_w[15:8];
    assign div_align_lowlight_w   = div_align_payload_w[7:0];

    always @(posedge clk) begin
        if (!rst_n) begin
            s0_valid <= 1'b0;
            s0_sof   <= 1'b0;
            s0_eol   <= 1'b0;
            s0_r     <= 8'd0;
            s0_g     <= 8'd0;
            s0_b     <= 8'd0;
            s0_lowlight_level <= 8'd0;
        end else begin
            s0_valid <= in_valid;
            s0_sof   <= in_sof;
            s0_eol   <= in_eol;
            if (in_valid) begin
                s0_r               <= in_r;
                s0_g               <= in_g;
                s0_b               <= in_b;
                s0_lowlight_level  <= lowlight_level_i;
            end
        end
    end

    retinex_weighted_sum3_u8 #(
        .MUL_LATENCY(LUMA_MUL_LATENCY)
    ) u_luma_multadd (
        .clk      (clk),
        .rst_n    (rst_n),
        .in_valid (s0_valid),
        .in_a     (s0_r),
        .in_b     (s0_g),
        .in_c     (s0_b),
        .coef_a   (8'd77),
        .coef_b   (8'd150),
        .coef_c   (8'd29),
        .out_valid(luma_valid),
        .out_sum  (luma_sum)
    );

    retinex_stream_delay #(
        .DATA_WIDTH(32),
        .LATENCY   (LUMA_MUL_LATENCY)
    ) u_luma_align (
        .clk      (clk),
        .rst_n    (rst_n),
        .in_valid (s0_valid),
        .in_sof   (s0_sof),
        .in_eol   (s0_eol),
        .in_data  ({s0_r, s0_g, s0_b, s0_lowlight_level}),
        .out_valid(luma_align_valid_w),
        .out_sof  (luma_align_sof_w),
        .out_eol  (luma_align_eol_w),
        .out_data (luma_align_payload_w)
    );

    always @(posedge clk) begin
        if (!rst_n) begin
            s1_sof            <= 1'b0;
            s1_eol            <= 1'b0;
            s1_r              <= 8'd0;
            s1_g              <= 8'd0;
            s1_b              <= 8'd0;
            s1_luma           <= 8'd0;
            s1_lowlight_level <= 8'd0;
        end else begin
            s1_sof <= luma_align_sof_w;
            s1_eol <= luma_align_eol_w;
            if (luma_align_valid_w) begin
                s1_r              <= luma_align_r_w;
                s1_g              <= luma_align_g_w;
                s1_b              <= luma_align_b_w;
                s1_luma           <= luma_u8;
                s1_lowlight_level <= luma_align_lowlight_w;
            end
        end
    end

    retinex_gaussian_5x5 #(
        .IMAGE_WIDTH(IMAGE_WIDTH)
    ) u_gaussian_5x5 (
        .clk      (clk),
        .rst_n    (rst_n),
        .in_valid (luma_align_valid_w),
        .in_sof   (luma_align_sof_w),
        .in_eol   (luma_align_eol_w),
        .in_pixel (luma_u8),
        .out_valid(blur_valid),
        .out_blur (blur_luma)
    );

    always @(posedge clk) begin
        if (!rst_n) begin
            s2_valid           <= 1'b0;
            s2_sof             <= 1'b0;
            s2_eol             <= 1'b0;
            s2_r               <= 8'd0;
            s2_g               <= 8'd0;
            s2_b               <= 8'd0;
            s2_luma            <= 8'd0;
            s2_blur            <= 8'd0;
            s2_lowlight_level  <= 8'd0;
        end else begin
            s2_valid <= blur_valid;
            s2_sof   <= s1_sof;
            s2_eol   <= s1_eol;
            if (blur_valid) begin
                s2_r              <= s1_r;
                s2_g              <= s1_g;
                s2_b              <= s1_b;
                s2_luma           <= s1_luma;
                s2_blur           <= blur_luma;
                s2_lowlight_level <= s1_lowlight_level;
            end
        end
    end

    retinex_log_wrapper #(
        .IN_WIDTH (9),
        .FRAC_BITS(LOG_FRAC_BITS),
        .OUT_WIDTH(12)
    ) u_log_luma (
        .clk (clk),
        .din ({1'b0, s2_luma} + 9'd1),
        .dout(log_luma)
    );

    retinex_log_wrapper #(
        .IN_WIDTH (9),
        .FRAC_BITS(LOG_FRAC_BITS),
        .OUT_WIDTH(12)
    ) u_log_blur (
        .clk (clk),
        .din ({1'b0, s2_blur} + 9'd1),
        .dout(log_blur)
    );

    retinex_stream_delay #(
        .DATA_WIDTH(48),
        .LATENCY   (LOG_LATENCY)
    ) u_log_align (
        .clk      (clk),
        .rst_n    (rst_n),
        .in_valid (s2_valid),
        .in_sof   (s2_sof),
        .in_eol   (s2_eol),
        .in_data  ({s2_r, s2_g, s2_b, s2_luma, s2_blur, s2_lowlight_level}),
        .out_valid(log_align_valid_w),
        .out_sof  (log_align_sof_w),
        .out_eol  (log_align_eol_w),
        .out_data (log_align_payload_w)
    );

    always @* begin
        if (SPATIAL_DETAIL_EN != 0) begin
            detail_term_comb = $signed({1'b0, log_luma}) -
                               $signed({1'b0, log_blur});
        end else begin
            detail_term_comb = 13'sd0;
        end
        if ((SPATIAL_DETAIL_EN != 0) &&
            (log_align_blur_w < TARGET_LUMA[7:0])) begin
            illum_lift_comb = $signed({1'b0, TARGET_LUMA[7:0]}) -
                              $signed({1'b0, log_align_blur_w});
        end else if ((SPATIAL_DETAIL_EN == 0) &&
                     (log_align_luma_w < TARGET_LUMA[7:0])) begin
            illum_lift_comb = $signed({1'b0, TARGET_LUMA[7:0]}) -
                              $signed({1'b0, log_align_luma_w});
        end else begin
            illum_lift_comb = 16'sd0;
        end
        enhanced_accum_comb = $signed({1'b0, log_align_luma_w, 8'd0})
                            + (detail_term_comb * DETAIL_GAIN)
                            + (illum_lift_comb * (LIFT_GAIN <<< 8));
        luma_enh_comb = clamp_u8_signed(enhanced_accum_comb >>> 8);
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            s3_valid           <= 1'b0;
            s3_sof             <= 1'b0;
            s3_eol             <= 1'b0;
            s3_r               <= 8'd0;
            s3_g               <= 8'd0;
            s3_b               <= 8'd0;
            s3_luma_orig       <= 8'd0;
            s3_luma_enh        <= 8'd0;
            s3_blur            <= 8'd0;
            s3_lowlight_level  <= 8'd0;
        end else begin
            s3_valid <= log_align_valid_w;
            s3_sof   <= log_align_sof_w;
            s3_eol   <= log_align_eol_w;
            if (log_align_valid_w) begin
                s3_r              <= log_align_r_w;
                s3_g              <= log_align_g_w;
                s3_b              <= log_align_b_w;
                s3_luma_orig      <= log_align_luma_w;
                s3_luma_enh       <= luma_enh_comb;
                s3_blur           <= log_align_blur_w;
                s3_lowlight_level <= log_align_lowlight_w;
            end
        end
    end

    retinex_gain_divider #(
        .IP_LATENCY(GAIN_DIV_LATENCY)
    ) u_gain_divider (
        .clk        (clk),
        .rst_n      (rst_n),
        .in_valid   (s3_valid),
        .numerator  ({s3_luma_enh, 8'd0}),
        .denominator(s3_luma_orig),
        .out_valid  (div_valid),
        .quotient_q8(scale_q8_raw)
    );

    retinex_stream_delay #(
        .DATA_WIDTH(48),
        .LATENCY   (GAIN_DATA_ALIGN_LATENCY)
    ) u_div_align (
        .clk      (clk),
        .rst_n    (rst_n),
        .in_valid (s3_valid),
        .in_sof   (s3_sof),
        .in_eol   (s3_eol),
        .in_data  ({s3_r, s3_g, s3_b, s3_luma_orig, s3_blur, s3_lowlight_level}),
        .out_valid(div_align_valid_w),
        .out_sof  (div_align_sof_w),
        .out_eol  (div_align_eol_w),
        .out_data (div_align_payload_w)
    );

    retinex_output_stage #(
        .SCALE_MAX_Q8(SCALE_MAX_Q8),
        .EDGE_GAIN   (EDGE_GAIN),
        .SHADOW_TARGET(SHADOW_TARGET),
        .SHADOW_LOW_KNEE(SHADOW_LOW_KNEE)
    ) u_output_stage (
        .clk              (clk),
        .rst_n            (rst_n),
        .in_valid         (div_valid),
        .in_sof           (div_align_sof_w),
        .in_eol           (div_align_eol_w),
        .in_r             (div_align_r_w),
        .in_g             (div_align_g_w),
        .in_b             (div_align_b_w),
        .in_luma_orig     (div_align_luma_orig_w),
        .in_blur          (div_align_blur_w),
        .in_lowlight_level(div_align_lowlight_w),
        .scale_q8_i       (scale_q8_raw),
        .out_valid        (out_valid_w),
        .out_sof          (out_sof_w),
        .out_eol          (out_eol_w),
        .out_r            (out_r_w),
        .out_g            (out_g_w),
        .out_b            (out_b_w)
    );

    assign out_valid = out_valid_w;
    assign out_sof   = out_sof_w;
    assign out_eol   = out_eol_w;
    assign out_r     = out_r_w;
    assign out_g     = out_g_w;
    assign out_b     = out_b_w;

endmodule
