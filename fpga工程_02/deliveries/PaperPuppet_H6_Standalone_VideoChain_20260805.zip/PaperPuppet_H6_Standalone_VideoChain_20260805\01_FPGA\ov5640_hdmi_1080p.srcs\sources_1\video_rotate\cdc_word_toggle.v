// ============================================================================
// Module Function:
//   Bit-serial word CDC helper for slow control words using request/acknowledge toggles.
// ============================================================================
`timescale 1ns / 1ps

module cdc_word_toggle #(
    parameter integer WIDTH = 16
) (
    input  wire             src_clk_i,
    input  wire             src_rst_n_i,
    input  wire [WIDTH-1:0] src_data_i,
    input  wire             src_send_toggle_i,
    output wire             src_busy_o,

    input  wire             dst_clk_i,
    input  wire             dst_rst_n_i,
    output wire [WIDTH-1:0] dst_data_o,
    output wire             dst_pulse_o
);

function integer clog2_fn;
    input integer value;
    integer tmp;
    begin
        tmp = value - 1;
        for (clog2_fn = 0; tmp > 0; clog2_fn = clog2_fn + 1) begin
            tmp = tmp >> 1;
        end
    end
endfunction

localparam integer INDEX_W = (WIDTH <= 2) ? 1 : clog2_fn(WIDTH);
localparam [INDEX_W-1:0] LAST_INDEX = WIDTH - 1;

reg             src_toggle_d_r;
reg [WIDTH-1:0] src_pending_data_r;
reg             src_pending_valid_r;
reg [WIDTH-1:0] src_shift_data_r;
reg [INDEX_W-1:0] src_bit_index_r;
reg             src_bit_r;
reg             src_req_toggle_r;
reg             src_busy_r;
reg             src_ack_meta_r;
reg             src_ack_sync_r;
reg             src_ack_seen_r;

reg             dst_req_meta_r;
reg             dst_req_sync_r;
reg             dst_req_seen_r;
reg             dst_bit_meta_r;
reg             dst_bit_sync_r;
reg             dst_ack_toggle_r;
reg [WIDTH-1:0] dst_shift_r;
reg [WIDTH-1:0] dst_data_r;
reg [INDEX_W-1:0] dst_bit_index_r;
reg             dst_capture_pending_r;
reg             dst_pulse_r;

wire            src_new_cmd_w;
wire [INDEX_W-1:0] src_next_bit_index_w;
wire [WIDTH-1:0] src_shift_next_w;
wire [WIDTH-1:0] dst_shift_with_bit_w;

function [WIDTH-1:0] shift_zero_msb_fn;
    input [WIDTH-1:0] word_in;
    integer i;
    begin
        shift_zero_msb_fn[WIDTH-1] = 1'b0;
        for (i = 0; i < WIDTH-1; i = i + 1) begin
            shift_zero_msb_fn[i] = word_in[i+1];
        end
    end
endfunction

function [WIDTH-1:0] shift_insert_msb_fn;
    input [WIDTH-1:0] word_in;
    input bit_value;
    integer i;
    begin
        shift_insert_msb_fn[WIDTH-1] = bit_value;
        for (i = 0; i < WIDTH-1; i = i + 1) begin
            shift_insert_msb_fn[i] = word_in[i+1];
        end
    end
endfunction

assign src_new_cmd_w        = src_send_toggle_i ^ src_toggle_d_r;
assign src_next_bit_index_w = src_bit_index_r + {{(INDEX_W-1){1'b0}}, 1'b1};
assign src_shift_next_w     = shift_zero_msb_fn(src_shift_data_r);
assign dst_shift_with_bit_w = shift_insert_msb_fn(dst_shift_r, dst_bit_sync_r);
assign src_busy_o           = src_busy_r | src_pending_valid_r;
assign dst_data_o           = dst_data_r;
assign dst_pulse_o          = dst_pulse_r;

always @(posedge src_clk_i or negedge src_rst_n_i) begin
    if (!src_rst_n_i) begin
        src_toggle_d_r      <= 1'b0;
        src_pending_data_r  <= {WIDTH{1'b0}};
        src_pending_valid_r <= 1'b0;
        src_shift_data_r    <= {WIDTH{1'b0}};
        src_bit_index_r     <= {INDEX_W{1'b0}};
        src_bit_r           <= 1'b0;
        src_req_toggle_r    <= 1'b0;
        src_busy_r          <= 1'b0;
        src_ack_meta_r      <= 1'b0;
        src_ack_sync_r      <= 1'b0;
        src_ack_seen_r      <= 1'b0;
    end else begin
        src_toggle_d_r <= src_send_toggle_i;
        src_ack_meta_r <= dst_ack_toggle_r;
        src_ack_sync_r <= src_ack_meta_r;

        if (!src_busy_r) begin
            if (src_pending_valid_r) begin
                src_shift_data_r    <= shift_zero_msb_fn(src_pending_data_r);
                src_pending_valid_r <= 1'b0;
                src_bit_index_r     <= {INDEX_W{1'b0}};
                src_bit_r           <= src_pending_data_r[0];
                src_req_toggle_r    <= ~src_req_toggle_r;
                src_busy_r          <= 1'b1;
            end
        end else if (src_ack_sync_r != src_ack_seen_r) begin
            src_ack_seen_r <= src_ack_sync_r;
            if (src_bit_index_r == LAST_INDEX) begin
                src_busy_r <= 1'b0;
            end else begin
                src_bit_index_r  <= src_next_bit_index_w;
                src_shift_data_r <= src_shift_next_w;
                src_bit_r        <= src_shift_data_r[0];
                src_req_toggle_r <= ~src_req_toggle_r;
            end
        end

        if (src_new_cmd_w) begin
            src_pending_data_r  <= src_data_i;
            src_pending_valid_r <= 1'b1;
        end
    end
end

always @(posedge dst_clk_i or negedge dst_rst_n_i) begin
    if (!dst_rst_n_i) begin
        dst_req_meta_r         <= 1'b0;
        dst_req_sync_r         <= 1'b0;
        dst_req_seen_r         <= 1'b0;
        dst_bit_meta_r         <= 1'b0;
        dst_bit_sync_r         <= 1'b0;
        dst_ack_toggle_r       <= 1'b0;
        dst_shift_r            <= {WIDTH{1'b0}};
        dst_data_r             <= {WIDTH{1'b0}};
        dst_bit_index_r        <= {INDEX_W{1'b0}};
        dst_capture_pending_r  <= 1'b0;
        dst_pulse_r            <= 1'b0;
    end else begin
        dst_req_meta_r <= src_req_toggle_r;
        dst_req_sync_r <= dst_req_meta_r;
        dst_bit_meta_r <= src_bit_r;
        dst_bit_sync_r <= dst_bit_meta_r;
        dst_pulse_r    <= 1'b0;

        if (dst_capture_pending_r) begin
            dst_shift_r <= dst_shift_with_bit_w;
            if (dst_bit_index_r == LAST_INDEX) begin
                dst_data_r      <= dst_shift_with_bit_w;
                dst_pulse_r     <= 1'b1;
                dst_bit_index_r <= {INDEX_W{1'b0}};
            end else begin
                dst_bit_index_r <= dst_bit_index_r + {{(INDEX_W-1){1'b0}}, 1'b1};
            end
            dst_ack_toggle_r      <= ~dst_ack_toggle_r;
            dst_capture_pending_r <= 1'b0;
        end else if (dst_req_sync_r != dst_req_seen_r) begin
            dst_req_seen_r        <= dst_req_sync_r;
            dst_capture_pending_r <= 1'b1;
        end
    end
end

endmodule
