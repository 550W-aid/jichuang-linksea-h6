// Module Function:
//   Compatibility wrapper for the original New_shader RGB888 pixel-stream
//   interface. It exposes the Retinex core without any board-level signals.
module retinex_pipeline_top #(
    parameter IMAGE_WIDTH = 1280,
    parameter [7:0] LOWLIGHT_LEVEL = 8'hff
) (
    input  wire       pix_clk,
    input  wire       rst_n,
    input  wire       eth_pixel_valid,
    input  wire       eth_frame_sof,
    input  wire       eth_line_eol,
    input  wire [7:0] eth_pixel_r,
    input  wire [7:0] eth_pixel_g,
    input  wire [7:0] eth_pixel_b,
    output wire       disp_pixel_valid,
    output wire       disp_frame_sof,
    output wire       disp_line_eol,
    output wire [7:0] disp_pixel_r,
    output wire [7:0] disp_pixel_g,
    output wire [7:0] disp_pixel_b
);
    retinex_core #(
        .IMAGE_WIDTH(IMAGE_WIDTH)
    ) retinex_core_inst (
        .clk             (pix_clk),
        .rst_n           (rst_n),
        .lowlight_level_i(LOWLIGHT_LEVEL),
        .in_valid        (eth_pixel_valid),
        .in_sof          (eth_frame_sof),
        .in_eol          (eth_line_eol),
        .in_r            (eth_pixel_r),
        .in_g            (eth_pixel_g),
        .in_b            (eth_pixel_b),
        .out_valid       (disp_pixel_valid),
        .out_sof         (disp_frame_sof),
        .out_eol         (disp_line_eol),
        .out_r           (disp_pixel_r),
        .out_g           (disp_pixel_g),
        .out_b           (disp_pixel_b)
    );
endmodule
