// ============================================================================
// Module Function:
//   Bypass display shell kept as a compatibility hook for rotate-path insertion experiments.
// ============================================================================
`timescale 1ns / 1ps

module display_rotate_insert_shell (
    input  wire        fpga_colorbar_test_en_i,
    input  wire        new480_stream_en_i,
    input  wire        half_line_triple_buffer_en_i,
    input  wire        selected_rd_empty_i,
    input  wire        frame_ready_sync_hdmi_i,
    input  wire        video_hs_i,
    input  wire        video_vs_i,
    input  wire        video_de_i,
    input  wire [23:0] video_rgb888_i,
    input  wire [23:0] fpga_colorbar_rgb_i,
    output wire        video_hs_o,
    output wire        video_vs_o,
    output wire        video_de_o,
    output wire [23:0] video_rgb_o,
    output wire        rotate_datapath_inserted_o
);

// Keep the proven display shell in bypass while a lightweight probe is
// inserted in the real pixel-data path inside TOP1. The shell still forwards
// the known-good timing and RGB path unchanged.
assign video_hs_o = video_hs_i;
assign video_vs_o = video_vs_i;
assign video_de_o = (fpga_colorbar_test_en_i || new480_stream_en_i) ? video_de_i :
                    (frame_ready_sync_hdmi_i & video_de_i);
assign video_rgb_o = video_de_o ?
                     ((fpga_colorbar_test_en_i ||
                       (new480_stream_en_i && selected_rd_empty_i) ||
                       (half_line_triple_buffer_en_i && !frame_ready_sync_hdmi_i)) ?
                      fpga_colorbar_rgb_i : video_rgb888_i) :
                     24'd0;
assign rotate_datapath_inserted_o = 1'b1;

endmodule
