// ============================================================================
// Module Function:
//   UDP packet transmit formatter.
// ============================================================================
module udp_tx(
    input                clk,
    input                rst_n,
    input                tx_start_en,
    input      [7:0]     tx_data,
    input      [15:0]    tx_byte_num,
    input      [47:0]    des_mac,
    input      [31:0]    des_ip,
    input      [31:0]    crc_data,
    input      [7:0]     crc_next,
    output reg           tx_done,
    output reg           tx_req,
    output reg           gmii_tx_en,
    output reg [7:0]     gmii_txd,
    output reg           crc_en,
    output reg           crc_clr
);

parameter BOARD_MAC = 48'h00_11_22_33_44_55;
parameter BOARD_IP  = {8'd192, 8'd168, 8'd1, 8'd123};
parameter DES_MAC   = 48'hff_ff_ff_ff_ff_ff;
parameter DES_IP    = {8'd192, 8'd168, 8'd1, 8'd102};

localparam ETH_TYPE     = 16'h0800;
localparam MIN_DATA_NUM = 16'd18;

localparam ST_IDLE      = 3'd0;
localparam ST_CHECKSUM  = 3'd1;
localparam ST_PREAMBLE  = 3'd2;
localparam ST_ETH_HEAD  = 3'd3;
localparam ST_IP_UDP    = 3'd4;
localparam ST_PAYLOAD   = 3'd5;
localparam ST_CRC       = 3'd6;
localparam [19:0] IP_CHECKSUM_BASE =
    20'h04500 + 20'h04000 + 20'h04011 + BOARD_IP[31:16] + BOARD_IP[15:0];

reg [2:0]   state;
reg         start_en_d0;
reg         start_en_d1;
reg         start_en_d2;
reg [3:0]   checksum_step;
reg [1:0]   crc_cnt;
reg [15:0]  frame_total_len;
reg [15:0]  frame_udp_len;
reg [15:0]  frame_bytes_left;
reg [15:0]  payload_bytes_left;
reg [15:0]  frame_ip_id;
reg [15:0]  ip_id_seed;
reg [15:0]  frame_checksum;
reg [47:0]  frame_target_mac;
reg [31:0]  frame_target_ip;
reg [19:0]  checksum_acc;
reg [16:0]  checksum_fold;
reg [63:0]  preamble_shift;
reg [111:0] eth_head_shift;
reg [223:0] ip_udp_shift;
reg [3:0]   preamble_bytes_left;
reg [3:0]   eth_bytes_left;
reg [5:0]   ip_udp_bytes_left;

wire        pos_start_en;
wire [15:0] next_total_len;
wire [15:0] next_udp_len;
wire [15:0] next_frame_bytes;
wire [47:0] next_target_mac;
wire [31:0] next_target_ip;

assign pos_start_en     = (~start_en_d2) & start_en_d1;
assign next_total_len   = tx_byte_num + 16'd28;
assign next_udp_len     = tx_byte_num + 16'd8;
assign next_frame_bytes = (tx_byte_num >= MIN_DATA_NUM) ? tx_byte_num : MIN_DATA_NUM;
assign next_target_mac  = (des_mac != 48'd0) ? des_mac : DES_MAC;
assign next_target_ip   = (des_ip  != 32'd0) ? des_ip  : DES_IP;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        start_en_d0 <= 1'b0;
        start_en_d1 <= 1'b0;
        start_en_d2 <= 1'b0;
    end
    else begin
        start_en_d0 <= tx_start_en;
        start_en_d1 <= start_en_d0;
        start_en_d2 <= start_en_d1;
    end
end

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        state              <= ST_IDLE;
        checksum_step      <= 4'd0;
        crc_cnt            <= 2'd0;
        frame_total_len    <= 16'd0;
        frame_udp_len      <= 16'd0;
        frame_bytes_left   <= 16'd0;
        payload_bytes_left <= 16'd0;
        frame_ip_id        <= 16'd0;
        ip_id_seed         <= 16'd0;
        frame_checksum     <= 16'd0;
        frame_target_mac   <= DES_MAC;
        frame_target_ip    <= DES_IP;
        checksum_acc       <= 20'd0;
        checksum_fold      <= 17'd0;
        preamble_shift     <= 64'd0;
        eth_head_shift     <= 112'd0;
        ip_udp_shift       <= 224'd0;
        preamble_bytes_left<= 4'd0;
        eth_bytes_left     <= 4'd0;
        ip_udp_bytes_left  <= 6'd0;
        tx_done            <= 1'b0;
        tx_req             <= 1'b0;
        gmii_tx_en         <= 1'b0;
        gmii_txd           <= 8'd0;
        crc_en             <= 1'b0;
        crc_clr            <= 1'b0;
    end
    else begin
        tx_done    <= 1'b0;
        tx_req     <= 1'b0;
        gmii_tx_en <= 1'b0;
        gmii_txd   <= 8'd0;
        crc_en     <= 1'b0;
        crc_clr    <= 1'b0;

        case(state)
            ST_IDLE: begin
                if(pos_start_en) begin
                    frame_total_len    <= next_total_len;
                    frame_udp_len      <= next_udp_len;
                    frame_bytes_left   <= next_frame_bytes;
                    payload_bytes_left <= tx_byte_num;
                    frame_target_mac   <= next_target_mac;
                    frame_target_ip    <= next_target_ip;
                    frame_ip_id        <= ip_id_seed + 16'd1;
                    ip_id_seed         <= ip_id_seed + 16'd1;
                    checksum_acc       <= 20'd0;
                    checksum_fold      <= 17'd0;
                    checksum_step      <= 4'd0;
                    state              <= ST_CHECKSUM;
                end
            end

            ST_CHECKSUM: begin
                case(checksum_step)
                    4'd0: begin
                        checksum_acc  <= IP_CHECKSUM_BASE;
                        checksum_step <= 4'd1;
                    end
                    4'd1: begin
                        checksum_acc  <= checksum_acc + frame_total_len;
                        checksum_step <= 4'd2;
                    end
                    4'd2: begin
                        checksum_acc  <= checksum_acc + frame_ip_id;
                        checksum_step <= 4'd3;
                    end
                    4'd3: begin
                        checksum_acc  <= checksum_acc + frame_target_ip[31:16];
                        checksum_step <= 4'd4;
                    end
                    4'd4: begin
                        checksum_acc  <= checksum_acc + frame_target_ip[15:0];
                        checksum_step <= 4'd5;
                    end
                    4'd5: begin
                        checksum_fold <= checksum_acc[15:0] + {13'd0, checksum_acc[19:16]};
                        checksum_step <= 4'd6;
                    end
                    4'd6: begin
                        checksum_fold <= checksum_fold[15:0] + {16'd0, checksum_fold[16]};
                        checksum_step <= 4'd7;
                    end
                    4'd7: begin
                        frame_checksum <= ~(checksum_fold[15:0] + checksum_fold[16]);
                        checksum_step <= 4'd8;
                    end
                    4'd8: begin
                        preamble_shift <= 64'h55_55_55_55_55_55_55_d5;
                        eth_head_shift <= {frame_target_mac, BOARD_MAC, ETH_TYPE};
                        ip_udp_shift   <= {
                            8'h45, 8'h00, frame_total_len,
                            frame_ip_id,
                            16'h4000,
                            8'h40, 8'd17, frame_checksum,
                            BOARD_IP,
                            frame_target_ip,
                            16'd1234, 16'd1234,
                            frame_udp_len, 16'h0000
                        };
                        preamble_bytes_left <= 4'd8;
                        eth_bytes_left      <= 4'd14;
                        ip_udp_bytes_left   <= 6'd28;
                        state               <= ST_PREAMBLE;
                    end
                endcase
            end

            ST_PREAMBLE: begin
                gmii_tx_en <= 1'b1;
                gmii_txd   <= preamble_shift[63:56];
                if(preamble_bytes_left > 4'd1) begin
                    preamble_bytes_left <= preamble_bytes_left - 4'd1;
                    preamble_shift      <= {preamble_shift[55:0], 8'd0};
                end
                else begin
                    preamble_bytes_left <= 4'd0;
                    state               <= ST_ETH_HEAD;
                end
            end

            ST_ETH_HEAD: begin
                gmii_tx_en <= 1'b1;
                crc_en     <= 1'b1;
                gmii_txd   <= eth_head_shift[111:104];
                if(eth_bytes_left > 4'd1) begin
                    eth_bytes_left <= eth_bytes_left - 4'd1;
                    eth_head_shift <= {eth_head_shift[103:0], 8'd0};
                end
                else begin
                    eth_bytes_left <= 4'd0;
                    state          <= ST_IP_UDP;
                end
            end

            ST_IP_UDP: begin
                gmii_tx_en <= 1'b1;
                crc_en     <= 1'b1;
                gmii_txd   <= ip_udp_shift[223:216];
                if((ip_udp_bytes_left == 6'd1) && (payload_bytes_left != 16'd0))
                    tx_req <= 1'b1;

                if(ip_udp_bytes_left > 6'd1) begin
                    ip_udp_bytes_left <= ip_udp_bytes_left - 6'd1;
                    ip_udp_shift      <= {ip_udp_shift[215:0], 8'd0};
                end
                else begin
                    ip_udp_bytes_left <= 6'd0;
                    state             <= ST_PAYLOAD;
                end
            end

            ST_PAYLOAD: begin
                gmii_tx_en <= 1'b1;
                crc_en     <= 1'b1;
                gmii_txd   <= (payload_bytes_left != 16'd0) ? tx_data : 8'd0;

                if(frame_bytes_left > 16'd1) begin
                    frame_bytes_left <= frame_bytes_left - 16'd1;
                end
                else begin
                    frame_bytes_left <= 16'd0;
                    crc_cnt          <= 2'd0;
                    state            <= ST_CRC;
                end

                if(payload_bytes_left > 16'd1) begin
                    payload_bytes_left <= payload_bytes_left - 16'd1;
                    tx_req             <= 1'b1;
                end
                else if(payload_bytes_left == 16'd1) begin
                    payload_bytes_left <= 16'd0;
                end
            end

            ST_CRC: begin
                gmii_tx_en <= 1'b1;
                case(crc_cnt)
                    2'd0: gmii_txd <= {
                        ~crc_next[0], ~crc_next[1], ~crc_next[2], ~crc_next[3],
                        ~crc_next[4], ~crc_next[5], ~crc_next[6], ~crc_next[7]
                    };
                    2'd1: gmii_txd <= {
                        ~crc_data[16], ~crc_data[17], ~crc_data[18], ~crc_data[19],
                        ~crc_data[20], ~crc_data[21], ~crc_data[22], ~crc_data[23]
                    };
                    2'd2: gmii_txd <= {
                        ~crc_data[8], ~crc_data[9], ~crc_data[10], ~crc_data[11],
                        ~crc_data[12], ~crc_data[13], ~crc_data[14], ~crc_data[15]
                    };
                    default: gmii_txd <= {
                        ~crc_data[0], ~crc_data[1], ~crc_data[2], ~crc_data[3],
                        ~crc_data[4], ~crc_data[5], ~crc_data[6], ~crc_data[7]
                    };
                endcase

                if(crc_cnt == 2'd3) begin
                    tx_done  <= 1'b1;
                    crc_clr  <= 1'b1;
                    crc_cnt  <= 2'd0;
                    state    <= ST_IDLE;
                end
                else begin
                    crc_cnt <= crc_cnt + 2'd1;
                end
            end

            default: begin
                state <= ST_IDLE;
            end
        endcase
    end
end

endmodule
