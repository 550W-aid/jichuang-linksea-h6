// ============================================================================
// Module Function:
//   UDP packet receive parser.
// ============================================================================
module udp_rx(
    input                clk,
    input                rst_n,
    input                gmii_rx_dv,
    input      [7:0]     gmii_rxd,
    output reg           rec_pkt_done,
    output reg           rec_en,
    output reg [7:0]     rec_data,
    output reg [15:0]    rec_byte_num
);

parameter BOARD_MAC = 48'h00_11_22_33_44_55;
parameter BOARD_IP  = {8'd192, 8'd168, 8'd1, 8'd10};

localparam [2:0] ST_IDLE     = 3'd0;
localparam [2:0] ST_PREAMBLE = 3'd1;
localparam [2:0] ST_HEADER   = 3'd2;
localparam [2:0] ST_DECIDE   = 3'd3;
localparam [2:0] ST_PAYLOAD  = 3'd4;
localparam [2:0] ST_DROP     = 3'd5;

localparam [15:0] ETH_TYPE_IP       = 16'h0800;
localparam [7:0]  IP_PROTO_UDP      = 8'd17;
localparam [15:0] MAX_UDP_TOTAL_LEN = 16'd2055;
localparam integer PAYLOAD_CNT_W    = 11;

(* preserve, altera_attribute = "-name DONT_MERGE_REGISTER ON; -name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg       gmii_rx_dv_d;
(* preserve, altera_attribute = "-name DONT_MERGE_REGISTER ON; -name AUTO_SHIFT_REGISTER_RECOGNITION OFF" *) reg [7:0] gmii_rxd_d;

reg [2:0]  state;
reg [2:0]  preamble_left;
reg [5:0]  header_idx;

reg [5:0]  dst_mac_board_bits;
reg [5:0]  dst_mac_bcast_bits;
reg [15:0] eth_type_bytes;
reg [7:0]  ip_proto_byte;
reg [31:0] ip_dest_word;
reg [7:0]  udp_len_hi;
reg [7:0]  udp_len_lo;

reg        mac_match_board;
reg        mac_match_bcast;
reg        eth_type_ok;
reg        ip_proto_udp_ok;
reg        ip_dest_ok;
reg [15:0] udp_total_len;
reg        udp_len_valid;
reg        udp_len_fit;
reg [PAYLOAD_CNT_W-1:0] payload_len_latched;
reg        frame_accept_latched;
reg        payload_zero_latched;

reg [PAYLOAD_CNT_W-1:0] payload_bytes_left;

always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        gmii_rx_dv_d         <= 1'b0;
        gmii_rxd_d           <= 8'd0;
        state                <= ST_IDLE;
        preamble_left        <= 3'd0;
        header_idx           <= 6'd0;
        dst_mac_board_bits   <= 6'd0;
        dst_mac_bcast_bits   <= 6'd0;
        eth_type_bytes       <= 16'd0;
        ip_proto_byte        <= 8'd0;
        ip_dest_word         <= 32'd0;
        udp_len_hi           <= 8'd0;
        udp_len_lo           <= 8'd0;
        mac_match_board      <= 1'b0;
        mac_match_bcast      <= 1'b0;
        eth_type_ok          <= 1'b0;
        ip_proto_udp_ok      <= 1'b0;
        ip_dest_ok           <= 1'b0;
        udp_total_len        <= 16'd0;
        udp_len_valid        <= 1'b0;
        udp_len_fit          <= 1'b0;
        payload_len_latched  <= {PAYLOAD_CNT_W{1'b0}};
        frame_accept_latched <= 1'b0;
        payload_zero_latched <= 1'b0;
        payload_bytes_left   <= {PAYLOAD_CNT_W{1'b0}};
        rec_pkt_done         <= 1'b0;
        rec_en               <= 1'b0;
        rec_data             <= 8'd0;
        rec_byte_num         <= 16'd0;
    end
    else begin
        gmii_rx_dv_d <= gmii_rx_dv;
        gmii_rxd_d   <= gmii_rxd;

        rec_pkt_done <= 1'b0;
        rec_en       <= 1'b0;

        if(!gmii_rx_dv_d) begin
            state              <= ST_IDLE;
            preamble_left      <= 3'd0;
            header_idx         <= 6'd0;
            payload_bytes_left <= {PAYLOAD_CNT_W{1'b0}};
        end
        else begin
            case(state)
                ST_IDLE: begin
                    if(gmii_rxd_d == 8'hd5) begin
                        state      <= ST_HEADER;
                        header_idx <= 6'd0;
                    end
                end

                ST_PREAMBLE: begin
                    if(gmii_rxd_d == 8'hd5) begin
                        state      <= ST_HEADER;
                        header_idx <= 6'd0;
                    end
                end

                ST_HEADER: begin
                    case(header_idx)
                        6'd0: begin
                            dst_mac_board_bits[5] <= (gmii_rxd_d == BOARD_MAC[47:40]);
                            dst_mac_bcast_bits[5] <= (gmii_rxd_d == 8'hff);
                        end
                        6'd1: begin
                            dst_mac_board_bits[4] <= (gmii_rxd_d == BOARD_MAC[39:32]);
                            dst_mac_bcast_bits[4] <= (gmii_rxd_d == 8'hff);
                        end
                        6'd2: begin
                            dst_mac_board_bits[3] <= (gmii_rxd_d == BOARD_MAC[31:24]);
                            dst_mac_bcast_bits[3] <= (gmii_rxd_d == 8'hff);
                        end
                        6'd3: begin
                            dst_mac_board_bits[2] <= (gmii_rxd_d == BOARD_MAC[23:16]);
                            dst_mac_bcast_bits[2] <= (gmii_rxd_d == 8'hff);
                        end
                        6'd4: begin
                            dst_mac_board_bits[1] <= (gmii_rxd_d == BOARD_MAC[15:8]);
                            dst_mac_bcast_bits[1] <= (gmii_rxd_d == 8'hff);
                        end
                        6'd5: begin
                            dst_mac_board_bits[0] <= (gmii_rxd_d == BOARD_MAC[7:0]);
                            dst_mac_bcast_bits[0] <= (gmii_rxd_d == 8'hff);
                        end
                        6'd12: eth_type_bytes[15:8]  <= gmii_rxd_d;
                        6'd13: eth_type_bytes[7:0]   <= gmii_rxd_d;
                        6'd23: ip_proto_byte         <= gmii_rxd_d;
                        6'd30: ip_dest_word[31:24]   <= gmii_rxd_d;
                        6'd31: ip_dest_word[23:16]   <= gmii_rxd_d;
                        6'd32: ip_dest_word[15:8]    <= gmii_rxd_d;
                        6'd33: ip_dest_word[7:0]     <= gmii_rxd_d;
                        6'd38: udp_len_hi            <= gmii_rxd_d;
                        6'd39: udp_len_lo            <= gmii_rxd_d;
                        6'd40: begin
                            mac_match_board <= &dst_mac_board_bits;
                            mac_match_bcast <= &dst_mac_bcast_bits;
                            eth_type_ok     <= (eth_type_bytes == ETH_TYPE_IP);
                            ip_proto_udp_ok <= (ip_proto_byte == IP_PROTO_UDP);
                            ip_dest_ok      <= (ip_dest_word[31:8] == BOARD_IP[31:8]) &&
                                               ((ip_dest_word[7:0] == BOARD_IP[7:0]) || (ip_dest_word[7:0] == 8'hff));
                            udp_total_len   <= {udp_len_hi, udp_len_lo};
                            udp_len_valid   <= ({udp_len_hi, udp_len_lo} >= 16'd8);
                            udp_len_fit     <= ({udp_len_hi, udp_len_lo} <= MAX_UDP_TOTAL_LEN);
                            if(({udp_len_hi, udp_len_lo} >= 16'd8) &&
                               ({udp_len_hi, udp_len_lo} <= MAX_UDP_TOTAL_LEN)) begin
                                payload_len_latched <= ({udp_len_hi, udp_len_lo} - 16'd8);
                            end
                            else begin
                                payload_len_latched <= {PAYLOAD_CNT_W{1'b0}};
                            end
                        end
                        6'd41: begin
                            frame_accept_latched <= (mac_match_board || mac_match_bcast) &&
                                                    eth_type_ok &&
                                                    ip_proto_udp_ok &&
                                                    ip_dest_ok &&
                                                    udp_len_valid &&
                                                    udp_len_fit;
                            payload_zero_latched <= (payload_len_latched == {PAYLOAD_CNT_W{1'b0}});
                            state                <= ST_DECIDE;
                        end
                        default: begin
                        end
                    endcase

                    if(state == ST_HEADER)
                        header_idx <= header_idx + 6'd1;
                end

                ST_DECIDE: begin
                    if(frame_accept_latched) begin
                        if(payload_zero_latched) begin
                            rec_pkt_done <= 1'b1;
                            rec_byte_num <= 16'd0;
                            state        <= ST_DROP;
                        end
                        else begin
                            rec_byte_num <= {{(16-PAYLOAD_CNT_W){1'b0}}, payload_len_latched};
                            rec_en   <= 1'b1;
                            rec_data <= gmii_rxd_d;
                            if(payload_len_latched == 11'd1) begin
                                payload_bytes_left <= 11'd0;
                                rec_pkt_done       <= 1'b1;
                                state              <= ST_DROP;
                            end
                            else begin
                                payload_bytes_left <= payload_len_latched - 11'd1;
                                state              <= ST_PAYLOAD;
                            end
                        end
                    end
                    else begin
                        state <= ST_DROP;
                    end
                end

                ST_PAYLOAD: begin
                    rec_en   <= 1'b1;
                    rec_data <= gmii_rxd_d;
                    if(payload_bytes_left == 11'd1) begin
                        payload_bytes_left <= 11'd0;
                        rec_pkt_done       <= 1'b1;
                        state              <= ST_DROP;
                    end
                    else begin
                        payload_bytes_left <= payload_bytes_left - 11'd1;
                    end
                end

                default: begin
                    state <= ST_DROP;
                end
            endcase
        end
    end
end

endmodule
