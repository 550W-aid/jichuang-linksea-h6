proc run_route {projectDir projectName topEntity seriesName deviceName packageName synthName ImpleName} {
#用 Notepad++ 打开脚本文件-->编码-->(第二项) 以 UTF-8 无 BOM 格式编码-->保存,确保格式编码是第二项
#UDM
set_global_assignment -name TOP_LEVEL_ENTITY $topEntity
set_global_assignment -name DESIGN_PATH $projectDir
set_global_assignment -name PROJECT_NAME $projectName
set_global_assignment -name IMPLE_NAME $ImpleName
set vecname  $projectName
set vecdir $projectDir
set veclog4cpp $projectDir/$projectName.runs/$ImpleName

regsub -all {\\\\} $vecdir {/} vecdir
regsub -all {\\\\} $vecdir {/} resultdir

setlogfile $veclog4cpp/log4cpp.property $projectDir/$projectName.runs/$ImpleName/$projectName.edi

#若包含IP,则需将IP.v列出
#set_global_assignment -name VERILOG_FILE pll.v
set_global_assignment -name DEVICE_SERIES $seriesName
set_global_assignment -name DEVICE_NAME $deviceName
set_global_assignment -name PACKAGE_NAME $packageName
set_global_assignment -name PACKAGE CCGA
set_global_assignment -name PINS 717

proc InitialAssignment {} {
	set_global_assignment -name PackAlgName VPack 
	set_global_assignment -name GainHashSize 16 
	set_global_assignment -name PackAlgSeedPolicy PINS_SEED_POLICY
	set_global_assignment -name PackAlgGainPolicy SHAREDPINS_GAIN_POLICY
	set_global_assignment -name VPACK_ALPHA 50 
		
	#set_global_assignment -name ChipName        ER2C3000G
	set_global_assignment -name CLB_MaxNumLEs   10
	set_global_assignment -name CLB_MaxNumAclrs 2
	set_global_assignment -name CLB_MaxNumEnas  2
	
	set_global_assignment -name ALPHA 0.5
	#set_global_assignment -name BBFACTOR  8
	set_global_assignment -name FIRST_ITER_PRESFAC  3.0
	set_global_assignment -name HEAP_SPREAD_BETA 0.9
	set_global_assignment -name HEAP_CONVERGE 0.8
	set_global_assignment -name INIT_SA 0
	set_global_assignment -name INNERNUM 10
	set_global_assignment -name TIMING_TRADEOFF_LAMBDA 0.9
	set_global_assignment -name HEAP_STALL_MAX 20
	set_global_assignment -name PRES_FAC_MULT 1.3
	set_global_assignment -name ASTAR_FAC  1.05
	set_global_assignment -name ACC_MULT 1.3
	set_global_assignment -name REFINE_RLIM 3
	set_global_assignment -name HEAP_WEIGHT_ADD 1
	
	set_global_assignment -name DETAILED_PLACER_ALGORITHM 2
	# Keep timing-driven placement and hold repair, but avoid the unstable,
	# non-converging post-route setup repair loop used by eLinx 3.0.
	set_global_assignment -name ENABLE_FIX_HOLD_VIOLATE 1
	set_global_assignment -name FIX_SETUP_SLACK 0
	set_global_assignment -name MAX_ROUTER_ITERATION  150
	

	#set_global_assignment -name MAX_CHAN_USE  20
}

load_pb_ver $projectDir/$projectName.runs/$synthName/$vecname.ver.pb
print_version_information
if {[catch {check_pb_version} err_msg]} {
	exit
}

if {[catch {udm_load_checkpoint $projectDir/$projectName.runs/$synthName/$projectName\_$seriesName.ecp} err_msg]} {
	exit
} else {
  set udm_gene 1
}

InitialAssignment 

#ARC
source  ..\\Infrastructure\\psk_intern\\$seriesName\\series_library\\arc_guide.tcl
set_arc_ucm_parameter TILE_DAT_PATH           ..\\Infrastructure\\psk_intern\\$seriesName\\series_library\\tile
set_arc_ucm_parameter STRUCTURE_PATH          ..\\Infrastructure\\psk_intern\\$seriesName\\$deviceName\\$packageName\\structure.dat
set_arc_ucm_parameter TILE_TIMING_DAT_PATH    ..\\Infrastructure\\psk_intern\\$seriesName\\$deviceName\\timing_info.dat

if {[catch {arc_deserialize_device_info} err_msg]||[catch {arc_deserialize_tile_info} err_msg]} {
  set arc_gene_line "$vecname  $vecdir  arc generate Error:$err_msg"
  set arc_gene 0
  puts $arc_gene_line
  exit
} else {
  set arc_gene_line "$vecname  $vecdir  arc generate Success"
  set arc_gene 1
}
puts "arc_gene is $arc_gene"

#PACK#	
set vecname  $projectName
set vecdir $projectDir
regsub -all {\\\\} $vecdir {/} vecdir
regsub -all {\\\\} $vecdir {/} resultdir
	

#PLACE#
if {[catch {read_port_info -f ../Infrastructure/psk_intern/$seriesName/series_library/place_route_guide.xml} err_msg]} {
 set read_file "$vecname $vecdir read_port_info Error:$err_msg"
 set read_xml 0
 puts $read_file
 exit
} else {
 set read_file "$vecname $vecdir read_port_info Success"
 set read_xml 1
}
	
#timing_analysis
#set_global_assignment -name DEVICE EQ6HL150
#set_global_assignment -name VOLTAGE 1.6
#set_global_assignment -name TEMPERATURE 100
#set_global_assignment -name DELAY_TYPE rise_rise
#set_global_assignment -name TIMING_MODEL_BLOCK_TYPE stratix_lcell
#set_global_assignment -name TIMING_MODEL_BLOCK_TYPE stratix_io
#set_global_assignment -name TIMING_MODEL_BLOCK_TYPE stratix_ram_block
#set_global_assignment -name TIMING_MODEL_BLOCK_TYPE stratix_mac_mult
#set_global_assignment -name TIMING_MODEL_BLOCK_TYPE stratix_mac_out
#set_global_assignment -name TIMING_MODEL_BLOCK_TYPE stratix_pll
#set_global_assignment -name TIMING_MODEL_BLOCK_TYPE MUX
#set_global_assignment -name PROCESS_NAME TT
#set_global_assignment -name ENABLE_TIMING_ANALYSIS true
#read_timing_model ..\\Infrastructure\\psk_appendix\\$seriesName\\$deviceName\\timing_model-LL.xml
#save_time_model ..\\Infrastructure\\psk_intern\\$seriesName\\$deviceName\\timing_model-LL.dat

if {$udm_gene==1 && $arc_gene==1 && $read_xml==1} {	
	if {[catch {source $vecdir/$projectName.runs/$ImpleName/$vecname.run.psf} err_msg opts]} {
		puts "constraint file error"
		puts "$opts"
		set fid [open "$projectDir/$projectName.runs/$ImpleName/$projectName.edi" a+]
		puts $fid "\[ERROR\] constraint file error:$err_msg"
		close $fid
		exit
	}
	
	#增加时序延迟值
	if {[catch {load_time_model ..\\Infrastructure\\psk_intern\\$seriesName\\$deviceName\\} err_msg]} {
	   puts "load timing model fail"
	   exit
	}
	#读取drc项
	if {[catch {read_drc_config_file ..\\Infrastructure\\psk_intern\\$seriesName\\$deviceName\\elinx_drc.dat} err_msg]} {
	   puts "read drc model fail"
	   exit
	}
	
	#读取drc项
	if {[catch {excute_check_preplace} err_msg]} {
	   puts "drc fail"
	   exit
	}
	
	
	#read_sdc $vecdir/$vecname.sdc
	create_timing_group 
	puts "serialize pack timing delay "
	serialize_timing_delay $projectDir/$projectName.runs/$ImpleName/$vecname.pack.dly.pb
	if {[catch {try_place -f $projectDir/$projectName.runs/$ImpleName/$vecname.place} err_msg]} {
		set result_line "$vecname $vecdir try_place Error:$err_msg"
	  set result 0
	  exit
	} else {
		set result_line "$vecname $vecdir try_place Success"
		set result 1
	}
	place_clear
	puts "serialize place timing delay "
	serialize_timing_delay $projectDir/$projectName.runs/$ImpleName/$vecname.place.dly.pb
}

#if {[catch {write_udm -f $vecdir/$vecname.udm} err_msg]} {
#exit
#}

#ROUTE#
#if {[catch {arc_getconverted_route_graph} err_msg]} {
#   exit
#}
if {[catch {route_init_arc} err_msg]} {
   exit
}
  
if {$result==1} {
#check the input processor module of placement:arc_processor/ucm_processor/udm_processor
  if {[catch {route_pro_ucm} err_msg]} {
	  set ucm_proc_line "$vecname $vecdir route_pro_ucm Error:$err_msg"
		set ucm_proc 0
		puts $ucm_proc_line
	  exit
	} else {
		set ucm_proc_line "$vecname $vecdir route_pro_ucm Success"
		set ucm_proc 1
	}			
		
	if {[catch {route_pro_udm} err_msg]} {
	  set udm_proc_line "$vecname  $vecdir  route_pro_udm Error:$err_msg"
		set udm_proc 0
		puts $udm_proc_line
	  exit
	} else {
	  set udm_proc_line "$vecname  $vecdir  route_pro_udm Success"
		set udm_proc 1
	}			

		
if {$ucm_proc==1 && $udm_proc==1} {			
  if {[catch {route_channel} err_msg]} {
    set route_channel_line "$vecname $vecdir route_channel Error:$err_msg"
		set route_channel 0
		puts $route_channel_line
	  
	} else {
	  set route_channel_line "$vecname $vecdir route_channel Success"
		set route_channel 1
	}				
}

if {$route_channel==1} {

	write_tiles_nets $projectDir/$projectName.runs/$ImpleName/$vecname.tiles.pb	


#  arc_getconverted_route_graph_info		
  if {[catch {route_internal} err_msg]} {
	  set route_internal_line "$vecname $vecdir route_internal Error:$err_msg"
		set route_internal 0
		puts $route_internal_line
	  exit
	} else {
	  set route_internal_line "$vecname $vecdir route_internal Success"
		set route_internal 1
	}	
	set route_internal 1
	
	set_global_assignment -name PackArchFileName ../Infrastructure/psk_intern/$seriesName/series_library/pack_guide.xml
	bitgen_cfgbram -v	
	puts "serialize route timing delay "
	serialize_timing_delay $projectDir/$projectName.runs/$ImpleName/$vecname.route.dly.pb
	compute_driven_slack
	free_timing_group
	build_timing_graph
	deserialize_timing_delay $projectDir/$projectName.runs/$ImpleName/$vecname.route.dly.pb
	generate_eda_netlist ../Infrastructure/psk_intern/$seriesName/series_library/sdf_guide.xml $projectDir/$projectName.runs/$ImpleName/$vecname.sdo
	puts "serialize timing graph"
	serialize_timing_graph $projectDir/$projectName.runs/$ImpleName/$vecname.tbg.pb
	show_fmax 1
	compute_clock_fmax
	print_timing_report $projectDir/$projectName.runs/$ImpleName/$vecname.tan.rpt
	get_fmax_and_slack $projectDir/$projectName.runs/$ImpleName/$vecname.slack.rpt
	serialize_net_period $projectDir/$projectName.runs/$ImpleName/$vecname.net_period.pb
	write_netlist_node $projectDir/$projectName.runs/$ImpleName/$vecname
	free_timing_graph


# if {$route_internal==1} {

  # if {[catch {route_node_statistic} err_msg]} {
	  # set route_node_statistic "$vecname $vecdir route_node_statistic Error:$err_msg"
		# set route_node_statistic 0
		# puts $route_node_statistic
	  # exit
	# } else {
	  # set route_node_statistic "$vecname $vecdir route_internal Success"
		# set route_node_statistic 1
	# }	
	# set route_node_statistic 1	
# }

if {$route_internal==1} {			
  if {[catch {route_write_results -f $projectDir/$projectName.runs/$ImpleName/$vecname.route} err_msg]} {
    set writeudm_line "$vecname $vecdir write_routing_results -f $resultdir/$vecname.route Error:err_msg"
	  puts $writeudm_line
	  exit
	} else {
	  set writeudm_line "$vecname $vecdir write_routing_results -f $resultdir/$vecname.route Success"
	}
	#arc_getconverted_route_graph_info				
	if {[catch {route_write_results -udm} err_msg]} {
	  set writeudm_line "$vecname $vecdir write_routing_results -udm Error:err_msg"
      puts $writeudm_line
	  exit
	} else {
	  set writeudm_line "$vecname $vecdir write_routing_results -udm Success"
	  puts $writeudm_line
	  if {[catch {write_statistical_info $topEntity -f $projectDir/$projectName.runs/$ImpleName/$projectName\_utilization_placed.rpt} err_msg]} {
		set write_statistical_line "$vecname $vecdir write statistical info Error:$err_msg"
		puts $write_statistical_line
	  }
	}
}
write_route_status_rpt $projectDir/$projectName.runs/$ImpleName/$projectName\_route_status.rpt

route_delete_interface

set route_circuit_line "$vecname $vecdir routing is completed"

#WRITEUDM#
#if {[catch {write_udm -f $vecdir/$vecname.udm} err_msg]} {
#exit
#}
#if {[catch {write_pcf -f $vecdir/$vecname.pcf} err_msg]} {
#exit
#}

#UDM
udm_save_checkpoint $projectDir/$projectName.runs/$ImpleName/$projectName\_$seriesName\_$deviceName.ecp
save_pb_ver $projectDir/$projectName.runs/$ImpleName/$vecname.ver.pb
DoGenerateVOFile $projectDir/$projectName.runs/$ImpleName/$vecname.vo
#udm_write_signal 
#udm_write_cluster
#delete_udm
puts "All was well!"
#exit
}
}
}
