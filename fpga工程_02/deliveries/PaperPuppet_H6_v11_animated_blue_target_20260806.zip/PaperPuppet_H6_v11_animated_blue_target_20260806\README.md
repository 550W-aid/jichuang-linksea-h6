# PaperPuppet H6 v11 animated target candidate

Status: `BUILT_NOT_BOARD_VERIFIED`

This is a standalone FPGA candidate for teammate board review. It does not
merge PaperPuppet into the total project. The camera, SDRAM, and HDMI baseline
remains the board-stable v10A configuration.

## Program image

`01_FPGA/ov5640_hdmi_1080p.runs/imple_1/ov5640_hdmi_1080p.jpsk`

JPSK SHA256:

```text
77BBBF3DDAFC77CC2F2AAAAC0C99D49184D6DFAE1FE2CA0F1E63CEDA0112AA21
```

Bitstream header: `EQ6HL130`, `CSG484_H`, `TOP1`, eLinx `3.0.7`, generated
2026-08-06 10:15:39.

## Feedback addressed

- Based on `dev/person-3` through commit
  `ceaa175561e03eae71a584a960465a82941b844e`.
- Adds idle sway/breathing, left/right motion, jump/fly, and fast horizontal
  sweep/attack poses.
- Adds a state-colored marker at the recognized target center.
- Adds an A4 printable saturated-blue recognition target and preview.

State marker colors:

- Idle: white
- Move left: blue
- Move right: green
- Jump/fly: magenta
- Sweep/attack: orange

## Stable baseline retained

- OV5640 register `3036 = 8'h54`.
- Camera input capture remains on `posedge ov5640_pclk`.
- Default puppet enable remains off until KEY2 is pressed.
- The two-stage HDMI RGB/HS/VS/DE output pipeline is unchanged.

## RTL changes from v10A

- `paper_puppet_h6_overlay.v`: frame-boundary motion classification, pose
  animation, idle sway, and state marker.
- `eth_video_rx_to_sdram.v`: register packet-finalization decisions before
  sequence updates to close the 125 MHz Ethernet timing path. Packet, CRC,
  retry, and duplicate-suppression behavior is unchanged.
- `eth_video_rotate_system.v`: isolate the camera line modulo counter in a
  small PCLK process while preserving reset, frame-start, resume, and line-end
  priorities.
- `tests/tb_paper_puppet_h6_overlay.v`: checks right, jump, and sweep states.

## Local release gates

- ModelSim RTL compile: 0 errors, 0 warnings.
- Overlay simulation: PASS, 0 errors, 0 warnings.
- Ethernet contract tests: 4/4 PASS.
- Quartus compatibility synthesis: 0 errors, 91 warnings.
- H6 pack: complete.
- H6 route: complete, 0 negative paths.
- WNS/WHS/TNS/THS: `0.000 / 0.000 / 0.000 / 0.000 ns`.
- Fmax: sys_clk `66.640 MHz`, ov5640_pclk `93.058 MHz`, eth_rxc
  `134.427 MHz`, HDMI `_clk4` `89.518 MHz`.
- Bitgen: complete.

See `BOARD_TEST_STEPS.md` before programming. Hardware acceptance is pending
because no local H6 board is available.
