# PaperPuppet H6 v11 board test

## Before programming

1. Verify the JPSK SHA256 is
   `77BBBF3DDAFC77CC2F2AAAAC0C99D49184D6DFAE1FE2CA0F1E63CEDA0112AA21`.
2. Confirm the board is `EQ6HL130 / CSG484_H` and the programmer is using
   `01_FPGA/ov5640_hdmi_1080p.runs/imple_1/ov5640_hdmi_1080p.jpsk`.
3. Print `physical_target/PaperPuppet_BlueMarker_A4.svg` at 100 percent scale
   on matte white paper. Do not use fit-to-page scaling.

## Test order

1. Program the JPSK and power-cycle the board if required by the programmer.
2. Do not press KEY2. Observe ordinary camera pass-through continuously for
   at least 60 seconds.
3. Reject immediately for a black screen, lost sync, horizontal stripes,
   tearing, line streaks, displaced pixels, flicker, or intermittent frames.
4. Only after the 60-second baseline passes, press KEY2 once to enable the
   PaperPuppet overlay.
5. Hold the printed blue marker roughly 0.8 to 1.2 m from the camera in even,
   diffuse lighting. Avoid blue clothing or large saturated-blue objects in
   the background.
6. Keep the target still and verify idle sway plus a white center marker.
7. Move it slowly left and right. Verify the pose follows direction and the
   marker becomes blue for left and green for right.
8. Move it upward by at least about 18 image pixels between frames. Verify the
   jump/fly pose and magenta marker.
9. Move it horizontally quickly by at least about 32 image pixels between
   frames. Verify the sweep/attack pose, horizontal staff, and orange marker.
10. Hold each state long enough to confirm it does not corrupt HDMI timing or
    destabilize the camera image.

## Evidence to return

- Board model and programmer/eLinx version.
- Exact JPSK SHA256.
- A continuous video covering the initial 60-second pass-through and KEY2
  transition.
- Short clips or photos of idle, left, right, jump, and sweep states.
- Any failure timestamp and whether it occurs before or after KEY2.

Do not merge this candidate into the total project until these checks pass.
