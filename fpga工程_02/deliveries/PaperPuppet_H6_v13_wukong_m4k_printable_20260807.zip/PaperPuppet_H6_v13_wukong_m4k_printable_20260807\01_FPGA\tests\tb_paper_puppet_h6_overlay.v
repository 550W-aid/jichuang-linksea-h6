`timescale 1ns/1ps

module tb_paper_puppet_h6_overlay;
reg clk = 1'b0;
reg rst_n = 1'b0;
reg key_n = 1'b1;
reg hsync = 1'b0;
reg vsync = 1'b0;
reg de = 1'b0;
reg [11:0] x = 12'd0;
reg [11:0] y = 12'd0;
reg [23:0] rgb = 24'd0;
wire [23:0] rgb_o;
wire hsync_o;
wire vsync_o;
wire de_o;
wire puppet_enable;
wire target_valid;
wire [11:0] target_center_x;
wire [11:0] target_center_y;
integer i;

always #5 clk = ~clk;

paper_puppet_h6_overlay #(
    .DEBOUNCE_COUNT(20'd3),
    .MIN_TARGET_PIXELS(20'd4)
) dut (
    .clk(clk), .rst_n(rst_n), .key_n(key_n), .hsync_i(hsync),
    .vsync_i(vsync), .de_i(de), .x_i(x), .y_i(y), .rgb_i(rgb),
    .rgb_o(rgb_o), .hsync_o(hsync_o), .vsync_o(vsync_o), .de_o(de_o),
    .puppet_enable(puppet_enable),
    .target_valid(target_valid), .target_center_x(target_center_x),
    .target_center_y(target_center_y)
);

task tick;
begin
    @(negedge clk);
    @(posedge clk);
    #1;
end
endtask

task fail;
    input [8*80-1:0] message;
begin
    $display("FAIL: %0s", message);
    $finish;
end
endtask

task commit_target;
    input [11:0] center_x;
    input [11:0] center_y;
    integer p;
begin
    de = 1'b1;
    rgb = 24'h1010F0;
    for (p = 0; p < 4; p = p + 1) begin
        x = center_x - 1'b1 + p[1:0];
        y = center_y - 1'b1 + p[1:0];
        tick;
    end
    vsync = 1'b1;
    de = 1'b0;
    tick;
    vsync = 1'b0;
    tick;
    tick;
end
endtask

initial begin
    repeat (3) tick;
    rst_n = 1'b1;
    rgb = 24'h123456;
    de = 1'b1;
    hsync = 1'b1;
    vsync = 1'b0;
    repeat (2) tick;
    if (rgb_o !== 24'h123456) fail("disabled output is not bit-exact pass-through");
    if ((hsync_o !== 1'b1) || (vsync_o !== 1'b0) || (de_o !== 1'b1))
        fail("RGB and timing outputs are not aligned after fixed latency");

    key_n = 1'b0;
    repeat (7) tick;
    key_n = 1'b1;
    repeat (7) tick;
    if (!puppet_enable) fail("debounced key did not enable puppet mode");

    rgb = 24'hF01010;
    for (i = 0; i < 4; i = i + 1) begin
        x = 12'd98 + i;
        y = 12'd198 + i;
        tick;
    end
    if (target_valid) fail("target committed before frame boundary");
    vsync = 1'b1; de = 1'b0; tick;
    vsync = 1'b0; tick;
    tick;
    if (!target_valid) fail("target was not committed at frame boundary");
    if ((target_center_x != 12'd99) || (target_center_y != 12'd199))
        fail("committed target center is incorrect");

    commit_target(12'd109, 12'd199);
    if (dut.action_state_r != 3'd2) fail("right motion did not select move-right state");
    commit_target(12'd109, 12'd170);
    if (dut.action_state_r != 3'd3) fail("upward motion did not select jump state");
    commit_target(12'd55, 12'd170);
    if (dut.action_state_r != 3'd4) fail("fast horizontal motion did not select sweep state");

    de = 1'b1; rgb = 24'h204060;
    x = 12'd55; y = 12'd170; tick;
    tick;
    if (rgb_o === 24'h204060) fail("enabled overlay did not replace a puppet pixel");

    x = 12'd500; y = 12'd400; tick;
    tick;
    if (rgb_o !== 24'h204060) fail("background pixel was modified");

    $display("PASS: paper puppet overlay RTL checks complete");
    $finish;
end
endmodule
