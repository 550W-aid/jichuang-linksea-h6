# PaperPuppet H6 v12 Wukong artwork

This is an independent H6/eLinx candidate. It is not merged into the total project.

v13 carries forward the v12 160x270, 4-bit transparent indexed Wukong paper-puppet sprite. The sprite uses the supplied gold/red artwork, frame-latched position updates, jump and horizontal sweep motion, and remains disabled by default so camera pass-through is unchanged.

This release also includes `physical_target/PaperPuppet_BlueMarker_A4.svg`, an A4-ready recognition target with a broad dashed cut contour, a single matte royal-blue marker, and neutral decorations that do not pull the detector bounding-box center. Print at 100% and keep the blue region unobstructed.

The H6 packer rejects M512 primitives, so the sprite ROM is explicitly implemented with supported M4K blocks. The artwork and pixel format are unchanged.

Build status: `BUILT_NOT_BOARD_VERIFIED`. The FPGA image is unchanged from v12; this iteration adds the requested printable physical target.

The programming file is `01_FPGA/ov5640_hdmi_1080p.runs/imple_1/ov5640_hdmi_1080p.jpsk`.

Evidence is in `build_logs/`: compatibility synthesis, VQM generation, H6 pack, H6 route, and H6 bitgen logs. Route timing was `WNS=0.000 ns`, `WHS=0.000 ns`, `TNS=0.000 ns`, `THS=0.000 ns`; hardware has not been tested because no board is available.
