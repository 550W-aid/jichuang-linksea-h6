`timescale 1ns/1ps

// HDMI-domain first-stage paper-puppet detector and procedural overlay.
// The disabled path is a combinational, bit-exact RGB pass-through.
module paper_puppet_h6_overlay #(
    parameter [19:0] DEBOUNCE_COUNT = 20'd742500,
    parameter [19:0] MIN_TARGET_PIXELS = 20'd64
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        key_n,
    input  wire        hsync_i,
    input  wire        vsync_i,
    input  wire        de_i,
    input  wire [11:0] x_i,
    input  wire [11:0] y_i,
    input  wire [23:0] rgb_i,
    output wire [23:0] rgb_o,
    output wire        hsync_o,
    output wire        vsync_o,
    output wire        de_o,
    output reg         puppet_enable,
    output reg         target_valid,
    output reg  [11:0] target_center_x,
    output reg  [11:0] target_center_y
);

wire [7:0] red_w   = rgb_i[23:16];
wire [7:0] green_w = rgb_i[15:8];
wire [7:0] blue_w  = rgb_i[7:0];
wire saturated_w = ((red_w > 8'd150) && ({1'b0, red_w} > {1'b0, green_w} + 9'd45) && ({1'b0, red_w} > {1'b0, blue_w} + 9'd45)) ||
                   ((green_w > 8'd150) && ({1'b0, green_w} > {1'b0, red_w} + 9'd45) && ({1'b0, green_w} > {1'b0, blue_w} + 9'd45)) ||
                   ((blue_w > 8'd150) && ({1'b0, blue_w} > {1'b0, red_w} + 9'd45) && ({1'b0, blue_w} > {1'b0, green_w} + 9'd45));

reg key_meta_r;
reg key_sync_r;
reg key_stable_r;
reg [19:0] key_count_r;
(* preserve *) reg detect_saturated_r;
(* preserve *) reg detect_vsync_r;
reg detect_vsync_d_r;
(* preserve *) reg [11:0] detect_x_r;
(* preserve *) reg [11:0] detect_y_r;
(* preserve *) reg [23:0] detect_rgb_s1_r;
(* preserve *) reg        detect_de_s1_r;
(* preserve *) reg        detect_vsync_s1_r;
(* preserve *) reg [11:0] detect_x_s1_r;
(* preserve *) reg [11:0] detect_y_s1_r;
reg [11:0] min_x_r;
reg [11:0] max_x_r;
reg [11:0] min_y_r;
reg [11:0] max_y_r;
reg [19:0] target_count_r;
localparam [2:0] ACTION_IDLE  = 3'd0;
localparam [2:0] ACTION_LEFT  = 3'd1;
localparam [2:0] ACTION_RIGHT = 3'd2;
localparam [2:0] ACTION_JUMP  = 3'd3;
localparam [2:0] ACTION_SWEEP = 3'd4;
reg [2:0] action_state_r;
reg [3:0] action_hold_r;
reg [3:0] anim_phase_r;
reg [11:0] previous_center_x_r;
reg [11:0] previous_center_y_r;

wire frame_start_w = detect_vsync_r & ~detect_vsync_d_r;
wire [12:0] center_x_sum_w = {1'b0, min_x_r} + {1'b0, max_x_r};
wire [12:0] center_y_sum_w = {1'b0, min_y_r} + {1'b0, max_y_r};
wire [12:0] motion_dx_w = (center_x_sum_w[12:1] >= previous_center_x_r) ?
                          ({1'b0, center_x_sum_w[12:1]} - {1'b0, previous_center_x_r}) :
                          ({1'b0, previous_center_x_r} - {1'b0, center_x_sum_w[12:1]});
wire [12:0] motion_dy_up_w = (previous_center_y_r >= center_y_sum_w[12:1]) ?
                             ({1'b0, previous_center_y_r} - {1'b0, center_y_sum_w[12:1]}) : 13'd0;
wire detect_saturated_s1_w = ((detect_rgb_s1_r[23:16] > 8'd150) &&
                              ({1'b0, detect_rgb_s1_r[23:16]} > {1'b0, detect_rgb_s1_r[15:8]} + 9'd45) &&
                              ({1'b0, detect_rgb_s1_r[23:16]} > {1'b0, detect_rgb_s1_r[7:0]} + 9'd45)) ||
                             ((detect_rgb_s1_r[15:8] > 8'd150) &&
                              ({1'b0, detect_rgb_s1_r[15:8]} > {1'b0, detect_rgb_s1_r[23:16]} + 9'd45) &&
                              ({1'b0, detect_rgb_s1_r[15:8]} > {1'b0, detect_rgb_s1_r[7:0]} + 9'd45)) ||
                             ((detect_rgb_s1_r[7:0] > 8'd150) &&
                              ({1'b0, detect_rgb_s1_r[7:0]} > {1'b0, detect_rgb_s1_r[23:16]} + 9'd45) &&
                              ({1'b0, detect_rgb_s1_r[7:0]} > {1'b0, detect_rgb_s1_r[15:8]} + 9'd45));

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        key_meta_r    <= 1'b1;
        key_sync_r    <= 1'b1;
        key_stable_r  <= 1'b1;
        key_count_r   <= 20'd0;
        puppet_enable <= 1'b0;
    end else begin
        key_meta_r <= key_n;
        key_sync_r <= key_meta_r;
        if (key_sync_r == key_stable_r) begin
            key_count_r <= 20'd0;
        end else if (key_count_r >= DEBOUNCE_COUNT - 1'b1) begin
            key_stable_r <= key_sync_r;
            key_count_r  <= 20'd0;
            if (!key_sync_r)
                puppet_enable <= ~puppet_enable;
        end else begin
            key_count_r <= key_count_r + 1'b1;
        end
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        detect_saturated_r <= 1'b0;
        detect_vsync_r     <= 1'b0;
        detect_vsync_d_r   <= 1'b0;
        detect_x_r         <= 12'd0;
        detect_y_r         <= 12'd0;
        detect_rgb_s1_r    <= 24'd0;
        detect_de_s1_r     <= 1'b0;
        detect_vsync_s1_r  <= 1'b0;
        detect_x_s1_r      <= 12'd0;
        detect_y_s1_r      <= 12'd0;
        min_x_r         <= 12'hfff;
        max_x_r         <= 12'd0;
        min_y_r         <= 12'hfff;
        max_y_r         <= 12'd0;
        target_count_r  <= 20'd0;
        target_valid    <= 1'b0;
        target_center_x <= 12'd640;
        target_center_y <= 12'd360;
        previous_center_x_r <= 12'd640;
        previous_center_y_r <= 12'd360;
        action_state_r <= ACTION_IDLE;
        action_hold_r  <= 4'd0;
        anim_phase_r   <= 4'd0;
    end else begin
        detect_rgb_s1_r    <= rgb_i;
        detect_de_s1_r     <= de_i;
        detect_vsync_s1_r  <= vsync_i;
        detect_x_s1_r      <= x_i;
        detect_y_s1_r      <= y_i;
        detect_saturated_r <= detect_de_s1_r && detect_saturated_s1_w;
        detect_vsync_r     <= detect_vsync_s1_r;
        detect_vsync_d_r   <= detect_vsync_r;
        detect_x_r         <= detect_x_s1_r;
        detect_y_r         <= detect_y_s1_r;
        if (frame_start_w) begin
            target_valid <= (target_count_r >= MIN_TARGET_PIXELS);
            if (target_count_r >= MIN_TARGET_PIXELS) begin
                target_center_x <= center_x_sum_w[12:1];
                target_center_y <= center_y_sum_w[12:1];
                previous_center_x_r <= center_x_sum_w[12:1];
                previous_center_y_r <= center_y_sum_w[12:1];
                anim_phase_r <= anim_phase_r + 1'b1;
                if (motion_dy_up_w >= 13'd18) begin
                    action_state_r <= ACTION_JUMP;
                    action_hold_r  <= 4'd8;
                end else if (motion_dx_w >= 13'd32) begin
                    action_state_r <= ACTION_SWEEP;
                    action_hold_r  <= 4'd8;
                end else if (motion_dx_w >= 13'd5) begin
                    action_state_r <= (center_x_sum_w[12:1] < previous_center_x_r) ? ACTION_LEFT : ACTION_RIGHT;
                    action_hold_r  <= 4'd4;
                end else if (action_hold_r != 4'd0) begin
                    action_hold_r <= action_hold_r - 1'b1;
                end else begin
                    action_state_r <= ACTION_IDLE;
                end
            end
            min_x_r        <= 12'hfff;
            max_x_r        <= 12'd0;
            min_y_r        <= 12'hfff;
            max_y_r        <= 12'd0;
            target_count_r <= 20'd0;
        end else if (detect_saturated_r) begin
            if (detect_x_r < min_x_r) min_x_r <= detect_x_r;
            if (detect_x_r > max_x_r) max_x_r <= detect_x_r;
            if (detect_y_r < min_y_r) min_y_r <= detect_y_r;
            if (detect_y_r > max_y_r) max_y_r <= detect_y_r;
            if (target_count_r != 20'hfffff)
                target_count_r <= target_count_r + 1'b1;
        end
    end
end

wire [12:0] x_plus_72_w = {1'b0, x_i} + 13'd72;
wire [12:0] x_plus_66_w = {1'b0, x_i} + 13'd66;
wire [12:0] x_plus_48_w = {1'b0, x_i} + 13'd48;
wire [12:0] x_plus_34_w = {1'b0, x_i} + 13'd34;
wire [12:0] x_plus_28_w = {1'b0, x_i} + 13'd28;
wire [12:0] x_plus_18_w = {1'b0, x_i} + 13'd18;
wire [12:0] x_plus_12_w = {1'b0, x_i} + 13'd12;
wire [12:0] x_plus_5_w  = {1'b0, x_i} + 13'd5;
wire [12:0] y_plus_88_w = {1'b0, y_i} + 13'd88;
wire [12:0] y_plus_66_w = {1'b0, y_i} + 13'd66;
wire [12:0] y_plus_58_w = {1'b0, y_i} + 13'd58;
wire [12:0] y_plus_54_w = {1'b0, y_i} + 13'd54;
wire [12:0] y_plus_47_w = {1'b0, y_i} + 13'd47;
wire [12:0] y_plus_41_w = {1'b0, y_i} + 13'd41;
wire [12:0] y_plus_34_w = {1'b0, y_i} + 13'd34;
wire [12:0] y_plus_30_w = {1'b0, y_i} + 13'd30;
wire [12:0] y_plus_22_w = {1'b0, y_i} + 13'd22;
wire [12:0] y_plus_20_w = {1'b0, y_i} + 13'd20;
wire [12:0] y_plus_12_w = {1'b0, y_i} + 13'd12;
wire [12:0] y_plus_5_w  = {1'b0, y_i} + 13'd5;
wire [12:0] cx_w = {1'b0, target_center_x};
wire [12:0] cy_w = {1'b0, target_center_y};
wire [12:0] pose_cx_w = cx_w + ((action_state_r == ACTION_IDLE) && anim_phase_r[2] ? 13'd2 : 13'd0);
wire [12:0] pose_cy_w = cy_w - ((action_state_r == ACTION_JUMP) ? {9'd0, anim_phase_r[2:0], 1'b0} : 13'd0);

// Detailed Wukong artwork is a transparent indexed sprite. Motion is kept
// frame-latched with the tracker state and rendered around the target center.
wire signed [13:0] sprite_dx_s_w = $signed({1'b0, x_i}) -
                                    $signed({1'b0, target_center_x}) + 14'sd80;
wire signed [13:0] sprite_dy_s_w = $signed({1'b0, y_i}) -
                                    $signed({1'b0, target_center_y}) + 14'sd135 -
                                    ((action_state_r == ACTION_JUMP) ?
                                     $signed({9'd0, anim_phase_r[2:0], 1'b0}) : 14'sd0);
wire signed [13:0] sprite_x_offset_s_w =
    ((action_state_r == ACTION_SWEEP) && anim_phase_r[1]) ? 14'sd8 : 14'sd0;
wire signed [13:0] sprite_x_s_w = sprite_dx_s_w + sprite_x_offset_s_w;
wire sprite_bounds_w = target_valid &&
                       (sprite_x_s_w >= 14'sd0) && (sprite_x_s_w < 14'sd160) &&
                       (sprite_dy_s_w >= 14'sd0) && (sprite_dy_s_w < 14'sd270);
wire [15:0] sprite_address_w = (sprite_dy_s_w[13:0] * 14'd160) +
                               sprite_x_s_w[13:0];
wire [3:0] sprite_index_w;
wire sprite_opaque_w = sprite_bounds_w && (sprite_index_w != 4'd0);

paper_puppet_h6_sprite_rom u_sprite_rom (
    .clk        (clk),
    .address    (sprite_address_w),
    .pixel_index(sprite_index_w)
);

wire staff_left_w = (x_plus_72_w >= pose_cx_w) && (x_plus_66_w <= pose_cx_w) &&
                    (y_plus_88_w >= pose_cy_w) && ({1'b0, y_i} <= pose_cy_w + 13'd74);
wire staff_right_w = ({1'b0, x_i} >= pose_cx_w + 13'd66) && ({1'b0, x_i} <= pose_cx_w + 13'd72) &&
                     (y_plus_88_w >= pose_cy_w) && ({1'b0, y_i} <= pose_cy_w + 13'd74);
wire sweep_staff_w = (action_state_r == ACTION_SWEEP) && (x_plus_72_w >= pose_cx_w) &&
                     ({1'b0, x_i} <= pose_cx_w + 13'd72) && (y_plus_5_w >= pose_cy_w) &&
                     ({1'b0, y_i} <= pose_cy_w + 13'd5);
wire staff_w = sweep_staff_w || ((action_state_r == ACTION_RIGHT) ? staff_right_w : staff_left_w);
wire head_w = (x_plus_28_w >= pose_cx_w) && ({1'b0, x_i} <= pose_cx_w + 13'd28) &&
              (y_plus_66_w >= pose_cy_w) && (y_plus_22_w <= pose_cy_w);
wire ears_w = (x_plus_48_w >= pose_cx_w) && ({1'b0, x_i} <= pose_cx_w + 13'd48) &&
              (y_plus_54_w >= pose_cy_w) && (y_plus_34_w <= pose_cy_w);
wire face_w = (x_plus_18_w >= pose_cx_w) && ({1'b0, x_i} <= pose_cx_w + 13'd18) &&
              (y_plus_58_w >= pose_cy_w) && (y_plus_30_w <= pose_cy_w);
wire body_w = (x_plus_34_w >= pose_cx_w) && ({1'b0, x_i} <= pose_cx_w + 13'd34) &&
              (y_plus_20_w >= pose_cy_w) && ({1'b0, y_i} <= pose_cy_w + 13'd58);
wire belt_w = body_w && (y_i >= target_center_y + 12'd18) && (y_i <= target_center_y + 12'd25);
wire eye_w = ((x_plus_12_w >= cx_w) && (x_plus_5_w <= cx_w) ||
              (x_i >= target_center_x + 12'd5) && (x_i <= target_center_x + 12'd12)) &&
             (y_plus_47_w >= cy_w) && (y_plus_41_w <= cy_w);
wire jump_arm_w = (action_state_r == ACTION_JUMP) && (x_plus_66_w >= pose_cx_w) &&
                  ({1'b0, x_i} <= pose_cx_w + 13'd66) && (y_plus_12_w >= pose_cy_w) &&
                  ({1'b0, y_i} <= pose_cy_w + 13'd12);
wire marker_w = target_valid && (x_plus_5_w >= cx_w) && ({1'b0, x_i} <= cx_w + 13'd5) &&
                (y_plus_5_w >= cy_w) && ({1'b0, y_i} <= cy_w + 13'd5);
wire overlay_w = target_valid &&
                 (sprite_opaque_w || staff_w || head_w || ears_w || body_w ||
                  jump_arm_w || marker_w);

(* preserve *) reg [23:0] rgb_s1_r;
(* preserve *) reg        hsync_s1_r;
(* preserve *) reg        vsync_s1_r;
(* preserve *) reg        de_s1_r;
(* preserve *) reg        puppet_enable_s1_r;
(* preserve *) reg        overlay_s1_r;
(* preserve *) reg        staff_s1_r;
(* preserve *) reg        head_s1_r;
(* preserve *) reg        ears_s1_r;
(* preserve *) reg        face_s1_r;
(* preserve *) reg        belt_s1_r;
(* preserve *) reg        eye_s1_r;
(* preserve *) reg        marker_s1_r;
(* preserve *) reg        sprite_opaque_s1_r;
(* preserve *) reg  [3:0] sprite_index_s1_r;
(* preserve *) reg [2:0]  action_s1_r;
(* preserve *) reg [23:0] rgb_out_r;
(* preserve *) reg        hsync_out_r;
(* preserve *) reg        vsync_out_r;
(* preserve *) reg        de_out_r;

assign rgb_o   = rgb_out_r;
assign hsync_o = hsync_out_r;
assign vsync_o = vsync_out_r;
assign de_o    = de_out_r;

// Split the shape comparisons from the final RGB mux. This keeps the HDMI
// pixel path registered while delaying RGB and timing signals equally.
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        rgb_s1_r           <= 24'd0;
        hsync_s1_r         <= 1'b0;
        vsync_s1_r         <= 1'b0;
        de_s1_r            <= 1'b0;
        puppet_enable_s1_r <= 1'b0;
        overlay_s1_r       <= 1'b0;
        staff_s1_r         <= 1'b0;
        head_s1_r          <= 1'b0;
        ears_s1_r          <= 1'b0;
        face_s1_r          <= 1'b0;
        belt_s1_r          <= 1'b0;
        eye_s1_r           <= 1'b0;
        marker_s1_r        <= 1'b0;
        sprite_opaque_s1_r <= 1'b0;
        sprite_index_s1_r  <= 4'd0;
        action_s1_r        <= ACTION_IDLE;
    end else begin
        rgb_s1_r           <= rgb_i;
        hsync_s1_r         <= hsync_i;
        vsync_s1_r         <= vsync_i;
        de_s1_r            <= de_i;
        puppet_enable_s1_r <= puppet_enable;
        overlay_s1_r       <= overlay_w;
        staff_s1_r         <= staff_w;
        head_s1_r          <= head_w;
        ears_s1_r          <= ears_w;
        face_s1_r          <= face_w;
        belt_s1_r          <= belt_w;
        eye_s1_r           <= eye_w;
        marker_s1_r        <= marker_w;
        sprite_opaque_s1_r <= sprite_opaque_w;
        sprite_index_s1_r  <= sprite_index_w;
        action_s1_r        <= action_state_r;
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        rgb_out_r   <= 24'd0;
        hsync_out_r <= 1'b0;
        vsync_out_r <= 1'b0;
        de_out_r    <= 1'b0;
    end else begin
        hsync_out_r <= hsync_s1_r;
        vsync_out_r <= vsync_s1_r;
        de_out_r    <= de_s1_r;
        if (!puppet_enable_s1_r || !de_s1_r || !overlay_s1_r)
            rgb_out_r <= rgb_s1_r;
        else if (marker_s1_r)
            case (action_s1_r)
                ACTION_LEFT:  rgb_out_r <= 24'h2080FF;
                ACTION_RIGHT: rgb_out_r <= 24'h20E080;
                ACTION_JUMP:  rgb_out_r <= 24'hF040FF;
                ACTION_SWEEP: rgb_out_r <= 24'hFF8020;
                default:      rgb_out_r <= 24'hFFFFFF;
            endcase
        else if (sprite_opaque_s1_r)
            case (sprite_index_s1_r)
                4'd1:  rgb_out_r <= 24'hC20507;
                4'd2:  rgb_out_r <= 24'hFBCA1E;
                4'd3:  rgb_out_r <= 24'h500A09;
                4'd4:  rgb_out_r <= 24'hC1BC8A;
                4'd5:  rgb_out_r <= 24'h636450;
                4'd6:  rgb_out_r <= 24'hD36036;
                4'd7:  rgb_out_r <= 24'hDA923B;
                4'd8:  rgb_out_r <= 24'hF3E6B6;
                4'd9:  rgb_out_r <= 24'hFBE432;
                4'd10: rgb_out_r <= 24'hFCF5CB;
                4'd11: rgb_out_r <= 24'hF0BD36;
                default: rgb_out_r <= 24'hFFFFFF;
            endcase
        else if (staff_s1_r)
            rgb_out_r <= 24'hD8B020;
        else if (eye_s1_r)
            rgb_out_r <= 24'hFFF060;
        else if (face_s1_r)
            rgb_out_r <= 24'hF0B070;
        else if (belt_s1_r)
            rgb_out_r <= 24'hFFD020;
        else if (head_s1_r)
            rgb_out_r <= 24'hC02020;
        else if (ears_s1_r)
            rgb_out_r <= 24'hB01818;
        else
            rgb_out_r <= 24'h901010;
    end
end

endmodule

// One transparent indexed sprite keeps the character recognizable without a
// full-frame buffer. The H6 build maps this to M512; simulation uses the same
// hex payload with an asynchronous read so the existing two-stage RGB pipe is
// preserved.
module paper_puppet_h6_sprite_rom (
    input  wire        clk,
    input  wire [15:0] address,
    output reg  [3:0]  pixel_index
);
`ifdef SYNTHESIS
    altsyncram #(
        .operation_mode("ROM"),
        .width_a(4),
        .widthad_a(16),
        .numwords_a(43200),
        .outdata_reg_a("UNREGISTERED"),
        .clock_enable_input_a("NORMAL"),
        .clock_enable_output_a("NORMAL"),
          // The H6 packer accepts M4K RAMs but rejects M512 primitives.
          // Keep the indexed artwork in embedded RAM so the final JPSK is
          // programmable on the target device.
          .ram_block_type("M4K"),
        .init_file("ov5640_hdmi_1080p.srcs/sources_1/paper_puppet/wukong_shadow_fpga_160x270.mif"),
        .intended_device_family("Stratix")
    ) u_rom (
        .clock0   (clk),
        .address_a(address),
        .q_a      (pixel_index)
    );
`else
    reg [3:0] memory [0:43199];
    initial $readmemh("ov5640_hdmi_1080p.srcs/sources_1/paper_puppet/wukong_shadow_fpga_160x270.hex", memory);
    always @* begin
        if (address < 16'd43200)
            pixel_index = memory[address];
        else
            pixel_index = 4'd0;
    end
`endif
endmodule
