# H6 board test

1. Program `01_FPGA/ov5640_hdmi_1080p.runs/imple_1/ov5640_hdmi_1080p.jpsk` with the team's normal H6 programmer.
2. Print `physical_target/PaperPuppet_BlueMarker_A4.svg` at 100% on matte paper and cut on the dashed contour. Keep the `#0047FF` central marker flat and unobstructed.
3. Connect OV5640 and HDMI, power-cycle, and verify camera pass-through for at least 60 seconds. The default puppet enable is 0.
4. Press KEY2 once and verify the Wukong sprite appears over the target region without corrupting the camera background.
5. Exercise KEY2/action controls and check idle, jump, and horizontal sweep motion at frame boundaries.
6. Record board/device revision, programming result, camera pass-through result, overlay result, and any HDMI artifacts for review.

This package is built and timing-checked but is not board-verified.
