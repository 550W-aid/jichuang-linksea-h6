# Physical target recommendation

- Print `PaperPuppet_BlueMarker_A4.svg` at 100% scale on matte heavyweight paper.
- Preferred marker color: saturated royal blue, `#0047FF`.
- Recognition region: rounded rectangle, 90 x 125 mm.
- Expected camera distance: approximately 0.8 to 1.2 m; keep the marker at least about 60 x 80 HDMI pixels.
- Background: plain light gray or white, without saturated blue objects.
- Track the central marker, not the detailed body contour.
- Keep arms, staff, hat feathers, and decorations black, gray, white, or muted gold.
- Do not add other saturated red, green, or blue regions to the puppet or background.
- Avoid glossy lamination, folds, shadows across the marker, thin blue protrusions, and partially covering the blue rectangle.

The marker center corresponds to the puppet overlay anchor. The decorative outline is intentionally neutral so it does not move the detector bounding box.
