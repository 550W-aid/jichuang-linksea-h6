// ============================================================================
// Module Function:
//   Parse EV UDP video packets, validate optional CRC16 trailers, tolerate
//   retransmitted packets, and convert accepted RGB888 chunks into ordered
//   RGB565 SDRAM write requests. Legacy EV packets without CRC remain valid.
// ============================================================================
`timescale 1ns/1ps

module eth_video_rx_to_sdram #(
    parameter [10:0] HALF_PIXELS = 11'd640,
    parameter [10:0] FRAME_LINES = 11'd720,
    parameter [10:0] CHUNK_PIXELS = 11'd320,
    parameter [1:0]  CHUNKS_PER_HALF = 2'd2,
    parameter        ALLOW_PACKET_DUPLICATES = 1'b1,
    parameter        RETRY_BAD_PACKET = 1'b0
)(
    input  wire        eth_clk,
    input  wire        wr_clk_i,
    input  wire        rst_n,
    input  wire        rec_en_i,
    input  wire [7:0]  rec_data_i,
    input  wire [15:0] rec_byte_num_i,
    input  wire        wr_reset_i,
    input  wire        wr_reset_wr_i,

    output reg         wr_req0_o,
    output reg         wr_req1_o,
    output reg [15:0]  wr_data_o,
    output reg         frame_done_toggle_o,
    output reg         frame_abort_toggle_o,
    output reg         packet_seen_toggle_o,
    output reg [15:0]  good_packet_count_o,
    output reg [15:0]  bad_packet_count_o,
    output reg [15:0]  frame_count_o,
    output reg [10:0]  last_line_o,
    output reg         last_half_o,
    output reg [1:0]   last_chunk_o,
    output reg [15:0]  last_words_o,
    output reg [7:0]   last_frame_id_o,
    output reg         active_o
);

    localparam [7:0]  MAGIC0 = 8'h45; // "E"
    localparam [7:0]  MAGIC1 = 8'h56; // "V"
    localparam [1:0]  CODEC_RGB888_LITERAL  = 2'd1;
    localparam [1:0]  CODEC_RGB888_H2_LINE  = 2'd2;
    localparam [1:0]  CODEC_RGB888_H2_CHUNK = 2'd3;
    localparam [10:0] PACKET_BYTES_LITERAL  = 11'd968;
    localparam [10:0] PACKET_BYTES_H2_LINE  = 11'd968;
    localparam [10:0] PACKET_BYTES_H2_CHUNK = 11'd488;
    localparam [8:0]  CHUNK_WORDS           = 9'd320;
    localparam [8:0]  H2_CHUNK_STORED_WORDS = 9'd160;
    localparam [9:0]  H2_LINE_OUTPUT_WORDS  = 10'd640;
    localparam [6:0]  FRAME_DONE_PUBLISH_DELAY = 7'd64;

    reg [15:0] packet_mem0 [0:511];
    reg [15:0] packet_mem1 [0:511];
    reg [15:0] packet_mem2 [0:511];
    reg [15:0] packet_mem3 [0:511];

    reg        rec_en_d_r;
    reg [10:0] byte_idx_r;
    reg        header0_ok_r;
    reg        header_ok_r;
    reg        accept_packet_r;
    reg [1:0]  packet_bank_r;
    reg        packet_bank_available_r;
    reg [7:0]  frame_id_r;
    reg [10:0] line_r;
    reg        half_r;
    reg [1:0]  chunk_r;
    reg        codec_h2_r;
    reg        codec_h2_line_r;
    reg [10:0] expected_packet_bytes_r;
    reg [8:0]  expected_words_r;
    reg        line_valid_r;
    reg        chunk_valid_r;
    reg        packet_prefix_valid_r;
    reg        packet_coord_match_r;
    reg        h2_line_chunk_valid_r;
    reg        full_chunk_valid_r;
    reg        packet_last_line_r;
    reg        last_packet_r;
    reg [1:0]  rgb_phase_r;
    reg [7:0]  rgb_r_r;
    reg [7:0]  rgb_g_r;
    reg [8:0]  word_count_r;
    reg        payload_overflow_r;
    reg        payload_room_r;
    reg [8:0]  expected_last_word_r;
    reg        packet_mem_wr_en_r;
    reg [1:0]  packet_mem_wr_bank_r;
    reg [8:0]  packet_mem_wr_addr_r;
    reg [15:0] packet_mem_wr_data_r;
    reg        frame_active_r;
    reg [7:0]  seq_frame_id_r;
    reg [10:0] seq_line_r;
    reg [1:0]  seq_chunk_r;
    reg [1:0]  seq_codec_r;
    reg        start_frame_pending_r;
    reg [1:0]  start_frame_codec_r;
    reg        packet_frame_member_r;
    reg        packet_abort_r;
    reg        duplicate_packet_r;
    reg        packet_crc_en_r;
    reg [15:0] crc_calc_r;
    reg [15:0] crc_received_r;
    reg        crc_hi_phase_r;
    reg        crc_lo_phase_r;
    reg        last_good_valid_r;
    reg [7:0]  last_good_frame_id_r;
    reg [10:0] last_good_line_r;
    reg        last_good_half_r;
    reg [1:0]  last_good_chunk_r;
    reg [1:0]  last_good_codec_r;
    reg [1:0]  enqueue_seq_eth_r;
    reg        ready0_toggle_eth_r;
    reg        ready1_toggle_eth_r;
    reg        ready2_toggle_eth_r;
    reg        ready3_toggle_eth_r;
    reg        bank0_half_eth_r;
    reg        bank1_half_eth_r;
    reg        bank2_half_eth_r;
    reg        bank3_half_eth_r;
    reg        bank0_h2_eth_r;
    reg        bank1_h2_eth_r;
    reg        bank2_h2_eth_r;
    reg        bank3_h2_eth_r;
    reg        bank0_h2_line_eth_r;
    reg        bank1_h2_line_eth_r;
    reg        bank2_h2_line_eth_r;
    reg        bank3_h2_line_eth_r;
    reg [1:0]  bank0_seq_eth_r;
    reg [1:0]  bank1_seq_eth_r;
    reg [1:0]  bank2_seq_eth_r;
    reg [1:0]  bank3_seq_eth_r;
    reg        frame_end_toggle_eth_r;
    reg [1:0]  ack0_eth_sync_r;
    reg [1:0]  ack1_eth_sync_r;
    reg [1:0]  ack2_eth_sync_r;
    reg [1:0]  ack3_eth_sync_r;
    reg        finalize_packet_r;
    reg        finalize_good_r;
    reg        finalize_duplicate_good_r;
    reg        finalize_frame_member_r;
    reg [1:0]  finalize_bank_r;
    reg        finalize_half_r;
    reg        finalize_h2_r;
    reg        finalize_h2_line_r;
    reg        finalize_last_packet_r;
    reg        finalize_abort_r;
    reg        finalize_duplicate_r;

    reg [1:0]  ready0_wr_sync_r;
    reg [1:0]  ready1_wr_sync_r;
    reg [1:0]  ready2_wr_sync_r;
    reg [1:0]  ready3_wr_sync_r;
    reg        ack0_toggle_wr_r;
    reg        ack1_toggle_wr_r;
    reg        ack2_toggle_wr_r;
    reg        ack3_toggle_wr_r;
    reg        wr_active_r;
    reg [1:0]  wr_bank_r;
    reg [1:0]  dequeue_seq_wr_r;
    reg        wr_half_r;
    reg        wr_h2_r;
    reg        wr_h2_line_r;
    reg [1:0]  frame_end_wr_sync_r;
    reg        frame_end_seen_wr_r;
    reg        frame_done_pending_wr_r;
    reg [6:0]  frame_done_delay_wr_r;
    reg        h2_dup_phase_r;
    reg [8:0]  wr_source_words_r;
    reg [9:0]  wr_output_words_r;
    reg [8:0]  rd_addr_r;
    reg [9:0]  out_count_r;
    reg [15:0] rd_data_r;
    reg        rd_valid_r;

    wire        rec_start_w = rec_en_i & ~rec_en_d_r;
    wire        rec_end_w   = rec_en_d_r & ~rec_en_i;
    wire        bank0_busy_eth_w = ready0_toggle_eth_r ^ ack0_eth_sync_r[1];
    wire        bank1_busy_eth_w = ready1_toggle_eth_r ^ ack1_eth_sync_r[1];
    wire        bank2_busy_eth_w = ready2_toggle_eth_r ^ ack2_eth_sync_r[1];
    wire        bank3_busy_eth_w = ready3_toggle_eth_r ^ ack3_eth_sync_r[1];
    wire        bank0_ready_wr_w = ready0_wr_sync_r[1] ^ ack0_toggle_wr_r;
    wire        bank1_ready_wr_w = ready1_wr_sync_r[1] ^ ack1_toggle_wr_r;
    wire        bank2_ready_wr_w = ready2_wr_sync_r[1] ^ ack2_toggle_wr_r;
    wire        bank3_ready_wr_w = ready3_wr_sync_r[1] ^ ack3_toggle_wr_r;
    wire [15:0] rgb565_word_w = {rgb_r_r[7:3], rgb_g_r[7:2], rec_data_i[7:3]};
    wire [15:0] expected_packet_bytes_ext_w = {5'd0, expected_packet_bytes_r};
    wire        packet_len_ok_w = (rec_byte_num_i == 16'd0) ||
                                  (rec_byte_num_i == expected_packet_bytes_ext_w);
    wire        packet_words_ok_w = (word_count_r == expected_words_r);
    wire        packet_integrity_good_w = !payload_overflow_r &&
                                           packet_words_ok_w &&
                                           (rgb_phase_r == 2'd0) &&
                                           (byte_idx_r == expected_packet_bytes_r) &&
                                           packet_len_ok_w &&
                                           (!packet_crc_en_r ||
                                            (crc_calc_r == crc_received_r));
    wire        codec_literal_byte_w = (rec_data_i[1:0] == CODEC_RGB888_LITERAL);
    wire        codec_h2_line_byte_w = (rec_data_i[1:0] == CODEC_RGB888_H2_LINE);
    wire        codec_h2_chunk_byte_w = (rec_data_i[1:0] == CODEC_RGB888_H2_CHUNK);
    wire [2:0]  full_chunks_per_line_w = {1'b0, CHUNKS_PER_HALF} << 1;
    wire [1:0]  packet_terminal_chunk_w = codec_h2_line_byte_w ?
                                                  (CHUNKS_PER_HALF - 1'b1) :
                                                  (full_chunks_per_line_w[1:0] - 1'b1);
    wire        supported_packet_w = codec_h2_line_byte_w ? h2_line_chunk_valid_r :
                                     ((codec_literal_byte_w || codec_h2_chunk_byte_w) &&
                                      full_chunk_valid_r);
    wire        packet_header_valid_w = packet_prefix_valid_r &&
                                        supported_packet_w;
    wire        packet_sequence_match_w = packet_coord_match_r &&
                                          (!frame_active_r ||
                                           (rec_data_i[1:0] == seq_codec_r));
    wire        packet_accept_w = packet_header_valid_w &&
                                  packet_sequence_match_w &&
                                  packet_bank_available_r &&
                                  !wr_reset_i;
    wire        packet_duplicate_w = ALLOW_PACKET_DUPLICATES &&
                                     last_good_valid_r &&
                                     packet_header_valid_w &&
                                     (frame_id_r == last_good_frame_id_r) &&
                                     (line_r == last_good_line_r) &&
                                     (half_r == last_good_half_r) &&
                                     (chunk_r == last_good_chunk_r) &&
                                     (rec_data_i[1:0] == last_good_codec_r);
    wire        header_last_packet_w = packet_last_line_r &&
                                       (chunk_r == packet_terminal_chunk_w);
    wire [15:0] reported_words_w = (codec_h2_line_r && packet_words_ok_w) ?
                                   {6'd0, H2_LINE_OUTPUT_WORDS} :
                                   (codec_h2_r && packet_words_ok_w) ?
                                   {7'd0, CHUNK_WORDS} :
                                   {7'd0, word_count_r};
    wire        wr_output_last_w = (out_count_r == (wr_output_words_r - 10'd1));
    wire        wr_read_after_output_w = rd_valid_r &&
                                         !wr_output_last_w &&
                                         (!wr_h2_r || h2_dup_phase_r);
    wire        wr_read_fire_w = wr_active_r &&
                                 (rd_addr_r < wr_source_words_r) &&
                                 (!rd_valid_r || wr_read_after_output_w);

    function [15:0] crc16_ccitt_byte;
        input [15:0] crc_i;
        input [7:0]  data_i;
        integer bit_idx;
        reg [15:0] crc_v;
        begin
            crc_v = crc_i;
            for (bit_idx = 0; bit_idx < 8; bit_idx = bit_idx + 1) begin
                if (crc_v[15] ^ data_i[7-bit_idx])
                    crc_v = {crc_v[14:0], 1'b0} ^ 16'h1021;
                else
                    crc_v = {crc_v[14:0], 1'b0};
            end
            crc16_ccitt_byte = crc_v;
        end
    endfunction

    always @(posedge eth_clk) begin
        if (packet_mem_wr_en_r) begin
            case (packet_mem_wr_bank_r)
                2'd0: packet_mem0[packet_mem_wr_addr_r] <= packet_mem_wr_data_r;
                2'd1: packet_mem1[packet_mem_wr_addr_r] <= packet_mem_wr_data_r;
                2'd2: packet_mem2[packet_mem_wr_addr_r] <= packet_mem_wr_data_r;
                default: packet_mem3[packet_mem_wr_addr_r] <= packet_mem_wr_data_r;
            endcase
        end
    end

    always @(posedge eth_clk or negedge rst_n) begin
        if (!rst_n) begin
            rec_en_d_r              <= 1'b0;
            byte_idx_r              <= 11'd0;
            header0_ok_r            <= 1'b0;
            header_ok_r             <= 1'b0;
            accept_packet_r         <= 1'b0;
            packet_bank_r           <= 2'd0;
            packet_bank_available_r <= 1'b0;
            frame_id_r              <= 8'd0;
            line_r                  <= 11'd0;
            half_r                  <= 1'b0;
            chunk_r                 <= 2'd0;
            codec_h2_r              <= 1'b0;
            codec_h2_line_r         <= 1'b0;
            expected_packet_bytes_r <= PACKET_BYTES_LITERAL;
            expected_words_r        <= CHUNK_WORDS;
            line_valid_r            <= 1'b0;
            chunk_valid_r           <= 1'b0;
            packet_prefix_valid_r   <= 1'b0;
            packet_coord_match_r    <= 1'b0;
            h2_line_chunk_valid_r   <= 1'b0;
            full_chunk_valid_r      <= 1'b0;
            packet_last_line_r      <= 1'b0;
            last_packet_r           <= 1'b0;
            rgb_phase_r             <= 2'd0;
            rgb_r_r                 <= 8'd0;
            rgb_g_r                 <= 8'd0;
            word_count_r            <= 9'd0;
            payload_overflow_r      <= 1'b0;
            payload_room_r          <= 1'b0;
            expected_last_word_r    <= CHUNK_WORDS - 9'd1;
            packet_mem_wr_en_r      <= 1'b0;
            packet_mem_wr_bank_r    <= 2'd0;
            packet_mem_wr_addr_r    <= 9'd0;
            packet_mem_wr_data_r    <= 16'd0;
            frame_active_r          <= 1'b0;
            seq_frame_id_r          <= 8'd0;
            seq_line_r              <= 11'd0;
            seq_chunk_r             <= 2'd0;
            seq_codec_r             <= 2'd0;
            start_frame_pending_r    <= 1'b0;
            start_frame_codec_r      <= 2'd0;
            packet_frame_member_r   <= 1'b0;
            packet_abort_r          <= 1'b0;
            duplicate_packet_r      <= 1'b0;
            packet_crc_en_r         <= 1'b0;
            crc_calc_r              <= 16'hffff;
            crc_received_r          <= 16'd0;
            crc_hi_phase_r          <= 1'b0;
            crc_lo_phase_r          <= 1'b0;
            last_good_valid_r       <= 1'b0;
            last_good_frame_id_r    <= 8'd0;
            last_good_line_r        <= 11'd0;
            last_good_half_r        <= 1'b0;
            last_good_chunk_r       <= 2'd0;
            last_good_codec_r       <= 2'd0;
            enqueue_seq_eth_r       <= 2'd0;
            ready0_toggle_eth_r     <= 1'b0;
            ready1_toggle_eth_r     <= 1'b0;
            ready2_toggle_eth_r     <= 1'b0;
            ready3_toggle_eth_r     <= 1'b0;
            bank0_half_eth_r        <= 1'b0;
            bank1_half_eth_r        <= 1'b0;
            bank2_half_eth_r        <= 1'b0;
            bank3_half_eth_r        <= 1'b0;
            bank0_h2_eth_r          <= 1'b0;
            bank1_h2_eth_r          <= 1'b0;
            bank2_h2_eth_r          <= 1'b0;
            bank3_h2_eth_r          <= 1'b0;
            bank0_h2_line_eth_r     <= 1'b0;
            bank1_h2_line_eth_r     <= 1'b0;
            bank2_h2_line_eth_r     <= 1'b0;
            bank3_h2_line_eth_r     <= 1'b0;
            bank0_seq_eth_r         <= 2'd0;
            bank1_seq_eth_r         <= 2'd0;
            bank2_seq_eth_r         <= 2'd0;
            bank3_seq_eth_r         <= 2'd0;
            frame_end_toggle_eth_r  <= 1'b0;
            ack0_eth_sync_r         <= 2'b00;
            ack1_eth_sync_r         <= 2'b00;
            ack2_eth_sync_r         <= 2'b00;
            ack3_eth_sync_r         <= 2'b00;
            finalize_packet_r       <= 1'b0;
            finalize_good_r         <= 1'b0;
            finalize_duplicate_good_r <= 1'b0;
            finalize_frame_member_r <= 1'b0;
            finalize_bank_r         <= 2'd0;
            finalize_half_r         <= 1'b0;
            finalize_h2_r           <= 1'b0;
            finalize_h2_line_r      <= 1'b0;
            finalize_last_packet_r  <= 1'b0;
            finalize_abort_r        <= 1'b0;
            finalize_duplicate_r    <= 1'b0;
            frame_abort_toggle_o    <= 1'b0;
            packet_seen_toggle_o    <= 1'b0;
            good_packet_count_o     <= 16'd0;
            bad_packet_count_o      <= 16'd0;
            frame_count_o           <= 16'd0;
            last_line_o             <= 11'd0;
            last_half_o             <= 1'b0;
            last_chunk_o            <= 2'd0;
            last_words_o            <= 16'd0;
            last_frame_id_o         <= 8'd0;
            active_o                <= 1'b0;
        end else begin
            rec_en_d_r         <= rec_en_i;
            active_o           <= frame_active_r;
            ack0_eth_sync_r    <= {ack0_eth_sync_r[0], ack0_toggle_wr_r};
            ack1_eth_sync_r    <= {ack1_eth_sync_r[0], ack1_toggle_wr_r};
            ack2_eth_sync_r    <= {ack2_eth_sync_r[0], ack2_toggle_wr_r};
            ack3_eth_sync_r    <= {ack3_eth_sync_r[0], ack3_toggle_wr_r};
            packet_mem_wr_en_r <= 1'b0;
            finalize_packet_r  <= 1'b0;

            if (start_frame_pending_r) begin
                frame_active_r       <= 1'b1;
                seq_frame_id_r       <= frame_id_r;
                seq_line_r           <= line_r;
                seq_chunk_r          <= chunk_r;
                seq_codec_r          <= start_frame_codec_r;
                start_frame_pending_r <= 1'b0;
            end

            if (finalize_packet_r && !(wr_reset_i && !rec_en_i)) begin
                if (finalize_duplicate_good_r) begin
                    // A reliable sender places the retry immediately after
                    // the original packet. Consume it without advancing the
                    // frame sequence or publishing a second packet bank.
                    good_packet_count_o <= good_packet_count_o + 16'd1;
                end else if (finalize_good_r) begin
                    good_packet_count_o <= good_packet_count_o + 16'd1;
                    last_good_valid_r    <= 1'b1;
                    last_good_frame_id_r <= frame_id_r;
                    last_good_line_r     <= line_r;
                    last_good_half_r     <= finalize_half_r;
                    last_good_chunk_r    <= chunk_r;
                    last_good_codec_r    <= finalize_h2_line_r ?
                                            CODEC_RGB888_H2_LINE :
                                            (finalize_h2_r ? CODEC_RGB888_H2_CHUNK :
                                                             CODEC_RGB888_LITERAL);
                    case (finalize_bank_r)
                        2'd0: begin
                            bank0_half_eth_r    <= finalize_half_r;
                            bank0_h2_eth_r      <= finalize_h2_r;
                            bank0_h2_line_eth_r <= finalize_h2_line_r;
                            bank0_seq_eth_r     <= enqueue_seq_eth_r;
                            ready0_toggle_eth_r <= ~ready0_toggle_eth_r;
                        end
                        2'd1: begin
                            bank1_half_eth_r    <= finalize_half_r;
                            bank1_h2_eth_r      <= finalize_h2_r;
                            bank1_h2_line_eth_r <= finalize_h2_line_r;
                            bank1_seq_eth_r     <= enqueue_seq_eth_r;
                            ready1_toggle_eth_r <= ~ready1_toggle_eth_r;
                        end
                        2'd2: begin
                            bank2_half_eth_r    <= finalize_half_r;
                            bank2_h2_eth_r      <= finalize_h2_r;
                            bank2_h2_line_eth_r <= finalize_h2_line_r;
                            bank2_seq_eth_r     <= enqueue_seq_eth_r;
                            ready2_toggle_eth_r <= ~ready2_toggle_eth_r;
                        end
                        default: begin
                            bank3_half_eth_r    <= finalize_half_r;
                            bank3_h2_eth_r      <= finalize_h2_r;
                            bank3_h2_line_eth_r <= finalize_h2_line_r;
                            bank3_seq_eth_r     <= enqueue_seq_eth_r;
                            ready3_toggle_eth_r <= ~ready3_toggle_eth_r;
                        end
                    endcase
                    enqueue_seq_eth_r <= enqueue_seq_eth_r + 2'd1;

                    if (finalize_last_packet_r) begin
                        frame_end_toggle_eth_r <= ~frame_end_toggle_eth_r;
                        frame_count_o          <= frame_count_o + 16'd1;
                        frame_active_r         <= 1'b0;
                    end else if (seq_chunk_r ==
                                 (finalize_h2_line_r ?
                                  (CHUNKS_PER_HALF - 1'b1) :
                                  (full_chunks_per_line_w[1:0] - 1'b1))) begin
                        seq_line_r  <= seq_line_r + 11'd1;
                        seq_chunk_r <= 2'd0;
                    end else begin
                        seq_chunk_r <= seq_chunk_r + 2'd1;
                    end
                end else begin
                    bad_packet_count_o <= bad_packet_count_o + 16'd1;
                    if (!finalize_duplicate_r &&
                        !(RETRY_BAD_PACKET && finalize_frame_member_r &&
                          !finalize_abort_r) &&
                        (finalize_abort_r || finalize_frame_member_r)) begin
                        frame_active_r       <= 1'b0;
                        frame_abort_toggle_o <= ~frame_abort_toggle_o;
                    end
                end
            end

            if (wr_reset_i && !rec_en_i) begin
                byte_idx_r         <= 11'd0;
                header0_ok_r       <= 1'b0;
                header_ok_r        <= 1'b0;
                accept_packet_r    <= 1'b0;
                rgb_phase_r        <= 2'd0;
                word_count_r       <= 9'd0;
                payload_overflow_r <= 1'b0;
                payload_room_r     <= 1'b0;
                frame_active_r     <= 1'b0;
                packet_prefix_valid_r <= 1'b0;
                packet_coord_match_r  <= 1'b0;
                h2_line_chunk_valid_r <= 1'b0;
                full_chunk_valid_r    <= 1'b0;
                packet_last_line_r    <= 1'b0;
                seq_frame_id_r     <= 8'd0;
                seq_line_r         <= 11'd0;
                seq_chunk_r        <= 2'd0;
                seq_codec_r        <= 2'd0;
                start_frame_pending_r <= 1'b0;
                start_frame_codec_r   <= 2'd0;
                packet_frame_member_r <= 1'b0;
                packet_abort_r     <= 1'b0;
                duplicate_packet_r <= 1'b0;
                packet_crc_en_r    <= 1'b0;
                crc_calc_r         <= 16'hffff;
                crc_received_r     <= 16'd0;
                crc_hi_phase_r     <= 1'b0;
                crc_lo_phase_r     <= 1'b0;
                last_good_valid_r  <= 1'b0;
                enqueue_seq_eth_r  <= 2'd0;
                finalize_packet_r  <= 1'b0;
            end

            if (rec_start_w) begin
                byte_idx_r              <= 11'd0;
                header0_ok_r            <= 1'b0;
                header_ok_r             <= 1'b0;
                accept_packet_r         <= 1'b0;
                packet_bank_available_r <= 1'b0;
                frame_id_r              <= 8'd0;
                line_r                  <= 11'd0;
                half_r                  <= 1'b0;
                chunk_r                 <= 2'd0;
                codec_h2_r              <= 1'b0;
                codec_h2_line_r         <= 1'b0;
                expected_packet_bytes_r <= PACKET_BYTES_LITERAL;
                expected_words_r        <= CHUNK_WORDS;
                line_valid_r            <= 1'b0;
                chunk_valid_r           <= 1'b0;
                packet_prefix_valid_r   <= 1'b0;
                packet_coord_match_r    <= 1'b0;
                h2_line_chunk_valid_r   <= 1'b0;
                full_chunk_valid_r      <= 1'b0;
                packet_last_line_r      <= 1'b0;
                last_packet_r           <= 1'b0;
                rgb_phase_r             <= 2'd0;
                word_count_r            <= 9'd0;
                payload_overflow_r      <= 1'b0;
                payload_room_r          <= 1'b0;
                expected_last_word_r    <= CHUNK_WORDS - 9'd1;
                start_frame_pending_r   <= 1'b0;
                packet_frame_member_r   <= 1'b0;
                packet_abort_r          <= 1'b0;
                duplicate_packet_r      <= 1'b0;
                packet_crc_en_r         <= 1'b0;
                crc_calc_r              <= 16'hffff;
                crc_received_r          <= 16'd0;
                crc_hi_phase_r          <= 1'b0;
                crc_lo_phase_r          <= 1'b0;
                packet_seen_toggle_o    <= ~packet_seen_toggle_o;
                if (!bank0_busy_eth_w) begin
                    packet_bank_r           <= 2'd0;
                    packet_bank_available_r <= 1'b1;
                end else if (!bank1_busy_eth_w) begin
                    packet_bank_r           <= 2'd1;
                    packet_bank_available_r <= 1'b1;
                end else if (!bank2_busy_eth_w) begin
                    packet_bank_r           <= 2'd2;
                    packet_bank_available_r <= 1'b1;
                end else if (!bank3_busy_eth_w) begin
                    packet_bank_r           <= 2'd3;
                    packet_bank_available_r <= 1'b1;
                end
            end

            if (rec_en_i) begin
                // Predecode trailer positions one byte early. This removes the
                // 11-bit byte-index comparator from crc_received_r's enable
                // path while preserving the byte-stream protocol.
                crc_hi_phase_r <= ((byte_idx_r + 11'd1) == (expected_packet_bytes_r - 11'd2));
                crc_lo_phase_r <= ((byte_idx_r + 11'd1) == (expected_packet_bytes_r - 11'd1));
                case (byte_idx_r)
                    11'd0: header0_ok_r <= (rec_data_i == MAGIC0);
                    11'd1: header_ok_r  <= header0_ok_r && (rec_data_i == MAGIC1);
                    11'd2: frame_id_r   <= rec_data_i;
                    11'd3: line_r[10:8] <= rec_data_i[2:0];
                    11'd4: begin
                        line_r[7:0]  <= rec_data_i;
                        line_valid_r <= ({line_r[10:8], rec_data_i} < FRAME_LINES);
                    end
                    11'd5: half_r <= rec_data_i[0];
                    11'd6: begin
                        chunk_r       <= rec_data_i[1:0];
                        chunk_valid_r <= ({1'b0, rec_data_i[1:0]} <
                                          full_chunks_per_line_w);
                        packet_prefix_valid_r <= header_ok_r && line_valid_r &&
                                                 (half_r == line_r[0]);
                        packet_coord_match_r <= frame_active_r ?
                                                ((frame_id_r == seq_frame_id_r) &&
                                                 (line_r == seq_line_r) &&
                                                 (half_r == seq_line_r[0]) &&
                                                 (rec_data_i[1:0] == seq_chunk_r)) :
                                                ((line_r == 11'd0) && !half_r &&
                                                 (rec_data_i[1:0] == 2'd0));
                        h2_line_chunk_valid_r <=
                            ({1'b0, rec_data_i[1:0]} < {1'b0, CHUNKS_PER_HALF});
                        full_chunk_valid_r <=
                            ({1'b0, rec_data_i[1:0]} < full_chunks_per_line_w);
                        packet_last_line_r <= (line_r == (FRAME_LINES - 11'd1));
                    end
                    11'd7: begin
                        codec_h2_r      <= codec_h2_line_byte_w || codec_h2_chunk_byte_w;
                        codec_h2_line_r <= codec_h2_line_byte_w;
                        packet_crc_en_r <= rec_data_i[7];
                        expected_packet_bytes_r <=
                            codec_h2_chunk_byte_w ?
                            (PACKET_BYTES_H2_CHUNK + (rec_data_i[7] ? 11'd2 : 11'd0)) :
                            (codec_h2_line_byte_w ? PACKET_BYTES_H2_LINE :
                             PACKET_BYTES_LITERAL) + (rec_data_i[7] ? 11'd2 : 11'd0);
                        expected_words_r <=
                            codec_h2_chunk_byte_w ?
                            H2_CHUNK_STORED_WORDS : CHUNK_WORDS;
                        expected_last_word_r <=
                            codec_h2_chunk_byte_w ?
                            (H2_CHUNK_STORED_WORDS - 9'd1) :
                            (CHUNK_WORDS - 9'd1);
                        payload_room_r <= packet_accept_w || packet_duplicate_w;
                        last_packet_r <= header_last_packet_w;
                        accept_packet_r <= packet_accept_w;
                        duplicate_packet_r <= packet_duplicate_w;
                        packet_frame_member_r <= packet_header_valid_w &&
                                                 packet_sequence_match_w &&
                                                 (frame_active_r ||
                                                  packet_bank_available_r) &&
                                                 !wr_reset_i;
                        packet_abort_r <= frame_active_r && !packet_duplicate_w &&
                                          (!packet_header_valid_w ||
                                           !packet_sequence_match_w ||
                                           !packet_bank_available_r ||
                                           wr_reset_i);
                        if (!frame_active_r && packet_accept_w) begin
                            start_frame_pending_r <= 1'b1;
                            start_frame_codec_r   <= rec_data_i[1:0];
                        end
                    end
                    default: begin
                    end
                endcase

                // packet_accept_w is registered on header byte 7, so this
                // payload pipeline starts on byte 8 without a byte-index
                // decode in the 125 MHz data path.
                if (payload_room_r) begin
                    case (rgb_phase_r)
                        2'd0: begin
                            rgb_r_r     <= rec_data_i;
                            rgb_phase_r <= 2'd1;
                        end
                        2'd1: begin
                            rgb_g_r     <= rec_data_i;
                            rgb_phase_r <= 2'd2;
                        end
                        default: begin
                            packet_mem_wr_en_r   <= accept_packet_r;
                            packet_mem_wr_bank_r <= packet_bank_r;
                            packet_mem_wr_addr_r <= word_count_r;
                            packet_mem_wr_data_r <= rgb565_word_w;
                            word_count_r         <= word_count_r + 9'd1;
                            rgb_phase_r          <= 2'd0;
                            if (word_count_r == expected_last_word_r) begin
                                payload_room_r <= 1'b0;
                            end
                        end
                    endcase
                end else if (!rec_start_w &&
                             (accept_packet_r || duplicate_packet_r) &&
                             (!packet_crc_en_r ||
                              (byte_idx_r < (expected_packet_bytes_r - 11'd2)))) begin
                    payload_overflow_r <= 1'b1;
                end

                // CRC16-CCITT covers the complete eight-byte EV header and
                // RGB payload. The optional two-byte trailer is big-endian.
                if (rec_start_w) begin
                    crc_calc_r <= crc16_ccitt_byte(16'hffff, rec_data_i);
                end else if (!packet_crc_en_r ||
                             (!crc_hi_phase_r && !crc_lo_phase_r)) begin
                    crc_calc_r <= crc16_ccitt_byte(crc_calc_r, rec_data_i);
                end else if (crc_hi_phase_r) begin
                    crc_received_r[15:8] <= rec_data_i;
                end else if (crc_lo_phase_r) begin
                    crc_received_r[7:0] <= rec_data_i;
                end

                if (byte_idx_r != 11'h7ff)
                    byte_idx_r <= byte_idx_r + 11'd1;
            end

            if (rec_end_w) begin
                last_line_o     <= line_r;
                last_half_o     <= half_r;
                last_chunk_o    <= chunk_r;
                last_words_o    <= reported_words_w;
                last_frame_id_o <= frame_id_r;
                finalize_packet_r         <= (byte_idx_r != 11'd0);
                finalize_good_r           <= accept_packet_r &&
                                             packet_integrity_good_w;
                finalize_duplicate_good_r <= duplicate_packet_r &&
                                             packet_integrity_good_w;
                finalize_frame_member_r   <= packet_frame_member_r;
                finalize_bank_r           <= packet_bank_r;
                finalize_half_r           <= half_r;
                finalize_h2_r             <= codec_h2_r;
                finalize_h2_line_r        <= codec_h2_line_r;
                finalize_last_packet_r    <= last_packet_r;
                finalize_abort_r          <= packet_abort_r;
                finalize_duplicate_r      <= duplicate_packet_r;

                byte_idx_r         <= 11'd0;
                accept_packet_r    <= 1'b0;
                duplicate_packet_r <= 1'b0;
                rgb_phase_r        <= 2'd0;
                word_count_r       <= 9'd0;
                payload_overflow_r <= 1'b0;
                payload_room_r     <= 1'b0;
            end
        end
    end

    always @(posedge wr_clk_i or negedge rst_n) begin
        if (!rst_n) begin
            ready0_wr_sync_r <= 2'b00;
            ready1_wr_sync_r <= 2'b00;
            ready2_wr_sync_r <= 2'b00;
            ready3_wr_sync_r <= 2'b00;
            ack0_toggle_wr_r <= 1'b0;
            ack1_toggle_wr_r <= 1'b0;
            ack2_toggle_wr_r <= 1'b0;
            ack3_toggle_wr_r <= 1'b0;
            wr_active_r      <= 1'b0;
            wr_bank_r        <= 2'd0;
            dequeue_seq_wr_r <= 2'd0;
            wr_half_r        <= 1'b0;
            wr_h2_r          <= 1'b0;
            wr_h2_line_r     <= 1'b0;
            frame_end_wr_sync_r <= 2'b00;
            frame_end_seen_wr_r <= 1'b0;
            frame_done_pending_wr_r <= 1'b0;
            frame_done_delay_wr_r <= 7'd0;
            frame_done_toggle_o <= 1'b0;
            h2_dup_phase_r   <= 1'b0;
            wr_source_words_r <= CHUNK_WORDS;
            wr_output_words_r <= {1'b0, CHUNK_WORDS};
            rd_addr_r        <= 9'd0;
            out_count_r      <= 10'd0;
            rd_data_r        <= 16'd0;
            rd_valid_r       <= 1'b0;
            wr_req0_o        <= 1'b0;
            wr_req1_o        <= 1'b0;
            wr_data_o        <= 16'd0;
        end else begin
            ready0_wr_sync_r <= {ready0_wr_sync_r[0], ready0_toggle_eth_r};
            ready1_wr_sync_r <= {ready1_wr_sync_r[0], ready1_toggle_eth_r};
            ready2_wr_sync_r <= {ready2_wr_sync_r[0], ready2_toggle_eth_r};
            ready3_wr_sync_r <= {ready3_wr_sync_r[0], ready3_toggle_eth_r};
            frame_end_wr_sync_r <= {frame_end_wr_sync_r[0], frame_end_toggle_eth_r};
            wr_req0_o        <= 1'b0;
            wr_req1_o        <= 1'b0;

            if (wr_reset_wr_i) begin
                wr_active_r      <= 1'b0;
                dequeue_seq_wr_r <= 2'd0;
                rd_addr_r        <= 9'd0;
                out_count_r      <= 10'd0;
                rd_valid_r       <= 1'b0;
                h2_dup_phase_r   <= 1'b0;
                wr_source_words_r <= CHUNK_WORDS;
                wr_output_words_r <= {1'b0, CHUNK_WORDS};
                frame_end_seen_wr_r <= frame_end_wr_sync_r[1];
                frame_done_pending_wr_r <= 1'b0;
                frame_done_delay_wr_r <= 7'd0;
                ack0_toggle_wr_r <= ready0_wr_sync_r[1];
                ack1_toggle_wr_r <= ready1_wr_sync_r[1];
                ack2_toggle_wr_r <= ready2_wr_sync_r[1];
                ack3_toggle_wr_r <= ready3_wr_sync_r[1];
            end else begin
                if (frame_end_wr_sync_r[1] != frame_end_seen_wr_r) begin
                    frame_end_seen_wr_r <= frame_end_wr_sync_r[1];
                    frame_done_pending_wr_r <= 1'b1;
                    frame_done_delay_wr_r <= 7'd0;
                end
                if (frame_done_pending_wr_r) begin
                    if (wr_active_r || bank0_ready_wr_w || bank1_ready_wr_w ||
                        bank2_ready_wr_w || bank3_ready_wr_w) begin
                        frame_done_delay_wr_r <= 7'd0;
                    end else if (frame_done_delay_wr_r == FRAME_DONE_PUBLISH_DELAY) begin
                        frame_done_toggle_o <= ~frame_done_toggle_o;
                        frame_done_pending_wr_r <= 1'b0;
                        frame_done_delay_wr_r <= 7'd0;
                    end else begin
                        frame_done_delay_wr_r <= frame_done_delay_wr_r + 7'd1;
                    end
                end
                if (!wr_active_r) begin
                    rd_valid_r     <= 1'b0;
                    rd_addr_r      <= 9'd0;
                    out_count_r    <= 10'd0;
                    h2_dup_phase_r <= 1'b0;
                    if (bank0_ready_wr_w && (bank0_seq_eth_r == dequeue_seq_wr_r)) begin
                        wr_active_r <= 1'b1;
                        wr_bank_r   <= 2'd0;
                        wr_half_r   <= bank0_half_eth_r;
                        wr_h2_r      <= bank0_h2_eth_r;
                        wr_h2_line_r <= bank0_h2_line_eth_r;
                        wr_source_words_r <= bank0_h2_eth_r ?
                                             (bank0_h2_line_eth_r ? CHUNK_WORDS : H2_CHUNK_STORED_WORDS) :
                                             CHUNK_WORDS;
                        wr_output_words_r <= bank0_h2_line_eth_r ? H2_LINE_OUTPUT_WORDS :
                                                                    {1'b0, CHUNK_WORDS};
                    end else if (bank1_ready_wr_w && (bank1_seq_eth_r == dequeue_seq_wr_r)) begin
                        wr_active_r <= 1'b1;
                        wr_bank_r   <= 2'd1;
                        wr_half_r   <= bank1_half_eth_r;
                        wr_h2_r      <= bank1_h2_eth_r;
                        wr_h2_line_r <= bank1_h2_line_eth_r;
                        wr_source_words_r <= bank1_h2_eth_r ?
                                             (bank1_h2_line_eth_r ? CHUNK_WORDS : H2_CHUNK_STORED_WORDS) :
                                             CHUNK_WORDS;
                        wr_output_words_r <= bank1_h2_line_eth_r ? H2_LINE_OUTPUT_WORDS :
                                                                    {1'b0, CHUNK_WORDS};
                    end else if (bank2_ready_wr_w && (bank2_seq_eth_r == dequeue_seq_wr_r)) begin
                        wr_active_r <= 1'b1;
                        wr_bank_r   <= 2'd2;
                        wr_half_r   <= bank2_half_eth_r;
                        wr_h2_r      <= bank2_h2_eth_r;
                        wr_h2_line_r <= bank2_h2_line_eth_r;
                        wr_source_words_r <= bank2_h2_eth_r ?
                                             (bank2_h2_line_eth_r ? CHUNK_WORDS : H2_CHUNK_STORED_WORDS) :
                                             CHUNK_WORDS;
                        wr_output_words_r <= bank2_h2_line_eth_r ? H2_LINE_OUTPUT_WORDS :
                                                                    {1'b0, CHUNK_WORDS};
                    end else if (bank3_ready_wr_w && (bank3_seq_eth_r == dequeue_seq_wr_r)) begin
                        wr_active_r <= 1'b1;
                        wr_bank_r   <= 2'd3;
                        wr_half_r   <= bank3_half_eth_r;
                        wr_h2_r      <= bank3_h2_eth_r;
                        wr_h2_line_r <= bank3_h2_line_eth_r;
                        wr_source_words_r <= bank3_h2_eth_r ?
                                             (bank3_h2_line_eth_r ? CHUNK_WORDS : H2_CHUNK_STORED_WORDS) :
                                             CHUNK_WORDS;
                        wr_output_words_r <= bank3_h2_line_eth_r ? H2_LINE_OUTPUT_WORDS :
                                                                    {1'b0, CHUNK_WORDS};
                    end
                end else if (rd_valid_r) begin
                    wr_data_o <= rd_data_r;
                    wr_req0_o <= ~wr_half_r;
                    wr_req1_o <= wr_half_r;

                    if (wr_output_last_w) begin
                        wr_active_r    <= 1'b0;
                        rd_valid_r     <= 1'b0;
                        h2_dup_phase_r <= 1'b0;
                        dequeue_seq_wr_r <= dequeue_seq_wr_r + 2'd1;
                        case (wr_bank_r)
                            2'd0: ack0_toggle_wr_r <= ~ack0_toggle_wr_r;
                            2'd1: ack1_toggle_wr_r <= ~ack1_toggle_wr_r;
                            2'd2: ack2_toggle_wr_r <= ~ack2_toggle_wr_r;
                            default: ack3_toggle_wr_r <= ~ack3_toggle_wr_r;
                        endcase
                    end else begin
                        out_count_r <= out_count_r + 10'd1;
                        if (wr_h2_r)
                            h2_dup_phase_r <= ~h2_dup_phase_r;
                    end
                end

                if (wr_read_fire_w) begin
                    case (wr_bank_r)
                        2'd0: rd_data_r <= packet_mem0[rd_addr_r];
                        2'd1: rd_data_r <= packet_mem1[rd_addr_r];
                        2'd2: rd_data_r <= packet_mem2[rd_addr_r];
                        default: rd_data_r <= packet_mem3[rd_addr_r];
                    endcase
                    rd_addr_r  <= rd_addr_r + 9'd1;
                    rd_valid_r <= 1'b1;
                end
            end
        end
    end

endmodule
