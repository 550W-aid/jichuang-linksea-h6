@echo off
setlocal EnableExtensions
set "ELINX_PROGRAMMER=D:\eLinx3.0\bin\shell\bin\Programmer_core.exe"
set "ELINX_PROGRAM_TCL=%~dp0program_candidate_jpsk.tcl"
set "ELINX_PROGRAM_LOG=%~dp0program_candidate_last.log"

"%ELINX_PROGRAMMER%" -silence -f "%ELINX_PROGRAM_TCL%" > "%ELINX_PROGRAM_LOG%" 2>&1
type "%ELINX_PROGRAM_LOG%"
findstr /C:"Successful: (No_11)JTAG down FPGA successful." "%ELINX_PROGRAM_LOG%" >nul
if errorlevel 1 (
    echo JTAG programming did not report success.
    exit /b 1
)
exit /b 0
