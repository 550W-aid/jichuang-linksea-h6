# PaperPuppet H6 Standalone Video Chain

This is an independent H6/eLinx board candidate based on the team's stable OV5640, SDRAM, and HDMI project. It is intentionally not merged into the total project.

The candidate defaults to camera pass-through. `KEY2` toggles a frame-latched saturated-color detector and a procedural Sun Wukong overlay. The first stage implements idle following only. The legacy rotation preview framebuffer is disabled, and the source tree contains no explicit `altsyncram` primitive.

The generated programming file is `01_FPGA/ov5640_hdmi_1080p.runs/imple_1/ov5640_hdmi_1080p.jpsk`.

This v9 candidate restores the stable OV5640 -> SDRAM -> HDMI pass-through as the
default path (`PAPER_PUPPET_STANDALONE=1`, puppet enable reset value `0`). The
camera register `3036` is set for an approximately 74.7 MHz PCLK. H6 pack,
zero-error routing, timing, and bitgen passed locally. Hardware acceptance is
still pending: the teammate must program the JPSK and observe the default image
for at least 60 seconds before testing KEY2.
