`timescale 1ns/1ps

// HDMI-domain first-stage paper-puppet detector and procedural overlay.
// The disabled path is a combinational, bit-exact RGB pass-through.
module paper_puppet_h6_overlay #(
    parameter [19:0] DEBOUNCE_COUNT = 20'd742500,
    parameter [19:0] MIN_TARGET_PIXELS = 20'd64
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        key_n,
    input  wire        hsync_i,
    input  wire        vsync_i,
    input  wire        de_i,
    input  wire [11:0] x_i,
    input  wire [11:0] y_i,
    input  wire [23:0] rgb_i,
    output wire [23:0] rgb_o,
    output wire        hsync_o,
    output wire        vsync_o,
    output wire        de_o,
    output reg         puppet_enable,
    output reg         target_valid,
    output reg  [11:0] target_center_x,
    output reg  [11:0] target_center_y
);

wire [7:0] red_w   = rgb_i[23:16];
wire [7:0] green_w = rgb_i[15:8];
wire [7:0] blue_w  = rgb_i[7:0];
wire saturated_w = ((red_w > 8'd150) && ({1'b0, red_w} > {1'b0, green_w} + 9'd45) && ({1'b0, red_w} > {1'b0, blue_w} + 9'd45)) ||
                   ((green_w > 8'd150) && ({1'b0, green_w} > {1'b0, red_w} + 9'd45) && ({1'b0, green_w} > {1'b0, blue_w} + 9'd45)) ||
                   ((blue_w > 8'd150) && ({1'b0, blue_w} > {1'b0, red_w} + 9'd45) && ({1'b0, blue_w} > {1'b0, green_w} + 9'd45));

reg key_meta_r;
reg key_sync_r;
reg key_stable_r;
reg [19:0] key_count_r;
(* preserve *) reg detect_saturated_r;
(* preserve *) reg detect_vsync_r;
reg detect_vsync_d_r;
(* preserve *) reg [11:0] detect_x_r;
(* preserve *) reg [11:0] detect_y_r;
(* preserve *) reg [23:0] detect_rgb_s1_r;
(* preserve *) reg        detect_de_s1_r;
(* preserve *) reg        detect_vsync_s1_r;
(* preserve *) reg [11:0] detect_x_s1_r;
(* preserve *) reg [11:0] detect_y_s1_r;
reg [11:0] min_x_r;
reg [11:0] max_x_r;
reg [11:0] min_y_r;
reg [11:0] max_y_r;
reg [19:0] target_count_r;

wire frame_start_w = detect_vsync_r & ~detect_vsync_d_r;
wire [12:0] center_x_sum_w = {1'b0, min_x_r} + {1'b0, max_x_r};
wire [12:0] center_y_sum_w = {1'b0, min_y_r} + {1'b0, max_y_r};
wire detect_saturated_s1_w = ((detect_rgb_s1_r[23:16] > 8'd150) &&
                              ({1'b0, detect_rgb_s1_r[23:16]} > {1'b0, detect_rgb_s1_r[15:8]} + 9'd45) &&
                              ({1'b0, detect_rgb_s1_r[23:16]} > {1'b0, detect_rgb_s1_r[7:0]} + 9'd45)) ||
                             ((detect_rgb_s1_r[15:8] > 8'd150) &&
                              ({1'b0, detect_rgb_s1_r[15:8]} > {1'b0, detect_rgb_s1_r[23:16]} + 9'd45) &&
                              ({1'b0, detect_rgb_s1_r[15:8]} > {1'b0, detect_rgb_s1_r[7:0]} + 9'd45)) ||
                             ((detect_rgb_s1_r[7:0] > 8'd150) &&
                              ({1'b0, detect_rgb_s1_r[7:0]} > {1'b0, detect_rgb_s1_r[23:16]} + 9'd45) &&
                              ({1'b0, detect_rgb_s1_r[7:0]} > {1'b0, detect_rgb_s1_r[15:8]} + 9'd45));

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        key_meta_r    <= 1'b1;
        key_sync_r    <= 1'b1;
        key_stable_r  <= 1'b1;
        key_count_r   <= 20'd0;
        puppet_enable <= 1'b0;
    end else begin
        key_meta_r <= key_n;
        key_sync_r <= key_meta_r;
        if (key_sync_r == key_stable_r) begin
            key_count_r <= 20'd0;
        end else if (key_count_r >= DEBOUNCE_COUNT - 1'b1) begin
            key_stable_r <= key_sync_r;
            key_count_r  <= 20'd0;
            if (!key_sync_r)
                puppet_enable <= ~puppet_enable;
        end else begin
            key_count_r <= key_count_r + 1'b1;
        end
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        detect_saturated_r <= 1'b0;
        detect_vsync_r     <= 1'b0;
        detect_vsync_d_r   <= 1'b0;
        detect_x_r         <= 12'd0;
        detect_y_r         <= 12'd0;
        detect_rgb_s1_r    <= 24'd0;
        detect_de_s1_r     <= 1'b0;
        detect_vsync_s1_r  <= 1'b0;
        detect_x_s1_r      <= 12'd0;
        detect_y_s1_r      <= 12'd0;
        min_x_r         <= 12'hfff;
        max_x_r         <= 12'd0;
        min_y_r         <= 12'hfff;
        max_y_r         <= 12'd0;
        target_count_r  <= 20'd0;
        target_valid    <= 1'b0;
        target_center_x <= 12'd640;
        target_center_y <= 12'd360;
    end else begin
        detect_rgb_s1_r    <= rgb_i;
        detect_de_s1_r     <= de_i;
        detect_vsync_s1_r  <= vsync_i;
        detect_x_s1_r      <= x_i;
        detect_y_s1_r      <= y_i;
        detect_saturated_r <= detect_de_s1_r && detect_saturated_s1_w;
        detect_vsync_r     <= detect_vsync_s1_r;
        detect_vsync_d_r   <= detect_vsync_r;
        detect_x_r         <= detect_x_s1_r;
        detect_y_r         <= detect_y_s1_r;
        if (frame_start_w) begin
            target_valid <= (target_count_r >= MIN_TARGET_PIXELS);
            if (target_count_r >= MIN_TARGET_PIXELS) begin
                target_center_x <= center_x_sum_w[12:1];
                target_center_y <= center_y_sum_w[12:1];
            end
            min_x_r        <= 12'hfff;
            max_x_r        <= 12'd0;
            min_y_r        <= 12'hfff;
            max_y_r        <= 12'd0;
            target_count_r <= 20'd0;
        end else if (detect_saturated_r) begin
            if (detect_x_r < min_x_r) min_x_r <= detect_x_r;
            if (detect_x_r > max_x_r) max_x_r <= detect_x_r;
            if (detect_y_r < min_y_r) min_y_r <= detect_y_r;
            if (detect_y_r > max_y_r) max_y_r <= detect_y_r;
            if (target_count_r != 20'hfffff)
                target_count_r <= target_count_r + 1'b1;
        end
    end
end

wire [12:0] x_plus_72_w = {1'b0, x_i} + 13'd72;
wire [12:0] x_plus_66_w = {1'b0, x_i} + 13'd66;
wire [12:0] x_plus_48_w = {1'b0, x_i} + 13'd48;
wire [12:0] x_plus_34_w = {1'b0, x_i} + 13'd34;
wire [12:0] x_plus_28_w = {1'b0, x_i} + 13'd28;
wire [12:0] x_plus_18_w = {1'b0, x_i} + 13'd18;
wire [12:0] x_plus_12_w = {1'b0, x_i} + 13'd12;
wire [12:0] x_plus_5_w  = {1'b0, x_i} + 13'd5;
wire [12:0] y_plus_88_w = {1'b0, y_i} + 13'd88;
wire [12:0] y_plus_66_w = {1'b0, y_i} + 13'd66;
wire [12:0] y_plus_58_w = {1'b0, y_i} + 13'd58;
wire [12:0] y_plus_54_w = {1'b0, y_i} + 13'd54;
wire [12:0] y_plus_47_w = {1'b0, y_i} + 13'd47;
wire [12:0] y_plus_41_w = {1'b0, y_i} + 13'd41;
wire [12:0] y_plus_34_w = {1'b0, y_i} + 13'd34;
wire [12:0] y_plus_30_w = {1'b0, y_i} + 13'd30;
wire [12:0] y_plus_22_w = {1'b0, y_i} + 13'd22;
wire [12:0] y_plus_20_w = {1'b0, y_i} + 13'd20;
wire [12:0] cx_w = {1'b0, target_center_x};
wire [12:0] cy_w = {1'b0, target_center_y};

wire staff_w = (x_plus_72_w >= cx_w) && (x_plus_66_w <= cx_w) &&
               (y_plus_88_w >= cy_w) && (y_i <= target_center_y + 12'd74);
wire head_w = (x_plus_28_w >= cx_w) && (x_i <= target_center_x + 12'd28) &&
              (y_plus_66_w >= cy_w) && (y_plus_22_w <= cy_w);
wire ears_w = (x_plus_48_w >= cx_w) && (x_i <= target_center_x + 12'd48) &&
              (y_plus_54_w >= cy_w) && (y_plus_34_w <= cy_w);
wire face_w = (x_plus_18_w >= cx_w) && (x_i <= target_center_x + 12'd18) &&
              (y_plus_58_w >= cy_w) && (y_plus_30_w <= cy_w);
wire body_w = (x_plus_34_w >= cx_w) && (x_i <= target_center_x + 12'd34) &&
              (y_plus_20_w >= cy_w) && (y_i <= target_center_y + 12'd58);
wire belt_w = body_w && (y_i >= target_center_y + 12'd18) && (y_i <= target_center_y + 12'd25);
wire eye_w = ((x_plus_12_w >= cx_w) && (x_plus_5_w <= cx_w) ||
              (x_i >= target_center_x + 12'd5) && (x_i <= target_center_x + 12'd12)) &&
             (y_plus_47_w >= cy_w) && (y_plus_41_w <= cy_w);
wire overlay_w = target_valid && (staff_w || head_w || ears_w || body_w);

(* preserve *) reg [23:0] rgb_s1_r;
(* preserve *) reg        hsync_s1_r;
(* preserve *) reg        vsync_s1_r;
(* preserve *) reg        de_s1_r;
(* preserve *) reg        puppet_enable_s1_r;
(* preserve *) reg        overlay_s1_r;
(* preserve *) reg        staff_s1_r;
(* preserve *) reg        head_s1_r;
(* preserve *) reg        ears_s1_r;
(* preserve *) reg        face_s1_r;
(* preserve *) reg        belt_s1_r;
(* preserve *) reg        eye_s1_r;
(* preserve *) reg [23:0] rgb_out_r;
(* preserve *) reg        hsync_out_r;
(* preserve *) reg        vsync_out_r;
(* preserve *) reg        de_out_r;

assign rgb_o   = rgb_out_r;
assign hsync_o = hsync_out_r;
assign vsync_o = vsync_out_r;
assign de_o    = de_out_r;

// Split the shape comparisons from the final RGB mux. This keeps the HDMI
// pixel path registered while delaying RGB and timing signals equally.
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        rgb_s1_r           <= 24'd0;
        hsync_s1_r         <= 1'b0;
        vsync_s1_r         <= 1'b0;
        de_s1_r            <= 1'b0;
        puppet_enable_s1_r <= 1'b0;
        overlay_s1_r       <= 1'b0;
        staff_s1_r         <= 1'b0;
        head_s1_r          <= 1'b0;
        ears_s1_r          <= 1'b0;
        face_s1_r          <= 1'b0;
        belt_s1_r          <= 1'b0;
        eye_s1_r           <= 1'b0;
    end else begin
        rgb_s1_r           <= rgb_i;
        hsync_s1_r         <= hsync_i;
        vsync_s1_r         <= vsync_i;
        de_s1_r            <= de_i;
        puppet_enable_s1_r <= puppet_enable;
        overlay_s1_r       <= overlay_w;
        staff_s1_r         <= staff_w;
        head_s1_r          <= head_w;
        ears_s1_r          <= ears_w;
        face_s1_r          <= face_w;
        belt_s1_r          <= belt_w;
        eye_s1_r           <= eye_w;
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        rgb_out_r   <= 24'd0;
        hsync_out_r <= 1'b0;
        vsync_out_r <= 1'b0;
        de_out_r    <= 1'b0;
    end else begin
        hsync_out_r <= hsync_s1_r;
        vsync_out_r <= vsync_s1_r;
        de_out_r    <= de_s1_r;
        if (!puppet_enable_s1_r || !de_s1_r || !overlay_s1_r)
            rgb_out_r <= rgb_s1_r;
        else if (staff_s1_r)
            rgb_out_r <= 24'hD8B020;
        else if (eye_s1_r)
            rgb_out_r <= 24'hFFF060;
        else if (face_s1_r)
            rgb_out_r <= 24'hF0B070;
        else if (belt_s1_r)
            rgb_out_r <= 24'hFFD020;
        else if (head_s1_r)
            rgb_out_r <= 24'hC02020;
        else if (ears_s1_r)
            rgb_out_r <= 24'hB01818;
        else
            rgb_out_r <= 24'h901010;
    end
end

endmodule
