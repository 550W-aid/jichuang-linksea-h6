// ============================================================================
// Module Function:
//   BRAM-backed preview frame store and rotated-preview pixel generator.
//   Integrated build uses the routed 480x270 RGB454 even/odd-column banking.
// ============================================================================
`timescale 1ns / 1ps

module rotate_bram_preview #(
    parameter integer SRC_FRAME_W = 1280,
    parameter integer SRC_FRAME_H = 720,
    parameter integer PREVIEW_W   = 256,
    parameter integer PREVIEW_H   = 144,
    parameter integer PIPE_LATENCY = 8
) (
    input  wire              wr_clk_i,
    input  wire              wr_rst_n_i,
    input  wire              wr_valid_i,
    input  wire [10:0]       wr_x_i,
    input  wire [10:0]       wr_y_i,
    input  wire [15:0]       wr_data_i,

    input  wire              rd_clk_i,
    input  wire              rd_rst_n_i,
    input  wire              enable_i,
    input  wire signed [8:0] angle_deg_i,
    input  wire              video_hs_i,
    input  wire              video_vs_i,
    input  wire              video_de_i,
    input  wire [23:0]       video_rgb_i,
    input  wire [11:0]       pixel_x_i,
    input  wire [11:0]       pixel_y_i,
    output wire              video_hs_o,
    output wire              video_vs_o,
    output wire              video_de_o,
    output wire [23:0]       video_rgb_o,
    output wire              preview_active_o
);

    function integer clog2;
        input integer value;
        integer i;
        begin
            value = value - 1;
            for (i = 0; value > 0; i = i + 1) begin
                value = value >> 1;
            end
            clog2 = (i == 0) ? 1 : i;
        end
    endfunction

    // When the preview needs two BRAM banks, interleave them by column parity
    // instead of splitting the image into left/right halves.
    localparam integer BANK_STRIDE    =
        (PREVIEW_W > 256) ? ((PREVIEW_W + 1) / 2) : PREVIEW_W;
    localparam integer BANK_PIXELS    = BANK_STRIDE * PREVIEW_H;
    localparam integer BANK_ADDR_BITS = clog2(BANK_PIXELS);

    reg signed [8:0] angle_active_r;
    reg              coord_cfg_valid_r;
    reg [2:0]        cfg_settle_r;
    reg [BANK_ADDR_BITS-1:0] rd_addr_r;
    reg              rd_bank_r;
    reg              rd_addr_inside_r;
    reg              rd_bank_q;
    reg [12:0]       rd_pixel_q;
    reg              rd_inside_q;
    reg              rd_inside_q2;
    reg              wr_take_r;
    reg              wr_bank_r;
    reg [BANK_ADDR_BITS-1:0] wr_addr_r;
    reg [12:0]       wr_data_454_r;

    reg [PIPE_LATENCY-1:0] hs_pipe_r;
    reg [PIPE_LATENCY-1:0] vs_pipe_r;
    reg [PIPE_LATENCY-1:0] de_pipe_r;
    reg [PIPE_LATENCY-1:0] en_pipe_r;
    (* preserve *) reg [23:0] rgb_pipe0_r;
    (* preserve *) reg [23:0] rgb_pipe1_r;
    (* preserve *) reg [23:0] rgb_pipe2_r;
    (* preserve *) reg [23:0] rgb_pipe3_r;
    (* preserve *) reg [23:0] rgb_pipe4_r;
    (* preserve *) reg [23:0] rgb_pipe5_r;
    (* preserve *) reg [23:0] rgb_pipe6_r;
    (* preserve *) reg [23:0] rgb_pipe7_r;

    wire                   wr_take_w;
    wire                   wr_bank_w;
    wire [16:0]            wr_addr_w;
    wire [12:0]            wr_data_454_w;
    wire                   rd_frame_start_w;
    wire                   coord_req_valid_w;
    wire [15:0]            req_out_x_w;
    wire [15:0]            req_out_y_w;
    wire signed [31:0]     src_x_w;
    wire signed [31:0]     src_y_w;
    wire                   src_inside_w;
    wire                   src_valid_w;
    wire                   rd_bank_w;
    wire [15:0]            rd_bank_x_w;
    wire [BANK_ADDR_BITS-1:0] rd_bank_x_addr_w;
    wire [BANK_ADDR_BITS-1:0] rd_addr_w;
    wire [12:0]            preview_mem0_q_w;
    wire [12:0]            preview_mem1_q_w;
    wire [23:0]            rd_rgb_w;

    function [BANK_ADDR_BITS-1:0] bank_row_addr_fn;
        input [15:0] y;
        begin
            if (BANK_STRIDE == 256) begin
                bank_row_addr_fn = (y << 8);
            end else begin
                bank_row_addr_fn = y * BANK_STRIDE;
            end
        end
    endfunction

    function [12:0] rgb565_to_454_fn;
        input [15:0] p;
        begin
            rgb565_to_454_fn = {p[15:12], p[10:6], p[4:1]};
        end
    endfunction

    function [23:0] rgb454_to_888_fn;
        input [12:0] p;
        begin
            rgb454_to_888_fn = {
                p[12:9], p[12:9],
                p[8:4],  p[8:6],
                p[3:0],  p[3:0]
            };
        end
    endfunction

    function [15:0] preview_x_from_hdmi_fn;
        input [11:0] pixel_x;
        reg [13:0] scaled_r;
        begin
            if ((SRC_FRAME_W == 1920) && (PREVIEW_W == 256)) begin
                preview_x_from_hdmi_fn = {5'd0, pixel_x[10:3]};
            end else if ((SRC_FRAME_W == 1280) && (PREVIEW_W == 480)) begin
                scaled_r = ({2'd0, pixel_x} << 1) + {2'd0, pixel_x};
                preview_x_from_hdmi_fn = {7'd0, scaled_r[11:3]};
            end else if ((SRC_FRAME_W == 1280) && (PREVIEW_W == 640)) begin
                preview_x_from_hdmi_fn = ({4'd0, pixel_x} >> 1);
            end else if ((SRC_FRAME_W == 1280) && (PREVIEW_W == 512)) begin
                scaled_r = {1'd0, pixel_x, 1'b0};
                preview_x_from_hdmi_fn = scaled_r / 14'd5;
            end else begin
                preview_x_from_hdmi_fn = {6'd0, pixel_x[11:2]};
            end
        end
    endfunction

    function [15:0] preview_y_from_hdmi_fn;
        input [11:0] pixel_y;
        reg [13:0] scaled_r;
        begin
            if ((SRC_FRAME_H == 1080) && (PREVIEW_H == 144)) begin
                preview_y_from_hdmi_fn = {5'd0, pixel_y[10:3]};
            end else if ((SRC_FRAME_H == 720) && (PREVIEW_H == 270)) begin
                scaled_r = ({2'd0, pixel_y} << 1) + {2'd0, pixel_y};
                preview_y_from_hdmi_fn = {7'd0, scaled_r[11:3]};
            end else if ((SRC_FRAME_H == 720) && (PREVIEW_H == 360)) begin
                preview_y_from_hdmi_fn = ({4'd0, pixel_y} >> 1);
            end else if ((SRC_FRAME_H == 720) && (PREVIEW_H == 288)) begin
                scaled_r = {1'd0, pixel_y, 1'b0};
                preview_y_from_hdmi_fn = scaled_r / 14'd5;
            end else begin
                preview_y_from_hdmi_fn = {6'd0, pixel_y[11:2]};
            end
        end
    endfunction

    assign wr_data_454_w    = rgb565_to_454_fn(wr_data_i);
    assign rd_frame_start_w = video_de_i && (pixel_x_i == 12'd0) && (pixel_y_i == 12'd0);
    assign coord_req_valid_w = enable_i && video_de_i && (cfg_settle_r == 3'd0);
    assign req_out_x_w      = preview_x_from_hdmi_fn(pixel_x_i);
    assign req_out_y_w      = preview_y_from_hdmi_fn(pixel_y_i);
    assign rd_bank_w        = (PREVIEW_W > 256) ? src_x_w[0] : 1'b0;
    assign rd_bank_x_w      = (PREVIEW_W > 256) ? src_x_w[15:1] : src_x_w[15:0];
    assign rd_bank_x_addr_w = rd_bank_x_w;
    assign rd_addr_w        = bank_row_addr_fn(src_y_w[15:0]) + rd_bank_x_addr_w;
    assign rd_rgb_w         = rgb454_to_888_fn(rd_pixel_q);
    assign preview_active_o = enable_i;

    assign video_hs_o  = hs_pipe_r[PIPE_LATENCY-1];
    assign video_vs_o  = vs_pipe_r[PIPE_LATENCY-1];
    assign video_de_o  = de_pipe_r[PIPE_LATENCY-1];
    assign video_rgb_o = de_pipe_r[PIPE_LATENCY-1] ?
                         (en_pipe_r[PIPE_LATENCY-1] ?
                          (rd_inside_q2 ? rd_rgb_w : 24'd0) :
                         rgb_pipe7_r) :
                         24'd0;

    altsyncram preview_mem0 (
        .clock0   (wr_clk_i),
        .clock1   (rd_clk_i),
        .wren_a   (wr_take_r && !wr_bank_r),
        .address_a(wr_addr_r),
        .data_a   (wr_data_454_r),
        .address_b(rd_addr_r),
        .q_b      (preview_mem0_q_w),
        .aclr0    (1'b0),
        .aclr1    (1'b0),
        .addressstall_a(1'b0),
        .addressstall_b(1'b0),
        .byteena_a(1'b1),
        .q_a      (),
        .eccstatus()
    );
    defparam
        preview_mem0.operation_mode = "DUAL_PORT",
        preview_mem0.width_a = 13,
        preview_mem0.widthad_a = BANK_ADDR_BITS,
        preview_mem0.numwords_a = BANK_PIXELS,
        preview_mem0.width_b = 13,
        preview_mem0.widthad_b = BANK_ADDR_BITS,
        preview_mem0.numwords_b = BANK_PIXELS,
        preview_mem0.outdata_reg_b = "UNREGISTERED",
        preview_mem0.address_reg_b = "CLOCK1",
        preview_mem0.width_byteena_a = 1,
        preview_mem0.byte_size = 8,
        preview_mem0.read_during_write_mode_mixed_ports = "DONT_CARE",
        preview_mem0.ram_block_type = "M4K",
        preview_mem0.device_family = "Stratix",
        preview_mem0.power_up_uninitialized = "TRUE",
        preview_mem0.init_file = "UNUSED";

    altsyncram preview_mem1 (
        .clock0   (wr_clk_i),
        .clock1   (rd_clk_i),
        .wren_a   (wr_take_r && wr_bank_r),
        .address_a(wr_addr_r),
        .data_a   (wr_data_454_r),
        .address_b(rd_addr_r),
        .q_b      (preview_mem1_q_w),
        .aclr0    (1'b0),
        .aclr1    (1'b0),
        .addressstall_a(1'b0),
        .addressstall_b(1'b0),
        .byteena_a(1'b1),
        .q_a      (),
        .eccstatus()
    );
    defparam
        preview_mem1.operation_mode = "DUAL_PORT",
        preview_mem1.width_a = 13,
        preview_mem1.widthad_a = BANK_ADDR_BITS,
        preview_mem1.numwords_a = BANK_PIXELS,
        preview_mem1.width_b = 13,
        preview_mem1.widthad_b = BANK_ADDR_BITS,
        preview_mem1.numwords_b = BANK_PIXELS,
        preview_mem1.outdata_reg_b = "UNREGISTERED",
        preview_mem1.address_reg_b = "CLOCK1",
        preview_mem1.width_byteena_a = 1,
        preview_mem1.byte_size = 8,
        preview_mem1.read_during_write_mode_mixed_ports = "DONT_CARE",
        preview_mem1.ram_block_type = "M4K",
        preview_mem1.device_family = "Stratix",
        preview_mem1.power_up_uninitialized = "TRUE",
        preview_mem1.init_file = "UNUSED";

    rotate_preview_capture_map_720p #(
        .SRC_FRAME_W(SRC_FRAME_W),
        .SRC_FRAME_H(SRC_FRAME_H),
        .PREVIEW_W  (PREVIEW_W),
        .PREVIEW_H  (PREVIEW_H)
    ) u_capture_map (
        .src_x_i    (wr_x_i),
        .src_y_i    (wr_y_i),
        .src_valid_i(wr_valid_i),
        .take_o     (wr_take_w),
        .bank_o     (wr_bank_w),
        .addr_o     (wr_addr_w)
    );

    rotate_coordinate_map #(
        .IMAGE_W(PREVIEW_W),
        .IMAGE_H(PREVIEW_H),
        .FORCE_RAW_COPY(0)
    ) u_preview_coord (
        .clk             (rd_clk_i),
        .rst_n           (rd_rst_n_i),
        .cfg_valid       (coord_cfg_valid_r),
        .cfg_ready       (),
        .cfg_angle_deg   (angle_active_r),
        .request_valid   (coord_req_valid_w),
        .request_sof     (rd_frame_start_w),
        .out_x           (req_out_x_w),
        .out_y           (req_out_y_w),
        .active_angle_deg(),
        .src_x           (src_x_w),
        .src_y           (src_y_w),
        .src_inside      (src_inside_w),
        .src_valid       (src_valid_w)
    );

    always @(posedge wr_clk_i or negedge wr_rst_n_i) begin
        if (!wr_rst_n_i) begin
            wr_take_r     <= 1'b0;
            wr_bank_r     <= 1'b0;
            wr_addr_r     <= {BANK_ADDR_BITS{1'b0}};
            wr_data_454_r <= 13'd0;
        end else begin
            wr_take_r     <= wr_take_w;
            wr_bank_r     <= wr_bank_w;
            wr_addr_r     <= wr_addr_w[BANK_ADDR_BITS-1:0];
            wr_data_454_r <= wr_data_454_w;
        end
    end

    always @(posedge rd_clk_i or negedge rd_rst_n_i) begin
        if (!rd_rst_n_i) begin
            angle_active_r    <= 9'sd0;
            coord_cfg_valid_r <= 1'b0;
            cfg_settle_r      <= 3'd0;
            rd_addr_r         <= {BANK_ADDR_BITS{1'b0}};
            rd_bank_r         <= 1'b0;
            rd_addr_inside_r  <= 1'b0;
            rd_bank_q         <= 1'b0;
            rd_pixel_q        <= 13'd0;
            rd_inside_q       <= 1'b0;
            rd_inside_q2      <= 1'b0;
            hs_pipe_r         <= {PIPE_LATENCY{1'b1}};
            vs_pipe_r         <= {PIPE_LATENCY{1'b1}};
            de_pipe_r         <= {PIPE_LATENCY{1'b0}};
            en_pipe_r         <= {PIPE_LATENCY{1'b0}};
            rgb_pipe0_r       <= 24'd0;
            rgb_pipe1_r       <= 24'd0;
            rgb_pipe2_r       <= 24'd0;
            rgb_pipe3_r       <= 24'd0;
            rgb_pipe4_r       <= 24'd0;
            rgb_pipe5_r       <= 24'd0;
            rgb_pipe6_r       <= 24'd0;
            rgb_pipe7_r       <= 24'd0;
        end else begin
            coord_cfg_valid_r <= 1'b0;
            if (angle_deg_i != angle_active_r) begin
                angle_active_r    <= angle_deg_i;
                coord_cfg_valid_r <= 1'b1;
                cfg_settle_r      <= 3'd4;
            end else if (cfg_settle_r != 3'd0) begin
                cfg_settle_r <= cfg_settle_r - 3'd1;
            end

            hs_pipe_r   <= {hs_pipe_r[PIPE_LATENCY-2:0], video_hs_i};
            vs_pipe_r   <= {vs_pipe_r[PIPE_LATENCY-2:0], video_vs_i};
            de_pipe_r   <= {de_pipe_r[PIPE_LATENCY-2:0], video_de_i};
            en_pipe_r   <= {en_pipe_r[PIPE_LATENCY-2:0], enable_i};
            rgb_pipe0_r <= video_rgb_i;
            rgb_pipe1_r <= rgb_pipe0_r;
            rgb_pipe2_r <= rgb_pipe1_r;
            rgb_pipe3_r <= rgb_pipe2_r;
            rgb_pipe4_r <= rgb_pipe3_r;
            rgb_pipe5_r <= rgb_pipe4_r;
            rgb_pipe6_r <= rgb_pipe5_r;
            rgb_pipe7_r <= rgb_pipe6_r;

            if (src_valid_w) begin
                rd_addr_r        <= src_inside_w ? rd_addr_w : {BANK_ADDR_BITS{1'b0}};
                rd_bank_r        <= src_inside_w ? rd_bank_w : 1'b0;
                rd_addr_inside_r <= src_inside_w;
            end

            rd_bank_q    <= rd_bank_r;
            rd_inside_q  <= rd_addr_inside_r;
            rd_pixel_q   <= rd_bank_q ? preview_mem1_q_w : preview_mem0_q_w;
            rd_inside_q2 <= rd_inside_q;
        end
    end

endmodule
