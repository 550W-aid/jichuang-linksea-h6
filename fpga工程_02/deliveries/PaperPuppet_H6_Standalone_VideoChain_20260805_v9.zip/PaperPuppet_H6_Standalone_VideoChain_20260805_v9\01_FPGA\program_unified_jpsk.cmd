@echo off
setlocal EnableExtensions
set "ELINX_PROGRAMMER=D:\eLinx3.0\bin\shell\bin\Programmer_core.exe"
if not exist "%ELINX_PROGRAMMER%" set "ELINX_PROGRAMMER=D:\eLinx\eLinx3.0\bin\shell\bin\Programmer_core.exe"
set "ELINX_PROGRAM_TCL=%~dp0program_unified_jpsk.tcl"

if not exist "%ELINX_PROGRAMMER%" (
    echo ERROR: Programmer_core.exe was not found.
    exit /b 2
)

"%ELINX_PROGRAMMER%" -silence -f "%ELINX_PROGRAM_TCL%"
exit /b %ERRORLEVEL%
