set script_dir [file dirname [file normalize [info script]]]
set bitstream [file normalize [file join $script_dir "bitstreams" "CICC1001959_20260722_480x270_ETH30_Retinex_MultiExposure_BOARDTEST.jpsk"]]
puts "Programming $bitstream"
catch {send_rawpsk_usb2cable2jtag2fpga $bitstream EQ6HL130} result
puts $result
