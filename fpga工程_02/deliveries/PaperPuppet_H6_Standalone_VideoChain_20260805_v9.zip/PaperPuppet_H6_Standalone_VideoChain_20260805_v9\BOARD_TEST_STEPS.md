# PaperPuppet H6 v9 Board Test Steps

## Acceptance Priority

This candidate addresses the prior default-camera tearing report. Do not test
the overlay until Test A has passed. The expected reset state is camera
pass-through with puppet mode disabled.

## Equipment

- H6 board with `EQ6HL130 / CSG484_H`
- OV5640 camera connected as used by the stable reference project
- HDMI transmitter/display connected as used by the stable reference project
- eLinx USB/JTAG cable and eLinx 3.0 programmer
- A matte, strongly saturated red, green, or blue paper target

## Program

1. Power the board and connect JTAG, OV5640, and HDMI.
2. Run `01_FPGA\program_paper_puppet_jpsk.cmd`.
3. Require the programmer log to contain `JTAG down FPGA successful`.
4. If programming fails, do not continue functional acceptance. Save `01_FPGA\program_paper_puppet_last.log`.

## Test A: Default Camera Pass-Through

1. Reset or power-cycle the board. Puppet mode defaults to disabled.
2. Confirm the display locks to HDMI and shows the live OV5640 image.
3. Observe for at least 60 seconds, including at least one camera scene change.
4. Reject on no signal, black screen, repeated horizontal tearing, unstable sync, or persistent pixel displacement.

## Test B: Puppet Overlay

1. Press and release `KEY2` once. The input is synchronized and debounced; one press toggles puppet mode.
2. Move a saturated red, green, or blue paper target into the camera image.
3. Confirm a red/gold procedural Sun Wukong silhouette appears near the target and follows it frame by frame.
4. Move the target through the center and four quadrants. Confirm the background remains live and the overlay does not cause loss of HDMI sync.
5. Press and release `KEY2` again. Confirm the overlay disappears and camera pass-through remains.

## Evidence To Return

- Programmer log
- 20 to 30 second video showing power/reset, default camera image, KEY2 enable, target following, and KEY2 disable
- Display model/resolution used
- Any observed offset between target and overlay center
- Pass/fail for programming, default HDMI, and puppet overlay

## Rollback

If HDMI does not lock after programming, load the team's current stable total-project-C `.jpsk` and confirm the camera/display hardware still works before reporting a candidate regression.
