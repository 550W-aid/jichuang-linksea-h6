// ============================================================================
// Module Function:
//   UART-accessible control/status register block used by the rotation command interface.
// ============================================================================
`timescale 1ns / 1ps

module uart_ctrl_regs (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [7:0]  rx_data_i,
    input  wire        rx_valid_i,
    output wire [7:0]  tx_data_o,
    output wire        tx_valid_o,
    input  wire        tx_ready_i,
    output wire [15:0] mode_o,
    output wire [15:0] algo_enable_o,
    output wire [15:0] brightness_gain_o,
    output wire [15:0] gamma_sel_o,
    output wire [15:0] scale_sel_o,
    output wire [15:0] rotate_sel_o,
    output wire [15:0] rotate_angle_deg_o,
    output wire        rotate_cfg_toggle_o,
    output wire [15:0] edge_sel_o,
    output wire [15:0] osd_sel_o,
    output wire [15:0] cam_cmd_o,
    output wire [15:0] cam_reg_addr_o,
    output wire [15:0] cam_wr_data_o,
    input  wire [15:0] status_reg_i,
    input  wire [15:0] fps_counter_i,
    input  wire [15:0] heartbeat_i,
    input  wire [15:0] rotate_active_angle_i,
    input  wire [15:0] rotate_status_i,
    input  wire [15:0] rotate_debug0_i,
    input  wire [15:0] rotate_debug1_i,
    input  wire [15:0] cam_rd_data_i,
    input  wire [15:0] cam_status_i,
    input  wire [15:0] cam_frame_count_i,
    input  wire [15:0] cam_line_count_i,
    input  wire [15:0] cam_last_pixel_i,
    input  wire [15:0] cam_error_count_i
);

    localparam [7:0] FRAME_HEAD   = 8'h55;
    localparam [7:0] RESP_HEAD    = 8'hAA;
    localparam [7:0] CMD_WRITE    = 8'h01;
    localparam [7:0] CMD_READ     = 8'h02;
    localparam [7:0] CMD_PING     = 8'h03;
    localparam [7:0] STATUS_OK    = 8'h00;
    localparam [7:0] STATUS_CSUM  = 8'hE0;
    localparam [7:0] STATUS_CMD   = 8'hE1;
    localparam [7:0] STATUS_ADDR  = 8'hE2;
    localparam [15:0] BRIGHTNESS_DEFAULT = 16'h0010;
    localparam integer CMD_FIFO_DEPTH = 8;

    reg [2:0]  rx_idx_r;
    reg        rx_active_r;
    reg [7:0]  frame_cmd_r;
    reg [7:0]  frame_addr_r;
    reg [15:0] frame_value_r;

    reg [15:0] ctrl_shadow_r [0:7];
    reg [15:0] rotate_angle_deg_r;
    reg        rotate_cfg_toggle_r;
    reg [15:0] cam_shadow_r  [0:2];

    reg        tx_active_r;
    reg [2:0]  tx_idx_r;
    reg [7:0]  resp_status_r;
    reg [7:0]  resp_addr_r;
    reg [15:0] resp_value_r;

    reg        rw_read_pending_r;
    reg [7:0]  rw_read_addr_r;
    reg [3:0]  rw_read_index_r;
    reg        boot_brightness_init_r;
    reg        rw_mem_wren_r;
    reg [3:0]  rw_mem_waddr_r;
    reg [15:0] rw_mem_wdata_r;
    reg [15:0] ro_read_data_r;
    reg [7:0]  cmd_fifo_cmd_r [0:CMD_FIFO_DEPTH-1];
    reg [7:0]  cmd_fifo_addr_r [0:CMD_FIFO_DEPTH-1];
    reg [15:0] cmd_fifo_value_r [0:CMD_FIFO_DEPTH-1];
    reg        cmd_fifo_csum_ok_r [0:CMD_FIFO_DEPTH-1];
    reg [2:0]  cmd_fifo_wr_ptr_r;
    reg [2:0]  cmd_fifo_rd_ptr_r;
    reg [3:0]  cmd_fifo_count_r;

    wire [7:0]  resp_checksum_w;
    wire [7:0]  proc_cmd_w;
    wire [7:0]  proc_addr_w;
    wire [15:0] proc_value_w;
    wire        proc_csum_ok_w;
    wire        addr_bank_ok_w;
    wire        addr_ctrl_main_rw_w;
    wire        addr_rotate_angle_rw_w;
    wire        addr_status_ro_w;
    wire        addr_cam_range_w;
    wire        addr_cam_rw_w;
    wire        addr_cam_ro_w;
    wire [3:0]  rw_index_w;
    wire        read_addr_valid_w;
    wire        rw_read_addr_valid_w;
    wire [3:0]  rw_mem_raddr_w;
    wire [15:0] rw_mem_rdata_w;
    wire        use_boot_brightness_w;

    assign mode_o              = ctrl_shadow_r[0];
    assign algo_enable_o       = ctrl_shadow_r[1];
    assign brightness_gain_o   = ctrl_shadow_r[2];
    assign gamma_sel_o         = ctrl_shadow_r[3];
    assign scale_sel_o         = ctrl_shadow_r[4];
    assign rotate_sel_o        = ctrl_shadow_r[5];
    assign rotate_angle_deg_o  = rotate_angle_deg_r;
    assign rotate_cfg_toggle_o = rotate_cfg_toggle_r;
    assign edge_sel_o          = ctrl_shadow_r[6];
    assign osd_sel_o           = ctrl_shadow_r[7];
    assign cam_cmd_o           = cam_shadow_r[0];
    assign cam_reg_addr_o      = cam_shadow_r[1];
    assign cam_wr_data_o       = cam_shadow_r[2];

    assign tx_valid_o = tx_active_r;
    assign resp_checksum_w = RESP_HEAD ^ resp_status_r ^ resp_addr_r ^
                             resp_value_r[15:8] ^ resp_value_r[7:0];
    assign proc_cmd_w             = cmd_fifo_cmd_r[cmd_fifo_rd_ptr_r];
    assign proc_addr_w            = cmd_fifo_addr_r[cmd_fifo_rd_ptr_r];
    assign proc_value_w           = cmd_fifo_value_r[cmd_fifo_rd_ptr_r];
    assign proc_csum_ok_w         = cmd_fifo_csum_ok_r[cmd_fifo_rd_ptr_r];
    assign addr_bank_ok_w         = (proc_addr_w[7:5] == 3'b000);
    assign addr_ctrl_main_rw_w    = addr_bank_ok_w & (proc_addr_w <= 8'h07);
    assign addr_rotate_angle_rw_w = addr_bank_ok_w & (proc_addr_w == 8'h0B);
    assign addr_status_ro_w       = addr_bank_ok_w &
                                    ((proc_addr_w == 8'h08) ||
                                     (proc_addr_w == 8'h09) ||
                                     (proc_addr_w == 8'h0A) ||
                                     (proc_addr_w == 8'h0C) ||
                                     (proc_addr_w == 8'h0D) ||
                                     (proc_addr_w == 8'h0E) ||
                                     (proc_addr_w == 8'h0F));
    assign addr_cam_range_w       = addr_bank_ok_w &  proc_addr_w[4] & (proc_addr_w[3:0] < 4'd9);
    assign addr_cam_rw_w          = addr_cam_range_w & (proc_addr_w[3:0] < 4'd3);
    assign addr_cam_ro_w          = addr_cam_range_w & ~addr_cam_rw_w;
    assign rw_index_w             = addr_ctrl_main_rw_w ? {1'b0, proc_addr_w[2:0]} :
                                    (addr_rotate_angle_rw_w ? 4'hB :
                                     (4'd8 + {2'd0, proc_addr_w[1:0]}));
    assign rw_mem_raddr_w         = rw_read_pending_r ? rw_read_index_r : rw_index_w;
    assign rw_read_addr_valid_w   = addr_ctrl_main_rw_w | addr_rotate_angle_rw_w | addr_cam_rw_w;
    assign read_addr_valid_w      = rw_read_addr_valid_w | addr_status_ro_w | addr_cam_ro_w;
    assign use_boot_brightness_w  = boot_brightness_init_r & (proc_addr_w == 8'h02);

    assign tx_data_o =
        (tx_idx_r == 3'd0) ? RESP_HEAD :
        (tx_idx_r == 3'd1) ? resp_status_r :
        (tx_idx_r == 3'd2) ? resp_addr_r :
        (tx_idx_r == 3'd3) ? resp_value_r[15:8] :
        (tx_idx_r == 3'd4) ? resp_value_r[7:0] :
                             resp_checksum_w;

    altsyncram rw_regfile_inst (
        .clock0        (clk),
        .wren_a        (rw_mem_wren_r),
        .address_a     (rw_mem_waddr_r),
        .data_a        (rw_mem_wdata_r),
        .address_b     (rw_mem_raddr_w),
        .q_b           (rw_mem_rdata_w),
        .aclr0         (1'b0),
        .addressstall_a(1'b0),
        .byteena_a     (1'b1),
        .q_a           (),
        .eccstatus     ()
    );
    defparam
        rw_regfile_inst.operation_mode = "DUAL_PORT",
        rw_regfile_inst.width_a = 16,
        rw_regfile_inst.widthad_a = 4,
        rw_regfile_inst.numwords_a = 16,
        rw_regfile_inst.width_b = 16,
        rw_regfile_inst.widthad_b = 4,
        rw_regfile_inst.numwords_b = 16,
        rw_regfile_inst.outdata_reg_b = "UNREGISTERED",
        rw_regfile_inst.address_reg_b = "CLOCK0",
        rw_regfile_inst.width_byteena_a = 1,
        rw_regfile_inst.byte_size = 8,
        rw_regfile_inst.read_during_write_mode_mixed_ports = "DONT_CARE",
        rw_regfile_inst.ram_block_type = "M4K",
        rw_regfile_inst.device_family = "Stratix",
        rw_regfile_inst.power_up_uninitialized = "FALSE",
        rw_regfile_inst.init_file = "UNUSED";

    function frame_checksum_ok;
        input [7:0] cmd;
        input [7:0] addr;
        input [15:0] value;
        input [7:0] checksum;
        begin
            frame_checksum_ok = (FRAME_HEAD ^ cmd ^ addr ^ value[15:8] ^ value[7:0]) == checksum;
        end
    endfunction

    function [15:0] rw_shadow_read_data_fn;
        input [7:0] addr;
        begin
            case (addr)
                8'h00: rw_shadow_read_data_fn = ctrl_shadow_r[0];
                8'h01: rw_shadow_read_data_fn = ctrl_shadow_r[1];
                8'h02: rw_shadow_read_data_fn = ctrl_shadow_r[2];
                8'h03: rw_shadow_read_data_fn = ctrl_shadow_r[3];
                8'h04: rw_shadow_read_data_fn = ctrl_shadow_r[4];
                8'h05: rw_shadow_read_data_fn = ctrl_shadow_r[5];
                8'h06: rw_shadow_read_data_fn = ctrl_shadow_r[6];
                8'h07: rw_shadow_read_data_fn = ctrl_shadow_r[7];
                8'h0B: rw_shadow_read_data_fn = rotate_angle_deg_r;
                8'h10: rw_shadow_read_data_fn = cam_shadow_r[0];
                8'h11: rw_shadow_read_data_fn = cam_shadow_r[1];
                default: rw_shadow_read_data_fn = cam_shadow_r[2];
            endcase
        end
    endfunction

    always @* begin
        ro_read_data_r = 16'h0000;

        if (addr_status_ro_w) begin
            case (proc_addr_w)
                8'h08: ro_read_data_r = status_reg_i;
                8'h09: ro_read_data_r = fps_counter_i;
                8'h0A: ro_read_data_r = heartbeat_i;
                8'h0C: ro_read_data_r = rotate_active_angle_i;
                8'h0D: ro_read_data_r = rotate_status_i;
                8'h0E: ro_read_data_r = rotate_debug0_i;
                default: ro_read_data_r = rotate_debug1_i;
            endcase
        end else if (addr_cam_ro_w) begin
            case (proc_addr_w[3:0])
                4'h3: ro_read_data_r = cam_rd_data_i;
                4'h4: ro_read_data_r = cam_status_i;
                4'h5: ro_read_data_r = cam_frame_count_i;
                4'h6: ro_read_data_r = cam_line_count_i;
                4'h7: ro_read_data_r = cam_last_pixel_i;
                default: ro_read_data_r = cam_error_count_i;
            endcase
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rx_idx_r                <= 3'd0;
            rx_active_r             <= 1'b0;
            frame_cmd_r             <= 8'h00;
            frame_addr_r            <= 8'h00;
            frame_value_r           <= 16'h0000;

            ctrl_shadow_r[0] <= 16'h0000;
            ctrl_shadow_r[1] <= 16'h0001;
            ctrl_shadow_r[2] <= BRIGHTNESS_DEFAULT;
            ctrl_shadow_r[3] <= 16'h0000;
            ctrl_shadow_r[4] <= 16'h0000;
            ctrl_shadow_r[5] <= 16'h0000;
            ctrl_shadow_r[6] <= 16'h0000;
            ctrl_shadow_r[7] <= 16'h0000;
            rotate_angle_deg_r <= 16'h0000;
            rotate_cfg_toggle_r <= 1'b0;
            cam_shadow_r[0] <= 16'h0000;
            cam_shadow_r[1] <= 16'h0000;
            cam_shadow_r[2] <= 16'h0000;

            tx_active_r             <= 1'b0;
            tx_idx_r                <= 3'd0;
            resp_status_r           <= STATUS_OK;
            resp_addr_r             <= 8'h00;
            resp_value_r            <= 16'h0000;

            rw_read_pending_r       <= 1'b0;
            rw_read_addr_r          <= 8'h00;
            rw_read_index_r         <= 4'd0;
            boot_brightness_init_r  <= 1'b1;
            rw_mem_wren_r           <= 1'b0;
            rw_mem_waddr_r          <= 4'd0;
            rw_mem_wdata_r          <= 16'h0000;
            cmd_fifo_wr_ptr_r       <= 3'd0;
            cmd_fifo_rd_ptr_r       <= 3'd0;
            cmd_fifo_count_r        <= 4'd0;
        end else begin
            rw_mem_wren_r <= 1'b0;

            if (boot_brightness_init_r) begin
                rw_mem_wren_r          <= 1'b1;
                rw_mem_waddr_r         <= 4'd2;
                rw_mem_wdata_r         <= BRIGHTNESS_DEFAULT;
                boot_brightness_init_r <= 1'b0;
            end

            if (rw_read_pending_r && !tx_active_r) begin
                resp_status_r     <= STATUS_OK;
                resp_addr_r       <= rw_read_addr_r;
                resp_value_r      <= rw_shadow_read_data_fn(rw_read_addr_r);
                tx_active_r       <= 1'b1;
                tx_idx_r          <= 3'd0;
                rw_read_pending_r <= 1'b0;
            end else if (!tx_active_r && (cmd_fifo_count_r != 4'd0)) begin
                cmd_fifo_count_r <= cmd_fifo_count_r - 4'd1;
                cmd_fifo_rd_ptr_r <= cmd_fifo_rd_ptr_r + 3'd1;
                resp_addr_r  <= proc_addr_w;
                resp_value_r <= 16'h0000;

                if (!proc_csum_ok_w) begin
                    resp_status_r <= STATUS_CSUM;
                    tx_active_r   <= 1'b1;
                    tx_idx_r      <= 3'd0;
                end else if (proc_cmd_w == CMD_PING) begin
                    resp_status_r <= STATUS_OK;
                    resp_addr_r   <= 8'h00;
                    tx_active_r   <= 1'b1;
                    tx_idx_r      <= 3'd0;
                end else if (proc_cmd_w == CMD_READ) begin
                    if (!read_addr_valid_w) begin
                        resp_status_r <= STATUS_ADDR;
                        tx_active_r   <= 1'b1;
                        tx_idx_r      <= 3'd0;
                    end else if (addr_status_ro_w || addr_cam_ro_w) begin
                        resp_status_r <= STATUS_OK;
                        resp_value_r  <= ro_read_data_r;
                        tx_active_r   <= 1'b1;
                        tx_idx_r      <= 3'd0;
                    end else if (use_boot_brightness_w) begin
                        resp_status_r <= STATUS_OK;
                        resp_value_r  <= BRIGHTNESS_DEFAULT;
                        tx_active_r   <= 1'b1;
                        tx_idx_r      <= 3'd0;
                    end else begin
                        rw_read_pending_r <= 1'b1;
                        rw_read_addr_r    <= proc_addr_w;
                        rw_read_index_r   <= rw_index_w;
                    end
                end else if (proc_cmd_w == CMD_WRITE) begin
                    if (rw_read_addr_valid_w) begin
                        resp_status_r <= STATUS_OK;
                        resp_value_r  <= proc_value_w;
                        rw_mem_wren_r  <= 1'b1;
                        rw_mem_waddr_r <= rw_index_w;
                        rw_mem_wdata_r <= proc_value_w;
                        tx_active_r    <= 1'b1;
                        tx_idx_r       <= 3'd0;
                        if (addr_ctrl_main_rw_w) begin
                            ctrl_shadow_r[proc_addr_w[2:0]] <= proc_value_w;
                        end else if (addr_rotate_angle_rw_w) begin
                            rotate_angle_deg_r <= proc_value_w;
                            rotate_cfg_toggle_r <= ~rotate_cfg_toggle_r;
                        end else begin
                            cam_shadow_r[proc_addr_w[1:0]] <= proc_value_w;
                        end
                    end else begin
                        resp_status_r <= STATUS_ADDR;
                        tx_active_r   <= 1'b1;
                        tx_idx_r      <= 3'd0;
                    end
                end else begin
                    resp_status_r <= STATUS_CMD;
                    tx_active_r   <= 1'b1;
                    tx_idx_r      <= 3'd0;
                end
            end

            if (tx_active_r && tx_ready_i) begin
                if (tx_idx_r == 3'd5) begin
                    tx_active_r <= 1'b0;
                    tx_idx_r    <= 3'd0;
                end else begin
                    tx_idx_r <= tx_idx_r + 3'd1;
                end
            end

            if (rx_valid_i) begin
                if (!rx_active_r) begin
                    if (rx_data_i == FRAME_HEAD) begin
                        rx_active_r <= 1'b1;
                        rx_idx_r    <= 3'd1;
                    end
                end else begin
                    case (rx_idx_r)
                        3'd1: begin
                            frame_cmd_r <= rx_data_i;
                            rx_idx_r    <= 3'd2;
                        end
                        3'd2: begin
                            frame_addr_r <= rx_data_i;
                            rx_idx_r     <= 3'd3;
                        end
                        3'd3: begin
                            frame_value_r[15:8] <= rx_data_i;
                            rx_idx_r            <= 3'd4;
                        end
                        3'd4: begin
                            frame_value_r[7:0] <= rx_data_i;
                            rx_idx_r           <= 3'd5;
                        end
                        default: begin
                            rx_active_r <= 1'b0;
                            rx_idx_r    <= 3'd0;

                            if (cmd_fifo_count_r < CMD_FIFO_DEPTH) begin
                                cmd_fifo_cmd_r[cmd_fifo_wr_ptr_r] <= frame_cmd_r;
                                cmd_fifo_addr_r[cmd_fifo_wr_ptr_r] <= frame_addr_r;
                                cmd_fifo_value_r[cmd_fifo_wr_ptr_r] <= frame_value_r;
                                cmd_fifo_csum_ok_r[cmd_fifo_wr_ptr_r] <=
                                    frame_checksum_ok(frame_cmd_r, frame_addr_r, frame_value_r, rx_data_i);
                                cmd_fifo_wr_ptr_r <= cmd_fifo_wr_ptr_r + 3'd1;
                                cmd_fifo_count_r <= cmd_fifo_count_r + 4'd1;
                            end
                        end
                    endcase
                end
            end
        end
    end

endmodule
