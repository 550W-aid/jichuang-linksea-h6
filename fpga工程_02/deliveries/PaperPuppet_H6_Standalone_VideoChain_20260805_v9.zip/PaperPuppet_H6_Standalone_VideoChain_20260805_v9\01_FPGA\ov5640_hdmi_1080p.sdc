#
# Timing and CDC constraints for ov5640_hdmi_1080p.
# The project-local compile flow explicitly calls read_sdc before
# create_timing_group; keep this file limited to commands accepted by the native
# eLinx route/timer parser.
#
set sdc_version 2.0

create_clock -name sys_clk -period 20.000 [get_ports {sys_clk}]
# OV5640: 24 MHz / prediv 3 * PLL 84 / sysdiv 2 / PCLK div 4 = 84 MHz.
# Registers: 3037=13, 3036=54, 3035=21, 3824=04.
create_clock -name ov5640_pclk -period 13.333 [get_ports {ov5640_pclk}]
create_clock -name eth_rxc -period 8.000 [get_ports {eth_rxc}]

# Capture the PHY's source-synchronous GMII data on the falling edge of
# eth_rxc and keep the nine input registers physically close to their pads.
set_input_delay -clock [get_clocks {eth_rxc}] -max 2.000 [get_ports {eth_rx_ctl eth_rxd[0] eth_rxd[1] eth_rxd[2] eth_rxd[3] eth_rxd[4] eth_rxd[5] eth_rxd[6] eth_rxd[7]}]
set_input_delay -clock [get_clocks {eth_rxc}] -min 4.500 [get_ports {eth_rx_ctl eth_rxd[0] eth_rxd[1] eth_rxd[2] eth_rxd[3] eth_rxd[4] eth_rxd[5] eth_rxd[6] eth_rxd[7]}]

# GMII TX data launches from the recovered eth_rxc clock and the same 125 MHz
# is forwarded through GTX_CLK. This native timer parses -reference_pin but does
# not include the routed GTX reference latency in output slack. Constrain the
# equivalent board-facing setup/hold check after route instead of creating a
# broken c0-to-c1 path group. scripts/check_gmii_output_timing.py gates all nine
# GMII outputs before bitgen without making the native placer optimize them.

# The SiI9134 I2C driver toggles every 25 sys_clk cycles (1 MHz full clock).
create_clock -name {\eth_video_rotate_system:u_eth_video_rotate_system|sil9134_dri:hdmi_ctrl_inst|i2c_dri:inst_i2c_sil9134_dri|dri_clk} -period 1000.000 [get_nets {\eth_video_rotate_system:u_eth_video_rotate_system|sil9134_dri:hdmi_ctrl_inst|i2c_dri:inst_i2c_sil9134_dri|dri_clk}]

# The merged design has independent board, camera, Ethernet, SDRAM, and HDMI
# domains. RTL uses explicit synchronizers/FIFOs at those boundaries. Native
# eLinx is more reliable with explicit one-line false paths than with a multiline
# clock-group command inside the generated run.psf.

set_input_delay -clock [get_clocks {ov5640_pclk}] -max 4.500 [get_ports {ov5640_data[0] ov5640_data[1] ov5640_data[2] ov5640_data[3] ov5640_data[4] ov5640_data[5] ov5640_data[6] ov5640_data[7]}]
set_input_delay -clock [get_clocks {ov5640_pclk}] -min -1.000 [get_ports {ov5640_data[0] ov5640_data[1] ov5640_data[2] ov5640_data[3] ov5640_data[4] ov5640_data[5] ov5640_data[6] ov5640_data[7]}]
set_input_delay -clock [get_clocks {ov5640_pclk}] -max 4.500 [get_ports {ov5640_href}]
set_input_delay -clock [get_clocks {ov5640_pclk}] -min -1.000 [get_ports {ov5640_href}]
set_input_delay -clock [get_clocks {ov5640_pclk}] -max 4.500 [get_ports {ov5640_vsync}]
set_input_delay -clock [get_clocks {ov5640_pclk}] -min -1.000 [get_ports {ov5640_vsync}]
# VSYNC is a frame-level control held for many PCLKs. The dedicated IO
# synchronizer may consume one extra cycle without changing RGB565 byte or
# line pairing; keep data/HREF on the normal single-cycle input gate.
set_multicycle_path -setup 2 -from [get_ports {ov5640_vsync}] -to [get_pins {*|ov5640_vsync_io_pclk_r*|ff/D}]
set_multicycle_path -hold 1 -from [get_ports {ov5640_vsync}] -to [get_pins {*|ov5640_vsync_io_pclk_r*|ff/D}]

# Startup/reset cleanup.
# Board reset and PLL lock release are asynchronous bring-up controls, not
# frame/video datapaths. They fan out to async clear pins across generated clock
# domains, so recovery/removal is handled by holding reset through PLL lock and
# must not be scored as a normal data path in the native slack matrix.
set_false_path -from [get_ports {sys_rst_n}] -to [get_pins {*|ff/aclr}]
set_false_path -from [get_cells {*clk_gen_inst*altpll_component*}] -to [get_pins {*|ff/aclr}]

# Coarse clock-domain cuts.
set_false_path -from [get_clocks {sys_clk}] -to [get_clocks {ov5640_pclk}]
set_false_path -from [get_clocks {ov5640_pclk}] -to [get_clocks {sys_clk}]
set_false_path -from [get_clocks {sys_clk}] -to [get_clocks {eth_rxc}]
set_false_path -from [get_clocks {eth_rxc}] -to [get_clocks {sys_clk}]
set_false_path -from [get_clocks {sys_clk}] -to [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk0}]
set_false_path -from [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk0}] -to [get_clocks {sys_clk}]
set_false_path -from [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk0}] -to [get_clocks {ov5640_pclk}]
set_false_path -from [get_clocks {ov5640_pclk}] -to [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk0}]
set_false_path -from [get_clocks {eth_rxc}] -to [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk0}]
set_false_path -from [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk0}] -to [get_clocks {eth_rxc}]
set_false_path -from [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk0}] -to [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk2}]
set_false_path -from [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk2}] -to [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk0}]
set_false_path -from [get_clocks {sys_clk}] -to [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk4}]
set_false_path -from [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk4}] -to [get_clocks {sys_clk}]
set_false_path -from [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk0}] -to [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk4}]
set_false_path -from [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk4}] -to [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk0}]
set_false_path -from [get_clocks {ov5640_pclk}] -to [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk4}]
set_false_path -from [get_clocks {\eth_video_rotate_system:u_eth_video_rotate_system|clk_gen:clk_gen_inst|altpll:altpll_component|_clk4}] -to [get_clocks {ov5640_pclk}]

# Slow rotate-angle control uses cdc_word_toggle: req/data cross into the HDMI
# pixel domain and ack crosses back. Only the first synchronizer stage is cut.
set_false_path -from [get_pins {*|rotate_stream_overlay_inst|u_rotate_angle_cdc|src_req_toggle_r*|ff/Q}] -to [get_pins {*|rotate_stream_overlay_inst|u_rotate_angle_cdc|dst_req_meta_r*|ff/D}]
set_false_path -from [get_pins {*|rotate_stream_overlay_inst|u_rotate_angle_cdc|src_bit_r*|ff/Q}] -to [get_pins {*|rotate_stream_overlay_inst|u_rotate_angle_cdc|dst_bit_meta_r*|ff/D}]
set_false_path -from [get_pins {*|rotate_stream_overlay_inst|u_rotate_angle_cdc|dst_*|ff/Q}] -to [get_pins {*|rotate_stream_overlay_inst|u_rotate_angle_cdc|src_ack_meta_r*|ff/D}]

# GUI low-light enable/level uses the same acknowledged bit-serial CDC to move
# one coherent 10-bit control word from sys_clk into the HDMI pixel domain.
set_false_path -from [get_pins {*|shader_control_cdc_inst|src_req_toggle_r*|ff/Q}] -to [get_pins {*|shader_control_cdc_inst|dst_req_meta_r*|ff/D}]
set_false_path -from [get_pins {*|shader_control_cdc_inst|src_bit_r*|ff/Q}] -to [get_pins {*|shader_control_cdc_inst|dst_bit_meta_r*|ff/D}]
set_false_path -from [get_pins {*|shader_control_cdc_inst|dst_*|ff/Q}] -to [get_pins {*|shader_control_cdc_inst|src_ack_meta_r*|ff/D}]

# System/HDMI status handshakes use two-stage bit synchronizers.
set_false_path -to [get_pins {*|ov5640_top_inst|sys_init_done_meta_pclk_r*|ff/D}]
set_false_path -to [get_pins {*|hdmi_cfg_done_meta_r*|ff/D}]

set_false_path -from [get_pins {*|display_enable_r*|ff/Q}] -to [get_pins {*|frame_ready_meta_hdmi_r*|ff/D}]
# HDMI-to-system status is already covered by the _clk4-to-sys_clk coarse cut.
# Do not name its first-stage register here: diagnostic UART builds remove the
# unused status readback, and this native SDC parser has no conditional command.

# Ethernet diagnostic event counters use tx-domain toggles that are counted in
# sys_clk after two-stage synchronization. Cut only the first sync stage.
set_false_path -from [get_pins {*|eth_board_bringup_inst|eth_arp_req_toggle_tx*|ff/Q}] -to [get_pins {*|eth_board_bringup_inst|eth_arp_req_toggle_sys_d0*|ff/D}]
set_false_path -from [get_pins {*|eth_board_bringup_inst|eth_arp_en_toggle_tx*|ff/Q}] -to [get_pins {*|eth_board_bringup_inst|eth_arp_en_toggle_sys_d0*|ff/D}]
set_false_path -from [get_pins {*|eth_board_bringup_inst|eth_arp_done_toggle_tx*|ff/Q}] -to [get_pins {*|eth_board_bringup_inst|eth_arp_done_toggle_sys_d0*|ff/D}]
set_false_path -from [get_pins {*|eth_board_bringup_inst|eth_udp_tx_start_toggle_tx*|ff/Q}] -to [get_pins {*|eth_board_bringup_inst|eth_udp_tx_start_toggle_sys_d0*|ff/D}]
set_false_path -from [get_pins {*|eth_board_bringup_inst|eth_raw_rx_toggle_rx*|ff/Q}] -to [get_pins {*|eth_board_bringup_inst|eth_raw_rx_toggle_sys_d0*|ff/D}]
set_false_path -from [get_pins {*|eth_board_bringup_inst|eth_rx_pkt_toggle_rx*|ff/Q}] -to [get_pins {*|eth_board_bringup_inst|eth_rx_pkt_toggle_sys_d0*|ff/D}]

# Ethernet RX last-length/last-byte debug uses a second cdc_word_toggle channel.
set_false_path -from [get_pins {*|eth_board_bringup_inst|u_rx_last_info_cdc|src_req_toggle_r*|ff/Q}] -to [get_pins {*|eth_board_bringup_inst|u_rx_last_info_cdc|dst_req_meta_r*|ff/D}]
set_false_path -from [get_pins {*|eth_board_bringup_inst|u_rx_last_info_cdc|src_bit_r*|ff/Q}] -to [get_pins {*|eth_board_bringup_inst|u_rx_last_info_cdc|dst_bit_meta_r*|ff/D}]
set_false_path -from [get_pins {*|eth_board_bringup_inst|u_rx_last_info_cdc|dst_*|ff/Q}] -to [get_pins {*|eth_board_bringup_inst|u_rx_last_info_cdc|src_ack_meta_r*|ff/D}]

# Ethernet video-to-SDRAM packet bridge uses write-domain ack toggles returned
# to eth_rxc through two-stage synchronizers, plus a write-reset request sampled
# into eth_rxc. Cut only those first synchronizer stages.
set_false_path -from [get_pins {*|eth_video_rx_to_sdram_inst|ack0_toggle_wr_r*|ff/Q}] -to [get_pins {*|eth_video_rx_to_sdram_inst|ack0_eth_sync_r[0]*|ff/D}]
set_false_path -from [get_pins {*|eth_video_rx_to_sdram_inst|ack1_toggle_wr_r*|ff/Q}] -to [get_pins {*|eth_video_rx_to_sdram_inst|ack1_eth_sync_r[0]*|ff/D}]
set_false_path -from [get_pins {*|wr_rst_cnt_r*|ff/Q}] -to [get_pins {*|wr_rst_eth_sync_r[0]*|ff/D}]

# wr_rst_cnt_r drives the dynamic clear for the SDRAM write-side FIFOs. It is a
# stretched, local clk_100m control used to drop a partial tail before switching
# frame slots; the dcfifo async-clear recovery/removal path is not a video data
# path and was the remaining _clk0 async-slack limiter after the HDMI overlay
# pipeline fix.
set_false_path -from [get_cells {*wr_rst_cnt_r*}] -to [get_cells {*wr_fifo_data*dcfifo*}]
# The same stretched write reset discards an invalid Ethernet frame from the
# clk_100m-to-PCLK bridge before the current SDRAM slot is reused.
set_false_path -from [get_cells {*wr_rst_cnt_r*}] -to [get_cells {*eth_sdram_fifo*dcfifo*}]

# rd_rst_cnt_r atomically clears the SDRAM read FIFOs whenever the displayed
# triple-buffer slot changes. This is the read-side counterpart of wr_rst_cnt_r.
set_false_path -from [get_cells {*rd_rst_cnt_r*}] -to [get_cells {*rd_fifo_data*dcfifo*}]

# Vendor dcfifo internally synchronizes gray-coded pointers between write/read
# clocks. Cut only those generated synchronizer first-stage paths.
set_false_path -from [get_pins {*|dcfifo|auto_generated|delayed_wrptr_g*|ff/Q}] -to [get_pins {*|dcfifo|auto_generated|read_sync_registers*|ff/D}]
set_false_path -from [get_pins {*|dcfifo|auto_generated|read_counter_for_write*|ff/Q}] -to [get_pins {*|dcfifo|auto_generated|write_sync_registers*|ff/D}]

set_false_path -from [get_cells {*u_rotate_angle_cdc*src_req_toggle_r*}] -to [get_cells {*u_rotate_angle_cdc*dst_req_meta_r*}]
set_false_path -from [get_cells {*u_rotate_angle_cdc*src_bit_r*}] -to [get_cells {*u_rotate_angle_cdc*dst_bit_meta_r*}]
set_false_path -from [get_cells {*u_rotate_angle_cdc*dst_*}] -to [get_cells {*u_rotate_angle_cdc*src_ack_meta_r*}]

set_false_path -from [get_cells {*eth_board_bringup_inst*eth_arp_req_toggle_tx*}] -to [get_cells {*eth_board_bringup_inst*eth_arp_req_toggle_sys_d0*}]
set_false_path -from [get_cells {*eth_board_bringup_inst*eth_arp_en_toggle_tx*}] -to [get_cells {*eth_board_bringup_inst*eth_arp_en_toggle_sys_d0*}]
set_false_path -from [get_cells {*eth_board_bringup_inst*eth_arp_done_toggle_tx*}] -to [get_cells {*eth_board_bringup_inst*eth_arp_done_toggle_sys_d0*}]
set_false_path -from [get_cells {*eth_board_bringup_inst*eth_udp_tx_start_toggle_tx*}] -to [get_cells {*eth_board_bringup_inst*eth_udp_tx_start_toggle_sys_d0*}]
set_false_path -from [get_cells {*eth_board_bringup_inst*eth_raw_rx_toggle_rx*}] -to [get_cells {*eth_board_bringup_inst*eth_raw_rx_toggle_sys_d0*}]
set_false_path -from [get_cells {*eth_board_bringup_inst*eth_rx_pkt_toggle_rx*}] -to [get_cells {*eth_board_bringup_inst*eth_rx_pkt_toggle_sys_d0*}]

set_false_path -from [get_cells {*u_rx_last_info_cdc*src_req_toggle_r*}] -to [get_cells {*u_rx_last_info_cdc*dst_req_meta_r*}]
set_false_path -from [get_cells {*u_rx_last_info_cdc*src_bit_r*}] -to [get_cells {*u_rx_last_info_cdc*dst_bit_meta_r*}]
set_false_path -from [get_cells {*u_rx_last_info_cdc*dst_*}] -to [get_cells {*u_rx_last_info_cdc*src_ack_meta_r*}]

set_false_path -from [get_cells {*eth_video_rx_to_sdram_inst*ack0_toggle_wr_r*}] -to [get_cells {*eth_video_rx_to_sdram_inst*ack0_eth_sync_r*}]
set_false_path -from [get_cells {*eth_video_rx_to_sdram_inst*ack1_toggle_wr_r*}] -to [get_cells {*eth_video_rx_to_sdram_inst*ack1_eth_sync_r*}]
set_false_path -from [get_cells {*wr_rst_cnt_r*}] -to [get_cells {*wr_rst_eth_sync_r*}]

set_false_path -from [get_cells {*dcfifo*delayed_wrptr_g*}] -to [get_cells {*dcfifo*read_sync_registers*}]
set_false_path -from [get_cells {*dcfifo*read_counter_for_write*}] -to [get_cells {*dcfifo*write_sync_registers*}]
# STM32F407 FSMC is an asynchronous SRAM-style interface. The firmware keeps
# address/control stable long enough for these absolute board-level limits.
set_max_delay -from [get_ports {fsmc_addr[0] fsmc_addr[1] fsmc_addr[2] fsmc_addr[3] fsmc_addr[4] fsmc_addr[5] fsmc_addr[6] fsmc_addr[7]}] -to [get_ports {fsmc_data[0] fsmc_data[1] fsmc_data[2] fsmc_data[3] fsmc_data[4] fsmc_data[5] fsmc_data[6] fsmc_data[7] fsmc_data[8] fsmc_data[9] fsmc_data[10] fsmc_data[11] fsmc_data[12] fsmc_data[13] fsmc_data[14] fsmc_data[15]}] 20.000
set_max_delay -from [get_ports {fsmc_cs_n fsmc_rd_n}] -to [get_ports {fsmc_data[0] fsmc_data[1] fsmc_data[2] fsmc_data[3] fsmc_data[4] fsmc_data[5] fsmc_data[6] fsmc_data[7] fsmc_data[8] fsmc_data[9] fsmc_data[10] fsmc_data[11] fsmc_data[12] fsmc_data[13] fsmc_data[14] fsmc_data[15]}] 5.000
