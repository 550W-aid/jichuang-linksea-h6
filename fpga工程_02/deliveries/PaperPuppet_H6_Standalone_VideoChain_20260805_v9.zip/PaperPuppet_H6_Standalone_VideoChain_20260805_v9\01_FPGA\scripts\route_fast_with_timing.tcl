set scriptDir [file dirname [file normalize [info script]]]
set dir [file normalize [file join $scriptDir ".."]]
cd "D:/eLinx3.0/bin/shell/bin"
set prj ov5640_hdmi_1080p
set topEntity TOP1
set seriesName "eHiChip6"
set deviceName "EQ6HL130"
set packageName "CSG484_H"
set synthName synth_1
set ImpleName imple_1
source [file join $scriptDir "run_route_fast_with_timing.tcl"]
run_route $dir $prj $topEntity $seriesName $deviceName $packageName $synthName $ImpleName
exit 0
